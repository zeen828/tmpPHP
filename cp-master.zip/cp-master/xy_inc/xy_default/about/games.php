﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="IE=EmulateIE8" http-equiv="X-UA-Compatible">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>黄金城游艺－<?=$this->settings['webName']?></title>
<link href="/favicon.ico" rel="shortcut icon" type="image/x-icon">
<script type="text/javascript" src="/skin/js/jquery-1.8.0.min.js"></script>
<link rel="stylesheet" href="/cl/standard.css">
<link rel="stylesheet" href="/cl/wj43.css">
<link rel="stylesheet" href="/cl/about.css">
</head>
<body lim:visitorcapacity="1">
<?php $this->display('inc_header3.php'); ?>
<!-- CONTENT start -->
<div class="innerMain">

  <!-- GAMES start -->
	<section id="games">
		<!--<div class="hr"></div>-->
    	<div class="pic banner3">
        <div class="quote-shadow"></div>
        <div class="banner-mask">
        	<div class="wrap">
            <div class="quote">
            <span style="font-size:30px; ">精益求精的游戏</span><br>
            <span style="font-size:24px; ">游戈在你我手中</span>
            <div class="line">&nbsp;</div>
            <charle class="size22">LOTTERY &amp; BINGO</charle><br>
            <charle class="size12">WE ALSO HAVE</charle><br>
            <charle class="size15">thousand FUNNY GAMES FOR YOU</charle>
            </div>
            </div>
        </div>
        </div>
    	<div class="hr"></div>
		<div class="title wrap">黄金城游艺
        	<charle>GAMES</charle>
			<div class="intro">
            	<p>黄金城娱乐提供，重庆时时彩，黑龙江时时彩，天津时时彩，新疆时时彩，上海时时乐，福彩3D, 排列三、五，北京快乐8，广东十一选五，重庆十一选五，江西多乐彩等涵盖各地福、体主流彩种。技术团队不断创新，开发更好娱乐产品， 以增加用户价值。技术领先正是黄金城的优质产品和服务理念，也是能够从竞争激烈的行业中脱颖而出的关键因素。即使面临再大挑战，黄金城仍然会为了提升客户体验而不遗余力! </p>
			</div>
		</div>
        
        <div class="pleft wrap">
        	<img src="/cl/about/icon_game_r1.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">重庆时时彩<br><charle>CHONGQING SHISHICAI</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>重庆时时彩是国内第一个快开彩票，也是国内第一个开设夜场的快开彩票。彩票以2元1注分为星彩玩法，大小单双等多种玩法进行投注。投注区分为万位,千位,百位,十位和个位，以0~9为号码进行投注。具有玩法简单、中奖率高、开奖快、即买即兑、赔率设奖，固定奖金等特点。自推出后一直备受彩民朋友的喜爱。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        <clear></clear>
		<div class="pright wrap">
        	<img src="/cl/about/icon_game_r5.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">新疆时时彩<br><charle>XINGJIANG SHISHICAI</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>新疆时时彩是一种开奖节奏快、中奖率高、玩法多样、简单的快开彩票，彩票投注区分为万位,千位,百位,十位和个位，以0~9为号码进行投注。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        
        <div class="pleft wrap">
        	<img src="/cl/about/icon_game_r6.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">黑龙江时时彩<br><charle>HEILONGJIANG SHISHICAI</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>黑龙江时时彩是一种开奖节奏快、中奖率高、玩法多样、简单的快开彩票，彩票投注区分为万位,千位,百位,十位和个位，以0~9为号码进行投注。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        <clear></clear>
		<div class="pright wrap">
        	<img src="/cl/about/icon_game_r14.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">天津时时彩<br><charle>TIANJING SHISHICAI</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>天津时时彩是一种开奖节奏快，玩法多样、简单，五星到大小单双应有尽有的快开彩票，彩票投注区分为万位,千位,百位,十位和个位，以0~9为号码进行投注，最高中奖率超过40%。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        
        <div class="pleft wrap">
        	<img src="/cl/about/icon_game_r4.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">上海时时乐<br><charle>SHANGHAI SHISHILE</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>上海时时乐又称天天彩选三，由中国福利彩票发行管理中心统一发行。彩票投注区分为百位,十位和个位，以0~9为号码进行投注。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        <clear></clear>
		<div class="pright wrap">
        	<img src="/cl/about/icon_game_r2.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">十一运夺金<br><charle>SHIYIYUN DUOJIN</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>十一运夺金是国内首个11选5玩法的彩票，由山东体彩中心为十一届全运会筹备场地建设资金开放的目前返奖率最高的彩票，其特点是玩法简单多样，中奖率高，返奖率高达59%。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        
        <div class="pleft wrap">
        	<img src="/cl/about/icon_game_r8.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">江西多乐彩<br><charle>JIANGXI DUOLECAI</charle><div class="shortline">&nbsp;</div></div>

            <claer>
            <p>江西多乐彩是一种开奖节奏快、玩法多样、简单的快开彩票，既可玩乐透，又可选排列，投注方式灵活，奖金固定，中奖率高。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        <clear></clear>
		<div class="pright wrap">
        	<img src="/cl/about/icon_game_r9.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">广东十一选五<br><charle>GUANGDONG 11XUAN5</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>广东十一选五是一种开奖快，返奖高，投注灵活，玩法多样的彩票，以01~11为号码进行投注，每期开出5个号码作为中奖号码。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        <div class="pleft wrap">
        	<img src="/cl/about/icon_game_r10.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">重庆十一选<br><charle>CHONGQING 11XUAN5</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>重庆十一选五是一种开奖节奏快、玩法多样、简单的快开彩票，包括任选一,任选二,任选三,任选四,任选五,任选六,任选七,任选八,前二直选,前二组选,前三直选,前三组选等多种玩法。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        <clear></clear>
		<div class="pright wrap">
        	<img src="/cl/about/icon_game_r11.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">福彩3D<br><charle>FUCAI 3D</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>福彩3D是一种以3位自然数为投注号码的彩票，投注号码由000—999组成。三个位置从左到右分别是"百位""十位""个位"，一组三个号码的排列或组合成为一体。</p>
			</claer></div>
            <clear></clear>
		</div>
        
        <div class="pleft wrap">
        	<img src="/cl/about/icon_game_r12.png" height="128" width="128">
            <div class="article">
            <div class="subtitle">排列三，五<br><charle>PAILIE 3 PAILIE 5</charle><div class="shortline">&nbsp;</div></div>
            <claer>
            <p>排列三，五是一种玩法简单，数字型玩法，更易组合和分析，智力型彩票。彩票投注区分为万位,千位,百位,十位和个位，以0~9为号码进行投注。"排列三"的中奖号码为当期摇出的全部中奖号码的前3位，"排列五"的中奖号码为当期摇出的全部中奖号码，每日进行开奖。</p>
			</claer></div>
            <clear></clear>
		</div>
        
    </section>
    <!-- GAMES end -->
    
</div>
<!-- CONTENT end -->
<?php $this->display('inc_footer2.php'); ?>
<script>
$(function() {
    $(".wjalert").live("click",function(){
		alert("对不起，请先登录");
		return false;
	})
});
</script>
</body></html>