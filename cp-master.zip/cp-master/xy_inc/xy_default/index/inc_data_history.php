﻿<table border='0' cellspacing='0' cellpadding='0' width="200px" height="100px" scrolling="auto">
<?php $this->display('index/inc_data_history_get.php', 0, 4); ?>
</table>