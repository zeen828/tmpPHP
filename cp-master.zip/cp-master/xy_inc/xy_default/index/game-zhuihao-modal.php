<div src="/index.php/index/zhuiHaoQs/" rel="2.00">
<table width="100%">
	<thead class="tr-top">
		<tr>
			<td><input type="checkbox" />
			<td>期号</td>
			<td>倍数</td>
			<td>金额</td>
			<td>开奖时间</td>
		</tr>
	</thead>
	<tbody  class="tr-cont">
		<!--
		<tr>
			<td><input type="checkbox" />
			<td>20120623-050</td>
			<td><input type="text" class="beishu" value="1"/></td>
			<td><span class="amount">2.00</span>元</td>
			<td>2012-06-23 12:35</td>
		</tr>
		-->
	</tbody>
</table>
</div>