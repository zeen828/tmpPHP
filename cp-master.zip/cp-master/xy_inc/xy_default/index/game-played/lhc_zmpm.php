<input type="hidden" name="playedGroup" value="<?=$this->groupId?>" />
<input type="hidden" name="playedId" value="<?=$this->played?>" />
<input type="hidden" name="type" value="<?=$this->type?>" />
	<div class="dGameStatus hklhc" action="tzlhcSelect" length="1">
    
        <span class="sTitle">正码<span class="sNote"><!--&nbsp;(&nbsp;最低限额：5&nbsp;)(&nbsp;单注限额：30,000&nbsp;)(&nbsp;单号限额：100,000&nbsp;)--></span></span>
        <table>
            <tbody><tr>
    
                <td class="boldborder">
                    <span title="01" class="sCBHKball_01"></span><span class="sRte" id="RteLO01" style="color: BLUE;"><?=$this->getLHCRte('RteLO01',$this->played)?></span><input type="text" maxlength="5" id="CdtLO01" name="LOTTO" acno="01">
                </td>
    
                <td class="boldborder">
                    <span title="11" class="sCBHKball_11"></span><span class="sRte" id="RteLO11" style="color: BLUE;"><?=$this->getLHCRte('RteLO11',$this->played)?></span><input type="text" maxlength="5" id="CdtLO11" name="LOTTO" acno="11">
                </td>
    
                <td class="boldborder">
                    <span title="21" class="sCBHKball_21"></span><span class="sRte" id="RteLO21" style="color: BLUE;"><?=$this->getLHCRte('RteLO21',$this->played)?></span><input type="text" maxlength="5" id="CdtLO21" name="LOTTO" acno="21">
                </td>
    
                <td class="boldborder">
                    <span title="31" class="sCBHKball_31"></span><span class="sRte" id="RteLO31" style="color: BLUE;"><?=$this->getLHCRte('RteLO31',$this->played)?></span><input type="text" maxlength="5" id="CdtLO31" name="LOTTO" acno="31">
                </td>
    
                <td class="">
                    <span title="41" class="sCBHKball_41"></span><span class="sRte" id="RteLO41" style="color: BLUE;"><?=$this->getLHCRte('RteLO41',$this->played)?></span><input type="text" maxlength="5" id="CdtLO41" name="LOTTO" acno="41">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="02" class="sCBHKball_02"></span><span class="sRte" id="RteLO02" style="color: BLUE;"><?=$this->getLHCRte('RteLO02',$this->played)?></span><input type="text" maxlength="5" id="CdtLO02" name="LOTTO" acno="02">
                </td>
    
                <td class="boldborder">
                    <span title="12" class="sCBHKball_12"></span><span class="sRte" id="RteLO12" style="color: BLUE;"><?=$this->getLHCRte('RteLO12',$this->played)?></span><input type="text" maxlength="5" id="CdtLO12" name="LOTTO" acno="12">
                </td>
    
                <td class="boldborder">
                    <span title="22" class="sCBHKball_22"></span><span class="sRte" id="RteLO22" style="color: BLUE;"><?=$this->getLHCRte('RteLO22',$this->played)?></span><input type="text" maxlength="5" id="CdtLO22" name="LOTTO" acno="22">
                </td>
    
                <td class="boldborder">
                    <span title="32" class="sCBHKball_32"></span><span class="sRte" id="RteLO32" style="color: BLUE;"><?=$this->getLHCRte('RteLO32',$this->played)?></span><input type="text" maxlength="5" id="CdtLO32" name="LOTTO" acno="32">
                </td>
    
                <td class="">
                    <span title="42" class="sCBHKball_42"></span><span class="sRte" id="RteLO42" style="color: BLUE;"><?=$this->getLHCRte('RteLO42',$this->played)?></span><input type="text" maxlength="5" id="CdtLO42" name="LOTTO" acno="42">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="03" class="sCBHKball_03"></span><span class="sRte" id="RteLO03" style="color: BLUE;"><?=$this->getLHCRte('RteLO03',$this->played)?></span><input type="text" maxlength="5" id="CdtLO03" name="LOTTO" acno="03">
                </td>
    
                <td class="boldborder">
                    <span title="13" class="sCBHKball_13"></span><span class="sRte" id="RteLO13" style="color: BLUE;"><?=$this->getLHCRte('RteLO13',$this->played)?></span><input type="text" maxlength="5" id="CdtLO13" name="LOTTO" acno="13">
                </td>
    
                <td class="boldborder">
                    <span title="23" class="sCBHKball_23"></span><span class="sRte" id="RteLO23" style="color: BLUE;"><?=$this->getLHCRte('RteLO23',$this->played)?></span><input type="text" maxlength="5" id="CdtLO23" name="LOTTO" acno="23">
                </td>
    
                <td class="boldborder">
                    <span title="33" class="sCBHKball_33"></span><span class="sRte" id="RteLO33" style="color: BLUE;"><?=$this->getLHCRte('RteLO33',$this->played)?></span><input type="text" maxlength="5" id="CdtLO33" name="LOTTO" acno="33">
                </td>
    
                <td class="">
                    <span title="43" class="sCBHKball_43"></span><span class="sRte" id="RteLO43" style="color: BLUE;"><?=$this->getLHCRte('RteLO43',$this->played)?></span><input type="text" maxlength="5" id="CdtLO43" name="LOTTO" acno="43">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="04" class="sCBHKball_04"></span><span class="sRte" id="RteLO04" style="color: BLUE;"><?=$this->getLHCRte('RteLO04',$this->played)?></span><input type="text" maxlength="5" id="CdtLO04" name="LOTTO" acno="04">
                </td>
    
                <td class="boldborder">
                    <span title="14" class="sCBHKball_14"></span><span class="sRte" id="RteLO14" style="color: BLUE;"><?=$this->getLHCRte('RteLO14',$this->played)?></span><input type="text" maxlength="5" id="CdtLO14" name="LOTTO" acno="14">
                </td>
    
                <td class="boldborder">
                    <span title="24" class="sCBHKball_24"></span><span class="sRte" id="RteLO24" style="color: BLUE;"><?=$this->getLHCRte('RteLO24',$this->played)?></span><input type="text" maxlength="5" id="CdtLO24" name="LOTTO" acno="24">
                </td>
    
                <td class="boldborder">
                    <span title="34" class="sCBHKball_34"></span><span class="sRte" id="RteLO34" style="color: BLUE;"><?=$this->getLHCRte('RteLO34',$this->played)?></span><input type="text" maxlength="5" id="CdtLO34" name="LOTTO" acno="34">
                </td>
    
                <td class="">
                    <span title="44" class="sCBHKball_44"></span><span class="sRte" id="RteLO44" style="color: BLUE;"><?=$this->getLHCRte('RteLO44',$this->played)?></span><input type="text" maxlength="5" id="CdtLO44" name="LOTTO" acno="44">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="05" class="sCBHKball_05"></span><span class="sRte" id="RteLO05" style="color: BLUE;"><?=$this->getLHCRte('RteLO05',$this->played)?></span><input type="text" maxlength="5" id="CdtLO05" name="LOTTO" acno="05">
                </td>
    
                <td class="boldborder">
                    <span title="15" class="sCBHKball_15"></span><span class="sRte" id="RteLO15" style="color: BLUE;"><?=$this->getLHCRte('RteLO15',$this->played)?></span><input type="text" maxlength="5" id="CdtLO15" name="LOTTO" acno="15">
                </td>
    
                <td class="boldborder">
                    <span title="25" class="sCBHKball_25"></span><span class="sRte" id="RteLO25" style="color: BLUE;"><?=$this->getLHCRte('RteLO25',$this->played)?></span><input type="text" maxlength="5" id="CdtLO25" name="LOTTO" acno="25">
                </td>
    
                <td class="boldborder">
                    <span title="35" class="sCBHKball_35"></span><span class="sRte" id="RteLO35" style="color: BLUE;"><?=$this->getLHCRte('RteLO35',$this->played)?></span><input type="text" maxlength="5" id="CdtLO35" name="LOTTO" acno="35">
                </td>
    
                <td class="">
                    <span title="45" class="sCBHKball_45"></span><span class="sRte" id="RteLO45" style="color: BLUE;"><?=$this->getLHCRte('RteLO45',$this->played)?></span><input type="text" maxlength="5" id="CdtLO45" name="LOTTO" acno="45">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="06" class="sCBHKball_06"></span><span class="sRte" id="RteLO06" style="color: BLUE;"><?=$this->getLHCRte('RteLO06',$this->played)?></span><input type="text" maxlength="5" id="CdtLO06" name="LOTTO" acno="06">
                </td>
    
                <td class="boldborder">
                    <span title="16" class="sCBHKball_16"></span><span class="sRte" id="RteLO16" style="color: BLUE;"><?=$this->getLHCRte('RteLO16',$this->played)?></span><input type="text" maxlength="5" id="CdtLO16" name="LOTTO" acno="16">
                </td>
    
                <td class="boldborder">
                    <span title="26" class="sCBHKball_26"></span><span class="sRte" id="RteLO26" style="color: BLUE;"><?=$this->getLHCRte('RteLO26',$this->played)?></span><input type="text" maxlength="5" id="CdtLO26" name="LOTTO" acno="26">
                </td>
    
                <td class="boldborder">
                    <span title="36" class="sCBHKball_36"></span><span class="sRte" id="RteLO36" style="color: BLUE;"><?=$this->getLHCRte('RteLO36',$this->played)?></span><input type="text" maxlength="5" id="CdtLO36" name="LOTTO" acno="36">
                </td>
    
                <td class="">
                    <span title="46" class="sCBHKball_46"></span><span class="sRte" id="RteLO46" style="color: BLUE;"><?=$this->getLHCRte('RteLO46',$this->played)?></span><input type="text" maxlength="5" id="CdtLO46" name="LOTTO" acno="46">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="07" class="sCBHKball_07"></span><span class="sRte" id="RteLO07" style="color: BLUE;"><?=$this->getLHCRte('RteLO07',$this->played)?></span><input type="text" maxlength="5" id="CdtLO07" name="LOTTO" acno="07">
                </td>
    
                <td class="boldborder">
                    <span title="17" class="sCBHKball_17"></span><span class="sRte" id="RteLO17" style="color: BLUE;"><?=$this->getLHCRte('RteLO17',$this->played)?></span><input type="text" maxlength="5" id="CdtLO17" name="LOTTO" acno="17">
                </td>
    
                <td class="boldborder">
                    <span title="27" class="sCBHKball_27"></span><span class="sRte" id="RteLO27" style="color: BLUE;"><?=$this->getLHCRte('RteLO27',$this->played)?></span><input type="text" maxlength="5" id="CdtLO27" name="LOTTO" acno="27">
                </td>
    
                <td class="boldborder">
                    <span title="37" class="sCBHKball_37"></span><span class="sRte" id="RteLO37" style="color: BLUE;"><?=$this->getLHCRte('RteLO37',$this->played)?></span><input type="text" maxlength="5" id="CdtLO37" name="LOTTO" acno="37">
                </td>
    
                <td class="">
                    <span title="47" class="sCBHKball_47"></span><span class="sRte" id="RteLO47" style="color: BLUE;"><?=$this->getLHCRte('RteLO47',$this->played)?></span><input type="text" maxlength="5" id="CdtLO47" name="LOTTO" acno="47">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="08" class="sCBHKball_08"></span><span class="sRte" id="RteLO08" style="color: BLUE;"><?=$this->getLHCRte('RteLO08',$this->played)?></span><input type="text" maxlength="5" id="CdtLO08" name="LOTTO" acno="08">
                </td>
    
                <td class="boldborder">
                    <span title="18" class="sCBHKball_18"></span><span class="sRte" id="RteLO18" style="color: BLUE;"><?=$this->getLHCRte('RteLO18',$this->played)?></span><input type="text" maxlength="5" id="CdtLO18" name="LOTTO" acno="18">
                </td>
    
                <td class="boldborder">
                    <span title="28" class="sCBHKball_28"></span><span class="sRte" id="RteLO28" style="color: BLUE;"><?=$this->getLHCRte('RteLO28',$this->played)?></span><input type="text" maxlength="5" id="CdtLO28" name="LOTTO" acno="28">
                </td>
    
                <td class="boldborder">
                    <span title="38" class="sCBHKball_38"></span><span class="sRte" id="RteLO38" style="color: BLUE;"><?=$this->getLHCRte('RteLO38',$this->played)?></span><input type="text" maxlength="5" id="CdtLO38" name="LOTTO" acno="38">
                </td>
    
                <td class="">
                    <span title="48" class="sCBHKball_48"></span><span class="sRte" id="RteLO48" style="color: BLUE;"><?=$this->getLHCRte('RteLO48',$this->played)?></span><input type="text" maxlength="5" id="CdtLO48" name="LOTTO" acno="48">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="09" class="sCBHKball_09"></span><span class="sRte" id="RteLO09" style="color: BLUE;"><?=$this->getLHCRte('RteLO09',$this->played)?></span><input type="text" maxlength="5" id="CdtLO09" name="LOTTO" acno="09">
                </td>
    
                <td class="boldborder">
                    <span title="19" class="sCBHKball_19"></span><span class="sRte" id="RteLO19" style="color: BLUE;"><?=$this->getLHCRte('RteLO19',$this->played)?></span><input type="text" maxlength="5" id="CdtLO19" name="LOTTO" acno="19">
                </td>
    
                <td class="boldborder">
                    <span title="29" class="sCBHKball_29"></span><span class="sRte" id="RteLO29" style="color: BLUE;"><?=$this->getLHCRte('RteLO29',$this->played)?></span><input type="text" maxlength="5" id="CdtLO29" name="LOTTO" acno="29">
                </td>
    
                <td class="boldborder">
                    <span title="39" class="sCBHKball_39"></span><span class="sRte" id="RteLO39" style="color: BLUE;"><?=$this->getLHCRte('RteLO39',$this->played)?></span><input type="text" maxlength="5" id="CdtLO39" name="LOTTO" acno="39">
                </td>
    
                <td class="">
                    <span title="49" class="sCBHKball_49"></span><span class="sRte" id="RteLO49" style="color: BLUE;"><?=$this->getLHCRte('RteLO49',$this->played)?></span><input type="text" maxlength="5" id="CdtLO49" name="LOTTO" acno="49">
                </td>
    </tr><tr>

                <td class="boldborder">
                    <span title="10" class="sCBHKball_10"></span><span class="sRte" id="RteLO10" style="color: BLUE;"><?=$this->getLHCRte('RteLO10',$this->played)?></span><input type="text" maxlength="5" id="CdtLO10" name="LOTTO" acno="10">
                </td>
    
                <td class="boldborder">
                    <span title="20" class="sCBHKball_20"></span><span class="sRte" id="RteLO20" style="color: BLUE;"><?=$this->getLHCRte('RteLO20',$this->played)?></span><input type="text" maxlength="5" id="CdtLO20" name="LOTTO" acno="20">
                </td>
    
                <td class="boldborder">
                    <span title="30" class="sCBHKball_30"></span><span class="sRte" id="RteLO30" style="color: BLUE;"><?=$this->getLHCRte('RteLO30',$this->played)?></span><input type="text" maxlength="5" id="CdtLO30" name="LOTTO" acno="30">
                </td>
    
                <td class="boldborder">
                    <span title="40" class="sCBHKball_40"></span><span class="sRte" id="RteLO40" style="color: BLUE;"><?=$this->getLHCRte('RteLO40',$this->played)?></span><input type="text" maxlength="5" id="CdtLO40" name="LOTTO" acno="40">
                </td>
    <td>&nbsp;</td>
</tr>

        </tbody></table>
         
        <table>
            <tbody><tr>
    
                <td width="60"><span class="sGameStatusItem">总大</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTBSOED" style="color: BLUE;"><?=$this->getLHCRte('RteLTTBSOED',$this->played)?></span><input type="text" maxlength="5" id="CdtLTTBSD" name="LTTBSOE" acno="总大"></td>
    
                <td width="60"><span class="sGameStatusItem">总小</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTBSOES" style="color: BLUE;"><?=$this->getLHCRte('RteLTTBSOES',$this->played)?></span><input type="text" maxlength="5" id="CdtLTTBSS" name="LTTBSOE" acno="总小"></td>
    
                <td width="60"><span class="sGameStatusItem">总单</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTBSOEO" style="color: BLUE;"><?=$this->getLHCRte('RteLTTBSOEO',$this->played)?></span><input type="text" maxlength="5" id="CdtLTTOEO" name="LTTBSOE" acno="总单"></td>
    
                <td width="60"><span class="sGameStatusItem">总双</span></td>
                <td class=""><span class="sRte" id="RteLTTBSOEE" style="color: BLUE;"><?=$this->getLHCRte('RteLTTBSOEE',$this->played)?></span><input type="text" maxlength="5" id="CdtLTTOEE" name="LTTBSOE" acno="总双"></td>
    </tr>

        </tbody></table>
        <div class="space"></div>
    </div>
    <div id="dResult">
        <input type="button" value="重设" onclick="resetTotalCredit();" name="重设">
        <input type="button" value="确定" onclick="bringRte();" name="确定">
        <span id="sTotalCredit" class="sTotal FontBold">0</span>
        <span>总计额度</span>
    </div>
    <div class="space"></div>
