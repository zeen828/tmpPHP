<meta content="IE=EmulateIE8" http-equiv="X-UA-Compatible" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" >
<title><?=$this->settings['webName']?></title>
<link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link href='/skin/main/bl_ococ.css' rel="stylesheet" type="text/css" />
<link href="/skin/css/wjstyle.css" rel="stylesheet" type="text/css">
<link href="/skin/css/hklhc.css" rel="stylesheet" type="text/css">
<link type="text/css" rel="stylesheet" href="/skin/js/jqueryui/skin/smoothness/jquery-ui-1.8.21.custom.css" />
<script type="text/javascript" src="/skin/js/jquery-1.8.0.min.js"></script>
<script type="text/javascript" src="/skin/js/hklhc.js"></script>
<script type="text/javascript" src="/skin/js/jquery.cookie.js"></script>
<script type="text/javascript" src="/skin/js/Array.ext.js"></script>
<script>var TIP=true;</script>
<script type="text/javascript" src="/skin/main/onload.js"></script>
<script type="text/javascript" src="/skin/main/function.js"></script>
<script type="text/javascript" src="/skin/js/jqueryui/jquery-ui-1.8.23.custom.min.js"></script>
<script type="text/javascript" src="/skin/js/jqueryui/i18n/jquery.ui.datepicker-zh-CN.js"></script>
<script type="text/javascript" src="/skin/js/jquery.messager.js"></script>
<script type="text/javascript" src="/skin/js/gamecommon.js"></script>
<!--[if IE 6]>
    <script src="/skin/js/DD_belatedPNG.js" type="text/javascript"></script>
    <script type="text/javascript">
    jQuery(document).ready(function() {
      jQuery('div.pricebox h3').unbind('click');
      jQuery('#header').removeClass('sprite');
      DD_belatedPNG.fix('.img-login,.img-bj,.img01,.img02,.logo');
    });
    </script>
<![endif]-->