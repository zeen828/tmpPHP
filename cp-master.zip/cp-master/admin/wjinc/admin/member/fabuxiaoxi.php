<form action="/admin778899.php/member/fabuxiaoxi_action" class="submit_link wz" target="ajax" call="addMember" method="post">
<table cellpadding="0" cellspacing="0" width="320" class="layout">
	<tr>
		<th>发布方式：</th>
		<td><label>群发<input type="radio" name="user" value="1" /></label> <label>用户名<input type="radio" name="user" value="2" checked="checked" /></label></td>
	</tr>
	<tr>
		<th></th>
		<td><input type="text" name="uid" /><span style="color:#F00">群发无需填写！</span></td>
	</tr>
	<tr>
		<th>消息标题：</th>
		<td><label><input type="text" name="title" /></label></td>
	</tr>
	<tr>
		<th>消息内容：</th>
		<td><textarea name="message" style="height:200px; width:250px;"></textarea></td>
	</tr>
	<tr>
		<th><span class="spn9"><input type="submit" value="提交"></span></th>
		<td><span class="spn9"></span></td>
	</tr>
</table>
</form>