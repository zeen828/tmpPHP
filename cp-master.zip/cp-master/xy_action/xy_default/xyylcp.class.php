﻿<?php
class xyylcp extends WebBase{
	public $title='黄金城娱乐自主研发五分彩';
	/**
	 * 获取信息页面
	 */
	public final function xml(){
		$this->display('xyyl/5fc.php');
	}
	public final function xml2(){
		$this->display('xyyl/2fc.php');
	}
	public final function xml3(){
		$this->display('xyyl/ffc.php');
	}
	public final function xml4(){
		$this->display('xyyl/lhc.php');
	}
}
