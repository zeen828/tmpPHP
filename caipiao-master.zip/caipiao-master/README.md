# caipiao
时时彩北京赛车等彩票源码
![banner](https://github.com/yuanma8/caipiao/blob/master/index.png)
cpadmin是thinkphp3.2写的后台用户管理程序
cpgo是beego后端程序
cpnode是webpack的前端程序，采用vue+golang前后端分离技术+会员管理则采用thinkphp
0：
数据库文件在cpgo/cp.sql导入后
1：
安装好nodejs
cd cpnode
运行npm run dev
根据提示安装好node_modules
打开http://localhost:8080就可以打开首页了
2：
cd cpgo
安装beego框架
编译运行golang后端程序
3：
执行node open.js采集程序
4:
安装php运行环境
cpadmin/admin
用户名admin
密码admin或xdmloveu
验证码可以乱输就可以登录了

承接各种网站,app程序制作QQ:925418469
