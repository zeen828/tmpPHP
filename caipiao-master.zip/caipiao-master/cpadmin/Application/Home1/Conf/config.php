<?php
return array(
    'UPDATE_URL' => 'http://update.qd.qiawei.com/',
    'NEWS_URL' => 'http://qwadmin.qiawei.com/api/news/',
    'Version' => '1.1'
);