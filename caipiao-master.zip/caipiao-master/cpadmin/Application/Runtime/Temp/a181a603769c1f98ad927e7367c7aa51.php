<?php
//000000000000a:6:{s:8:"sitename";s:7:"CPADMIN";s:5:"title";s:12:"彩票网络";s:8:"keywords";s:9:"关键词";s:11:"description";s:12:"网站描述";s:6:"footer";s:12:"2019©网络";s:4:"test";s:6:"测试";}
?>