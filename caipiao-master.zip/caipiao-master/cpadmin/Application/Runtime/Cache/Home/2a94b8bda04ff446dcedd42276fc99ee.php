<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cmn-Hans"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
	
<title>彩票2元网触屏版手机站-手机买彩票_竞彩_足彩_足球彩票_福利彩票_体育彩票</title>
	
<meta name="description" content="彩票2元网为中国彩民提供福利彩票(双色球、福彩3D等几十个彩种)、体育彩票(大乐透、七星彩、排列3等几十个彩种)、竞彩、单场、足彩等彩票大厅代购平台，是国内彩种最齐全的购彩网站之一。">
<meta name="keywords" content="彩票2元网,触屏版手机站,彩票,彩票网,福利彩票,中国福利彩票,体育彩票,足球彩票,手机彩票,wap彩票,即开型彩票,高频彩票,手机买彩票">
<meta name="author" content="author,email address">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta http-equiv="Cache-Control" content="no-siteapp">
<meta name="format-detection" content="telephone=no, email=no">
<meta name="msapplication-tap-highlight" content="no">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=0">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link type="text/css" rel="stylesheet" href="index_files/base.css">
<link type="text/css" rel="stylesheet" href="index_files/index.css">
</head><body>
<div id="loading" style="display: none;"><div><a></a></div></div>
<section id="index" class="I">
	
	<div class="indexNav" id="indexNav">
		<div class="indexNav1"><a href="news/about.jsp">彩票2元网</a><span></span><a href="signIn">注册登录</a></div>
		<div class="indexNav2">
			<a href="hemai/">大厅<i></i></a>
			<a href="draw/">开奖公告</a>
			<a href="zst/">走势图</a>
			<a href="zx/newslist">资讯</a>
			<!--<a href="/discover">发现<i></i></a>
			<a href="/activity/list" id="hasActive">活动中心</a> -->
		</div>
	</div>
	
	<div id="mainPage"><div class="banner" id="banner"><i onclick="cp2y.closeBanner();" id="closeBanner"></i><ul id="bannerWarp" ontouchstart="touch.touchStart(event)" ontouchmove="touch.touchMove(event);" ontouchend="touch.touchEnd();" style="width: 200%;"><li style="width: 50%;"><a href="zx/newsdetail?id=188176#page=1" target="_blank"><img src="index_files/pl5.png"></a></li><li style="width: 50%;"><a href="https://app.binguo.com/download/downloadH5" target="_blank"><img src="index_files/czj-h5-20170621.png"></a></li></ul><nav id="bannerNav"><a class=""></a><a class="cur"></a></nav></div><a href="lottery/10032?type=a0"><div class="playType"><div class="img2"><img src="index_files/10032.png"><span>双色球</span></div><div class="playTypeArea"><p class="p11">奖池:7.65亿元<i class="hot">今日开奖</i></p><p><span>066期奖号:</span><em>01</em><em>14</em><em>17</em><em>20</em><em>22</em><em>32</em><b>04</b></p></div></div></a><a href="lottery/10026?type=a0"><div class="playType"><div class="img2"><img src="index_files/10026.png"><span>超级大乐透</span></div><div class="playTypeArea"><p class="p11">推荐</p><p><span>066期奖号:</span><em>04</em><em>10</em><em>11</em><em>18</em><em>31</em><b>05</b><b>08</b></p></div></div></a><a href="lottery/10025?type=a0"><div class="playType"><div class="img2"><img src="index_files/10025.png"><span>福彩3D</span></div><div class="playTypeArea"><p class="p11">简单3位赢千元</p><p><span>54期奖号:</span><em>6</em><em>3</em><em>2</em></p></div></div></a><a href="lottery/10024?type=a0"><div class="playType"><div class="img2"><img src="index_files/10024.png"><span>排列3/5</span></div><div class="playTypeArea"><p class="p11">简单3个号 猜中赢千元</p><p><span>54期奖号:</span><em>3</em><em>7</em><em>8</em><em>3</em><em>8</em></p></div></div></a><a href="lottery/10059?type=a0"><div class="playType"><div class="img2"><img src="index_files/10059.png"><span>竞彩足球</span></div><div class="playTypeArea"><p class="p11">猜一场就中奖，73%高返奖！</p><p>2串1，易中奖</p></div></div></a><a href="lottery/10060?type=a14"><div class="playType"><div class="img2"><img src="index_files/10060.png"><span>江西11选5</span></div><div class="playTypeArea"><p class="p11">每日78场 单注赢千元</p><p><span>78期奖号:</span><em>05</em><em>01</em><em>09</em><em>08</em><em>10</em></p></div></div></a><a href="lottery/10061?type=a11"><div class="playType"><div class="img2"><img src="index_files/10061.png"><span>新时时彩</span></div><div class="playTypeArea"><p class="p11">返奖率高达59%</p><p><span>39期奖号:</span><em>0</em><em>5</em><em>7</em><em>8</em><em>7</em></p></div></div></a><a href="lottery/10064?type=a12"><div class="playType"><div class="img2"><img src="index_files/10064.png"><span>快乐十分</span></div><div class="playTypeArea"><p class="p11">10分钟一期,返奖率高达59%</p><p><span>97期奖号:</span><em>05</em><em> 12</em><em> 02</em><em> 08</em><em> 18</em><em> 09</em><em> 01</em><em> 15</em></p></div></div></a><a href="lottery/10046?type=a14"><div class="playType"><div class="img2"><img src="index_files/10046.png"><span>十一运夺金</span></div><div class="playTypeArea"><p class="p11">追号倍投收益高</p><p><span>78期奖号:</span><em>03</em><em>07</em><em>11</em><em>10</em><em>01</em></p></div></div></a><a href="lottery/10066?type=a14"><div class="playType"><div class="img2"><img src="index_files/10066.png"><span>11选5</span></div><div class="playTypeArea"><p class="p11">每天90期奖不停</p><p><span>期奖号:</span><em></em></p></div></div></a><a href="lottery/10057?type=a0"><div class="playType"><div class="img2"><img src="index_files/10057.png"><span>北京单场</span></div><div class="playTypeArea"><p class="p11">奖金浮动 适合搏冷</p><p>浮动奖金，2元可中500万</p></div></div></a><a href="lottery/10058?type=a0"><div class="playType"><div class="img2"><img src="index_files/10058.png"><span>竞彩篮球</span></div><div class="playTypeArea"><p class="p11">玩大小最易中</p><p>竞彩篮球</p></div></div></a><a href="lottery/10082?type=a0"><div class="playType"><div class="img2"><img src="index_files/10082.png"><span>快乐扑克</span></div><div class="playTypeArea"><p class="p11">10分钟变身款爷</p><p><span>34期奖号:</span><var class="pkIcon">黑桃:03</var>,<var class="pkIcon">红桃:04</var>,<var class="pkIcon">梅花:A</var></p></div></div></a><a href="lottery/10065?type=a3"><div class="playType"><div class="img2"><img src="index_files/10065.png"><span>新快三</span></div><div class="playTypeArea"><p class="p11">玩小骰子赚大钱</p><p><span>54期奖号:</span><em>1</em><em>6</em><em>6</em></p></div></div></a><a href="lottery/10038?type=a11"><div class="playType"><div class="img2"><img src="index_files/10038.png"><span>老时时彩</span></div><div class="playTypeArea"><p class="p11">五星奖金116000元</p><p><span>18期奖号:</span><em>5</em><em>7</em><em>4</em><em>5</em><em>7</em></p></div></div></a></div>
	<div class="indexBottom">
<!-- 		<div class="indexMoreBtn"><a href="/more">下载客户端</a></div> -->
		<div class="FaqTel"><a href="tel:4006667575" class="isbtn">免费客服:400-666-7575</a></div>
	</div>
</section>
<script src="index_files/hm.js"></script><script src="index_files/zepto.js"></script>
<script src="index_files/conf.js"></script>

<script>

WebAppUrl.HOME_APP_URL="";
</script>

<script src="index_files/index1.js"></script>








<script>
var _hmt = _hmt || [];

</script>


</body></html>