<?php
return array(
    'UPDATE_URL' => 'http://update.wei.com/',
    'NEWS_URL' => 'http://sqiawei.com/api/news/',
    'Version' => '1.1'
);