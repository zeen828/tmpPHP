
import java.io.UnsupportedEncodingException;
import java.util.List;

import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.action.AuxiliaryData;
import com.letousky.lottery.delegate.AbstractDelegate;
import com.letousky.lottery.util.Base64DecoderEncoder;

public class TestSellCount extends AbstractDelegate {

	public String[] T(String[] params) throws LotteryException {//查询
		String operaterCode = "C0200";
		String results = helpMessage(params, operaterCode);
		System.out.println("results---"+results);
		//System.out.println("new MessageTool().splitsList(results)----"+new MessageTool().splitsList(results));
		return new MessageTool().split(results);
	}
	
	public List TT(String[] params) throws LotteryException {//修改
		String operaterCode = "C0201";
		String results = helpMessage(params, operaterCode);
		System.out.println("results----"+results);
		System.out.println("jieguo---"+new MessageTool().splits(results));
		return new MessageTool().splits(results);
	}

	public static void main(String[] args) throws Exception {
		// 测试查找一条数据
/*		String sellUserId = "100001";
		String[]params=new String[1];
		params[0] = sellUserId;
		TestSellCount t=new TestSellCount();
		String[] array=t.T(params);
		sellUserId=array[0];
		String sellUserName=array[1];
		String postUrl=array[2];
		String argument=array[3];
		String canyuNum=array[4];
		System.out.println("userid----------"+sellUserId);
		System.out.println("sellUserName----------"+java.net.URLDecoder.decode(sellUserName, "UTF-8"));
		System.out.println("postUrl----------"+postUrl);
		System.out.println("argument----------"+argument);
		System.out.println("canyuNum----------"+canyuNum);*/
		
	
		
	
		//Object[] obj=list.toArray();
		//	String[] object=(String[])obj[0];
			//System.out.println("object---"+object[1]);
			//String[] object1=(String[])obj[1];
			//System.out.println("object1---"+object1[0]);
		


	
		
		//测试修改数据
/*		try {
			String sellUserId = "100001";
			String sellUserName="李发扬_1";
			sellUserName=Base64DecoderEncoder.encryptBASE64(sellUserName.getBytes());
			String postUrl="http://localhost:8080/jczg/member/reg.jsp?u=100001_1";
			String argument="100001_1";
			String canyuNum="1";
			String[]params=new String[5];
			params[0]=sellUserId;
			params[1]=sellUserName;
			params[2]=postUrl;
			params[3]=argument;
			params[4]=canyuNum;
			TestSellCount t=new TestSellCount();
			List list=t.TT(params);
			System.out.println("我的List的集合是---"+list);
			
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		
		List list=new AuxiliaryData().getZucaiIssue(new String[]{"102"});	
		System.out.println("list----"+list);
		
		
	}
}
