package com.anylotto.client;

import org.dom4j.*;

public class SafeXMLMsgBean extends SafeMsgBean{
	 
	  public Document getReceiveDoc() {
		    try {
		      String temp=super.getSrcMsg();
		      if(temp.length()>0){
		    	  return DocumentHelper.parseText(super.getSrcMsg());
		      }else{
		    	  return null;
		      }
		    }catch (Exception ex) {
		        ex.printStackTrace();
		        return null;
		    }
		  }

  public void setSendDoc(Document doc) throws Exception {
      super.setSrcMsg(doc.asXML());
  }
}
