package com.anylotto.client;

import java.net.*;
import java.io.*;
import org.dom4j.*;
import org.dom4j.io.*;
import java.util.*;


public class ReadXMLBean{
  private ArrayList props;  //存储原始数据
  public ReadXMLBean() {
      props = new ArrayList();
      init();
  }

  //初始化实例
    public void init(){
      props.clear();
    }

    //推入数据值
    public void set(String name, String value)
        throws Exception
    {
        if(name == null)
        {
            throw new Exception("属性名为空！");
        }
        if(value != null)
        {
            props.add(new Property(name, value));
        } else
        {
            props.add(new Property(name, ""));
        }
    }


    //数据串
    protected String getSrcMsg()
        throws Exception
    {
        String srcMsg = "";
        if(props.isEmpty())
        {
            throw new Exception("数据为空！");
        }
        for(int i = 0; i < props.size(); i++)
        {
            Property prop = (Property)props.get(i);
            if(srcMsg.length() > 0)
            {
                srcMsg = srcMsg + "&";
            }
            srcMsg = srcMsg + prop.name + "=" + prop.value;
        }
        return srcMsg;
    }


    public Element sendUrl(String urlstr) throws Exception {

      URL url = null;

      url = new URL(urlstr);
      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
      connection.setRequestMethod("POST");
      connection.setDoOutput(true);
      connection.setDoInput(true);
      PrintWriter out = new PrintWriter(connection.getOutputStream());

      out.println(getSrcMsg());
      out.flush();

      connection.connect();
      BufferedInputStream in = new BufferedInputStream(connection.getInputStream());
      SAXReader reader = new SAXReader();

        Document doc = reader.read(in);
        Element root = doc.getRootElement();
        Element foo;
              foo=root.element("VALUE");
              return foo;

 }

}
