package com.anylotto.client;

public class HttpParseXml {

	public String[] parseXml(String params){
		
		return null;
	}
}
