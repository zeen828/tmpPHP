package com.anylotto.client;

public class Property {
  public String name;
  public String value;

  public Property(String name, String value)
  {
      this.name = name;
      this.value = value;

  }

}
