package com.hessianService;
import com.hessianDTO.CPSBean;
/**
 * 定义了一个接口
 * @author y6
 *
 */
public interface CPSService {

	public CPSBean getCPSBean(String buyType,String buyInfo);//获取bean的接口
}
