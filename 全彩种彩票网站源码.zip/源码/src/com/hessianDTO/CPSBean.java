package com.hessianDTO;

import java.io.Serializable;

/***
 * 描叙:此类是hessian中的bean类,将它存放在对象里面,在jingcaile工程中通过hessuanAPI将其取出来
 * @author y6
 *
 */
public class CPSBean implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String buyType;// 购买类型 0:phone,1:email
	private String buyInfo;// 购买信息:手机(phone例如:13888546235)邮箱(email例如:3587965@126.com)
	
	/**
	 * 定义无参构造函数
	 */
	public CPSBean() {
		
	}

	/**
	 * 定义有参构造函数
	 * @param buyType
	 * @param buyInfo
	 */
	public CPSBean(String buyType, String buyInfo)
	{
		this.buyType = buyType;
		this.buyInfo = buyInfo;
	}
	
	public String getBuyType() {
		return buyType;
	}


	public void setBuyType(String buyType) {
		this.buyType = buyType;
	}

	public String getBuyInfo() {
		return buyInfo;
	}

	public void setBuyInfo(String buyInfo) {
		this.buyInfo = buyInfo;
	}
	

}
