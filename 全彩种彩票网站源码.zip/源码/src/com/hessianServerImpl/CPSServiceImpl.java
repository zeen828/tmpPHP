package com.hessianServerImpl;
import com.hessianDTO.CPSBean;
import com.hessianService.CPSService;
public class CPSServiceImpl implements CPSService{

	@Override
	public CPSBean getCPSBean(String buyType, String buyInfo) {
		return new CPSBean("1", "13887@126.com");
	}

}
