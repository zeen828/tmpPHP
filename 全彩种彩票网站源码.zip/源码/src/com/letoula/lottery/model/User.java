package com.letoula.lottery.model;

import java.util.List;

public class User {
	private String userId;
	private int     	flag;					//操作成功标示0：失败；1：成功	
	private String     clientUserSession;	    //用于验证用户及是否登录  登录成功时不可空
	private double     balance;				//可用余额
	private int     	score;				   	//积分
	private String     errorMessage;			//登录失败时提示
	private List     buyHistorylist;			//用户购买记录列表
	private String     bindStatus;				//判断用户绑定和资金充值状态
	private int     	bindStatusKey;			//判断用户绑定和资金充值状态   1,手机绑定，送3元彩金2,首次充值，送3元彩金3,绑定银行卡，充值提款忒方便
	private boolean   isIncome;				//是否充值
	private boolean   isMobileBinded;			//是否手机绑定
	private boolean   isPrize;					//是否中奖
	private String     username;				//用户名
	private double 	redBalance;				//红包余额
	private String password;					//密码
	private String rightMessage;				//正确提示
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getClientUserSession() {
		return clientUserSession;
	}
	public void setClientUserSession(String clientUserSession) {
		this.clientUserSession = clientUserSession;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
	public List getBuyHistorylist() {
		return buyHistorylist;
	}
	public void setBuyHistorylist(List buyHistorylist) {
		this.buyHistorylist = buyHistorylist;
	}
	public String getBindStatus() {
		return bindStatus;
	}
	public void setBindStatus(String bindStatus) {
		this.bindStatus = bindStatus;
	}
	public int getBindStatusKey() {
		return bindStatusKey;
	}
	public void setBindStatusKey(int bindStatusKey) {
		this.bindStatusKey = bindStatusKey;
	}
	public boolean isIncome() {
		return isIncome;
	}
	public void setIncome(boolean isIncome) {
		this.isIncome = isIncome;
	}
	public boolean isMobileBinded() {
		return isMobileBinded;
	}
	public void setMobileBinded(boolean isMobileBinded) {
		this.isMobileBinded = isMobileBinded;
	}
	public boolean isPrize() {
		return isPrize;
	}
	public void setPrize(boolean isPrize) {
		this.isPrize = isPrize;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public double getRedBalance() {
		return redBalance;
	}
	public void setRedBalance(double redBalance) {
		this.redBalance = redBalance;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRightMessage() {
		return rightMessage;
	}
	public void setRightMessage(String rightMessage) {
		this.rightMessage = rightMessage;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
