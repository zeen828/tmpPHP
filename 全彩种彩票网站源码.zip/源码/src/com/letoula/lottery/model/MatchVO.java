package com.letoula.lottery.model;

public class MatchVO {

}
