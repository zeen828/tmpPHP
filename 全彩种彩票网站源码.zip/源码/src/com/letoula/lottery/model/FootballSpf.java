package com.letoula.lottery.model;

import java.util.Date;

public class FootballSpf {
	private     String     sels;//销售奖期多个以逗号分割
	private     String     dayOfWeekStr;// 周四
	private     String     dayKey;//日期41207
	private     Integer     rowEnd;//过滤比赛数1
	private     String     cp2yEndTime;//销售截止时间41207.90625
	private     Integer     issueId;//数据库存储的奖期ID537805
	private     MatchVO     matchVO;//实体 
	private     String     matchCode;//赛程代号20121025001
	private     String     issue;//奖期别名20121025
	private     String     hostName;//主队名称利物浦
	private     String     guestName;//客队名称阿森纳
	private     String     leagueName;//赛事名称英超联赛
	private     String     matchTime;//比赛时间41208.2597222222
	private     Integer     order;//比赛场次0
	private     Integer     rate;//让球数主队让客队2球：2，客队让主队2球：-2，不让球则为0
	private     Integer     spType;//单关类型单关：0，过关：1
	private     Double     sheng;//胜平负Sp2.1
	private     Double     ping;//胜平负Sp1.2
	private     Double     fu;//胜平负Sp3
	private 	 Double     rqSheng;//让球胜
	private 	 Double 	rqPing;//让球平
	private 	 Double	    rqFu;//让球负
	private     Double     t0;//总进球Sp2.3
	private     Double     t1;//总进球Sp4.1
	private     Double     t2;//总进球Sp4.2
	private     Double     t3;//总进球Sp3.2
	private     Double     t4;//总进球Sp2.3
	private     Double     t5;//总进球Sp1.9
	private     Double     t6;//总进球Sp2.2
	private     Double     t7;//总进球Sp11.1
	
	private     Double     ss;//胜胜
	private     Double     sp;//胜平
	private     Double     sf;//胜负
	
	private     Double     ps;//平胜
	private     Double     pp;//平平
	private     Double     pf;//平负
	
	private     Double     fs;//负胜
	private     Double     fp;//负平
	private     Double     ff;//负负
	
	private     Double     s10;//胜1:0
	private     Double     s20;//胜2:0
	private     Double     s21;//胜2:1
	
	private     Double     s30;//胜3:0
	private     Double     s31;//胜3:1
	private     Double     s32;//胜3:2
	
	private     Double     S40;//胜4:0
	private     Double     S41;//胜4：1
	private     Double     S42;//胜4：2
	
	
	private     Double     S50;//胜5:0
	private     Double     S51;//胜5:1
	private     Double     S52;//胜5:2
	
	private     Double     sother;//胜其他
	
	private     Double     p00;//平0:0
	private     Double     p11;//平1:1
	private     Double     p22;//平2:2
	private     Double     p33;//平3:3
	
	private     Double     pother;//平其他
	
	private     Double     f01;//负0：1
	private     Double     f02;//负0：2
	private     Double     f12;//负1：2
	
	private     Double     f03;//负0：3
	private     Double     f13;//负1：3
	private     Double     f23;//负2：3
	
	private     Double     f04;//负0:4
	private     Double     f14;//负1:4
	private     Double     f24;//负2:4
	
	
	private     Double     f05;//负0：5
	private     Double     f15;//负1:5
	private     Double     f25;//负2：5
	
	private     Double     fother;//负其他
	
	
	
	
	public String getSels() {
		return sels;
	}
	public void setSels(String sels) {
		this.sels = sels;
	}
	public String getDayOfWeekStr() {
		return dayOfWeekStr;
	}
	public void setDayOfWeekStr(String dayOfWeekStr) {
		this.dayOfWeekStr = dayOfWeekStr;
	}
	public String getDayKey() {
		return dayKey;
	}
	public void setDayKey(String dayKey) {
		this.dayKey = dayKey;
	}
	public Integer getRowEnd() {
		return rowEnd;
	}
	public void setRowEnd(Integer rowEnd) {
		this.rowEnd = rowEnd;
	}
	public Integer getIssueId() {
		return issueId;
	}
	public void setIssueId(Integer issueId) {
		this.issueId = issueId;
	}
	public MatchVO getMatchVO() {
		return matchVO;
	}
	public void setMatchVO(MatchVO matchVO) {
		this.matchVO = matchVO;
	}
	public String getMatchCode() {
		return matchCode;
	}
	public void setMatchCode(String matchCode) {
		this.matchCode = matchCode;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getGuestName() {
		return guestName;
	}
	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}
	public String getLeagueName() {
		return leagueName;
	}
	public void setLeagueName(String leagueName) {
		this.leagueName = leagueName;
	}
	public Integer getOrder() {
		return order;
	}
	public void setOrder(Integer order) {
		this.order = order;
	}
	public Integer getRate() {
		return rate;
	}
	public void setRate(Integer rate) {
		this.rate = rate;
	}
	public Integer getSpType() {
		return spType;
	}
	public void setSpType(Integer spType) {
		this.spType = spType;
	}
	public Double getSheng() {
		return sheng;
	}
	public void setSheng(Double sheng) {
		this.sheng = sheng;
	}
	public Double getPing() {
		return ping;
	}
	public void setPing(Double ping) {
		this.ping = ping;
	}
	public Double getFu() {
		return fu;
	}
	public void setFu(Double fu) {
		this.fu = fu;
	}
	public Double getT0() {
		return t0;
	}
	public void setT0(Double t0) {
		this.t0 = t0;
	}
	public Double getT1() {
		return t1;
	}
	public void setT1(Double t1) {
		this.t1 = t1;
	}
	public Double getT2() {
		return t2;
	}
	public void setT2(Double t2) {
		this.t2 = t2;
	}
	public Double getT3() {
		return t3;
	}
	public void setT3(Double t3) {
		this.t3 = t3;
	}
	public Double getT4() {
		return t4;
	}
	public void setT4(Double t4) {
		this.t4 = t4;
	}
	public Double getT5() {
		return t5;
	}
	public void setT5(Double t5) {
		this.t5 = t5;
	}
	public Double getT6() {
		return t6;
	}
	public void setT6(Double t6) {
		this.t6 = t6;
	}
	public Double getT7() {
		return t7;
	}
	public void setT7(Double t7) {
		this.t7 = t7;
	}
	public String getCp2yEndTime() {
		return cp2yEndTime;
	}
	public void setCp2yEndTime(String cp2yEndTime) {
		this.cp2yEndTime = cp2yEndTime;
	}
	public String getMatchTime() {
		return matchTime;
	}
	public void setMatchTime(String matchTime) {
		this.matchTime = matchTime;
	}
	public Double getSs() {
		return ss;
	}
	public void setSs(Double ss) {
		this.ss = ss;
	}
	public Double getSp() {
		return sp;
	}
	public void setSp(Double sp) {
		this.sp = sp;
	}
	public Double getSf() {
		return sf;
	}
	public void setSf(Double sf) {
		this.sf = sf;
	}
	public Double getPs() {
		return ps;
	}
	public void setPs(Double ps) {
		this.ps = ps;
	}
	public Double getPp() {
		return pp;
	}
	public void setPp(Double pp) {
		this.pp = pp;
	}
	public Double getPf() {
		return pf;
	}
	public void setPf(Double pf) {
		this.pf = pf;
	}
	public Double getFs() {
		return fs;
	}
	public void setFs(Double fs) {
		this.fs = fs;
	}
	public Double getFp() {
		return fp;
	}
	public void setFp(Double fp) {
		this.fp = fp;
	}
	public Double getFf() {
		return ff;
	}
	public void setFf(Double ff) {
		this.ff = ff;
	}
	public Double getS10() {
		return s10;
	}
	public void setS10(Double s10) {
		this.s10 = s10;
	}
	public Double getS20() {
		return s20;
	}
	public void setS20(Double s20) {
		this.s20 = s20;
	}
	public Double getS21() {
		return s21;
	}
	public void setS21(Double s21) {
		this.s21 = s21;
	}
	public Double getS30() {
		return s30;
	}
	public void setS30(Double s30) {
		this.s30 = s30;
	}
	public Double getS31() {
		return s31;
	}
	public void setS31(Double s31) {
		this.s31 = s31;
	}
	public Double getS32() {
		return s32;
	}
	public void setS32(Double s32) {
		this.s32 = s32;
	}
	public Double getS40() {
		return S40;
	}
	public void setS40(Double s40) {
		S40 = s40;
	}
	public Double getS41() {
		return S41;
	}
	public void setS41(Double s41) {
		S41 = s41;
	}
	public Double getS42() {
		return S42;
	}
	public void setS42(Double s42) {
		S42 = s42;
	}
	public Double getS50() {
		return S50;
	}
	public void setS50(Double s50) {
		S50 = s50;
	}
	public Double getS51() {
		return S51;
	}
	public void setS51(Double s51) {
		S51 = s51;
	}
	public Double getS52() {
		return S52;
	}
	public void setS52(Double s52) {
		S52 = s52;
	}
	public Double getSother() {
		return sother;
	}
	public void setSother(Double sother) {
		this.sother = sother;
	}
	public Double getP11() {
		return p11;
	}
	public void setP11(Double p11) {
		this.p11 = p11;
	}
	public Double getP22() {
		return p22;
	}
	public void setP22(Double p22) {
		this.p22 = p22;
	}
	public Double getP33() {
		return p33;
	}
	public void setP33(Double p33) {
		this.p33 = p33;
	}
	public Double getPother() {
		return pother;
	}
	public void setPother(Double pother) {
		this.pother = pother;
	}
	public Double getF01() {
		return f01;
	}
	public void setF01(Double f01) {
		this.f01 = f01;
	}
	public Double getF02() {
		return f02;
	}
	public void setF02(Double f02) {
		this.f02 = f02;
	}
	public Double getF12() {
		return f12;
	}
	public void setF12(Double f12) {
		this.f12 = f12;
	}
	public Double getF03() {
		return f03;
	}
	public void setF03(Double f03) {
		this.f03 = f03;
	}
	public Double getF13() {
		return f13;
	}
	public void setF13(Double f13) {
		this.f13 = f13;
	}
	public Double getF23() {
		return f23;
	}
	public void setF23(Double f23) {
		this.f23 = f23;
	}
	public Double getF04() {
		return f04;
	}
	public void setF04(Double f04) {
		this.f04 = f04;
	}
	public Double getF14() {
		return f14;
	}
	public void setF14(Double f14) {
		this.f14 = f14;
	}
	public Double getF24() {
		return f24;
	}
	public void setF24(Double f24) {
		this.f24 = f24;
	}
	public Double getF05() {
		return f05;
	}
	public void setF05(Double f05) {
		this.f05 = f05;
	}
	public Double getF15() {
		return f15;
	}
	public void setF15(Double f15) {
		this.f15 = f15;
	}
	public Double getF25() {
		return f25;
	}
	public void setF25(Double f25) {
		this.f25 = f25;
	}
	public Double getFother() {
		return fother;
	}
	public void setFother(Double fother) {
		this.fother = fother;
	}
	public Double getP00() {
		return p00;
	}
	public void setP00(Double p00) {
		this.p00 = p00;
	}
	public Double getRqSheng() {
		return rqSheng;
	}
	public void setRqSheng(Double rqSheng) {
		this.rqSheng = rqSheng;
	}
	public Double getRqPing() {
		return rqPing;
	}
	public void setRqPing(Double rqPing) {
		this.rqPing = rqPing;
	}
	public Double getRqFu() {
		return rqFu;
	}
	public void setRqFu(Double rqFu) {
		this.rqFu = rqFu;
	}

}
