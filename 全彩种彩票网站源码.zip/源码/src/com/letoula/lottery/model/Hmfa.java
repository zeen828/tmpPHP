package com.letoula.lottery.model;

import java.util.Date;

public class Hmfa {
	private String schemeId;// 方案ID
	private String userName;// 用户名称
	private double schemeAmount;// 方案金额
	private String initiateTime;// 方案发起时间
	private double buyAmount;// 购买金额
	private double remainAmount;// 剩余金额
	private String schemeType;// 方案类型
	private String issue;// 奖期(追号为开始期)
	private int issueCount;// 期数
	private String type;// 中文玩法名称
	private String numbertent;// 方案
	private int open;// 合买方案公开情况
	private String progress;// 进展百分比
	private int minParticipant;// 合买参与最少金额
	private double safeguard;// 保底金额
	private int remuneration;// 佣金
	private String schemeDesc;// 方案描述
	private int flag;// 操作成功标示
	private String errorMessage;// 注册失败时提示
	private String lotteryName;//彩票名称
	private int schemeNumberUnit;//注数
	private String statusDesc;	  //方案状态	
	private double ownPrize;	  //参与中奖金额
	private String prizeDetail; //中奖金额 中奖金额明细
	private double Prize;
	
	public String getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(String schemeId) {
		this.schemeId = schemeId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public double getSchemeAmount() {
		return schemeAmount;
	}
	public void setSchemeAmount(double schemeAmount) {
		this.schemeAmount = schemeAmount;
	}
	public double getBuyAmount() {
		return buyAmount;
	}
	public void setBuyAmount(double buyAmount) {
		this.buyAmount = buyAmount;
	}
	public double getRemainAmount() {
		return remainAmount;
	}
	public void setRemainAmount(double remainAmount) {
		this.remainAmount = remainAmount;
	}
	public String getSchemeType() {
		return schemeType;
	}
	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public int getIssueCount() {
		return issueCount;
	}
	public void setIssueCount(int issueCount) {
		this.issueCount = issueCount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getNumbertent() {
		return numbertent;
	}
	public void setNumbertent(String numbertent) {
		this.numbertent = numbertent;
	}
	public int getOpen() {
		return open;
	}
	public void setOpen(int open) {
		this.open = open;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public int getMinParticipant() {
		return minParticipant;
	}
	public void setMinParticipant(int minParticipant) {
		this.minParticipant = minParticipant;
	}
	public double getSafeguard() {
		return safeguard;
	}
	public void setSafeguard(double safeguard) {
		this.safeguard = safeguard;
	}
	public int getRemuneration() {
		return remuneration;
	}
	public void setRemuneration(int remuneration) {
		this.remuneration = remuneration;
	}
	public String getSchemeDesc() {
		return schemeDesc;
	}
	public void setSchemeDesc(String schemeDesc) {
		this.schemeDesc = schemeDesc;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getInitiateTime() {
		return initiateTime;
	}
	public void setInitiateTime(String initiateTime) {
		this.initiateTime = initiateTime;
	}
	public String getLotteryName() {
		return lotteryName;
	}
	public void setLotteryName(String lotteryName) {
		this.lotteryName = lotteryName;
	}
	public int getSchemeNumberUnit() {
		return schemeNumberUnit;
	}
	public void setSchemeNumberUnit(int schemeNumberUnit) {
		this.schemeNumberUnit = schemeNumberUnit;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public double getOwnPrize() {
		return ownPrize;
	}
	public void setOwnPrize(double ownPrize) {
		this.ownPrize = ownPrize;
	}
	public String getPrizeDetail() {
		return prizeDetail;
	}
	public void setPrizeDetail(String prizeDetail) {
		this.prizeDetail = prizeDetail;
	}
	public double getPrize() {
		return Prize;
	}
	public void setPrize(double prize) {
		Prize = prize;
	}
	
	
}
