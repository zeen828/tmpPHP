package com.fivestars.interfaces.bbs.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sun.org.apache.xerces.internal.parsers.DOMParser;
import com.sun.org.apache.xerces.internal.xni.parser.XMLInputSource;


public class XMLHelper {

	public static LinkedList<String> uc_unserialize(String input){
		 LinkedList<String> result = new LinkedList<String>();
         try {                        
               org.dom4j.Document doc = DocumentHelper.parseText(input);
                 Element root = doc.getRootElement();
                 List nodes = root.elements("item");
                 for (Iterator it = nodes.iterator(); it.hasNext();) {
                     Element elm = (Element) it.next();
                     result.add(elm.getText());
                 }
         } catch (DocumentException e) {
                 e.printStackTrace();
         }
         return result;

	}
}
