package com.letousky.lottery.alipayUtil;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

public class UtilDate {
	
	public  static String getOrderNum(){
		Date date=new Date();
		DateFormat df=new SimpleDateFormat("yyyyMMddHHmmss");
		return df.format(date);
	}
	
	
	public static String getDate(){
		Date date=new Date();
		DateFormat df=new SimpleDateFormat("yyyyMMdd");
		return df.format(date);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UtilDate date=new UtilDate();
		System.out.println(date.getOrderNum());
	}
	
}
