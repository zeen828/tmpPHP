package com.letousky.lottery.action;

import java.net.URLDecoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.letousky.connector.MessageTool;
import com.letousky.lottery.delegate.QueryLotDelegate;

public class FootballClubAction extends BaseAction {
	 public ActionForward findFootballInfo(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
			    throws Exception
		{
		 	
		 String homeName=request.getParameter("home");
		 System.out.println("homename1======"+homeName);
		 homeName=URLDecoder.decode(homeName, "utf-8");
		 System.out.println("homename2======"+homeName);
		 
		 
		 String awayName=request.getParameter("away");
		 System.out.println("awayName1======"+awayName);
		 awayName=URLDecoder.decode(awayName, "utf-8");
		 System.out.println("awayName2======"+awayName);
		 
		  String home=homeName;
		  String  away=awayName;
		    String[] params6={home,away};
		    String message= new QueryLotDelegate().helpMessage(params6, "C0189");
		    System.out.println("message===="+message);
		    if(message!=null){
			    String[] arrs2=new MessageTool().split(message);
			    for(int i=0;i<arrs2.length;i++)
			    {
			    	System.out.print(i+"::"+arrs2[i]+"\t");
			    }
			    System.out.println();
			    request.setAttribute("arrs2", arrs2);
		    }
		    
		    String[]beisaiParams={home,"0"};
		    List beisailist=new QueryLotDelegate().queryPre(beisaiParams, "C0184");
		    for(int i=0;i<beisailist.size();i++)
		    {
		    	String[] str = (String[])beisailist.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    request.setAttribute("beisailist", beisailist);
		    
		 
		    
			    String[] paramsInfo={homeName,"0"};
			    String messageInfo= new QueryLotDelegate().helpMessage(paramsInfo, "C0190");
			    System.out.println("messageInfo===="+messageInfo);
			    String[] arrsInfo=new MessageTool().split(messageInfo);
			    for(int i=0;i<arrsInfo.length;i++)
			    {
			    	System.out.print(i+"::"+arrsInfo[i]+"\t");
			    }
			    System.out.println();
			    request.setAttribute("arrsInfo", arrsInfo);
		    
		 
		    home=homeName;
		    String type="1";
		    System.out.println("home====="+home);
		    String[] params={home,type};
		  
		    List list=new QueryLotDelegate().queryPre(params, "C0184");
		    String[] leagueNameArr=(String[]) list.get(0);
		    String leagueName=leagueNameArr[16];
		    String rank=leagueNameArr[0];

		    request.setAttribute("home", home);
		    request.setAttribute("rank", rank);
		    request.setAttribute("leagueName", leagueName);
		    request.setAttribute("list", list);
		    System.out.println("***********************");
//		    
		    away=awayName;
		    type="1";
		    System.out.println("away====="+away);
		    String[] params22={away,type};
		    List awayList=new QueryLotDelegate().queryPre(params22, "C0184");
		    String[] awayLeagueNameArr=(String[]) awayList.get(0);
		    String awayLeagueName=awayLeagueNameArr[16];
		    String awayRank=awayLeagueNameArr[0];
		    request.setAttribute("awayList", awayList);
		    request.setAttribute("away", away);
		    request.setAttribute("awayLeagueName", awayLeagueName);
		    request.setAttribute("awayRank", awayRank);
		    System.out.println("***********************");
		    
//		    home="汉堡";
//		    away="勒沃";
		    String type2="1";
		    String[]params2={home,away,type2};
		    List list2=new QueryLotDelegate().queryPre(params2, "C0185");
		    request.setAttribute("jiaozhanHis", list2);
		    System.out.println("-------------------------"+list2.size());
		    for(int i=0;i<list2.size();i++)
		    {
		    	String[] str = (String[])list2.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    
		    String[] paramsInfo2={home,"1"};
		    String messageInfo2= new QueryLotDelegate().helpMessage(paramsInfo2, "C0190");
		    System.out.println("messageInfo2===="+messageInfo2);
		    String[] arrsInfo2=new MessageTool().split(messageInfo2);
		    for(int i=0;i<arrsInfo2.length;i++)
		    {
		    	System.out.print(i+"::"+arrsInfo2[i]+"\t");
		    }
		    System.out.println();
		    request.setAttribute("arrsInfo2", arrsInfo2);
		    
		    
		    String[]params3={home,"","2"};
		    List list3=new QueryLotDelegate().queryPre(params3, "C0185");
		    for(int i=0;i<list3.size();i++)
		    {
		    	String[] str = (String[])list3.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    request.setAttribute("list3", list3);
		    
		    
		    String[] paramsInfo3={away,"1"};
		    String messageInfo3= new QueryLotDelegate().helpMessage(paramsInfo3, "C0190");
		    System.out.println("messageInfo3===="+messageInfo3);
		    String[] arrsInfo3=new MessageTool().split(messageInfo3);
		    for(int i=0;i<arrsInfo3.length;i++)
		    {
		    	System.out.print(i+"::"+arrsInfo3[i]+"\t");
		    }
		    System.out.println();
		    request.setAttribute("arrsInfo3", arrsInfo3);
		    
		    
		    String[]params4={"",away,"2"};
		    List list4=new QueryLotDelegate().queryPre(params4, "C0185");
		    for(int i=0;i<list4.size();i++)
		    {
		    	String[] str = (String[])list4.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    request.setAttribute("list4", list4);
		    
		    
		    
		    String[] paramsInfo4={home,"2"};
		    String messageInfo4= new QueryLotDelegate().helpMessage(paramsInfo4, "C0190");
		    System.out.println("messageInfo4===="+messageInfo4);
		    String[] arrsInfo4=new MessageTool().split(messageInfo4);
		    for(int i=0;i<arrsInfo4.length;i++)
		    {
		    	System.out.print(i+"::"+arrsInfo4[i]+"\t");
		    }
		    System.out.println();
		    request.setAttribute("arrsInfo4", arrsInfo4);
		    
		    
		    
		    String[]params5={home,"","3"};
		    List list5=new QueryLotDelegate().queryPre(params5, "C0185");
		    for(int i=0;i<list5.size();i++)
		    {
		    	String[] str = (String[])list5.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    request.setAttribute("list5", list5);
		    
		    
		    
		    String[] paramsInfo5={away,"2"};
		    String messageInfo5= new QueryLotDelegate().helpMessage(paramsInfo5, "C0190");
		    System.out.println("messageInfo5===="+messageInfo5);
		    String[] arrsInfo5=new MessageTool().split(messageInfo5);
		    for(int i=0;i<arrsInfo5.length;i++)
		    {
		    	System.out.print(i+"::"+arrsInfo5[i]+"\t");
		    }
		    System.out.println();
		    request.setAttribute("arrsInfo5", arrsInfo5);
		    
		    String[]params7={"",away,"3"};
		    List list7=new QueryLotDelegate().queryPre(params7, "C0185");
		    for(int i=0;i<list7.size();i++)
		    {
		    	String[] str = (String[])list7.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    request.setAttribute("list7", list7);
		    
		    String[]params8={home};
		    List list8=new QueryLotDelegate().queryPre(params8, "C0186");
		    for(int i=0;i<list8.size();i++)
		    {
		    	String[] str = (String[])list8.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    request.setAttribute("list8", list8);
		    
		    String[]params9={away};
		    List list9=new QueryLotDelegate().queryPre(params9, "C0186");
		    for(int i=0;i<list9.size();i++)
		    {
		    	String[] str = (String[])list9.get(i);
		    	for(int j=0;j<str.length;j++)
		    	{
		    		System.out.print(j+"::"+str[j]+"\t");
		    	}
		    	System.out.println();
		    	
		    }
		    request.setAttribute("list9", list9);
		    
		    String[]params10={home};
		    String message10=new QueryLotDelegate().helpMessage(params10, "C0187");
		    
		    System.out.println("message10===="+message10);
		    String[] arrs10=new MessageTool().split(message10);
		    for(int i=0;i<arrs10.length;i++)
		    {
		    	System.out.println(i+"::"+arrs10[i]+"\t");
		    }
		  
		    request.setAttribute("arrs10", arrs10);
		    
		    String[]params11={away};
		    String message11=new QueryLotDelegate().helpMessage(params11, "C0187");
		    
		    System.out.println("message11===="+message11);
		    String[] arrs11=new MessageTool().split(message11);
		    for(int i=0;i<arrs11.length;i++)
		    {
		    	System.out.println(i+"::"+arrs11[i]+"\t");
		    }
		    request.setAttribute("arrs11", arrs11);
//		    
//			String id="0";
//			String fid="361605";
//			String type3="1";
//		    String[] params5={id,fid,type3};
//		    String msg= new QueryLotDelegate().helpMessage(params5, "C0187");
//		    System.out.println("msg===="+msg);
//		    String[] arrs=new MessageTool().split(msg);
//		    for(int i=0;i<arrs.length;i++)
//		    {
//		    	System.out.print(arrs[i]+"\t");
//		    }
//		    System.out.println();
		    
		  
		    
		 	return mapping.findForward("success");
		}
}	
