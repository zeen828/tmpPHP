package com.letousky.lottery.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import com.anylotto.client.MD5Util;
import com.letousky.lottery.delegate.WinsFlat;

public class RechargeCooperation extends DispatchAction{
	
	public static final String USERNAME = "好人好梦";
	public static final String PASSWORD = "tanchong";
	public static final String LOGIN_MSG = "success";
	public static final String KEY = "7bbb6f3e34cf19fab8fb4ee6d0ea13b1";
	
	public ActionForward cooper(ActionMapping mapping,ActionForm form,HttpServletRequest request, HttpServletResponse response) throws Exception {
		 String Uname = request.getParameter("RC_NAME");
		 String Upwd  = request.getParameter("RC_PWD");
		 String mac = MD5Util.md5Hex(Uname + Upwd + MD5Util.md5Hex(Upwd));
		 if(!mac.equals(KEY)){
			 response.sendRedirect("/");
			 return null;
		 }else{
			 String[] userArr = new String[]{USERNAME,PASSWORD,"sl","0000"};
			 String loginMsg = new WinsFlat().newLogin(request,response,userArr);
			 if(!loginMsg.equals(LOGIN_MSG)){
				 response.sendRedirect("/");
				 return null;
			 }
		 }
		 return mapping.findForward("coopersuccess");
	 }
	 
	 public static void main(String[] args)
	 {
		 //MD5Util.md5Hex("17k9win" + "!QAZXSW@3edc" + MD5Util.md5Hex("!QAZXSW@3edc"));
		 //System.out.println(MD5Util.md5Hex("!QAZXSW@3edc"));
		 System.out.println(MD5Util.md5Hex("17k9win" + "!QAZXSW@3edc" + MD5Util.md5Hex("!QAZXSW@3edc")));
	 }
}
