package com.letousky.lottery.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginFilter implements Filter{

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req=(HttpServletRequest) request;

		HttpServletResponse res=(HttpServletResponse) response;

		//获得请求的URL

		String url=req.getRequestURL().toString();

		if(url.indexOf("/login.jsp") > -1 || url.indexOf("/user/")<=-1 || url.indexOf("/Register.jsp")>-1 || url.indexOf("/regsucces.jsp")>-1 || url.indexOf("/yhxy.jsp")>-1){
			//满足条件就继续执行
			chain.doFilter(request, response);
			return;
		}

		//获得session中的对象
		HttpSession session= req.getSession();
		String[] user=(String[])session.getAttribute("userAry");
		
		if(user == null || user.equals("")){
			String page = java.net.URLEncoder.encode(url.substring(url.lastIndexOf("/")+1,url.length()));
			res.sendRedirect(req.getContextPath() + "/member/login.jsp?pages="+page);
		}else
		{
			chain.doFilter(request, response);
		}
	
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
