package com.letousky.lottery.action;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import  org.apache.log4j.Logger;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.nutz.json.Json;

import com.anylotto.client.MD5Util;
import com.letousky.connector.Main;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.delegate.ChipinManage;
import com.letousky.lottery.util.InsiderCenterFormat;

public class DateJsonType extends DispatchAction{
  
	private static Logger __logger=InsiderCenterFormat.GET_LOGGER(DateJsonType.class);
	
	public synchronized ActionForward getJson(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		PrintWriter out=response.getWriter();
		try{
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String json=request.getParameter("param");
		__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>param="+json);
		Map<String,String> map = Json.fromJson(HashMap.class,json);
		String JsonType = map.get("JsonType") , status = "", d = "," , g = "_" , h = "-" , m = ":" , dx = "/" , sx = "//";
		String ticketFlag = "false" , awardFlag = "false";
		StringBuffer str = null; 
		if("TicketResult".equals(JsonType)){
			Object obj = (Object)map.get("DataList");
			List list = (List)obj;
			for(int i = 0; i < list.size();i++){
				str = new StringBuffer(); 
				Map DataList = (Map)list.get(i);
				String Transcode = DataList.get("Transcode").toString();
				__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> TicketResult Transcode="+Transcode+"");
				String ticketTrans = DataList.get("ticketTrans").toString();
				__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> TicketResult ticketTrans="+ticketTrans+"");
				String Mac =DataList.get("Mac").toString();
				__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> TicketResult Mac="+Mac+"");
				String Merchant_id =DataList.get("Merchant_id").toString();
				__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> TicketResult Merchant_id="+Merchant_id+"");
				String Printstatus =DataList.get("Printstatus").toString();
				__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> TicketResult Printstatus="+Printstatus+"");
				Map odds = (Map)DataList.get("Odds");
				String ticketingDate = odds.get("ticketingDate").toString();
				int datatype = Integer.parseInt(odds.get("datatype").toString());
//				String mac = MD5Util.md5Hex(Merchant_id + Transcode + Printstatus + DataList.get("Odds").toString() + "SBJK67SE");
//				if(!mac.equals(Mac)){
//					System.out.println("1111");
//					System.exit(0);
//				}
				str.append(Transcode+d);
				str.append(ticketTrans+d);
				str.append(Mac+d);
				str.append(Merchant_id+d);
				str.append(Printstatus+d);
				str.append(ticketingDate+d);
				str.append(datatype + g);
				if(odds.get("bet").toString().equals("{}")){
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>TicketResult dc continue="+Transcode);
					continue;
				}else{
					Map bet = (Map)odds.get("bet");
					String strbet = "";
					Set set = bet.entrySet();
					Iterator   iterator=set.iterator(); 
			        while (iterator.hasNext()) {   
			            Map.Entry  mapentry = (Map.Entry) iterator.next();
			            String name = mapentry.getKey().toString();
			            Map sp = (Map)mapentry.getValue();
			            strbet+=name+h;
			            Set set1 = sp.entrySet();
						Iterator iterator1=set1.iterator(); 
						StringBuffer strnum = new StringBuffer();
						while (iterator1.hasNext()) {   
							 Map.Entry  mapentry1 = (Map.Entry) iterator1.next();
							 strnum.append(mapentry1.getKey().toString()+m+mapentry1.getValue().toString() + dx);
						}
						strnum.deleteCharAt(strnum.lastIndexOf(dx));
						strbet += strnum.toString() + sx;
			        }
			        if(str.length() > 5){
			        	strbet = strbet.substring(0,strbet.length()-2);
			        }
			        str.append(strbet);
				}
				status = "1";
				if(str.length() > 0){
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>TicketResult tempid="+Transcode+"  status="+status);
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>TicketResult 发送串="+str);
					String[] re = new ChipinManage().datejson(new String[]{status,str.toString()}, "C0103");
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>TicketResult 后台返回="+re[0]);
				}else{
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>TicketResult 票异常");
					throw new LotteryException("1111");
				}
			}
		}else if("AwardData".equals(JsonType)){
			Object obj = (Object)map.get("DataList");
			List list = (List)obj;
			for(int i = 0; i < list.size();i++){
				str = new StringBuffer(); 
				Map DataList = (Map)list.get(i);
				String Transcode = DataList.get("Transcode").toString();
				String AwardSum = DataList.get("AwardSum").toString();
				String Mac = DataList.get("Mac").toString();
				String Merchant_id = DataList.get("Merchant_id").toString();
				__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> AwardData Transcode="+Transcode+"");
				str.append(Transcode+d);
				str.append(AwardSum);
				status = "2";
				if(str.length() > 0){
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> AwardData Transcode="+Transcode+"  status="+status);
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> AwardData 发送串="+str);
					String[] re = new ChipinManage().datejson(new String[]{status,str.toString()}, "C0103");
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> AwardData 后台返回="+re[0]);
				}else{
					__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>AwardData 票异常");
					throw new LotteryException("1111");
				}
			}
		}
		__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>返回值【0000】");
		out.print("0000");
	}catch(Exception ex){
		__logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>返回值【1111】");
		out.println("1111");
		return null;
	}
	
	return null;
	
}


	public  static  int  dayForWeek(String pTime) throws  Exception {   
		SimpleDateFormat format = new  SimpleDateFormat("yyyy-MM-dd" );   
		 Calendar c = Calendar.getInstance();   
		 c.setTime(format.parse(pTime));   
		 int  dayForWeek = 0 ;   
		 if (c.get(Calendar.DAY_OF_WEEK) == 1 ){   
		  dayForWeek = 7 ;   
		 }else {   
		  dayForWeek = c.get(Calendar.DAY_OF_WEEK) - 1 ;   
		 }   
		 return  dayForWeek;   
		}   

	
	public static void main(String[] args){
		try{
			System.out.println(dayForWeek("2013-11-19"));
		}catch(Exception e){
			
		}
	}
}
