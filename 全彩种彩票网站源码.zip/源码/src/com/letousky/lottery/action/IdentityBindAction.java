package com.letousky.lottery.action;

import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.delegate.AbstractDelegate;
import com.letousky.lottery.util.OperaterCode;

public class IdentityBindAction extends AbstractDelegate{
	/**
	 * 是否已绑定身份
	 * @param param
	 * @return
	 */
	public String isBind(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.IS_IDENTITY_BIND));
			return "0000";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	/**
	 * 身份 绑定
	 * @param param
	 * @return
	 */
	public String identityBind(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.IDENTITY_BIND));
			return "0000";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	
	/**
	 * 是否已绑定银行卡
	 * @param param
	 * @return
	 */
	public String isBankBind(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.IS_BANK_CARD));
			return "0000";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	/**
	 * 银行卡 绑定
	 * @param param
	 * @return
	 */
	public String BankBind(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.BANK_CARD));
			return "0000";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	
	/**
	 * 手机修改
	 * @param param
	 * @return
	 */
	public String mobileBind(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.MOBILE_BIND));
			return "0000";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	
	


}
