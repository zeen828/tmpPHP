package com.letousky.lottery.action;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fivestars.interfaces.bbs.client.Client;
import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.delegate.AbstractDelegate;
import com.letousky.lottery.delegate.WinsFlat;
import com.letousky.lottery.util.OperaterCode;

public class PwdUpdateAction extends AbstractDelegate{
	/**
	 * 密码修改
	 * @param param
	 * @return
	 */
	public String pwdUpdate(HttpServletRequest request, HttpServletResponse response,String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.PWD_UPDATE));
			String[] loginPar = new String[]{param[0],param[1],"sl","0000"}; 
			new WinsFlat().newLogin(request,response,loginPar);
			/*Client uc = new Client();
			String email = Math.random()*100+"@163.com";
			String $retrun = uc.uc_user_edit(param[0], param[1], param[1], email, 1, "", "");
			int $eid = Integer.parseInt($retrun);
			if($eid == 0){
				return "论坛用户没有做任何修改.";
			}else if($eid == -1){
				return "论坛用户旧密码不正确.";
			}else if($eid == -4){
				return "论坛用户email 格式有误.";
			}else if($eid == -5){
				return "论坛用户email 不允许注册.";
			}else if($eid == -6){
				return "论坛用户email 已经被注册.";
			}else if($eid == -7){
				return "论坛用户没有做任何修改.";
			}else if($eid == -8){
				return "受保护的用户，没有权限修改.";
			}*/
			return "修改成功！！！";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	/**
	 * 找回密码
	 * @return
	 */
	public String findPwd(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.FIND_PWD));
			return "0000";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	public static void main(String[] sdf){
		String[] param = new String[]{"yang452231","你的幸运数字是多少？","2"};
		String result = new PwdUpdateAction().findPwd(param);
		System.out.println(result);
	}
}
