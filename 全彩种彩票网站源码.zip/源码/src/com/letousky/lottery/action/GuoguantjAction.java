package com.letousky.lottery.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.letousky.connector.Message;
import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.util.MessageAuxiliary;
import com.letousky.lottery.util.OperaterCode;
import com.letousky.util.Symbols;

public class GuoguantjAction extends DispatchAction{
	/**
	 * 过关统计
	 * @param params
	 * @return
	 */
	public List ggtj(ActionMapping mapping,ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		List matchList = new ArrayList();
		Message message = new Message();
		message.setOperaterCode(OperaterCode.GGTJ);
		message.setOperaterNo("11111111");
		String date = request.getParameter("date");
		String userNickName = java.net.URLDecoder.decode(request.getParameter("userNickName"));
		String status = request.getParameter("status");
		String pageNum = request.getParameter("pageNum");
		String pageCount="30"; 
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append(date).append(Symbols.CON_SPLITBODY);
		strBuffer.append(userNickName).append(Symbols.CON_SPLITBODY);
		strBuffer.append(status).append(Symbols.CON_SPLITBODY);
		strBuffer.append(pageNum).append(Symbols.CON_SPLITBODY);
		strBuffer.append(pageCount).append(Symbols.CON_SPLITBODY);
		message.setBody(strBuffer.toString());
		String results= MessageAuxiliary.messageToMessage(message);
		try{
			matchList = new MessageTool().splits(results);
		}catch(LotteryException lotteryException){
			throw lotteryException;
		}
		Object[] obj = matchList.toArray();
		System.out.println(date);
		System.out.println(userNickName);
		System.out.println(status);
		System.out.println(pageNum);
		System.out.println(pageCount);
		System.out.println(obj.length);
		String d=",";
		out.print("{items:[");
		for(int i=0;i<obj.length;i++){
			if(i==obj.length-1){
				d="";
			}
			String[] str = (String[])obj[i];
			String info="";
			if(!str[12].equals("")){
				info=str[12].replaceAll("\\s", "");
			}
//			if(str[12].length()==9){
//				info=str[12].substring(0,6);
//			}else if(str[12].length()>=8){
//				info=str[12].substring(0,str[12].length()-1);
//			}
			out.print("{transCode:'"+str[0]+"',uId:'"+str[1]+"',uName:'"+str[2]+"',lotteryType:'"+str[3]+"'," +
					"betWay:'"+str[4]+"',upId:'"+str[5]+"',issue:'"+str[6]+"',betMultiples:'"+str[7]+"',"+
					"numShare:'"+str[8]+"',bets:'"+str[9]+"',bet:'"+str[16]+"',time:'"+str[10]+"',betNum:'"+str[11]+"',"+
					"otherInfo:'"+info+"',zjye:'"+str[13]+"',source:'"+str[14]+"',status:'"+str[15]+"',countPrice:'"+str[17]+"',manner:'"+str[18]+"'}"+d+"");
			
		}
		out.print("]}");
		return null;
	}
	/**
	 * 过关统计总记录数
	 * @param param
	 * @return
	 */
	public String[] ggtjSum(ActionMapping mapping,ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws IOException{
		PrintWriter out = response.getWriter();
		List matchList = new ArrayList();
		Message message = new Message();
		message.setOperaterCode(OperaterCode.GGTJ_SUM);
		message.setOperaterNo("11111111");
		String date = request.getParameter("date");
		String userNickName = java.net.URLDecoder.decode(request.getParameter("userNickName"));
		String status = request.getParameter("status");
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append(date).append(Symbols.CON_SPLITBODY);
		strBuffer.append(userNickName).append(Symbols.CON_SPLITBODY);
		strBuffer.append(status).append(Symbols.CON_SPLITBODY);
		message.setBody(strBuffer.toString());
		String results= MessageAuxiliary.messageToMessage(message);
		try{
			matchList = new MessageTool().splits(results);
		}catch(LotteryException lotteryException){
			throw lotteryException;
		}
		Object[] obj = matchList.toArray();
		out.print("{items:[");
		for(int i=0;i<obj.length;i++){
			String[] str = (String[])obj[i];
				out.print("{pageNum:'"+str[0]+"'},");
		}
		out.print("]}");
		return null;
	}
	public static void main(String[] fds){
		String[] param = new String[]{"20110715","all","0"};
		List matchList = new ArrayList();
		Message message = new Message();
		message.setOperaterCode(OperaterCode.GGTJ);
		message.setOperaterNo("11111111");
		String pageCount="10"; 
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append("20110915").append(Symbols.CON_SPLITBODY);
		strBuffer.append("all").append(Symbols.CON_SPLITBODY);
		strBuffer.append("1").append(Symbols.CON_SPLITBODY);
		strBuffer.append("1").append(Symbols.CON_SPLITBODY);
		strBuffer.append("10").append(Symbols.CON_SPLITBODY);
		message.setBody(strBuffer.toString());
		String results= MessageAuxiliary.messageToMessage(message);
		try{
			matchList = new MessageTool().splits(results);
		}catch(LotteryException lotteryException){
			throw lotteryException;
		}
		Object[] obj = matchList.toArray();
//		Object[] obj = list.toArray();
		for(int i=0;i<obj.length;i++){
			String[] str = (String[])obj[i];
			str[12]=str[12].replaceAll("\\s", "");
			System.out.println(str[12].length());
//			if(!str[12].equals("")){
//				str[12]=str[12].replaceAll(":","").replaceAll(",", "");
//			}
			for(int j=0;j<str.length;j++){
				System.out.print(str[j]+"--");
			}
			System.out.println();
		}
	}
}
