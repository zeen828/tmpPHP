package com.letousky.lottery.action;

import java.io.PrintWriter;
import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.delegate.AbstractDelegate;
import com.letousky.lottery.delegate.LoginManage;
import com.letousky.lottery.delegate.SelectMyAccountManage;
import com.letousky.lottery.util.OperaterCode;
import com.letousky.lottery.util.TimeUtil;

public class UserInfoAction extends AbstractDelegate{
	public String userInfoSave(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.USER_INFO_SAVE));
			return "0000";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	public static void main(String[] fsdf){
		String[] param =  new String[]{"22225","1","湖南省,邵阳市","15814732092"};
		String result= new UserInfoAction().userInfoSave(param);
		System.out.println(result);
	}
}
