package com.letousky.lottery.action;

import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.delegate.AbstractDelegate;
import com.letousky.lottery.util.OperaterCode;

public class PwdProtect extends AbstractDelegate{
	/**
	 * 密码保护设置
	 * @param param
	 * @return
	 */
	public String pwdProtectSet(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.PWD_PROTECT_SET));
			return "设置成功！！！";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	/**
	 * 密码保护修改
	 * @param param
	 * @return
	 */
	public String pwdProtectUpdate(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.PWD_PROTECT_UPDATE));
			return "修改成功！！！";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	/**
	 * 获得密码保护问题
	 * @param param
	 * @return
	 */
	public String pwdProtectQuestion(String[] param){
		try{
			new MessageTool().split(helpMessage(param,OperaterCode.PWD_PROTECT_QUESTION));
			return "设置成功！！！";
		} catch (LotteryException e) {
			return e.getMessage();
		} catch(Exception s){
			return s.getMessage();
		}
	}
	
}
