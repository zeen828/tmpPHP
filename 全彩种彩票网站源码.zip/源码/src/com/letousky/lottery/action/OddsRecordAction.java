package com.letousky.lottery.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.letousky.lottery.delegate.ChipinManage;
import com.letousky.lottery.util.OperaterCode;

public class OddsRecordAction extends BaseAction{
	
	private String FORWORDNAME = "";
	/**
	 * 
	 * @Title: soccer
	 * @Description: 竞彩足球赔率变化
	 * @param @param mapping
	 * @param @param form
	 * @param @param request
	 * @param @param response
	 * @param @return
	 * @return ActionForward
	 * @throws
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward soccer(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		try{
			response.setContentType("text/html;charset=UTF-8");
			String againstid = request.getParameter("id");
			String[] params = new String[]{againstid};
			String[] OddsArr = new ChipinManage().getzuodds(params, OperaterCode.RESULTS_FOOTBALLRECORD_SCORE);
			request.setAttribute("oddsArr", OddsArr);
			this.FORWORDNAME = "oddsjcsuccess"; 
		}catch(Exception e){
			request.setAttribute("errorMsg", e.getMessage());
			this.FORWORDNAME = "errormsg";
		}
		return mapping.findForward(this.FORWORDNAME);
	}
	
	/**
	 * 
	 * @Title: soccer
	 * @Description: 竞彩篮球赔率变化
	 * @param @param mapping
	 * @param @param form
	 * @param @param request
	 * @param @param response
	 * @param @return
	 * @return ActionForward
	 * @throws
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward basked(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
		try{
			response.setContentType("text/html;charset=UTF-8");
			String againstid = request.getParameter("id");
			String[] params = new String[]{againstid};
			String[] OddsArr = new ChipinManage().getzuodds(params, OperaterCode.RESULTS_BASKEDBALLRECORD_SCORE);
			request.setAttribute("oddsArr", OddsArr);
			this.FORWORDNAME = "oddslqsuccess"; 
		}catch(Exception e){
			request.setAttribute("errorMsg", e.getMessage());
			this.FORWORDNAME = "errormsg";
		}
		return mapping.findForward(this.FORWORDNAME);
	}
}
