package com.letousky.lottery.delegate;

import java.util.List;

import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;

/**
 * 参与合买
 * 
 * @author Administrator
 * 
 */
public class QueryLotDelegate extends AbstractDelegate {
	
	/**
	 * 查询列表
	 * 
	 * @param params
	 * @return
	 * @throws LotteryException
	 */
	public List queryPre(String[] params,String operaterCode) throws LotteryException {
		String result = helpMessage(params, operaterCode);
		System.out.println("result====----"+result);
		return new MessageTool().splits(result);
	}
	/**
	 * 获得分页记录数
	 * 
	 * @param params
	 * @return
	 */
	public int getNoteNum(String[] params,String operaterCode) throws LotteryException {
		String result = helpMessage(params, operaterCode);
		String[] results = new MessageTool().split(result);
		return Integer.parseInt(results[0]);
	}

}
