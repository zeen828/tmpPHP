package com.letousky.lottery.delegate;

import java.util.List;

import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;

public class SelectMyAccountManage extends AbstractDelegate {

	/**
	 * 鏌ヨ涓汉甯愭埛
	 * 
	 * @param params
	 * @return
	 * @throws LotteryException
	 */
	public String[] selectMyAccount(String[] params, String operaterCode)
			throws LotteryException {
		String result = helpMessage(params, operaterCode);
		return new MessageTool().split(result);
	}

	/**
	 * 鏌ヨ鍐荤粨閲戦
	 * 
	 * @param params
	 * @return
	 * @throws LotteryException
	 */

	public List selectCongealDetail(String[] params, String operaterCode)
			throws LotteryException {
		String result = helpMessage(params, operaterCode);
		return new MessageTool().splits(result);
	}
}
