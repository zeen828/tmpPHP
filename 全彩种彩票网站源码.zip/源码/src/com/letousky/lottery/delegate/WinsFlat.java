package com.letousky.lottery.delegate;


import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URL;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.fivestars.interfaces.bbs.client.Client;
import com.fivestars.interfaces.bbs.util.XMLHelper;
import com.letoula.lottery.model.User;
import com.letousky.common.lottery.JCHunheZuEntity;
import com.letousky.common.lottery.JCLanQiuDXEntity;
import com.letousky.common.lottery.JCLanQiuRFSFEntity;
import com.letousky.common.lottery.JCLanQiuSFCEntity;
import com.letousky.common.lottery.JCLanQiuSFEntity;
import com.letousky.common.lottery.JCbfEntity;
import com.letousky.common.lottery.JCbqcEntity;
import com.letousky.common.lottery.JCspfEntity;
import com.letousky.common.lottery.JCzjqEntity;
import com.letousky.common.lottery.LotteryEntity;
import com.letousky.common.lottery.BjdcRqspfEntity;
import com.letousky.common.lottery.BjdcZjqsEntity;
import com.letousky.common.lottery.BjdcBfEntity;
import com.letousky.common.lottery.BjdcSxpdsEntity;
import com.letousky.common.lottery.BjdcBqcspfEntity;
import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.rule.interfaces.ILotteryItem;
import com.letousky.lottery.rule.interfaces.LotteryItemSingleton;
import com.letousky.lottery.util.OperaterCode;

public class WinsFlat extends AbstractDelegate{
	
	LotteryEntity cspEntity = new JCspfEntity();
	/*
	 * 查询对阵
	 * request   winsFlat.jsp
	 * 
	 * 足彩
	 * */
	public List wins(String[] params)throws LotteryException {
		
		String operaterCode  = "";
		Map map = OperaterCode.map;
		map.put("102", OperaterCode.MAP_SFC);
		map.put("103", OperaterCode.MAP_RXJ);
		map.put("106", OperaterCode.MAP_JQC);
		map.put("107", OperaterCode.MAP_BQC);
		
		if("501".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS;
		}else if("502".equals(params[0]))
		{
     		operaterCode = OperaterCode.WINS_NUMBERS_DZ;
		}else if("503".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_ZJQ;
		}else if("504".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_BQC;
		}else if("509".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_HHGG;
			
		}else if("511".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_RQSPF;
		}
		
		String results = helpMessage(params,operaterCode);
		return new MessageTool().splits(results);
	}
	
	
	/*
	 * 查询对阵
	 * request   winsFlat.jsp
	 * 
	 * 篮彩
	 * */
	public List wins_bak(String[] params)throws LotteryException {
		
		String operaterCode  = "";
		
		if("505".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_SF;
		}else if("506".equals(params[0]))
		{
     		operaterCode = OperaterCode.WINS_NUMBERS_RFSF;
		}else if("507".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_SFC;
		}else if("508".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_DXF;
		}else if("510".equals(params[0]))
		{
			operaterCode = OperaterCode.WINS_NUMBERS_LQHH;
			
		}
		
		String results = helpMessage(params,operaterCode);
		return new MessageTool().splits(results);
	}
	
	/*
	 * 查询对阵
	 * request   winsFlat.jsp
	 * 
	 * 单场
	 * */
	public List wins_dc(String[] params)throws LotteryException {
		String results = helpMessage(params,OperaterCode.WINS_NUMBERS_DC);
		return new MessageTool().splits(results);
	}
	
	/**
	 * 
	 * @Title: superMain
	 * @Description: 合买名人
	 * @param @param params
	 * @param @return
	 * @param @throws LotteryException
	 * @return String[]
	 * @throws
	 * @param params
	 * @return
	 * @throws LotteryException
	 */
/*	public String[] superMain()throws LotteryException {
		String[] params = {"1"};
		String results = helpMessage(params,OperaterCode.List_SUPERMAN);
		return new MessageTool().split(results);
	}*/
	
	/*
	 * 查询对阵
	 * request   winsFlat.jsp
	 * 
	 * 传统足彩
	 * */
	public List wins_trade(String[] params)throws LotteryException {
		String results = helpMessage(params,OperaterCode.WINS_NUMBERS_TRADE);
		return new MessageTool().splits(results);
	}
	
	
	/*
	 * 竞彩即时比分
	 * request  winsFlat.jsp
	 * */
	public List score(String[] params)throws LotteryException {
		String results = helpMessage(params, OperaterCode.RESULTS_INSTANT_SCORE);
		return new MessageTool().splits(results);
	}
	
	
	/*
	 * 竞彩即时比分
	 * request  winsFlat.jsp
	 * */
	public List scoreDC(String[] params)throws LotteryException {
		String results = helpMessage(params, OperaterCode.RESULTS_INSTANT_SCOREDC);
		return new MessageTool().splits(results);
	}
	
	/*
	 * 竞彩获取第三方网站对阵ID
	 * request  winsFlat.jsp
	 * */
	public String[] marketId(String[] params)throws LotteryException {
		String results = helpMessage(params, OperaterCode.RESULTS_FOOTBALLMARKETID);
		return new MessageTool().split(results);
	}
	
	/*
	 * 竞彩投注查询赛事SP
	 * request  winsFlat.jsp
	 * */
	public HashMap betting_sel(String[] params)throws LotteryException {
		String results = helpMessage(params, OperaterCode.BETTING_SELLECT);
		List list = new MessageTool().splits(results);
		Object[] obj = list.toArray();
		String[] str = null;
		HashMap mapList = new HashMap();
		for(int i=0;i<obj.length;i++)
		{
			str = (String[])obj[i];
			mapList.put(str[0], "{\"5013\":\""+str[14]+"\",\"5011\":\""+str[15]+"\",\"5010\":\""+str[16]+"\",\"5113R\":\""+str[17]+"\",\"5111R\":\""+str[18]+"\",\"5110R\":\""+str[19]+"\",\"5113\":\""+str[17]+"\",\"5111\":\""+str[18]+"\",\"5110\":\""+str[19]+"\",\"5021-0\":\""+str[20]+"\",\"5022-0\":\""+str[21]+"\",\"5022-1\":\""+str[22]+"\",\"5023-0\":\""+str[23]+"\",\"5023-1\":\""+str[24]+"\",\"5023-2\":\""+str[25]+"\",\"5024-0\":\""+str[26]+"\",\"5024-1\":\""+str[27]+"\",\"5024-2\":\""+str[28]+"\",\"5025-0\":\""+str[29]+"\",\"5025-1\":\""+str[30]+"\",\"5025-2\":\""+str[31]+"\",\"5024-3\":\""+str[32]+"\",\"5020-0\":\""+str[33]+"\",\"5021-1\":\""+str[34]+"\",\"5022-2\":\""+str[35]+"\",\"5023-3\":\""+str[36]+"\",\"5024-4\":\""+str[37]+"\",\"5020-1\":\""+str[38]+"\",\"5020-2\":\""+str[39]+"\",\"5021-2\":\""+str[40]+"\",\"5020-3\":\""+str[41]+"\",\"5021-3\":\""+str[42]+"\",\"5022-3\":\""+str[43]+"\",\"5020-4\":\""+str[44]+"\",\"5021-4\":\""+str[45]+"\",\"5022-4\":\""+str[46]+"\",\"5020-5\":\""+str[47]+"\",\"5021-5\":\""+str[48]+"\",\"5022-5\":\""+str[49]+"\",\"5023-4\":\""+str[50]+"\",\"5030\":\""+str[51]+"\",\"5031\":\""+str[52]+"\",\"5032\":\""+str[53]+"\",\"5033\":\""+str[54]+"\",\"5034\":\""+str[55]+"\",\"5035\":\""+str[56]+"\",\"5036\":\""+str[57]+"\",\"5037\":\""+str[58]+"\",\"5043_3\":\""+str[59]+"\",\"5043_1\":\""+str[60]+"\",\"5043_0\":\""+str[61]+"\",\"5041_3\":\""+str[62]+"\",\"5041_1\":\""+str[63]+"\",\"5041_0\":\""+str[64]+"\",\"5040_3\":\""+str[65]+"\",\"5040_1\":\""+str[66]+"\",\"5040_0\":\""+str[67]+"\"}");
			
		}
		return mapList;
	}
	
	/**
	 * 
	 * @Title: selMarket
	 * @Description: 竞彩查询赛事对阵
	 * @param @param params
	 * @param @return
	 * @param @throws LotteryException
	 * @return List
	 * @throws
	 * @param params
	 * @return
	 * @throws LotteryException
	 */
	public List selMarket(String[] params)throws LotteryException {
		String results = helpMessage(params, OperaterCode.BETTING_SELLECT);
		return new MessageTool().splits(results);
	}
	
	/*
	 * 查询合买List
	 * 
	 * 返回  list[0]-集合   list[1]-记录数
	 * 
	 * request list_data.jsp
	 * */
	public List chippedList(String[] params)throws LotteryException {
		
		List list=new ArrayList();
		String results = helpMessage(params, OperaterCode.CHIPPEDLIST_NUMBERS_NEW); //合买集合
		String record=	helpMessage(new String[]{params[0],params[1],params[2],params[3],params[4],params[5],params[6],params[7],params[10],params[11]}, OperaterCode.CHIPPED_COUNT_NEW); //总记录数
		list.add(new MessageTool().splits(results));
		list.add(new MessageTool().split(record));
		return list;
	}
	
	
	/*
	 * 代沟，合买 投注
	 * 
	 * request request_betting.jsp
	 * */
	public List betting(HttpServletRequest request, HttpServletResponse 
			response,String[] params)throws LotteryException {
		if("302".equals(params[2])){
			params[17] =  params[17].replaceAll("sd", "上单").replaceAll("ss", "上双").replaceAll("xd", "下单").replaceAll("xs", "下双");
		}
		List list=new ArrayList();
		String[] str = new String[3]; 
		String[] u = (String[])request.getSession().getAttribute("userAry");
		if(params.length!=23){
			params[0]=super.getUserName(request);
			params[1]=super.getPassword(request);
		}
		super.SerialNO = super.doSerialNo();
		str[0] = params[11];str[1] = u[1];str[2] = super.SerialNO;
		String results=null;
		if("201".equals(params[2])){
			 results = helpMessage(params, OperaterCode.BUY_WINNING_SSQ);
		}else{
			results = helpMessage(params, OperaterCode.FOOTBALL_BETTING);
		}
		list.add(new MessageTool().split(results));
		list.add(str);
		return list;
	}
	/*
	 * 代沟，CPS合买 投注左国斌
	 * 
	 * request request_betting.jsp
	 * */
	public List bettingCPS(HttpServletRequest request, HttpServletResponse 
			response,String[] params)throws LotteryException {
		if("302".equals(params[2])){
			params[17] =  params[17].replaceAll("sd", "上单").replaceAll("ss", "上双").replaceAll("xd", "下单").replaceAll("xs", "下双");
		}
		List list=new ArrayList();
		String[] str = new String[3]; 
		//String[] u = (String[])request.getSession().getAttribute("userAry");
		if(params.length!=23){
			params[0]=super.getUserName(request);
			params[1]=super.getPassword(request);
		}
		super.SerialNO = super.doSerialNo();
		str[0] = params[11];str[1] = params[22];str[2] = super.SerialNO;
		String results = helpMessage(params, OperaterCode.FOOTBALL_BETTING);
		list.add(new MessageTool().split(results));
		list.add(str);
		return list;
	}
	
	/*
	 * 参与合买  确认参与 投注
	 * 
	 * request Chipped_in_submit.jsp
	 * */
	public List chipped_in(HttpServletRequest request, HttpServletResponse 
			response,String[] params)throws LotteryException{
			List list=new ArrayList();
			String[] str = new String[3]; 
			String[] u = (String[])request.getSession().getAttribute("userAry");
			params[0]=super.getUserName(request);
			params[1]=super.getPassword(request);
			super.SerialNO = super.doSerialNo();
			str[0] = ""+Double.parseDouble(params[4]);str[1] = u[1];str[2] = super.SerialNO;
			String results = helpMessage(params, OperaterCode.CHIPPED_BETTING);
			String []temp=results.split("%23;");
			for (int i = 0; i < temp.length; i++) {
				System.out.println("-----temp[i]"+temp[i]);
			}
			list.add(new MessageTool().split(results));
			list.add(str);
			return list;
	}
	
	/*
	 * 合买详情集合  params  合买ID
	 * 
	 * 
	 * */
	public List chipped_details(String[] params){
		String results = helpMessage(params, OperaterCode.List_Details); //合买详情集合
		return new MessageTool().splits(results);
	}
	
	/*
	 * 合买详情集合  params  合买交易号
	 * 
	 * 
	 * */
	public List chipped_details_SarNo(String[] params){
		String results = helpMessage(params, OperaterCode.List_Details_SARNOTWO); //合买详情集合
		return new MessageTool().splits(results);
	}
	
	/*
	 * 修改方案状态
	 * 
	 * 
	 * */
	public String[] isOpen_Update(String[] params){
		String results = helpMessage(params, OperaterCode.List_ISOPEN_UPDATE); 
		return new MessageTool().split(results);
	}
	
	/*
	 * 合买参与用户集合   总记录 
	 * */
	public List chipped_user_details(String[] params)throws LotteryException {
			List list=new ArrayList();
			String results = helpMessage(params, OperaterCode.List_USER_Details); //合买集合
			String record=	helpMessage(new String[]{params[0]}, OperaterCode.List_COUNT_Details); //总记录数
			list.add(new MessageTool().splits(results));
			list.add(new MessageTool().split(record));
			return list;
	}	
	
	/**
	 * 
	 * @Title: ShowUserPassword
	 * @Description: 找回密码
	 * @param @param params
	 * @param @return
	 * @param @throws LotteryException
	 * @return String[]
	 * @throws
	 * @param params
	 * @return
	 * @throws LotteryException
	 */
	public String[] ShowUserPassword(String[] params)throws LotteryException{
		return new MessageTool().split(helpMessage(params,OperaterCode.FIND_PWD));
	}
	
	/*
	 * 计算注数
	 * 
	 * request calculate_money.jsp
	 * */
	public String bouns(String mcn,String tzNumber,String oknumber,String oksp,String code) throws Exception{
	
	
		String[] arrMcn=mcn.split(",");
		tzNumber = new String(tzNumber.getBytes("ISO8859-1"),"UTF-8");
		oknumber = new String(oknumber.getBytes("ISO8859-1"),"UTF-8");
		oksp = new String(oksp.getBytes("ISO8859-1"),"UTF-8");
		
		String result="";double awardMoney=0.00;String[] awardResult=null;int money=0;
		
		if("501".equals(code))
		{
			cspEntity = new JCspfEntity();
			
		}else if("502".equals(code))
		{
			cspEntity = new JCbfEntity();
		}else if("503".equals(code))
		{
			cspEntity = new JCzjqEntity();
		}else if("504".equals(code))
		{
			cspEntity = new JCbqcEntity();
		}else if("505".equals(code))
		{
			cspEntity = new JCLanQiuSFEntity();
		}else if("506".equals(code))
		{
			cspEntity = new JCLanQiuRFSFEntity();
			
		}else if("507".equals(code))
		{
			cspEntity = new JCLanQiuSFCEntity();
		}else if("508".equals(code))
		{
			cspEntity = new JCLanQiuDXEntity();
		}else if("509".equals(code))
		{
			cspEntity = new JCHunheZuEntity();
		}else if("301".equals(code))
		{
			cspEntity = new BjdcRqspfEntity();
		}else if("302".equals(code))
		{
			tzNumber = tzNumber.replaceAll("sd", "上单").replaceAll("ss", "上双").replaceAll("xd", "下单").replaceAll("xs", "下双");
			oknumber = oknumber.replaceAll("sd", "上单").replaceAll("ss", "上双").replaceAll("xd", "下单").replaceAll("xs", "下双");
			cspEntity = new BjdcSxpdsEntity();
		
		}else if("303".equals(code))
		{
			cspEntity = new BjdcZjqsEntity();
		}else if("304".equals(code))
		{
			cspEntity = new BjdcBfEntity();
			
		}else if("305".equals(code))
		{
			cspEntity = new BjdcBqcspfEntity();
		}else if("102".equals(code) || "103".equals(code) || "106".equals(code) || "107".equals(code)){
			if("103".equals(code)) {
				tzNumber = tzNumber.replaceAll("\\*", "9");
			}
			ILotteryItem lotteryItem = LotteryItemSingleton.getLotteryItem(Integer.parseInt(code));
			lotteryItem.checkValid(Integer.parseInt(mcn),tzNumber, oknumber);
			String record = ""+lotteryItem.getRecordCount();
			return record;
		}
		
		
		for(int i=0;i<arrMcn.length;i++){
			
			cspEntity.countChipins(arrMcn[i],tzNumber);
			cspEntity.countAwards(arrMcn[i],tzNumber, oknumber, oksp);
			money+=cspEntity.getZhuShu();
			
			String temp = (String) cspEntity.getJiangDeng();
			if (temp != null) {
				awardResult = temp.split("/");// 中奖结果格式为:奖等/注数/奖金(例如:5/1/9.1)
				awardMoney += Double.parseDouble(awardResult[2]) * Integer.parseInt("1");
			}
		}
		result = money+"/"+awardResult[0]+"/"+awardResult[1]+"/"+String.valueOf(awardMoney);
		return result;
	}
	
	/*
	 * 计算奖金
	 * 
	 * request calculate_money.jsp
	 * */
	public String countAwards(String mcn,String tzNumber,String oknumber,String oksp,String code) throws Exception{
	
		String[] arrMcn=mcn.split(",");
		
		String result="";double awardMoney=0.00;String[] awardResult=null;int money=0;
		
		
		for(int i=0;i<arrMcn.length;i++){
			
			cspEntity.countAwards(arrMcn[i],tzNumber, oknumber, oksp);
		
			money+=cspEntity.getZhuShu();
			
			String temp = (String) cspEntity.getJiangDeng();
			if (temp != null) {
				awardResult = temp.split("/");// 中奖结果格式为:奖等/注数/奖金(例如:5/1/9.1)
				awardMoney += Double.parseDouble(awardResult[2]) * Integer.parseInt("1");
			}
		}
		result = money+"/"+awardResult[0]+"/"+awardResult[1]+"/"+String.valueOf(awardMoney);
		return result;
			
	}
	
	public static void SetCookies(String userId, HttpServletResponse response)
	  {
	    Cookie cookie = new Cookie("userId",userId);
	    cookie.setMaxAge(-1);
	    cookie.setPath("/");
	    response.addCookie(cookie);
	  }
	/***
	 * 描叙:通过userId查找loginName;
	 * @param request
	 * @param response
	 * @param params
	 * @return
	 */
	public String findLoginNameByUserId(HttpServletRequest request, HttpServletResponse response,String userId){
		String operaterCode = "C0204";
		String loginName="";
		String results = helpMessage(new String[]{userId}, operaterCode);
		String[]strArray= new MessageTool().split(results);
		try {
			loginName= java.net.URLDecoder.decode(strArray[1],"utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return loginName;
		
	}
	/***
	 * 描叙:通过userId查找loginName;
	 * @param request
	 * @param response
	 * @param params
	 * @return
	 */
	public String findRealNameByUserId(HttpServletRequest request, HttpServletResponse response,String userId){
		String operaterCode = "C0204";
		String loginName="";
		String results = helpMessage(new String[]{userId}, operaterCode);
		String[]strArray= new MessageTool().split(results);
		try {
			loginName= java.net.URLDecoder.decode(strArray[0],"utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return loginName;
		
	}
	 public String newLogin(HttpServletRequest request, HttpServletResponse response,String[] params)
	  throws Exception
	{
	
		 request.setCharacterEncoding("UTF-8");
		 response.setContentType("text/html;charset=UTF-8");
	  String code = params[2];
	  if (("sy".equals(code)) && 
	    (!params[3].trim().equals(request.getSession().getAttribute("validateCode").toString().trim()))) {
	    //out.print("{result:'dfsqw',errorMessage:'验证码输入有误！'}");
	    return "验证码输入有误！";
	  }

	  String[] results = (String[])null;
	  String[] result = (String[])null;
	  //params[0] = java.net.URLDecoder.decode(params[0]);
	  String[] userAry = new String[19];
	  try {
	    results = new MessageTool().split(helpMessage(new String[]{params[0],params[1]},OperaterCode.USER_LOGIN));
	    Cookie useridCookies = new Cookie("userId", results[1]);
	    Cookie passwordCookies = new Cookie("password", params[1]);
	    useridCookies.setMaxAge(3600);
	    passwordCookies.setMaxAge(3600);
	    useridCookies.setPath("/");
	    passwordCookies.setPath("/");
	    response.addCookie(useridCookies);
	    response.addCookie(passwordCookies);
	  } catch (LotteryException e) {
	   // out.print("{result:'wrong',errorMessage:'用户名或密码错误！请重新输入！'}");
	    return "用户名或密码错误！请重新输入！";
	  }
	  try {

	    result = new MessageTool().split(helpMessage(new String[] { params[0], params[1] }, OperaterCode.USER_ACCOUNT));
	    
	  } catch (LotteryException e) {
	    userAry[8] = "0.0";
	    userAry[9] = "0.0";
	    userAry[10] = "0.0";
	    userAry[13] = "0.0";
	    userAry[14] = "0.0";
	  }
	  if (result != null)
	  {
	    userAry[8] = result[1];
	    userAry[9] = result[2];
	    userAry[10] = result[3];
	    userAry[13] = result[4];
	    userAry[14] = result[5];
	  }

	  for (int i = 0; i < 8; i++) {
	    userAry[i] = results[i];
	  }

	  BigDecimal bd = new BigDecimal(results[8]);
	  userAry[11] = bd.setScale(2, 1).toString();

	  if (results != null) {
	    userAry[15] = results[8];
	    userAry[16] = results[9];
	    userAry[17] = results[10];
	  }
	 
	  userAry[12] = params[1];
	  userAry[18] = results[(results.length - 1)];
	  
	  HttpSession session = request.getSession();
	  session.setAttribute("password", params[1]);
	  session.setAttribute("uName", userAry[2]);
	  session.setAttribute("pwd", params[1]);
	  session.setAttribute("userAry", userAry);
	  session.setMaxInactiveInterval(-1);
	  
//	  String uc_R = uc_login(params[0],params[1],response,request); //UC登录
//	  if(!"success".equals(uc_R)){
//		  return uc_R;
//	  }
	  
	 // returnAjax(response, userAry);
	  
	  
	    //左国斌添加Memcached功能2014-6-24
	   /* MemcachedClientBuilder mClientBuilder =new XMemcachedClientBuilder(
	            AddrUtil.getAddresses("127.0.0.1:11211"));
	    try {
	        MemcachedClient memcachedClient =mClientBuilder.build();
	           memcachedClient.set("userId", 0, userAry[1]);  
	           String value= memcachedClient.get("userId");  
	           System.out.println("userId=" + value);  
	    } catch (IOException e) {
	        e.printStackTrace();
	    }*/
	    //左国斌添加Memcached功能2014-6-24
	    
	  
	  return userAry[2] + '-' + userAry[11];
	}
	 
	public String uc_login(String username,String password,HttpServletResponse response,HttpServletRequest request) throws UnsupportedEncodingException{
		 
		/*UC 登录*/
	    Client e = new Client(); 
	    String resultk = e.uc_user_login(username,password);

	    LinkedList<String> rs = XMLHelper.uc_unserialize(resultk);
	    if(rs.size()>0){
	    	int $uid = Integer.parseInt(rs.get(0));
	    	String $username = rs.get(1);
	    	String $password = rs.get(2);
	    	String $email = rs.get(3);
	    	if($uid > 0) {
	    		response.addHeader("P3P"," CP=\"CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR\"");
	    		String $ucsynlogin = e.uc_user_synlogin($uid);
	    		request.getSession().setAttribute("uc_user", $ucsynlogin);
	    		Cookie auth = new Cookie("auth", e.uc_authcode($password+"\t"+$uid, "ENCODE"));
	    		auth.setMaxAge(31536000);
	    		//auth.setDomain("localhost");
	    		response.addCookie(auth);
	    		Cookie user = new Cookie("uchome_loginuser",URLEncoder.encode(username,"UTF-8"));
	    		response.addCookie(user);
	    	
	    	} else if($uid == -1) {
	    		String email = Math.random()*100+"@163.com";
	    		String $returns = e.uc_user_register(username,password,email); 
	    		int $zuid = Integer.parseInt($returns); 
	 	        if ($zuid <= 0) {  
	 	            if ($zuid == -1) {  
	 	            	return "论坛用户名不合法";  
	 	            } else if ($zuid == -2) {  
	 	            	return "论坛包含要允许注册的词语";  	
	 	            } else if ($zuid == -3) {  
	 	            	return "论坛用户名已经存在";  
	 	            } else if ($zuid == -4) {  
	 	            	return "论坛Email 格式有误";  
	 	            } else if ($zuid == -5) {  
	 	            	return "论坛Email 不允许注册";  
	 	            } else if ($zuid == -6) {  
	 	            	return "论坛该 Email 已经被注册";  
	 	            } else {  
	 	            	return "论坛未定义";  
	 	            }  
	 	        } else {  
	 	        	uc_login(username,password,response,request);
	 	        	return "ucSuccess";
	 	        } 
	    	} else if($uid == -2) {
	    		return "密码错";
	    	} else {
	    		return "未定义";
	    	}
	    }else{
	    	return "论坛登录错误！";
	    }  
	   /*UC登录完*/ 
		return "success";
	}
	public String[] findStatusBylotNameAndIssue(String[]params){
		String operaterCode = "C0205";
		String results = helpMessage(params, operaterCode);
		String strA[]= new MessageTool().split(results);
		return strA;
	}
	
	public Map getIssueAndAwardPoolFrom163Web(){
		Map map=new HashMap();
		try {
			String url = "http://caipiao.163.com/";//网易彩票
			Document doc = Jsoup.parse(new URL(url), 5000);
			Element tdNode = doc.select(".czTimes").first();
			Element issueE=tdNode.getElementsByTag("em").first();
			Element awardPoolE=tdNode.getElementsByClass("totalPool").first();
		    System.out.println("issue-----"+issueE.text().trim());
		    System.out.println("awardPool-----"+awardPoolE.select("strong").text().replaceAll(",", "").replaceAll("元", ""));
		    map.put("issue", issueE.text().trim());
		    map.put("awardPool", awardPoolE.select("strong").text().replaceAll(",", "").replaceAll("元", ""));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}
	public static void main(String[] args)
	{
		System.out.println(new WinsFlat().getIssueAndAwardPoolFrom163Web());
		
		
	}

	
	
	public User mobileLogin(HttpServletRequest request, HttpServletResponse response,String[] params)
			  throws Exception
			{
			
			  request.setCharacterEncoding("UTF-8");
			  response.setContentType("text/html;charset=UTF-8");

			  String[] results = (String[])null;
			  String[] result = (String[])null;
//			  String[] userAry = new String[19];
			  User user=new User();
			 
			  try {
			    results = new MessageTool().split(helpMessage(new String[]{params[0],params[1]},OperaterCode.USER_LOGIN));
			  } catch (LotteryException e) {
				user.setFlag(0);
				user.setErrorMessage("账号或密码错误，请检查是否大小写输入错误!");
			    return user;
			  }
			  try {

			    result = new MessageTool().split(helpMessage(new String[] { params[0], params[1] }, OperaterCode.USER_ACCOUNT));
			    
			  } catch (LotteryException e) {
				  e.printStackTrace();
			  }
			  user.setUserId(results[1]);
			  user.setFlag(1);
			  user.setUsername(results[2]);
			  if (result != null)
			  {
				  
				  BigDecimal bd = new BigDecimal(result[1]);
				  String bdStr = bd.setScale(2, 1).toString();
				
				  BigDecimal awardBet = new BigDecimal(result[2]);
				  String awardBetStr = awardBet.setScale(2, 1).toString();
				  
				  user.setBalance(Double.parseDouble( bdStr)+Double.parseDouble(awardBetStr));
				  
				  BigDecimal redBlance = new BigDecimal(result[4]);
				  String redBlanceStr = redBlance.setScale(2, 1).toString();
				  user.setRedBalance(Double.parseDouble( redBlanceStr));
				  
				  
			  }

			  
			  HttpSession session = request.getSession();
			  user.setPassword(params[1]);
//			  session.setAttribute("password", params[1]);
//			  session.setAttribute("uName", userAry[2]);
//			  session.setAttribute("pwd", params[1]);
			  session.setAttribute(session.getId(), user);
			  session.setMaxInactiveInterval(-1);
			  user.setClientUserSession(session.getId());
			  return user;
			}
	
	
	/*
	 * 期号查询
	 * 
	 * 
	 * */
	public String[] issueQuery(String[] params){
		String results = helpMessage(params, OperaterCode.ISSUE_QUERY); //合买详情集合
		return new MessageTool().split(results);
	}
	
	
}
