package com.letousky.lottery.delegate;

import java.util.List;

import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;


public class ChipinManage extends AbstractDelegate {

	/**
	 * 鐢ㄦ埛鎶曟敞
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public String[] datejson(String[] params,String operaterCode) throws LotteryException {
		String results= helpMessage(params,operaterCode);
		System.out.println(results);
		return new MessageTool().split(results);
	}
	
	public String[] getzuodds(String[] params,String operaterCode) throws LotteryException {
		String results= helpMessage(params,operaterCode);
		return new MessageTool().split(results);
	}
	
}
