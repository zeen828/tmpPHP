package com.letousky.lottery.delegate;

public class TradeDelegate extends AbstractDelegate{

}
