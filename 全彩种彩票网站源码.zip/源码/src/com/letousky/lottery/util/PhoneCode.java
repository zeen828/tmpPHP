package com.letousky.lottery.util;

import org.apache.commons.configuration.AbstractFileConfiguration;
import org.apache.commons.configuration.PropertiesConfiguration;

import com.letousky.exception.LotteryException;

public class PhoneCode {
	final static String CHAR_CODE = "UTF-8";
	
	public static String readProp(String fileName, String value) throws LotteryException {
		String result = "";
		try {
			AbstractFileConfiguration configPro = new PropertiesConfiguration();
			configPro.setEncoding(CHAR_CODE);
			configPro.load(fileName);
			result =  (String)configPro.getProperty(value);
		}catch(Exception e) {
			throw new LotteryException("read file error");
		}
		return result;
	}
	public static void writeProp(String fileName, String propName, String propValue) {
					try {
						AbstractFileConfiguration configPro = new PropertiesConfiguration(fileName);
						configPro.setEncoding(CHAR_CODE);
						configPro.setProperty(propName, propValue);
						configPro.save();
					}catch(Exception e) {
						throw new LotteryException("write file error");
					}
				}  
	public static void main(String[] fsdf){
//		String str=PhoneCode.readProp("PhoneCode.properties", "connector.phone");
//		System.out.println(str);
		try{
			PhoneCode.writeProp("src/PhoneCode.properties", "connector","4567978");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
