package com.letousky.lottery.util;

import java.io.IOException; 
import java.io.InputStream;

import java.net.MalformedURLException;

import java.net.URL;

import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.PrintWriter;

import net.sf.json.JSONObject;

import org.dom4j.Attribute;
import org.dom4j.Element;
import org.dom4j.io.DOMReader;
import org.w3c.dom.Document;

import org.w3c.dom.DOMException;

import org.xml.sax.SAXException;

import com.letoula.InstantOddsBean;

import javax.xml.parsers.DocumentBuilder;

import javax.xml.parsers.DocumentBuilderFactory;

import javax.xml.parsers.ParserConfigurationException;

import javax.xml.transform.OutputKeys;

import javax.xml.transform.Transformer;

import javax.xml.transform.TransformerConfigurationException;

import javax.xml.transform.TransformerException;

import javax.xml.transform.TransformerFactory;

import javax.xml.transform.dom.DOMSource;

import javax.xml.transform.stream.StreamResult;

public class AnalysisOfXmlUtil {
	public static String url_Str="http://119.57.74.210:9090/fbService/sltAPI?v=1&uid=800001&pwd=12345&sport=s&target=odds&date=2011-3-10";
	static String xmlPath="E:/netDataToLocalFile.xml";
	private static String SERVICES_HOST = "www.webxml.com.cn";

	//获取document对象
	public static Document getDoc(String strUrl){
		Document doc=null;
		DocumentBuilderFactory documentBF = DocumentBuilderFactory.newInstance();
		documentBF.setNamespaceAware(true);
		try {
			DocumentBuilder documentB = documentBF.newDocumentBuilder();
			InputStream inputStream = getSoapInputStream(strUrl);
			doc=(Document) documentB.parse(inputStream);
			inputStream.close();
		}catch(DOMException e){
			e.printStackTrace();
			return null;
		}catch(ParserConfigurationException e){
			e.printStackTrace();
			return null;

		}catch (SAXException e){
			e.printStackTrace();
			return null;

		}catch(IOException e){
			e.printStackTrace();
			return null;
		}
		return doc;
	}
	public static InputStream getSoapInputStream(String url){
		InputStream inputStream = null;
		try {
			URL urlObj = new URL(url);
			URLConnection conn = urlObj.openConnection();
			conn.setRequestProperty("Host", SERVICES_HOST);
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
			conn.connect();
			inputStream=conn.getInputStream();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return inputStream;
	}
	
	public static void CreateFile(Document document, String savaFileURL){
		TransformerFactory transF = TransformerFactory.newInstance();
		try{
			Transformer transformer = transF.newTransformer();
			DOMSource source = new DOMSource(document);
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			PrintWriter pw = new PrintWriter(new FileOutputStream(savaFileURL));

			StreamResult result = new StreamResult(pw);

			transformer.transform(source, result);

			System.out.println("生成xml文件成功!");

			}catch(TransformerConfigurationException e){

				System.out.println(e.getMessage()+"1");

			}catch(IllegalArgumentException e){

			   System.out.println(e.getMessage()+"2");

			}catch(FileNotFoundException e){

			   System.out.println(e.getMessage()+"3");

			}catch(TransformerException e){

				System.out.println(e.getMessage()+"4");

			}
	}
	public static JSONObject  getInstantOdds(String urlStr){
		Document doc = getDoc(urlStr); 
		DOMReader reader = new  DOMReader();
		org.dom4j.Document domDoc=reader.read(doc);
		List match_list=domDoc.selectNodes("/matchlist/match");
		StringBuffer str_b= new StringBuffer("{items:[");
		String match_d="";
		int match_x=0;
		for(Iterator match_it = match_list.iterator();match_it.hasNext();){
			String company_d="";
			int company_x=0;
			if(match_x!=0){
				match_d=",";
			}
			match_x=1;
			Element el= (Element) match_it.next();
			InstantOddsBean iob =  new InstantOddsBean();
			
			str_b.append(match_d+"{match_id:'"+el.attribute("id").getValue()+"',"+
			"arc:'"+el.attribute("arc").getValue()+"',"+"atpt:'"+el.attribute("atpt").getValue()+"',"+
			"ayc:'"+el.attribute("ayc").getValue()+"',"+"hcn:'"+el.attribute("hcn").getValue()+"',"+
			"hrc:'"+el.attribute("hrc").getValue()+"',"+"htpt:'"+el.attribute("htpt").getValue()+"',"+
			"htr:'"+el.attribute("htr").getValue()+"',"+"hyc:'"+el.attribute("hyc").getValue()+"',"+
			"lcn:'"+el.attribute("lcn").getValue()+"',"+"ltr:'"+el.attribute("ltr").getValue()+"',"+
			"mt:'"+el.attribute("mt").getValue()+"',"+"rtime:'"+el.attribute("rtime").getValue()+"',"+
			"running:'"+el.attribute("running").getValue()+"',"+"vcn:'"+el.attribute("vcn").getValue()+"',"+
			"vtr:'"+el.attribute("vtr").getValue()+"',"
			);
			
			List company_list = el.selectNodes("company");
			Iterator company_it=company_list.iterator();
			str_b.append("company_items:[");
			while(company_it.hasNext()){
				String odd_d="";
				int odd_x=0;
				if(company_x!=0){
					company_d=",";
				}
				company_x=1;
				Element company_el=(Element) company_it.next();
				iob.setCompany_id(company_el.attribute("id").getValue());
				str_b.append(company_d+"{company_id:'"+company_el.attribute("id").getValue()+"',"+
				"cn:'"+company_el.attribute("cn").getValue()+"',"+"en:'"+company_el.attribute("en").getValue()+"',"+	
				"tr:'"+company_el.attribute("tr").getValue()+"',"
				);
				List odd_list = company_el.selectNodes("odd");
				Iterator odd_it=odd_list.iterator();
				str_b.append("odd_items:[");
				while(odd_it.hasNext()){
					if(odd_x!=0){
						odd_d=",";
					}
					odd_x=1;
					Element odd_el=(Element) odd_it.next();
					iob.setEt(odd_el.attribute("et").getValue());
					str_b.append(odd_d+"{et:'"+odd_el.attribute("et").getValue()+"',"+
					"h:'"+odd_el.attribute("h").getValue()+"',"+"o:'"+odd_el.attribute("o").getValue()+"',"+
					"p:'"+odd_el.attribute("p").getValue()+"',"+"ped:'"+odd_el.attribute("ped").getValue()+"',"+
					"t:'"+odd_el.attribute("t").getValue()+"',"+"time:'"+odd_el.attribute("time").getValue()+"',"+
					"u:'"+odd_el.attribute("u").getValue()+"',"+"vst:'"+odd_el.attribute("vst").getValue()+"'"
					);
					str_b.append("}");
				}
				str_b.append("]");
				str_b.append("}");
			}
			str_b.append("]}");
		}
		str_b.append("]}");
		JSONObject obj=JSONObject.fromObject(str_b.toString());
		return obj;
	}
	public static void main (String[] fsd){
		List<InstantOddsBean> list = new ArrayList<InstantOddsBean>();
		Document doc = getDoc(url_Str); 
		DOMReader reader = new  DOMReader();
		org.dom4j.Document domDoc=reader.read(doc);
		List match_list=domDoc.selectNodes("/matchlist/match");
		StringBuffer str_b= new StringBuffer("{items:[");
		String match_d="";
		int match_x=0;
		for(Iterator match_it = match_list.iterator();match_it.hasNext();){
			String company_d="";
			int company_x=0;
			if(match_x!=0){
				match_d=",";
			}
			match_x=1;
			Element el= (Element) match_it.next();
			InstantOddsBean iob =  new InstantOddsBean();
			str_b.append(match_d+"{match_id:'"+el.attribute("id").getValue()+"',"+
			"arc:'"+el.attribute("arc").getValue()+"',"+"atpt:'"+el.attribute("atpt").getValue()+"',"+
			"ayc:'"+el.attribute("ayc").getValue()+"',"+"hcn:'"+el.attribute("hcn").getValue()+"',"+
			"hrc:'"+el.attribute("hrc").getValue()+"',"+"htpt:'"+el.attribute("htpt").getValue()+"',"+
			"htr:'"+el.attribute("htr").getValue()+"',"+"hyc:'"+el.attribute("hyc").getValue()+"',"+
			"lcn:'"+el.attribute("lcn").getValue()+"',"+"ltr:'"+el.attribute("ltr").getValue()+"',"+
			"mt:'"+el.attribute("mt").getValue()+"',"+"rtime:'"+el.attribute("rtime").getValue()+"',"+
			"running:'"+el.attribute("running").getValue()+"',"+"vcn:'"+el.attribute("vcn").getValue()+"',"+
			"vtr:'"+el.attribute("vtr").getValue()+"',"
			);
			List company_list = el.selectNodes("company");
			Iterator company_it=company_list.iterator();
			str_b.append("company_items:[");
			while(company_it.hasNext()){
				String odd_d="";
				int odd_x=0;
				if(company_x!=0){
					company_d=",";
				}
				company_x=1;
				Element company_el=(Element) company_it.next();
				iob.setCompany_id(company_el.attribute("id").getValue());
				str_b.append(company_d+"{company_id:'"+company_el.attribute("id").getValue()+"',"+
				"cn:'"+company_el.attribute("cn").getValue()+"',"+"en:'"+company_el.attribute("en").getValue()+"',"+	
				"tr:'"+company_el.attribute("tr").getValue()+"',"
				);
				List odd_list = company_el.selectNodes("odd");
				Iterator odd_it=odd_list.iterator();
				str_b.append("odd_items:[");
				while(odd_it.hasNext()){
					if(odd_x!=0){
						odd_d=",";
					}
					odd_x=1;
					Element odd_el=(Element) odd_it.next();
					iob.setEt(odd_el.attribute("et").getValue());
					str_b.append(odd_d+"{et:'"+odd_el.attribute("et").getValue()+"',"+
					"h:'"+odd_el.attribute("h").getValue()+"',"+"o:'"+odd_el.attribute("o").getValue()+"',"+
					"p:'"+odd_el.attribute("p").getValue()+"',"+"ped:'"+odd_el.attribute("ped").getValue()+"',"+
					"t:'"+odd_el.attribute("t").getValue()+"',"+"time:'"+odd_el.attribute("time").getValue()+"',"+
					"u:'"+odd_el.attribute("u").getValue()+"',"+"vst:'"+odd_el.attribute("vst").getValue()+"'"
					);
					str_b.append("}");
				}
				str_b.append("]");
				str_b.append("}");
			}
			str_b.append("]}\n");
		}
		str_b.append("]}\n");
		//return JSONSerializer.toJSON(str_b);
		//JSONObject json = new JSONObject(str_b.toString());
		JSONObject json=getInstantOdds(url_Str);
		//String aa="{'JsonType':'TicketResult','DataList':[{'Transcode':'100001183859','ticketTrans':'20042776450868293898','Mac':'34bb9feeca7bd3d415586dcde824d5fb','Merchant_id':'50000002','Printstatus':'4','Odds':{'ticketingDate':'2011-04-14 12:43:06','bet':{'F20110414002':{'00':'3.150'},'F20110414001':{'00':'2.100'}},'datatype':1}},{'Transcode':'100001183860','ticketTrans':'20042495476302405925','Mac':'c7ac12353f4491a9aee16d4419820afe','Merchant_id':'50000002','Printstatus':'4','Odds':{'ticketingDate':'2011-04-14 12:43:06','bet':{'F20110414001':{'00':'2.100'},'F20110414004':{'03':'2.200'}},'datatype':1}}]}";
		//JSONObject obj=JSONObject.fromObject(aa);
		System.out.println(json);
		//System.out.println(json);
	}
}
