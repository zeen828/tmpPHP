package com.letousky.lottery.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import java.util.Random;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;



public class MessageSend {
	final static Logger __logger = Logger.getLogger(MessageSend.class);
//	private static String userid;
//	private static String message_url;
//	private static String account;
//	private static String password;
//	
//	static
//	{
//		Properties pro=new Properties();
//		try {
//		     pro.load(new FileInputStream((MessageSend.class.getResource("/").getPath()+"/message.properties"))); 
//			userid=pro.getProperty("userid");
//			message_url=pro.getProperty("message_url");
//			account=pro.getProperty("account");
//			password=pro.getProperty("password");
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
	
	public static void main(String[] args) {
		String url="http://218.244.145.26:9090/jczg/MobileLoginAction.do?action=UserRegister&username=zhuchengbo&password=192jevons";
		String html=getHtmlByUrl(url,2);
		System.out.println(html);
//		sengMsg("18357002875");
	}

	public static String getNum() {
		Random random = new Random();
		String result = "";
		for (int i = 0; i < 6; i++) {
			String r = String.valueOf(random.nextInt(10));
			result += r;
		}
		return result;
	}

	public static String sengMsg(String phone) {
//		__logger.error("---------message_url-----------"+message_url);
//		__logger.error("---------userid-----------"+userid);
//		__logger.error("---------password-----------"+password);
		String result = getNum();
		
		String sn="SDK-HFY-010-00024";
		String pwd="996688";
		
		MailClient client;
		try {
			client = new MailClient(sn,pwd);
			
			client.mdsmssend(phone, "您在www.beikecai.com请求的验证码是："+result+" 【贝壳彩】", "", "", "", "");
			
		} catch (UnsupportedEncodingException e) {
			
			e.printStackTrace();
		}
		
		
		
//		String paras = "action=send&userid="+1507+"&account="+2693+"&password="+123456+"&mobile="+phone+"&content=您在【贝壳彩】请求的验证码是："
//				+ result + "【beikecai.com】";
//		String xml = getHtmlByUrl("http://10086.dx.hn/sms.aspx?" + paras, 2);
//		System.out.println(xml);
//		__logger.error("---------"+xml+"-----------");
//		__logger.error("---------end-----------");
		return result;
	}

	public static String getHtmlByUrl(String url, int charcode) {
		String html = null;
		HttpClientBuilder builder = HttpClientBuilder.create();
		HttpClient client = builder.build();
		HttpPost get = new HttpPost(url);
		try {
			HttpResponse response = client.execute(get);
			int resStatus = response.getStatusLine().getStatusCode();
			if (resStatus == HttpStatus.SC_OK) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					if (charcode == 1) {
						html = new String(EntityUtils.toString(entity)
								.getBytes("ISO_8859_1"), "GBK");
					} else if (charcode == 2) {
						html = EntityUtils.toString(entity);
					} else {
						html = new String(EntityUtils.toString(entity)
								.getBytes("ISO_8859_1"), "UTF-8");
					}
				}
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			builder.disableConnectionState();
			// client.getConnectionManager().shutdown();
		}
		return html;
	}
}
