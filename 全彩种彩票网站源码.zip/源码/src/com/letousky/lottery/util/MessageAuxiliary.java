package com.letousky.lottery.util;

import com.letousky.connector.Message;
import com.letousky.connector.MessageHandler;

public class MessageAuxiliary {
	
     public static String messageToMessage(Message message) {
    	message.setVersion("1.10");
 		message.setChannelNo("1001");
 		message.setRequestNo("100");
 		message.setDataType("1");
 		message.setRequestType("0");
 		return new MessageHandler().sendMessage(message);
     }
}
