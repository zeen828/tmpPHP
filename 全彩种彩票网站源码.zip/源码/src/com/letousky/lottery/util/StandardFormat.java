package com.letousky.lottery.util;

import java.util.HashMap;
import java.util.Map;

public class StandardFormat {
	public static Map<String, String> lotName_formatMap = new HashMap();
	public static Map<String, String> lotNameMap = new HashMap();
	public static Map<String, String> lotStateMap = new HashMap();
	private static String[] tiyuBallNum = null;
	private static String[] fuliBallNum = null;
	private static String[] footBallNum = null;
	public static Map<String, String> lotNametoDayMap = new HashMap();// 开奖日期对应
	public static Map<String, String> lotNotoName = new HashMap();// 交易类型
	public static Map<String, String> cmsMap = new HashMap();// 专家推荐
	public static Map<String, String> skillMap = new HashMap();// 投注技巧
	public static Map<String, String> skillMap2 = new HashMap();// 投注技巧
	public static Map<String, String> cmsMap2 = new HashMap();// 专家推荐
	public static Map<String, String> state = new HashMap();// 购彩后的状态
	public static Map<String, String> DclotName = new HashMap();// 单场lot
	static {
		initLotName_formatMap();
		initLotName();
		initLotStateMap();
		letoustate();
		tiyuBallNum = new String[] { "104", "105", "108", "109", "110", "111" };
		fuliBallNum = new String[] { "201", "202", "204", "205" };
		footBallNum = new String[] { "102", "103", "106", "107" };
		initCmsMap();
		initSkillMap();
		initlotNameToday();
		initLotNoToLotName();
		initSkillMap2();
		initCmsMap2();
		initDclotName();
	}

	// 如果该玩法是体育彩票返回true
	public static boolean istiyuBalls(String s) {
		for (int i = 0; i < tiyuBallNum.length; i++) {
			if (s.trim().equals(tiyuBallNum[i]))
				return true;
		}
		return false;
	}

	// 如果该玩法是福利彩票返回true
	public static boolean isfuliBalls(String s) {
		for (int i = 0; i < fuliBallNum.length; i++) {
			if (s.trim().equals(fuliBallNum[i]))
				return true;
		}
		return false;
	}

	// 如果该玩法是足彩返回true
	public static boolean isFootBalls(String s) {
		for (int i = 0; i < footBallNum.length; i++) {
			if (s.trim().equals(footBallNum[i]))
				return true;
		}
		return false;
	}

	public static String getPlayCodes(String lotName, String code) {
		code = "/" + code.trim().replace("/", "//") + "/";
		String s = ",201,104,204,110,111,205,";
		return ((s.indexOf(("," + lotName + ",")) != -1) ? code.replaceAll(
				"/(\\d{1})/", "/0$1/") : code).replaceAll("^/", "").replaceAll(
				"/$", "").replace("//", "/");
	}



	private static void initLotStateMap() {
		lotStateMap.put("0", "销售中");
		lotStateMap.put("1", "暂无销售");// 封期
		lotStateMap.put("2", "暂无销售");// 封期
		lotStateMap.put("3", "暂无销售");// 封期
		lotStateMap.put("4", "暂无销售");// 封期
		lotStateMap.put("-1", "暂停销售");
		lotStateMap.put("-2", "暂无销售");// 封期
		lotStateMap.put("-21", "暂无销售");
	}

	private static void letoustate() {
		state.put("0", "发起成功");
		state.put("1", "处理成功");// 封期
		state.put("2", "打印成功");// 封期
		state.put("3", "出票成功");// 封期
		state.put("4", "已搅奖");// 封期
		state.put("5", "已派奖");
		state.put("-1", "废票");// 封期
		state.put("-2", "个人撤单");
		state.put("-3", "系统撤单");
	}

	private static void initLotName_formatMap() {
		lotName_formatMap.put("101", "0/0/0");
		lotName_formatMap.put("102", "0/0/0");
		lotName_formatMap.put("103", "0/0/0");
		lotName_formatMap.put("104", "0/0/0");
		lotName_formatMap.put("105", "0/0/0");
		lotName_formatMap.put("106", "0/0/0");
		lotName_formatMap.put("107", "0/0/0");
		lotName_formatMap.put("108", "0/0/0");
		lotName_formatMap.put("109", "0/0/0");
		lotName_formatMap.put("110", "0/0/0/0/0//0/0");
		lotName_formatMap.put("201", "0/0/0/0/0/0//0");
		lotName_formatMap.put("202", "0/0/0");
		lotName_formatMap.put("111", "0/0/0");
		lotName_formatMap.put("204", "0/0/0");
		lotName_formatMap.put("205", "0/0/0");
	}

	private static void initCmsMap() {
		cmsMap.put("102", "sfc");
		cmsMap.put("103", "rx9c");
		cmsMap.put("104", "378");
		cmsMap.put("105", "375");
		cmsMap.put("106", "4cjq");
		cmsMap.put("107", "bqc");
		cmsMap.put("108", "376");
		cmsMap.put("109", "375");
		cmsMap.put("110", "374");
		cmsMap.put("201", "ssq");
		cmsMap.put("202", "fc3d");
		cmsMap.put("111", "377");
		cmsMap.put("204", "373");
		cmsMap.put("205", "372");
		cmsMap2.put("401", "11x5");
	}

	private static void initCmsMap2() {
		cmsMap2.put("201", "ssq");
		cmsMap2.put("110", "376");
		cmsMap2.put("205", "378");
		cmsMap2.put("104", "375");
		cmsMap2.put("204", "4cjq");
		cmsMap2.put("111", "374");
		cmsMap2.put("105", "pl3");
		cmsMap2.put("202", "fc3d");
		cmsMap2.put("108", "376");
		cmsMap2.put("109", "ssq");
		cmsMap2.put("102", "396 ");
		cmsMap2.put("103", "rx9c");
		cmsMap2.put("107", "bcq");
		cmsMap2.put("106", "372");
		cmsMap2.put("401", "11x5");
	}

	private static void initSkillMap() {
		skillMap.put("102", "396");
		skillMap.put("103", "396");
		skillMap.put("106", "396");
		skillMap.put("107", "396");
		skillMap.put("108", "411");
		skillMap.put("104", "413");
		skillMap.put("105", "408");
		skillMap.put("109", "408");
		skillMap.put("110", "409");
		skillMap.put("201", "406");
		skillMap.put("202", "407");
		skillMap.put("111", "412");
		skillMap.put("204", "gcxd204");
		skillMap.put("205", "410");

	}

	private static void initSkillMap2() {
		skillMap2.put("201", "389");
		skillMap2.put("110", "390");
		skillMap2.put("205", "395");
		skillMap2.put("104", "394");
		skillMap2.put("204", "398");
		skillMap2.put("111", "393");
		skillMap2.put("105", "391");
		skillMap2.put("202", "397");
		skillMap2.put("108", "392");
		skillMap2.put("109", "389");
		skillMap2.put("102", "397");
		skillMap2.put("103", "393");
		skillMap2.put("107", "398");
		skillMap2.put("106", "395");

	}

	private static void initDclotName() {
		DclotName.put("WDL", "301");
		DclotName.put("OverUnder", "302");

		DclotName.put("Score", "304");
		DclotName.put("HalfFull", "305");
		DclotName.put("TotalGoals", "303");

		DclotName.put("WDL1", "让球胜平负");
		DclotName.put("OverUnder1", "上下盘单双");
		DclotName.put("TotalGoals1", "总进球数");
		DclotName.put("Score1", "比分");
		DclotName.put("HalfFull1", "半全场胜平负");

		DclotName.put("301", "WDL");
		DclotName.put("302", "OverUnder");
		DclotName.put("304", "Score");
		DclotName.put("305", "HalfFull");
		DclotName.put("303", "TotalGoals");

	}

	private static void initLotName() {
		lotNameMap.put("102", "胜负彩");
		lotNameMap.put("103", "任选9");
		lotNameMap.put("104", "36选7");
		lotNameMap.put("105", "排列3");
		lotNameMap.put("106", "4场进球");
		lotNameMap.put("107", "6场胜负");
		lotNameMap.put("108", "七星彩");
		lotNameMap.put("109", "排列3/5");
		lotNameMap.put("110", "大乐透");
		lotNameMap.put("201", "双色球");
		lotNameMap.put("202", "福彩3D");
		lotNameMap.put("111", "22选5");
		lotNameMap.put("204", "深圳风采");
		lotNameMap.put("205", "七乐彩");
		lotNameMap.put("401", "11选5");
		lotNameMap.put("301", "胜平负");
		lotNameMap.put("302", "上下盘");
		lotNameMap.put("303", "总进球");
		lotNameMap.put("304", "比分");
		lotNameMap.put("305", "半全场");

		lotNameMap.put("0", "生肖乐");
	}

	// 各玩法的开奖日期
	private static void initlotNameToday() {
		lotNametoDayMap.put("102", "不定期");
		lotNametoDayMap.put("103", "不定期");
		lotNametoDayMap.put("104", "一 三 五");
		lotNametoDayMap.put("105", "每日");
		lotNametoDayMap.put("106", "不定期");
		lotNametoDayMap.put("107", "不定期");
		lotNametoDayMap.put("108", "二 五 日");
		lotNametoDayMap.put("109", "每日");
		lotNametoDayMap.put("110", "一 三 六");
		lotNametoDayMap.put("201", "二 四 日");
		lotNametoDayMap.put("202", "每日");
		lotNametoDayMap.put("111", "每日");
		lotNametoDayMap.put("204", "二 五");
		lotNametoDayMap.put("205", "一 三 五");
	}
public static void main(String[] args){

	System.out.println(StandardFormat.lotNotoName.get("2036"));
}
	// 交易类型
	private static void initLotNoToLotName() {
		lotNotoName.put("1001", "充值");
		lotNotoName.put("1012", "活动奖金");
		lotNotoName.put("1002", "提现");
		lotNotoName.put("1003", "充值100元以上加款");
		lotNotoName.put("1004", "管理员辅助充值");
		lotNotoName.put("1005", "管理员加奖");
		lotNotoName.put("1006", "中奖派奖");
		lotNotoName.put("1007", "107");
		lotNotoName.put("1008", "代购撤单返款");
		lotNotoName.put("1009", "合买撤单返款");
		lotNotoName.put("1010", "合买联盟用户扣钱");
		lotNotoName.put("1011", "激活活动加钱");

		lotNotoName.put("2001", "进球彩代购投注");
		lotNotoName.put("2002", "进球彩代购追期");
		lotNotoName.put("2003", "胜负彩代购投注");
		lotNotoName.put("2004", "胜负彩代购追期");
		lotNotoName.put("2005", "任选9代购投注");
		lotNotoName.put("2006", "任选9代购追期");
		lotNotoName.put("2007", "36选7代购投注");
		lotNotoName.put("2008", "36选7代购追期");
		lotNotoName.put("2009", "进球彩代购投注");
		lotNotoName.put("2010", "进球彩代购追期");
		lotNotoName.put("2011", "6场半 代购投注");
		lotNotoName.put("2012", "胜负彩代购追期");
		lotNotoName.put("2013", "七星彩代购投注");
		lotNotoName.put("2014", "七星彩代购追期");
		lotNotoName.put("2015", "排列5代购投注");
		lotNotoName.put("2016", "排列5代购追期");
		lotNotoName.put("2017", "大乐透代购投注");
		lotNotoName.put("2018", "大乐透代购追期");
		lotNotoName.put("2019", "双色球代购投注");
		lotNotoName.put("2020", "双色球代购追期");
		lotNotoName.put("2021", "3D代购投注");
		lotNotoName.put("2022", "3D代购追期");
		lotNotoName.put("2023", "22选5代购投注");
		lotNotoName.put("2024", "22选5代购追期");
		lotNotoName.put("2025", "深圳风采代购投注");
		lotNotoName.put("2026", "深圳风采代购追期");
		lotNotoName.put("2027", "七乐彩代购投注");
		lotNotoName.put("2028", "七乐彩代购追期");
		lotNotoName.put("2029", "排列三代购投注");
		lotNotoName.put("2030", "排列三代购追期");
		lotNotoName.put("2036", "11选5代购投注");
		lotNotoName.put("2037", "11选5代购追加");
		
		lotNotoName.put("3001", "胜负彩合买参与");
		lotNotoName.put("3002", "任选9合买参与");
		lotNotoName.put("3003", "36选7合买参与");
		lotNotoName.put("3004", "排列三合买参与");
		lotNotoName.put("3005", "进球彩合买参与");
		lotNotoName.put("3006", "6场半合买参与");
		lotNotoName.put("3007", "七星彩合买参与");
		lotNotoName.put("3008", "排列5合买参与");
		lotNotoName.put("3009", "大乐透合买参与");
		lotNotoName.put("3010", "双色球合买参与");
		lotNotoName.put("3011", "3D合买参与");
		lotNotoName.put("3012", "22选5合买参与");
		lotNotoName.put("3013", "深圳风采合买参与");
		lotNotoName.put("3014", "七乐彩合买参与");

		lotNotoName.put("3015", "胜负彩合买保底");
		lotNotoName.put("3016", "任选9合买保底");
		lotNotoName.put("3017", "36选7合买保底");
		lotNotoName.put("3018", "排列三合买保底");
		lotNotoName.put("3019", "进球彩合买保底");
		lotNotoName.put("3020", "6场半合买保底");
		lotNotoName.put("3021", "七星彩合买保底");
		lotNotoName.put("3022", "排列5合买保底");
		lotNotoName.put("3023", "大乐透合买保底");
		lotNotoName.put("3024", "双色球合买保底");
		lotNotoName.put("3025", "3D合买保底");
		lotNotoName.put("3026", "22选5合买保底");
		lotNotoName.put("3027", "深圳风采合买保底");
		lotNotoName.put("3028", "七乐彩合买保底");

		lotNotoName.put("3029", "胜负彩合买个人撤单");
		lotNotoName.put("3030", "任选9合买个人撤单");
		lotNotoName.put("3031", "36选7合买个人撤单");
		lotNotoName.put("3032", "排列三合买个人撤单");
		lotNotoName.put("3033", "进球彩合买个人撤单");
		lotNotoName.put("3034", "胜负彩合买个人撤单");
		lotNotoName.put("3035", "七星彩合买个人撤单");
		lotNotoName.put("3036", "排列5合买个人撤单");
		lotNotoName.put("3037", "大乐透合买个人撤单");
		lotNotoName.put("3038", "双色球合买个人撤单");
		lotNotoName.put("3039", "3D合买个人撤单");
		lotNotoName.put("3040", "22选5合买个人撤单");
		lotNotoName.put("3041", "深圳风采合买个人撤单");
		lotNotoName.put("3042", "七乐彩合买个人撤单");

		lotNotoName.put("3043", "胜负彩合买系统撤单");
		lotNotoName.put("3044", "任选9合买系统撤单");
		lotNotoName.put("3045", "36选7合买系统撤单");
		lotNotoName.put("3046", "排列三合买系统撤单");
		lotNotoName.put("3047", "进球彩合买系统撤单");
		lotNotoName.put("3048", "胜负彩合买系统撤单");
		lotNotoName.put("3049", "七星彩合买系统撤单");
		lotNotoName.put("3050", "排列5合买系统撤单");

		lotNotoName.put("3051", "大乐透合买系统撤单");
		lotNotoName.put("3052", "双色球合买系统撤单");
		lotNotoName.put("3053", "3D合买系统撤单");
		lotNotoName.put("3054", "22选5合买系统撤单");
		lotNotoName.put("3055", "深圳风采合买系统撤单");
		lotNotoName.put("3056", "七乐彩合买系统撤单");
		lotNotoName.put("3057", "排列三系统撤单");

		lotNotoName.put("3058", "胜平负合买保底");
		lotNotoName.put("3059", "上下单双合买保底");
		lotNotoName.put("3060", "比分合买保底");
		lotNotoName.put("3061", "半全场合买保底");
		lotNotoName.put("3062", "总进球数合买保底");
		lotNotoName.put("3063", "胜平负合买系统撤单");
		lotNotoName.put("3064", "上下单双合买系统撤单");
		lotNotoName.put("3065", "比分合买系统撤单");
		lotNotoName.put("3066", "半全场合买系统撤单");
		lotNotoName.put("3067", "总进球数系统撤单");
		lotNotoName.put("3068", "胜平负合买个人撤单");
		lotNotoName.put("3069", "上下单双合买个人撤单");
		lotNotoName.put("3070", "比分合买个人撤单");
		lotNotoName.put("3071", "半全场合买个人撤单");
		lotNotoName.put("3072", "总进球数合买个人撤单");
		lotNotoName.put("2031", "胜平负代购投注");
		lotNotoName.put("2032", "上下单双代购投注");
		lotNotoName.put("2033", "比分代购投注");
		lotNotoName.put("2034", "半全场代购投注");
		lotNotoName.put("2035", "总进球数代购投注");
		lotNotoName.put("3078", "胜平负合买参与");
		lotNotoName.put("3079", "上下单双合买参与");
		lotNotoName.put("3080", "比分合买参与");
		lotNotoName.put("3081", "半全场合买参与");
		lotNotoName.put("3082", "总进球数合买参与");
		lotNotoName.put("3083", "单场停赛撤单");
	 
	}
}
