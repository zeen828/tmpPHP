package com.letousky.lottery.util;

import com.letousky.common.lottery.JCspfEntity;
import com.letousky.common.lottery.LotteryEntity;
import com.letousky.util.JingCaiConst;

import junit.framework.TestCase;

public class JCspfCountAwardTestCase extends TestCase {
	
	LotteryEntity cspEntity = new JCspfEntity();
	
	public void testCountAward2x1() {//3780,3/0,0//3776,3,0 过关方式=2 中奖号码:3780,3/3776,1 spVavle=3780,1.830/3780,0/3776,0
		try{
			
			String[] awardInfo = new String[2];//3872,3/3874,0/3916,1", "3872,3:1.680/3874,0:2.800/3916,1:3.700"));
			
			cspEntity.countAwards(String.valueOf(JingCaiConst.J2x1),
					"4634,3/1,0//4626,1/0,0//4627,3/1,0//4628,1/0,0", "4634,1/4626,1/4627,1/4628,0", "4634,4.10/4626,3.70/4627,3.40/4628,4.70");//过关方式 , 投注号码 ,中奖号码,SP值
			
			String temp = (String) cspEntity.getJiangDeng();
			if (temp != null) {
				String[] awardResult = temp.split("/");// 中奖结果格式为:奖等/注数/奖金(例如:5/1/9.1)
				double awardMoney = Double.parseDouble(awardResult[2])	* Integer.parseInt("1");
				awardInfo[0] = awardResult[0] + ":" + awardResult[1] + "注\r\n";
				awardInfo[1] = String.valueOf(awardMoney);
			}
			
			if(null != awardInfo[0] && null != awardInfo[1]) {
				System.out.println("中奖信息=" + awardInfo[0]);
				System.out.println("中奖金额=" + awardInfo[1]);
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
