/*
 * Created on 2005-12-26
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.letousky.lottery.util;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * @author crazy
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class EncodingFilter implements Filter {

	protected String encoding = null;

	protected FilterConfig config = null;

	protected boolean ignore = true;

	public void destroy() {
		this.encoding = null;
		this.config = null;
	}

	/**
	 * 
	 * @param servletRequest
	 * @param servletResponse
	 * @param filterChain
	 * @return
	 * @exception IOException,ServletException
	 */
	public void doFilter(ServletRequest request, 
						ServletResponse response,
						FilterChain chain) throws IOException, ServletException {

		if (ignore || (request.getCharacterEncoding() == null)) {
			String encoding = selectEncoding(request);
			if (encoding != null)
				request.setCharacterEncoding(encoding);
		}
		chain.doFilter(request, response);
	}

	/**
	 * 
	 * @param filterConfig
	 * @return
	 * @exception ServletException
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

		this.config = filterConfig;
		this.encoding = config.getInitParameter("encoding");
		String value = config.getInitParameter("ignore");
		if (value == null)
			this.ignore = true;
		else if (value.equalsIgnoreCase("true"))
			this.ignore = true;
		else if (value.equalsIgnoreCase("yes"))
			this.ignore = true;
		else
			this.ignore = false;
	}

	/**
	 * 
	 * @param request
	 * @return
	 */
	protected String selectEncoding(ServletRequest request) {

		return (this.encoding);
	}
}