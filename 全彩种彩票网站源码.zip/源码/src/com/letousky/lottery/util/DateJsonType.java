package com.letousky.lottery.util;

import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import  org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.letousky.exception.LotteryException;
import com.letousky.lottery.delegate.ChipinManage;

public class DateJsonType extends DispatchAction{
  
	protected final static Logger __logger = Logger.getLogger(DateJsonType.class);
	
	public ActionForward getJson(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		PrintWriter out=response.getWriter();
		String json=request.getParameter("param");
		__logger.debug("传过来的JSON字符串："+json);

	try{
		String str="",d=",",p="_",t="-",e="/",h="//",m=":",status="0";
		JSONObject jo = JSONObject.fromObject(json);
		
		String JsonType=jo.get("JsonType").toString();
		
		JSONArray ary=(JSONArray)jo.get("DataList");
		
		for(int i=0;i<ary.size();i++){
			str = "";
			JSONObject ap=JSONObject.fromObject(ary.get(i));
			
			if("AwardData".equals(JsonType)){
				
				str+=ap.get("Transcode").toString()+d;
				str+=ap.get("AwardSum").toString()+d;
				str = str.substring(0,str.lastIndexOf(",")-1);
				status="2";
				
			}else{
				
				JSONObject odds=JSONObject.fromObject(ap.get("Odds"));
				JSONObject bet=JSONObject.fromObject(odds.get("bet"));
				str+=ap.get("Transcode").toString()+d;
				str+=ap.get("ticketTrans").toString()+d;
				str+=ap.get("Mac").toString()+d;
				str+=ap.get("Merchant_id").toString()+d;
				str+=ap.get("Printstatus").toString()+d;
				str+=odds.get("ticketingDate").toString()+d;
				str+=odds.get("datatype").toString()+p;
			
				for(int s=0;s<bet.size();s++){
				
					String name = bet.names().get(s).toString();
					JSONObject sp=JSONObject.fromObject(bet.get(name).toString());
					str+=name+t;
					for(int l=0;l<sp.size();l++){
						String overName = sp.names().get(l).toString();
						str+=overName+m;
						if(l==sp.size()-1) str+=sp.get(overName).toString()+h;
						else str+=sp.get(overName).toString()+e;
					}
				
				}
			
			str = str.substring(0,str.lastIndexOf("/")-1);
			status="1";
		 }
			new ChipinManage().datejson(new String[]{status,str}, "C0103");
			out.print("0000");
			__logger.debug("出票成功，修改状态成功======");
		}
		
	}catch(Exception e){
			
			out.print("1111");
			__logger.debug("出票失败，修改状态失败======");
			return null;
	}
	
	return null;
	
}
	
	
	public static void main(String[] args){
		String json="{'JsonType':'TicketResult','DataList':[{'Transcode':'1415524','ticketTrans':'1311081814040000000000197','Mac':'f848fffe8d923b6628240491a8dd7f45','Merchant_id':'51000007','Printstatus':'4','Odds':{'ticketingDate':'2013-11-09 11:45:01','bet':{'F20131108017':{'01':'4.000'},'F20131108007':{'01':'3.300'},'F20131108009':{'01':'3.350'}},'datatype':1}}]}";

		
			String str="",d=",",p="_",t="-",e="/",h="//",m=":",status="0";
			JSONObject jo = JSONObject.fromObject(json);
			String JsonType=jo.get("JsonType").toString();
			
			JSONArray ary=(JSONArray)jo.get("DataList");
		
			for(int i=0;i<ary.size();i++){
				str = "";
				JSONObject ap=JSONObject.fromObject(ary.get(i));
				if("AwardData".equals(JsonType)){
					
					str+=ap.get("Transcode").toString()+d;
					str+=ap.get("AwardSum").toString()+d;
					str = str.substring(0,str.lastIndexOf(",")-1);
					status="2";
					
				}else{
					
					JSONObject odds=JSONObject.fromObject(ap.get("Odds"));
					JSONObject bet=JSONObject.fromObject(odds.get("bet"));
					
					str+=ap.get("Transcode").toString()+d;
					if(!"3".equals(ap.get("Printstatus").toString())){
						str+=ap.get("ticketTrans").toString()+d;
					}
					str+=ap.get("Mac").toString()+d;
					str+=ap.get("Merchant_id").toString()+d;
					str+=ap.get("Printstatus").toString()+d;
					str+=odds.get("ticketingDate").toString()+d;
					str+=odds.get("datatype").toString()+p;
				
					for(int s=0;s<bet.size();s++){
					
						String name = bet.names().get(s).toString();
						JSONObject sp=JSONObject.fromObject(bet.get(name).toString());
						str+=name+t;
						for(int l=0;l<sp.size();l++){
							String overName = sp.names().get(l).toString();
							str+=overName+m;
							if(l==sp.size()-1) str+=sp.get(overName).toString()+h;
							else str+=sp.get(overName).toString()+e;
						}
					
					}
				
				str = str.substring(0,str.lastIndexOf("/")-1);
				System.out.println(str);
				}
		}
	
	}
}
