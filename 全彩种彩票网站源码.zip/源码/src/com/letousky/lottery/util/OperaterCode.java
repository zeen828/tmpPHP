﻿package com.letousky.lottery.util;

import java.util.HashMap;
import java.util.Map;

public class OperaterCode {
	public final static String RESULTS_FOOTBALLMARKETID= "C0182"; 	
	public final static String WINS_NUMBERS 		= "C0143";  				//查询对阵501胜平负
	public final static String WINS_NUMBERS_DZ 		= "C0149";  				//查询对阵502比分
	public final static String WINS_NUMBERS_ZJQ 	= "C0150";  				//查询对阵503总进球
	public final static String WINS_NUMBERS_BQC 	= "C0151";  				//查询对阵504半全场
	public final static String WINS_NUMBERS_RQSPF 	= "C0167";  				//查询对阵511让球胜平负
	public final static String WINS_NUMBERS_HHGG 	= "C0168";  				//查询对阵509足球混合过关
	public final static String WINS_NUMBERS_LQHH 	= "C0169";  				//查询对阵510篮球混合过关
	public final static String WINS_NUMBERS_SF 	    = "C0153";  				//查询对阵505胜负
	public final static String WINS_NUMBERS_RFSF 	= "C0154";  				//查询对阵506让分胜负
	public final static String WINS_NUMBERS_SFC 	= "C0155";  				//查询对阵507胜负差
	public final static String WINS_NUMBERS_DXF 	= "C0156";  				//查询对阵508大小分
	
	public final static String WINS_NUMBERS_DC 	    = "C0161";  				//查询对阵301,302,303,304,305
	public final static String WINS_NUMBERS_TRADE 	= "C0048";  				//查询对阵102,103,106,107
	public final static String WINS_ISSUE_TRADE 	= "C0179";  				//查询开奖信息102,103,106,107(玩法,期号)
	public final static String WINS_WIN_TRADE 		= "C0178";  				//查询可销售期号102,103,106,107(玩法)
	
	public final static String CHIPPEDLIST_NUMBERS 	= "C0112"; 					//查询合买集合(玩法类型,status,分页参数)
	public final static String CHIPPED_COUNT 		= "C0113"; 					//合买总记录数
	public final static String CHIPPEDLIST_NUMBERS_NEW 	= "C0116"; 					//查询合买集合(玩法类型,status,分页参数)
	public final static String CHIPPED_COUNT_NEW 		= "C0117"; 					//合买总记录数
	
	public final static String FOOTBALL_BETTING 	= "C0010";  				//竞彩足球代沟，合买投注
	public final static String CHIPPED_BETTING 		= "C0011";  				//参与合买投注
	
	public final static String List_Details 		= "C0118";  				//合买详情集合(合买ID)
	public final static String List_Details_SARNO 	= "C0141";  				//合买详情集合(交易号)
	public final static String List_Details_SARNOTWO= "C0170";  				//新合买详情集合(交易号)
	public final static String List_ISOPEN_UPDATE 	= "C0171";  				//修改方案状态(交易号,状态编号0公开  1保密)
	public final static String List_USER_Details 	= "C0119";  				//合买用户(交易号，分页参数)
	public final static String List_COUNT_Details 	= "C0120";  				//合买用户总记录数(交易号)
	
	/*竞彩--我中啦数据接口*/
	public final static String DOM_URL = "http://116.213.75.148:8080/fbService/sltAPI?v=1&uid=800001&pwd=12345&sport=s&";
	public final static String SERVICES_HOST = "www.webxml.com.cn";
	
	/*
	 * 本站首页   数据接口
	 * */
	public final static String BUY_HOT_SINGLE 	    = "C0140";  				//首页合买热单(无)
	public final static String BUY_WINNING_MSG 	    = "C0067";  				//首页中奖信息(无)
	public final static String BUY_WINNING_LJZ 	    = "C0166";  				//首页中奖信息(无)
	public final static String BUY_WINNING_SSQ      = "C0209";                  //双色球购买,左国斌
	
	
	/*
	 * 用户信息
	 * 
	 */
	public final static String USER_LOGIN 		    = "C0002";				   	//用户登录(用户名，密码)
	public final static String USER_ACCOUNT 		= "C0012";				   	//查询用户账户信息(用户名，密码)
	public final static String USER_INFOMATION 		= "C0035";				   	//用户信息显示
	public final static String USER_INFO_SAVE    	= "C0136";					//用户信息保存
	public final static String USER_CZ_INFO_SAVE    = "C0173";					//用户注册信息保存
	public final static String PWD_UPDATE			= "C0008";					//密码修改
	public final static String FIND_PWD				= "C0034";					//找回密码
	public final static String PWD_PROTECT_SET		= "C0031"; 					//设置密码保护
	public final static String PWD_PROTECT_UPDATE   = "C0032";					//修改密码保护
	public final static String PWD_PROTECT_QUESTION = "C0030";					//获得密码保护问题
	
	public final static String CHECK_USERNAME		= "C0047";					//检查用户名
	public final static String CHECK_NICKNAME		= "C0049";					//检查用户昵称
	public final static String SEND_CODE			= "C0139";					//发送验证码
	public final static String USER_REGISTER		= "C0001";					//用户注册
	
	public final static String IS_IDENTITY_BIND		= "C0129";					//是否已身份绑定
	public final static String IDENTITY_BIND		= "C0124";					//绑定身份
	
	public final static String IS_BANK_CARD			= "C0131";					//是否已绑定银行卡
	public final static String BANK_CARD			= "C0125";					//绑定银行卡
	public final static String USER_ACTION			= "C0142";					//用户激活(用户名，密码)
	public final static String EMAIL_CHECK			= "C0144";					//邮箱验证
	public final static String PHONE_CHECK 			= "C0145";					//验证手机
	
	public final static String RESULTS_FOOTBALL_SCORE= "C0175";  				//即时比分竞彩(时间)
	public final static String RESULTS_FOOTBALLDC_SCORE= "C0176";  				//即时比分单场(期数)
	public final static String RESULTS_BASKEDBALLDC_SCORE= "C0177";  			//即时比分篮彩(时间)
	public final static String RESULTS_FOOTBALLRECORD_SCORE= "C0180";  			//足球赔率变化(info)
	public final static String RESULTS_BASKEDBALLRECORD_SCORE= "C0181";  		//篮彩赔率变化(info)
	public final static String CHECK_MOBILE			= "C0191";	
	public static final String MOBILE_BIND			= "C0202";					//手机绑定
	public final static String LOGIN_FEEDBACK 		    = "C0208";				   	//更新feedback;
	
	/*
	 * 会员中心  -- 我的账户
	 * 
	 */
	public final static String BUY_LOTTERY 			= "C0121";				   	//购彩记录集合(用户ID,玩法类型,状态,开始时间,结束时间,分页参数)
	public final static String BUY_COUNT_LOTTERY 	= "C0122";				   	//购彩记录总记录数(用户ID,玩法类型,状态,开始时间,结束时间)
	public final static String BUY_LOTTERY_DETAILS  = "C0123";					//购彩记录详情(交易号)
	
	public final static String TARY_SAVE_SINGLE		= "C0105";					//保存自动跟单 定制跟单(玩法类型,发起人,跟单人的呢称,跟单金额)
	public final static String TARY_CANCEL_SINGLE   = "C0106";					//取消自动跟单 取消定制的跟单(玩法类型,发起人,跟单人的呢称)
	public final static String TARY_SELECT_SINGLE	= "C0107";					//查询某个用户参与的所有定制的订单(用户呢称,玩法类型,状态,分页参数)
	public final static String TARY_SELECT_COUNT	= "C0128";					//所有定制订单总记录数(用户呢称,玩法类型,状态)
	public final static String TARY_SELECT_BINVI 	= "C0108";					//查询某个用户被邀请的所有记录集合(用户呢称,分页参数)
	public final static String TARY_COUNT_BINVI		= "C0109";					//查询某个用户被邀请的所有记录集合总条数(用户呢称)
	public final static String TARY_APPOINT_BINVI	= "C0126";					//我指定的跟单人集合(用户呢称,分页参数)
	public final static String TARY_APPOINT_COUNT	= "C0127";					//我指定的跟单人集合总条数(用户呢称)
	public final static String TARY_SINGLE_USER		= "C0132";					//跟我单的用户(用户呢称)
	public final static String TARY_ADDSINGLE_USER	= "C0130";					//跟我单的用户,添加跟单用户(玩法类型,发起人呢称,跟单人呢称,消息内容)
	public final static String TARY_DELJJ_YQ		= "C0133";					//跟我单的用户(消息ID,状态0删除,1未读)
	
	public final static String TARY_TEMP_DETAIL		= "C0159";					//出票详情记录(交易号，分页参数)
	public final static String TARY_TEMP_DETAIL_COUNT= "C0160";					//出票详情记录总数(交易号)
	
	public final static String ACCOUNT_DETAILS_LIST	= "C0013";				    //账户明细所有记录集合(开始时间,结束时间,交易类型)
	public final static String ACCOUNT_COUNT_STRIP	= "C0023";				    //账户明细总记录数(开始时间,结束时间,交易类型)
	
	
	public final static String ALIPAY_CASH          = "C0005";					//提现申请(用户名,密码,提现金额)
	public final static String ZPINJC_COMMISSION    = "C0152";					//佣金转入(用户ID，金额，来源1001)
	
	/*
	 * 购买彩票   本站辅助资料
	 * 
	 * */
	public final static String RESULTS_THE_LOTTERY	= "C0134";					//赛果开奖集合(时间，分页参数) 足球
	public final static String RESULTS_THE_BAKLOTTERY="C0157";					//赛果开奖集合(时间，分页参数) 篮球
	public final static String RESULTS_THE_BAKSTRIP ="C0158";					//赛果开奖集合(时间) 篮球总记录
	public final static String RESULTS_LOTTERY_STRIP= "C0135";					//赛果开奖总记录条数(时间)     足球总记录
	public final static String RESULTS_THE_DCLOTTERY = "C0085";					//赛果开奖集合(彩种，期号)北单
	public final static String RESULTS_INSTANT_SCORE= "C0146";  				//即时比分(时间)竞彩
	public final static String RESULTS_INSTANT_SCOREDC= "C0163";  				//即时比分(期号,对阵编号逗号分隔)北单
	public final static String RESULTS_USER_ZHANJI  = "C0147";  				//战绩集合()
	public final static String RESULTS_USER_ZJSTRIP = "C0148";  				//战绩集合总条数
	public final static String GGTJ					= "C0137";				    //中奖查询
	public final static String GGTJ_SUM				= "C0138";				    //中奖查询总记录数
	public final static String WINSITEM				= "C0077";				    //中奖查询
	public final static String NOW_ISSUE            = "C0018";					//查询当前期号
	public final static String CT_RESULTS 			= "C0162";					//传统足球开奖
	public final static String BETTING_SELLECT= "C0172";  				//即时比分(时间)竞彩
//	public final static String T_CHIPIN_TEMP_JL		= "C0167";					//出票详情总记录数
//	public final static String T_CHIPIN_TEMP		= "C0168";					//出票详情集合，T_CHIPIN_TEMP(交易号，分页参数)
	
	public final static String ISSUE_QUERY= "C0210";  				//期号查询
	
	/*
	 * 传统足彩上传号码格式定义
	 * 
	 * params[0] 投注号码长度
	 * 
	 * params[1] 投注号码包含的数字
	 * */
	public final static Map map = new HashMap();
	public final static String[] MAP_SFC = new String[]{"14","3|1|0"}; //14场 胜负彩
	public final static String[] MAP_BQC = new String[]{"12","3|1|0"};  //半全场
	public final static String[] MAP_RXJ = new String[]{"14","3|1|0|9"}; //任选9场
	public final static String[] MAP_JQC = new String[]{"8","0|1|2|3"}; //4场进球
	
	/*
	 * 北京单场上传号码格式定义
	 * 
	 * params[0] 投注号码长度
	 * 
	 * params[1] 投注号码包含的数字
	 * */
	public final static String[] MAP_DCSPF  = new String[]{"3","3|1|0"}; //胜平负
	public final static String[] MAP_DCSXDS = new String[]{"4","上单|上双|下单|下双"}; //上下单双
	public final static String[] MAP_DCZJQ  = new String[]{"8","0|1|2|3|4|5|6|7"}; //总进球
	public final static String[] MAP_DCBF   = new String[]{"4","43|10|20|21|30|31|32|40|41|42|44|00|11|22|33|34|01|02|12|03|13|23|04|14|24"}; //比分
	public final static String[] MAP_DCBQC  = new String[]{"8","33|31|30|13|11|10|03|01|00"}; //半全场
	
	
	public final static String GET_GAMEJSON_CAIGUO_TO_TZ = "{\"501负\":\"0\",\"501胜\":\"3\",\"501平\":\"1\",\"511胜\":\"3\",\"511平\":\"1\",\"511负\":\"0\""+
			  ",\"5021:0\":\"1:0\",\"5022:0\":\"2:0\",\"5022:1\":\"2:1\",\"5023:0\":\"3:0\",\"5023:1\":\"3:1\",\"5023:2\":\"3:2\""+
			  ",\"5024:0\":\"4:0\",\"5024:1\":\"4:1\",\"5024:2\":\"4:2\",\"5025:0\":\"5:0\",\"5025:1\":\"5:1\",\"5025:2\":\"5:2\""+
			  ",\"5020:0\":\"0:0\",\"5021:1\":\"1:1\",\"5022:2\":\"2:2\",\"5023:3\":\"3:3\",\"5020:1\":\"0:1\",\"5020:2\":\"0:2\""+
			  ",\"5021:2\":\"1:2\",\"5020:3\":\"0:3\",\"5021:3\":\"1:3\",\"5022:3\":\"2:3\",\"5020:4\":\"0:4\",\"5021:4\":\"1:4\""+
			  ",\"5022:4\":\"2:4\",\"5020:5\":\"0:5\",\"5021:5\":\"1:5\",\"5022:5\":\"2:5\",\"502胜其它\":\"4:3\",\"502平其它\":\"4:4\",\"502负其它\":\"3:4\""+
			  ",\"5030\":\"0\",\"5031\":\"1\",\"5032\":\"2\",\"5033\":\"3\",\"5034\":\"4\",\"5035\":\"5\",\"5036\":\"6\",\"5037\":\"7\""+
			  ",\"504胜胜\":\"3_3\",\"504胜平\":\"3_1\",\"504胜负\":\"3_0\",\"504平胜\":\"1_3\",\"504平平\":\"1_1\",\"504平负\":\"1_0\""+
			  ",\"504负胜\":\"0_3\",\"504负平\":\"0_1\",\"504负负\":\"0_0\""+
			  ",\"505主胜\":\"1\",\"504主负\":\"0\",\"506主胜\":\"1\",\"506主负\":\"0\",\"508大分\":\"1\",\"508小分\":\"2\""+
			  ",\"5071-5\":\"01\",\"5076-10\":\"02\",\"50711-15\":\"03\",\"50716-20\":\"04\",\"50721-25\":\"05\",\"50726\":\"06\""+
			  
			  ",\"301胜\":\"3\",\"301平\":\"1\",\"301负\":\"0\",\"1023\":\"3\",\"1021\":\"1\",\"1020\":\"0\""+
			  ",\"3041:0\":\"1:0\",\"3042:0\":\"2:0\",\"3042:1\":\"2:1\",\"3043:0\":\"3:0\",\"3043:1\":\"3:1\",\"3043:2\":\"3:2\""+
			  ",\"3044:0\":\"4:0\",\"3044:1\":\"4:1\",\"3044:2\":\"4:2\",\"3045:0\":\"5:0\",\"3045:1\":\"5:1\",\"3045:2\":\"5:2\""+
			  ",\"3040:0\":\"0:0\",\"3041:1\":\"1:1\",\"3042:2\":\"2:2\",\"3043:3\":\"3:3\",\"3040:1\":\"0:1\",\"3040:2\":\"0:2\""+
			  ",\"3041:2\":\"1:2\",\"3040:3\":\"0:3\",\"3041:3\":\"1:3\",\"3042:3\":\"2:3\",\"3040:4\":\"0:4\",\"3041:4\":\"1:4\""+
			  ",\"3042:4\":\"2:4\",\"3041:0\":\"0:5\",\"3041:5\":\"1:5\",\"3042:5\":\"2:5\",\"304胜其它\":\"4:3\",\"304平其它\":\"4:4\",\"304负其它\":\"3:4\""+
			  ",\"3030\":\"0\",\"3031\":\"1\",\"3032\":\"2\",\"3033\":\"3\",\"3034\":\"4\",\"3035\":\"5\",\"3036\":\"6\",\"3037\":\"7\""+
			  ",\"305胜-胜\":\"3_3\",\"305胜-平\":\"3_1\",\"305胜-负\":\"3_0\",\"305平-胜\":\"1_3\",\"305平-平\":\"1_1\",\"305平-负\":\"1_0\""+
			  ",\"305负-胜\":\"0_3\",\"305负-平\":\"0_1\",\"305负-负\":\"0_0\""+
			  ",\"302上单\":\"上单\",\"302上双\":\"上双\",\"302下单\":\"下单\",\"302下双\":\"下双\""+
			  
			  ",\"1033\":\"3\",\"1031\":\"1\",\"1030\":\"0\",\"1060\":\"0\",\"1061\":\"1\",\"1062\":\"2\",\"1063\":\"3\""+
			  ",\"1073\":\"3\",\"1071\":\"1\",\"1070\":\"0\"}";

public final static String GET_GAMEJSON_TZ_TO_CAIGUO = "{\"5010\":\"负\",\"5013\":\"胜\",\"5011\":\"平\",\"5113R\":\"胜\",\"5111R\":\"平\",\"5110R\":\"负\",\"5113\":\"胜\",\"5111\":\"平\",\"5110\":\"负\""+
			  ",\"5021:0\":\"1:0\",\"5022:0\":\"2:0\",\"5022:1\":\"2:1\",\"5023:0\":\"3:0\",\"5023:1\":\"3:1\",\"5023:2\":\"3:2\""+
			  ",\"5024:0\":\"4:0\",\"5024:1\":\"4:1\",\"5024:2\":\"4:2\",\"5025:0\":\"5:0\",\"5025:1\":\"5:1\",\"5025:2\":\"5:2\""+
			  ",\"5020:0\":\"0:0\",\"5021:1\":\"1:1\",\"5022:2\":\"2:2\",\"5023:3\":\"3:3\",\"5020:1\":\"0:1\",\"5020:2\":\"0:2\""+
			  ",\"5021:2\":\"1:2\",\"5020:3\":\"0:3\",\"5021:3\":\"1:3\",\"5022:3\":\"2:3\",\"5020:4\":\"0:4\",\"5021:4\":\"1:4\""+
			  ",\"5022:4\":\"2:4\",\"5020:5\":\"0:5\",\"5021:5\":\"1:5\",\"5022:5\":\"2:5\",\"5024:3\":\"胜其它\",\"5024:4\":\"平其它\",\"5023:4\":\"负其它\""+
			  ",\"5030\":\"0\",\"5031\":\"1\",\"5032\":\"2\",\"5033\":\"3\",\"5034\":\"4\",\"5035\":\"5\",\"5036\":\"6\",\"5037\":\"7\""+
			  ",\"5030B\":\"0\",\"5031B\":\"1\",\"5032B\":\"2\",\"5033B\":\"3\",\"5034B\":\"4\",\"5035B\":\"5\",\"5036B\":\"6\",\"5037B\":\"7\""+
			  ",\"5043_3\":\"胜胜\",\"5043_1\":\"胜平\",\"5043_0\":\"胜负\",\"5041_3\":\"平胜\",\"5041_1\":\"平平\",\"5041_0\":\"平负\""+
			  ",\"5040_3\":\"负胜\",\"5040_1\":\"负平\",\"5040_0\":\"负负\""+
			  ",\"5051\":\"主胜\",\"5050\":\"主负\",\"5061\":\"让分主胜\",\"5060\":\"让分主负\",\"5061D\":\"让分主胜\",\"5060D\":\"让分主负\",\"5081\":\"大分\",\"5082\":\"小分\",\"5081B\":\"大分\",\"5082B\":\"小分\""+
			  ",\"50701\":\"客1-5\",\"50702\":\"客6-10\",\"50703\":\"客11-15\",\"50704\":\"客16-20\",\"50705\":\"客21-25\",\"50706\":\"客26+\""+
			  ",\"50751\":\"主1-5\",\"50752\":\"主6-10\",\"50753\":\"主11-15\",\"50754\":\"主16-20\",\"50755\":\"主21-25\",\"50756\":\"主26+\""+
			  
			  ",\"3013\":\"胜\",\"3011\":\"平\",\"3010\":\"负\",\"1023\":\"3\",\"1021\":\"1\",\"1020\":\"0\""+
			  ",\"3041:0\":\"1:0\",\"3042:0\":\"2:0\",\"3042:1\":\"2:1\",\"3043:0\":\"3:0\",\"3043:1\":\"3:1\",\"3043:2\":\"3:2\""+
			  ",\"3044:0\":\"4:0\",\"3044:1\":\"4:1\",\"3044:2\":\"4:2\",\"3045:0\":\"5:0\",\"3045:1\":\"5:1\",\"3045:2\":\"5:2\""+
			  ",\"3040:0\":\"0:0\",\"3041:1\":\"1:1\",\"3042:2\":\"2:2\",\"3043:3\":\"3:3\",\"3040:1\":\"0:1\",\"3040:2\":\"0:2\""+
			  ",\"3041:2\":\"1:2\",\"3040:3\":\"0:3\",\"3041:3\":\"1:3\",\"3042:3\":\"2:3\",\"3040:4\":\"0:4\",\"3041:4\":\"1:4\""+
			  ",\"3042:4\":\"2:4\",\"3041:0\":\"0:5\",\"3041:5\":\"1:5\",\"3042:5\":\"2:5\",\"3044:3\":\"胜其它\",\"3044:4\":\"平其它\",\"3043:4\":\"负其它\""+
			  ",\"3030\":\"0\",\"3031\":\"1\",\"3032\":\"2\",\"3033\":\"3\",\"3034\":\"4\",\"3035\":\"5\",\"3036\":\"6\",\"3037\":\"7\""+
			  ",\"3053-3\":\"胜胜\",\"3053-1\":\"胜平\",\"3053-0\":\"胜负\",\"3051-3\":\"平胜\",\"3051-1\":\"平平\",\"3051-0\":\"平负\""+
			  ",\"3050-3\":\"负胜\",\"3050-1\":\"负平\",\"3050-0\":\"负负\""+
			  ",\"302上单\":\"上单\",\"302上双\":\"上双\",\"302下单\":\"下单\",\"302下双\":\"下双\""+
			  
			  ",\"1033\":\"3\",\"1031\":\"1\",\"1030\":\"0\",\"1039\":\"9\",\"106z0\":\"主0球\",\"106z1\":\"主1球\",\"106z2\":\"主2球\",\"106z3\":\"主3+球\""+
			  ",\"106k0\":\"客0球\",\"106k1\":\"客1球\",\"106k2\":\"客2球\",\"106k3\":\"客3+球\""+
			  ",\"107b3\":\"半场(胜)\",\"107b1\":\"半场(平)\",\"107b0\":\"半场(负)\",\"107q3\":\"全场(胜)\",\"107q1\":\"全场(平)\",\"107q0\":\"全场(负)\""+
			  ",\"701\":\"猜冠军\"}";

}
