package com.letousky.lottery.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.nutz.json.Json;
import org.nutz.json.JsonFormat;

import net.sf.json.JSONObject;

import com.letoula.MatchAction;
import com.letoula.data.wozhongla.League;
import com.letousky.common.lottery.FactoryEntity;
import com.letousky.common.lottery.JCspfEntity;
import com.letousky.common.lottery.LotteryEntity;
import com.letousky.connector.Message;
import com.letousky.connector.MessageHandler;
import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.lottery.delegate.AbstractDelegate;
import com.letousky.lottery.delegate.WinsFlat;
import com.letousky.util.JingCaiConst;
import com.letousky.lottery.util.OperaterCode;

public class Test extends AbstractDelegate{

	public final static String SPLAI = "%23;";
	MatchAction  ma = new MatchAction();
	
	public static String[] zuheyd= new  String[24]; 
	
	public static void zuheYH(){
		zuheyd[0] = "周日007->0;周日011->0";
		zuheyd[1] = "周日010->0;周日011->0";
		zuheyd[2] = "周日004->0;周日011->0";
		zuheyd[3] = "周日007->0;周日010->0";
		zuheyd[4] = "周日004->0;周日007->0";
		zuheyd[5] = "周日004->0;周日010->0";
		zuheyd[6] = "周日010->1;周日011->0";
		zuheyd[7] = "周日007->1;周日011->0";
		zuheyd[8] = "周日004->1;周日011->0";
		zuheyd[9] = "周日007->0;周日010->1";
		zuheyd[10] = "周日004->0;周日010->1";
		zuheyd[11] = "周日004->1;周日007->0";
		zuheyd[12] = "周日007->1;周日010->0";
		zuheyd[13] = "周日004->0;周日007->1";
		zuheyd[14] = "周日007->0;周日011->1";
		zuheyd[15] = "周日004->1;周日010->0";
		zuheyd[16] = "周日010->0;周日011->1";
		zuheyd[17] = "周日004->0;周日011->1";
		zuheyd[18] = "周日007->1;周日010->1";
		zuheyd[19] = "周日004->1;周日010->1";
		zuheyd[20] = "周日010->1;周日011->1";
		zuheyd[21] = "周日004->1;周日007->1";
		zuheyd[22] = "周日007->1;周日011->1";
		zuheyd[23] = "周日004->1;周日011->1";
		
		String sss_ = "";
		for(int s=0;s<zuheyd.length;s++){
			sss_ += zuheyd[s]+";";
		}
		sss_ = sss_.substring(0,sss_.length()-1);
		String[] newarr = sss_.split("\\;");
		String[] sortArr = arrsort(newarr,"->");
		for(int b=0;b<sortArr.length;b++){
			//System.out.println(sortArr[b]);
		}
		
		 List<String> list = new ArrayList<String>();
		 for (int i=0; i<sortArr.length; i++) {	
			 if(!list.contains(sortArr[i])) {//如果数组 list 不包含当前项，则增加该项到数组中	
				 list.add(sortArr[i]);	
				}   
		}
		 
		 String[] newStr =  list.toArray(new String[1]); 
		 Map newMap = new HashMap();
		 for (String element:newStr ) {
			 String[] bss = element.split("\\->");
			 if(newMap.containsKey(bss[0])){
				 newMap.put(bss[0],newMap.get(bss[0]).toString() +","+ bss[1]);
			 }else{
				 newMap.put(bss[0], bss[1]);
			 }
		}
	
		Set set = newMap.entrySet();
		Iterator iterator=set.iterator();
	    while (iterator.hasNext()) {   
	         Map.Entry  mapentry = (Map.Entry) iterator.next(); 
	         System.out.println(mapentry.getKey()+"----"+mapentry.getValue());
	    }
	}
	
	public static String[] arrsort(String[] arr,String separator){
			for(int i=0;i<arr.length-1;i++){
				for(int k=0;k<arr.length-i-1;k++){
					if(Integer.parseInt(zjtime(arr[k]).split(separator)[0])>Integer.parseInt(zjtime(arr[k+1]).split(separator)[0])){
						 String temp = arr[k];
						 arr[k] =  arr[k + 1];
						 arr[k + 1] = temp;
					}
				}
			}
		return arr;
	}
	
	public static String zjtime(String str){
		String ss = "";
		if(str.indexOf("周一")!=-1){
			ss = str.replace("周一", "1");
		}else if(str.indexOf("周二")!=-1){
			ss = str.replace("周二", "2");
		}else if(str.indexOf("周三")!=-1){
			ss = str.replace("周三", "3");
		}else if(str.indexOf("周四")!=-1){
			ss = str.replace("周四", "4");
		}else if(str.indexOf("周五")!=-1){
			ss = str.replace("周五", "5");
		}else if(str.indexOf("周六")!=-1){
			ss = str.replace("周六", "6");
		}else if(str.indexOf("周日")!=-1){
			ss = str.replace("周日", "7");
		}
		return ss;
	}
	public static void main(String[] args) throws Exception {
		
///*	//	zuheYH();
//		String operaterCode = "C0161";
//		String[] params=new String[2];
//		params[0]="301";
//		params[1]="40105";
//		String results = new Test().helpMessage(params,operaterCode);
		
//		String[] ary = new MessageTool().split(results);
//		for(int i=0;i<ary.length;i++){
//			System.out.println(ary[i]);
//		}

	/*	List list=new MessageTool().splits(results);
		Object[] obj=list.toArray();
		String[] str=null;
	
		for(int i=0;i<obj.length;i++){
			str=(String[])obj[i]; 
			
				for(int s=0;s<str.length;s++){
					System.out.print(str[s]+"--");
				}
				System.out.println("");
			
		
		} 
		*/
		String betNumLine="21";
		String[] aa= betNumLine.split("\\ss");
		for(int i=0;i<aa.length;i++)
		{
			System.out.println(aa[i]);
		}
//		LotteryEntity lotteryentity = FactoryEntity.createClass("509");
//		lotteryentity.countChipins("2", "1234,3/1/3R,0//2345,3,0//4567,3,0");
//		int zs = lotteryentity.getZhuShu();
//		System.out.println(zs);
	}
	
}
