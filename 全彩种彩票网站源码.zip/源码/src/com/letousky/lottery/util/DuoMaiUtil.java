package com.letousky.lottery.util;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class DuoMaiUtil {
	 //=================================================推送的URL例子================================================//  
	static String  t="http://www.duomai.com/api/order.php?" +
    		"mid=10026" +
    		"&hash=bc99ae0c22fbf6e4ab45abe0c7d46684" +
    		"&euid=dGVzdA==" +
    		"&order_sn=14010600035708" +
    		"&order_time=2014-01-06%2016:23:00" +
    		"&orders_price=6108.000000" +
    		"&discount_amount=0.000000" +
    		"&promotion_code=discountAmount" +
    		"&is_new_custom=0" +
    		"&status=9" +
    		"&commission=305.4" +
    		"&goods_id=000650030060010016%7C000650030060010018%7C000560080030020001" +
    		"&goods_name=TOTO%E3%80%80%E5%88%86%E4%BD%93%E9%A9%AC%E6%A1%B6300%E5%9D%91%E8%B7%9DCW703NB%2FSW703NB%7C111111111111111111111TOTO%E3%80%80%E5%88%86%E4%BD%93%E9%A9%AC%E6%A1%B6300%E5%9D%91%E8%B7%9DCW703NB%2FSW703NB%7C%E9%83%8E%E9%95%9C-b" +
    		"&goods_price=102.000000%7C6.000000%7C1200.000000" +
    		"&goods_ta=1%7C1%7C5" +
    		"&goods_cate=0%7C0%7C0" +
    		"&goods_cate_name=0%7C0%7C0" +
    		"&commission_type=A%7CA%7CA" +
    		"&rate=0.05%7C0.05%7C0.05" +
    		"&test=1";
	
	static String  tt="http://www.duomai.com/api/order.php?" +
	"mid=10026" +
	"&hash=bc99ae0c22fbf6e4ab45abe0c7d46684" +
	"&euid=dGVzdA==" +
	"&order_sn=14010600035708" +
	"&order_time=2014-01-06%2016:23:00" +
	"&orders_price=2.000000" +
	"&discount_amount=0.000000" +
	"&promotion_code=discountAmount" +
	"&is_new_custom=0" +
	"&status=0" +
	"&commission=305.4" +
	"&goods_id=201407102501_1_2" +
	"&goods_name=竞彩足球胜平负代购1注" +
	"&goods_price=2.0" +
	"&goods_ta=1" +
	"&goods_cate=0" +
	"&goods_cate_name=0" +
	"&commission_type=0" +
	"&rate=0.08" +
	"&test=1";
  //===============================================我们提供给多麦的URL==================================================//  
    String URL="http://www.beikecai.com/union_cps.php?" +
    		"sid=duomai" +
    		"&euid=10026_235_0_dGVzdA%3D%3D_0" +
    		"&mid=10026" +
    		"&to=http%3A%2F%2Fwww.beikecai.com%2F";
    
    String str="db53d36da07596e5ef88084bf88ad90c";
	public void sendHttp(){
		String paras="";
	}
	public static void main(String[] args) {
		String paras=tt;
		String xml=getHtmlByUrl(paras, 3);
		System.out.println(xml);
	}
	
	public static String getHtmlByUrl(String url, int charcode) {
		String html = null;
		HttpClientBuilder builder = HttpClientBuilder.create();
		HttpClient client = builder.build();
		HttpPost get = new HttpPost(url);
		try {
			HttpResponse response = client.execute(get);
			int resStatus = response.getStatusLine().getStatusCode();
			if (resStatus == HttpStatus.SC_OK) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					if (charcode == 1) {
						html = new String(EntityUtils.toString(entity)
								.getBytes("ISO_8859_1"), "GBK");
					} else if(charcode==2) {
						html = EntityUtils.toString(entity);
					}
					else
					{
						html = new String(EntityUtils.toString(entity)
								.getBytes("ISO_8859_1"), "UTF-8");
					}
				}
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			builder.disableConnectionState();
			// client.getConnectionManager().shutdown();
		}
		return html;
	}
}
