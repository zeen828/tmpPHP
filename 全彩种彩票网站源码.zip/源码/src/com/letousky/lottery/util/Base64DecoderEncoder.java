package com.letousky.lottery.util;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class Base64DecoderEncoder {
	/**    
     * BASE64解密   
   * @param key          
     * @return          
     * @throws Exception          
     */              
    public static String decryptBASE64(String key) throws Exception {   
    	byte[] byteDecr = new BASE64Decoder().decodeBuffer(key);
        return new String(byteDecr,"UTF-8");               
    }               
                  
    /**         
     * BASE64加密   
   * @param key          
     * @return          
     * @throws Exception          
     */              
    public static String encryptBASE64(byte[] key) throws Exception {               
        return (new BASE64Encoder()).encodeBuffer(key);               
    }  
    
    public static void main(String[] args)
    {
    	try {
    		String aa = Base64DecoderEncoder.encryptBASE64("李发扬".getBytes());
			System.out.println(aa);
			System.out.println(Base64DecoderEncoder.decryptBASE64("5p2O5Y+R5oms"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
