
var pageCount;//总页数
var currentPage;//当前页

function load()
{
	activityList(1);
}

//活动列表
function activityList(page)
{
	currentPage = page;
	$.ajax
	({
		url:'././activityAction.do?action=activityList&page='+page,
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var items = data.items;
			var activitys = data.activitys;
			var count = data.count;
			pageCount = data.pageCount;
			$('#num_id').text(count);
			$('#pageNum').text("共"+pageCount+"页");
			$('.context').empty();
			for(var i=0; i<items.length; i++)
			{
				var trNode =
				"<tr>"+
					"<td align='center' class='tab_content'>"+items[i].activityId+"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='text' id='activityName' value='"+items[i].activityName+"'></input>"+
					"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='text' id='beginTime' value='"+items[i].beginTime+"'></input>"+
					"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='text' id='endTime' value='"+items[i].endTime+"'></input>"+
					"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='button' value='修改活动' onclick='updateActivity(this)'/>"+
					"</td>"+
				"</tr>";
				$('.context').append(trNode);
			}
		}
	});
}

//修改活动信息
function updateActivity(_this)
{
	if (confirm("确定修改？"))
	{
		var trNode = $(_this).parent().parent();
		var activityId = trNode.children("td").eq(0).text();
		var activityName = trNode.find("#activityName").val();
		var beginTime = trNode.find("#beginTime").val();
		var endTime = trNode.find("#endTime").val();
		var reg = /^(\d{4})\-(\d{2})\-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/;
		if (reg.test(beginTime) == false || reg.test(endTime) == false)
		{
			alert("日期格式不对！");
			return false;
		}
		alert(activityId);
		alert(activityName);
		alert(beginTime);
		alert(endTime);
		return;
		if (activityName=="" || beginTime=="" || endTime=="")
		{
			alert("数据不能为空！");
			return;
		}
		$.ajax
		({
			url:'././activityAction.do?action=updateActivity&activityId='+activityId+'&activityName='+activityName+'&beginTime='+beginTime+'&endTime='+endTime,
			type:'GET',
			error:function(){alert('修改失败！！！')},
			success:function(data)
			{
				if (data > 0)
				{
					alert('修改成功');
				}
			}
		 });
	}
}

//跳至编辑汇率页面
function skipRate(_this,rateType)
{
	var trNode = $(_this).parent().parent();
	var userId = trNode.find("#userId").val();
	var loginName = trNode.children("td").eq(0).text();
	location.href='editRate.jsp?userId='+userId+'&type='+rateType+'&loginName='+loginName;	
}

//页数操作
function checkPage(_this)
{
	var tmpPage = 1;
	if($(_this).attr('id')=='aa'){
		tmpPage = pageCount;
	}else if($(_this).attr('id')=='back'){
		if (currentPage > 1){
			tmpPage = currentPage-1;
		}
	}else if($(_this).attr('id')=='next'){
		if (currentPage < pageCount){
			tmpPage = currentPage+1;	
		}
		if (currentPage >= pageCount){
			tmpPage = pageCount;	
		}
	}
	userLoginList(tmpPage);
}