//活动添加
function inActivity(){
	var startDate=$('#startDate').val();
	var endDate=$('#endDate').val();
	var content=$('#content').val();
	var info=$('#info').val();
	var money=$('#money').val();
	if(startDate==""){
		alert("请输入开始时间！！！");
		return;
	}
	if(endDate==""){
		alert("请输入截止时间！！！");
		return;
	}
	if(content==""){
		alert("请输入活动内容！！！");
		return;
	}
	if(info==""){
		alert("请输入活动信息！！！");
		return;
	}
	if(money==""){
		alert("请输入活动金额！！！");
		return;
	}
	startDate=startDate.replace("-","").replace("-","")+"000000";
	endDate=endDate.replace("-","").replace("-","")+"000000";
	content=encodeURI(encodeURI(content));
	info=encodeURI(encodeURI(info));
	$.ajax({
			url:'././ActivityManage.do?action=inActivity&startDate='+startDate+'&endDate='+endDate+'&content='+content+'&info='+info+'&money='+money+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				if(items[0].count=="0000"){
					alert("添加活动成功！！！");
				}else{
					alert("添加活动失败！！！");
				}
			}
	});
}