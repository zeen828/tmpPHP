
var pageCount;//总页数
var currentPage;//当前页

function load()
{
	marketAccountList(1);
}

//交易列表
function marketAccountList(page)
{
	currentPage = page;
	var startDate = $('#startDate').val();
	var endDate = $('#endDate').val();
	$.ajax
	({
		url:'././statisAction.do?action=marketAccountList&page='+page+'&startDate='+startDate+'&endDate='+endDate,
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var items = data.items;
			pageCount = data.pageCount;
			$('#count').text(data.count);
			$('#betSum').text(data.betSum);
			$('#awardSum').text(data.awardSum);
			$('#bankChargeSum').text(data.bankChargeSum);
			$('#handChargeSum').text(data.handChargeSum);
			$('#betRebateSum').text(data.betRebateSum);
			$('#onLineRebateSum').text(data.onLineRebateSum);
			$('#carrySum').text(data.carrySum);
			$('#activitySum').text(data.activitySum);
			$('#schemeRebateSum').text(data.schemeRebateSum);
			//$('#userMoneySum').text(data.userMoneySum);
			$('#pageNum').text("共"+pageCount+"页");
			$('.context').empty();
			for(var i=0; i<items.length; i++)
			{
				var trNode =
				"<tr>"+
					"<td align='center' class='tab_content'>"+formatTime(items[i].createTime)+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].bet+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].award+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].bankCharge+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].handCharge+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].betRebate+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].onLineRebate+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].carry+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].schemeRebate+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].activity+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].userMoney+"</td>"+
				"</tr>";
				$('.context').append(trNode);
			}
			$('#data tbody tr:even').css("backgroundColor","#CCCCCC");
		}
	});
}

//页数操作
function checkPage(_this)
{
	var tmpPage = 1;
	if($(_this).attr('id')=='aa'){
		tmpPage = pageCount;
	}else if($(_this).attr('id')=='back'){
		if (currentPage > 1){
			tmpPage = currentPage-1;
		}
	}else if($(_this).attr('id')=='next'){
		if (currentPage < pageCount){
			tmpPage = currentPage+1;	
		}
		if (currentPage >= pageCount){
			tmpPage = pageCount;	
		}
	}
	marketAccountList(tmpPage);
}

function formatTime(time){
	var dt = "";
	if (time != "" && time != 'null'){
		var year=time.substring(0,4);
		var month=time.substring(4,6);
		var day=time.substring(6,8);
		dt=year+"-"+month+"-"+day;
	}
	return dt;
}