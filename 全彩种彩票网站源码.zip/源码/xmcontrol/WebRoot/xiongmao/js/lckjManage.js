function getDataToTime(){
	$.ajax({
			url:'././kjManageAction.do?action=getlcDataToTime&startTime='+startTime+'&endTime='+endTime+'&page='+tempPage+'&pageCount=10&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(vs_list){
				var vs_item=eval("("+vs_list+")");
				var items=vs_item.items;
				var tr="<tr>"+
						"<td align='center' class='tab_header'>编号</td>"+
						"<td align='center' class='tab_header'>赛事编码</td>"+
						"<td align='center' class='tab_header'>联赛名称</td>"+
						"<td align='center' class='tab_header'>主队名称</td>"+
						"<td align='center' class='tab_header'>让球数</td>"+
						"<td align='center' class='tab_header'>客队名称</td>"+
						"<td align='center' class='tab_header'>比赛时间</td>"+
						"<td align='center' class='tab_header'>网站销售截止时间</td>"+
						"<td align='center' class='tab_header'>操作</td>"+
					"</tr>";
					$('.center_context_tab').empty();
					$('.center_context_tab').append(tr);
				for(var i=0;i<items.length;i++){
					var stopSellDate=pageDate(items[i].stopSellDate);
					var fsstopTime=pageDate(items[i].fsstopTime);
					var a="";
					if(items[i].status==1){
						a="<a href='javascript:void(0)' onClick='javascript:setkaijiang(this)' style='font:12px Arial;color:#0F3F94;'>开奖</a>";
					}else{
						a="<a href='javascript:void(0)' onClick='javascript:kaijiangDetail(this)' style='font:12px Arial;color:#0F3F94;'>详情</a>";
					}
					tr="<tr id='"+items[i].gameId+"'>"+
							"<td align='center' class='tab_content'>"+(i+1)+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].gameNum+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].gameName+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].hostTeam+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].concedeNum+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].visitingTeam+"</td>"+
							"<td align='center' class='tab_content'>"+stopSellDate+"</td>"+
							"<td align='center' class='tab_content'>"+fsstopTime+"</td>"+
							"<td align='center' class='tab_content'>"+a+"</td>"+
						"</tr>";
					$('.center_context_tab').append(tr);	
				}
			}
	});
}
var page;
var tempPage=1;
function getPageCountToTime(){
	$.ajax({
			url:'././kjManageAction.do?action=getlcCountToTime&startTime='+startTime+'&endTime='+endTime+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常ss！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				var num=items[0].pageNum;
				page=Math.ceil(items[0].pageNum/10);
				$('#num_id').text(num);
				$('#pageNum').text("共"+page+"页");
				getDataToTime();
			}
	});
}
//通过时间搜索对阵数据
var startTime="";
var endTime="";
function search(){
	startTime=$('#startDate').val().replace("-","").replace("-","")+"000000";
	endTime=$('#endDate').val().replace("-","").replace("-","")+"000000";
	getPageCountToTime();
}
//页数操作
function checkPage(_this){
	if($(_this).attr('id')=='begin'){
		tempPage=1;
	}else if($(_this).attr('id')=='last'){
		tempPage=page;
	}else if($(_this).attr('id')=='back'){
		tempPage=tempPage-1;
	}else{
		tempPage=tempPage+1;
	}
	if(tempPage<=-1){
		tempPage=1
		return;
	}
	if(tempPage>=(page+1)){
		tempPage=page;
		return;
	}
	getDataToTime();
}
//取出数据库时间处理
function pageDate(_dateTime){
	var year=_dateTime.substr(0,4);
	var month=_dateTime.substr(4,2);
	var day=_dateTime.substr(6,2);
	var hours=_dateTime.substr(8,2);
	var minutes=_dateTime.substr(10,2);
	var seconds=_dateTime.substr(12,2);
	var _pageDate=year+'-'+month+'-'+day+' '+hours+':'+minutes+':'+seconds;
	return _pageDate;
}
//开奖设置
var gameId="";
function setkaijiang(_this){
	gameId=$(_this).parent().parent().attr('id');
	$('#kjSet').show();
}
//确定开奖
function confrimKaiJiang(){
	var sf=$('#sf').val();
	var rf_sf=$('#rf_sf').val();
	var sfc=$('#sfc').val();
	var dsf=$('#dsf').val();
	var sf_award=$('#sf_award').val();
	var rfsf_award=$('#rfsf_award').val();
	var sfc_award=$('#sfc_award').val();
	var dsf_award=$('#dsf_award').val();
	var sf_gg=$('#sf_gg').val();
	var rfsf_gg=$('#rfsf_gg').val();
	var sfc_gg=$('#sfc_gg').val();
	var dxf_gg=$('#dxf_gg').val();
	var str=gameId+','+sf+','+rf_sf+','+sfc+','+dsf+','+
			sf_award+','+rfsf_award+','+sfc_award+','+dsf_award+','+sf_gg+','+
			rfsf_gg+','+sfc_gg+','+dxf_gg;
	var strs=str.split(",");
	for(var i=0;i<strs.length;i++){
		if(strs[i]=='-1'||strs[i]==''){
			alert("开奖数据不能为空！！！");
			return;
		}
	}
	str=encodeURI(encodeURI(str));
	$.ajax({
			url:'././kjManageAction.do?action=setlcStatus&str='+str+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(vs_list){
				alert('开奖成功！！！');
				getDataToTime();
			}
	});
}
//关闭窗口
function closeWindow(_this){
	var _id="#"+_this;
	$(_id).hide();
}
//开奖详细
function kaijiangDetail(_this){
	var againstId=$(_this).parent().parent().attr('id');
	alert(againstId);
	$.ajax({
			url:'././kjManageAction.do?action=getkjDetail&againstId='+againstId+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(vs_list){
				var Item=eval("("+vs_list+")");
				var items=Item.items;
				$('#homeTeamBCScore').val(items[0].hostBanChangBiFen);
				$('#awayTeamBCScore').val(items[0].guestBanChangBiFen);
				$('#homeTeamQCScore').val(items[0].hostQuanChangBiFen);
				$('#awayTeamQCScore').val(items[0].guestQuanChangBiFen);
				$('#letdgResult').val(items[0].rangQiuResults);
				$('#letggResult').val(items[0].rangQiuguoGuanResult);
				$('#letdcMoney').val(items[0].rangQiuAward);
				$('#scoreggResult').val(items[0].biFenGuanResult);
				$('#scoredcMoney').val(items[0].biFenAward);
				$('#scoredgResult').val(items[0].biFenResults);
				$('#zjqggResult').val(items[0].zongJingQiuGuanResult);
				$('#zjqdcMoney').val(items[0].zongJingQiuAward);
				$('#zjqdgResult').val(items[0].zongJingQiuResults);
				$('#bqcdcMoney').val(items[0].banQuanAward);
				$('#bqcdgResult').val(items[0].banQuanResults);
				$('#bqcggResult').val(items[0].banQuanGuanResult);
			}
	});
	$('#kjDetail').show();
}
