

function change_getIssue(_this){
	$.ajax({
		url:'jsonAction.do?action=m0008&gameCode='+_this.value+'&pageNum=0&pageCount=10',
		type:'GET',
		error:function(){alert('链接有误！！')},
		success:function(issue_list){
			var issue=eval("("+issue_list+")");
			var issue_items=issue.items;
			$('#issue').empty();
			var option ="<option value=0 selected=selected>--选择期号--</option>";
			for(var i=0;i<issue_items.length-1;i++){
				option+="<option value="+issue_items[i].issue+">--"+issue_items[i].issue+"--</option>";
			}
			$('#issue').append(option);
		}
	});
}
var type={
	'501':'胜平负'
}
var _status={
	'0':'处理成功',
	'1':'受理成功',
	'2':'通知成功'
}
var McN_Map={
	'1':'1串1',
	'2':'2串1',
	'3':'3串1',
	'4':'3串3',
	'5':'3串4',
	'6':'4串1',
	'7':'4串4',
	'8':'4串5',
	'9':'4串6',
	'10':'4串11',
	'11':'5串1',
	'12':'5串5',
	'13':'5串6',
	'14':'5串10',
	'15':'5串16',
	'16':'5串20',
	'17':'5串26',
	'18':'6串1',
	'19':'6串6',
	'20':'6串7',
	'21':'6串15',
	'22':'6串20',
	'23':'6串22',
	'24':'6串35',
	'25':'6串42',
	'26':'6串50',
	'27':'6串57',
	'28':'7串1',
	'29':'7串7',
	'30':'7串8',
	'31':'7串21',
	'32':'7串35',
	'33':'7串120',
	'34':'7串127',
	'35':'8串1',
	'36':'8串8',
	'37':'8串9',
	'38':'8串28',
	'39':'8串56',
	'40':'8串70',
	'41':'8串247',
	'42':'8串255'
}
function getAllInfo(){
	var game_code=$('#game_code').val();
	var status=$('#issue').val()
	if(game_code=="0"){
		alert("请选择彩种！！");
		return;
	}
	if(issue=="0"){
		alert("请选择期号！！");
		return;
	}
	getItems(game_code,status);
}
function getItems(game_code,status){
	var pageNum=0;
	$("#fy").empty();
	$("#money").empty();
	$.ajax({
		url:'././cpManageAction.do?action=m0214&gameCode='+game_code+'&status='+status+'&pageNum=0&pageCount=0',
			type:'GET',
			error:function(){alert('fdsfds')},
			success:function(w_list){
				var jason_list=eval("("+w_list+")");
				var lst=jason_list.items;
				var tr='',pageCount=1,sty='',cls='',money=0;
				pageNum=Math.ceil((lst.length-1)/10);
				if(pageNum>0){
					$("#demo2").paginate({
						count 		: pageNum,
						start 		: 1,
						display     : pageNum,
						border					: false,
						text_color  			: '#888',
						background_color    	: '#EEE',	
						text_hover_color  		: 'black',
						background_hover_color	: '#CFCFCF',
						onChange     			: function(page){
											$('._current','#fy').removeClass('_current').hide();
											$('#p'+page).addClass('_current').show();
										  }
					});
				}
				for(var i=0;i<lst.length-1;i++){
					tr+="<tr height='25' style='font:12px Arial;'>"+
			  			"<td width='45'>"+lst[i].tempId+"</td>"+
			  			"<td width='45'>"+lst[i].serialno+"</td>"+
			  			"<td width='190'>"+lst[i].recordId+"</td>"+
			  			"<td width='60'>"+McN_Map[lst[i].manner]+"</td>"+
			  			"<td width='60'>"+type[lst[i].gameCode]+"</td>"+
			  			"<td width='60'>"+lst[i].uName+"</td>"+
			  			"<td width='25'>"+lst[i].record+"</td>"+
			  			"<td width='25'>"+lst[i].multiple+"</td>"+
			  			"<td width='45'>"+lst[i].bets+"</td>"+
			  			"<td width='65'>"+_status[lst[i].status]+"</td>"+
			  			"<td><a href='#' title="+lst[i].chipinNums+" style='display:block;height:auto;overflow:hidden;'>"+lst[i].chipinNums.slice(0,32)+"....</a></td>"+
			  		"</tr>";
			  		money+=parseInt(lst[i].bets);
				  	if(pageNum>1){
				  			if(i==10-1){
				  				$("<div id='p"+pageCount+"' class='pagedemo _current' style=''><table width='100%' cellspacing='0' cellpadding='0' style='border:1px #906E14 solid;border-bottom:0px;'>"+tr+"</table></div>").appendTo("#fy");
				  				tr='';
				  				pageCount+=1;
				  			}else if(i==(pageCount*10-1)){
				  				$("<div id='p"+pageCount+"' class='pagedemo' style='display:none;'><table width='100%' cellspacing='0' cellpadding='0' style='border:1px #906E14 solid;border-bottom:0px;'>"+tr+"</table></div>").appendTo("#fy");
				  				tr='';
				  				pageCount+=1;
				  			}else if(i==lst.length-2){
				  				$("<div id='p"+pageCount+"' class='pagedemo' style='display:none;'><table width='100%' cellspacing='0' cellpadding='0' style='border:1px #906E14 solid;border-bottom:0px;'>"+tr+"</table></div>").appendTo("#fy");
				  				tr='';
				  			}
				  		}else{
				  			if(i==lst.length-2){
								$("<div id='p"+pageCount+"' class='pagedemo _current' style=''><table width='100%' cellspacing='0' cellpadding='0' style='border:1px #906E14 solid;border-bottom:0px;'>"+tr+"</table></div>").appendTo("#fy");		
							}	  		
				  		}
			  		
				}
				$('#money').append(money);
			}
	})
}
