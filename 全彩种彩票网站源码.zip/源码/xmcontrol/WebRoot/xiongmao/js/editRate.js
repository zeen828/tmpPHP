
var gamcode_map={
	'501':'竞彩足球-胜平负',
	'502':'竞彩足球-比分',
	'503':'竞彩足球-总进球',
	'504':'竞彩足球-半全场',
	'505':'竞彩篮球-胜负',
	'506':'竞彩篮球-让分胜负',
	'507':'竞彩篮球-胜负差',
	'508':'竞彩篮球-大小分',
	'509':'竞彩足球-混合过关',
	'510':'竞彩篮球-混合过关',
	'511':'竞彩足球-让球胜平负',
	'301':'北单-让球胜平负',
	'302':'北单-上下单双',
	'303':'北单-总进球数',
	'304':'北单-比分',
	'305':'北单-半全场胜平负',
	'102':'传统足球-胜负彩',
	'103':'传统足球-任选9',
	'106':'传统足球-4场半进球彩',
	'107':'传统足球-6场半全场'
}

function load()
{
	editRateList(1);
}

function doChange()
{
	editRateList(1);
}

//返点|上线配额列表
function editRateList(page)
{
	currentPage = page;
	var userId = $('#userId').val();
	var type = $('#type').val();
	$.ajax
	({
		url:'././userManageAction.do?action=editRateList&userId='+userId+'&type='+type,
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var items = data.items;
			$('.context').empty();
			for(var i=0; i<items.length; i++)
			{
				var trNode =
				"<tr>"+
					"<input type='hidden' value='"+items[i].gameCode+"' id='gameCode'/>"+
					"<td align='center' class='tab_content'>"+gamcode_map[items[i].gameCode]+"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='text' id='rate' value='"+items[i].rate+"'/> %"+
					"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='button' value='更新' onclick='updateRate(this)'/>"+
					"</td>"+
				"</tr>";
				$('.context').append(trNode);
			}
			var trNode2 =
			"<tr>"+
				"<td align='center' class='tab_content'>一键修改</td>"+
				"<td align='center' class='tab_content'>"+
					"<input type='text' id='allRate'/> %"+
				"</td>"+
				"<td align='center' class='tab_content'>"+
					"<input type='button' value='更新' onclick='updateAllRate()'/>"+
				"</td>"+
			"</tr>";
			$('.context').append(trNode2);
			$('#data tbody tr:even').css("backgroundColor","#CCCCCC");
		}
	});
}

//修改返点|上线配额
function updateRate(_this)
{
	var trNode = $(_this).parent().parent();
	var rate = trNode.find("#rate").val();
	if (rate == '')
	{
		alert('数据不能为空！');
		return;
	}
	var userId = $('#userId').val();
	var type = $('#type').val();
	var gameCode = trNode.find('#gameCode').val();
	if (gameCode>=501 && gameCode<=511)
	{
		if (rate > 16)
		{
			alert("竞彩最高返16%");
			return;
		}
	}
	if ((gameCode>=301 && gameCode<=305) || gameCode == 102 || gameCode == 103 || gameCode == 106 || gameCode == 107)
	{
		if (rate > 10)
		{
			alert("北单与传统最高返10%");
			return;
		}
	}
	$.ajax
	({
		url:'././userManageAction.do?action=updateRate&rate='+rate+'&manner=0&userId='+userId+'&type='+type+'&gameCode='+gameCode,
		type:'GET',
		error:function(){alert('更新失败！！！')},
		success:function(data)
		{
			if (data > 0)
			{
				alert('更新成功');
			}
		}
	 });
}

//修改全部返点|上线配额
function updateAllRate()
{
	var allRate = $("#allRate").val();
	if (allRate == '')
	{
		alert('配额不能为空！');
		return;
	}
	if (allRate > 10)
	{
		alert("最高返10%");
		return;
	}
	var userId = $('#userId').val();
	var type = $('#type').val();
	var gameCode = "0";//0表示全部彩种
	$.ajax
	({
		url:'././userManageAction.do?action=updateRate&rate='+allRate+'&manner=0&userId='+userId+'&type='+type+'&gameCode='+gameCode,
		type:'GET',
		error:function(){alert('更新失败！！！')},
		success:function(data)
		{
			if (data > 0)
			{
				alert('更新成功');
				load();
			}
		}
	 });
}
