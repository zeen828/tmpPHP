var pageCount;//总页数
var currentPage;//当前页

//出票记录列表
function chipinTempList(page)
{
	currentPage = page;
	$('#currentPage').text(currentPage);//显示当前页码
	var userNickName = $('#userNickName').val();
	var tempId = $('#tempId').val();
	var serialNo = $('#serialNo').val();
	var tradeType = $('#tradeType').val();
	var startDate = $('#startDate').val();
	var endDate = $('#endDate').val();
	$.ajax
	({
		url:'././chipinTempAction.do?action=chipinTempList&page='+page+'&userNickName='+encodeURIComponent(userNickName)+'&serialNo='+serialNo+'&tempId='+tempId+'&startDate='+startDate+'&endDate='+endDate,
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var items = data.items;//对应Action层的json的数据格式,属性是items,记录对象
			var count = data.count;//对应Action层的json的数据格式,属性是count,总记录数
			pageCount = data.pageCount;//对应Action层的json的数据格式,属性是pageCount,每页显示的记录数
			$('#num_id').text(count);//总记录数
			$('#pageNum').text("共"+pageCount+"页");//共多少页
			$('.context').empty();
			for(var i=0; i<items.length; i++)
			{
				var trNode =
				"<tr>"+
				    "<td align='center' class='tab_content'>"+items[i].tempId+"</td>"+
					"<td align='center' class='tab_content'><a href='http://218.244.145.26/letoula/useraccount/MannerDetail.jsp?id="+items[i].serialNo+"' target='_blank'>"+items[i].serialNo+"</a></td>"+
					"<td align='center' class='tab_content'>"+items[i].userNickName+"</td>"+
					"<td align='center' class='tab_content'>"+type[items[i].gameCode]+"</td>"+
					"<td align='center' class='tab_content'>"+McN_Map[items[i].manner]+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].record+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].multiple+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].bets+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].tempAwardBets+"</td>"+
					"<td align='center' class='tab_content'>"+formatTime(items[i].voteProccessTime)+"</td>"+
				"</tr>";
				$('.context').append(trNode);
			}
			$('#data tbody tr:even').css("backgroundColor","#CCCCCC");
		}
	});
}

var type={
	'501':'胜平负',
	'511':'让球胜平负',
	'503':'总进球数',
	'509':'混合过关',
	'502':'比分',
	'504':'半全场',
	
	'505':'胜负',
	'506':'让分胜负',
	'507':'胜负差',
	'508':'大小分',
	'510':'混合过关',
	
	'102':'胜负彩',
	'103':'任选9场',
	'106':'4场进球',
	'107':'6场半全场',
	
	'301':'让球胜平负',
	'302':'上下单双',
	'303':'总进球数',
	'304':'比分',
	'305':'半全场'
}
var _status={
	'0':'处理成功',
	'1':'受理成功',
	'2':'通知成功'
}
var McN_Map={
	'1':'1串1',
	'2':'2串1',
	'3':'3串1',
	'4':'3串3',
	'5':'3串4',
	'6':'4串1',
	'7':'4串4',
	'8':'4串5',
	'9':'4串6',
	'10':'4串11',
	'11':'5串1',
	'12':'5串5',
	'13':'5串6',
	'14':'5串10',
	'15':'5串16',
	'16':'5串20',
	'17':'5串26',
	'18':'6串1',
	'19':'6串6',
	'20':'6串7',
	'21':'6串15',
	'22':'6串20',
	'23':'6串22',
	'24':'6串35',
	'25':'6串42',
	'26':'6串50',
	'27':'6串57',
	'28':'7串1',
	'29':'7串7',
	'30':'7串8',
	'31':'7串21',
	'32':'7串35',
	'33':'7串120',
	'34':'7串127',
	'35':'8串1',
	'36':'8串8',
	'37':'8串9',
	'38':'8串28',
	'39':'8串56',
	'40':'8串70',
	'41':'8串247',
	'42':'8串255'
}

//页数操作
function checkPage(_this)
{
	var tmpPage = 1;
	if($(_this).attr('id')=='aa'){
		tmpPage = pageCount;
	}else if($(_this).attr('id')=='back'){
		if (currentPage > 1){
			tmpPage = currentPage-1;
		}
	}else if($(_this).attr('id')=='next'){
		if (currentPage < pageCount){
			tmpPage = currentPage+1;	
		}
		if (currentPage >= pageCount){
			tmpPage = pageCount;	
		}
	}
	chipinTempList(tmpPage);
}
//格式化时间
function formatTime(time){
	var dt = "";
	if (time != "" && time != 'null'){
		var year=time.substring(0,4);
		var month=time.substring(4,6);
		var day=time.substring(6,8);
		var hours=time.substring(8,10);
		var minute=time.substring(10,12);
		var seconds=time.substring(12,14);
		dt=year+"-"+month+"-"+day+" "+hours+":"+minute+":"+seconds;
	}
	return dt;
}
function load()
{
	chipinTempList(1);
}
