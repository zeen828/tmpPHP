var pages;
var tempPage=1;
var num;
function load(){
	$.ajax({
			url:'././leagueMatchAction.do?action=getLCPage&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				num=items[0].page;
				pages=Math.ceil(items[0].page/10);
				$('#num_id').text(num);
				$('#pageNum').text("共"+pages+"页");
			}
	});
	getData();
}
function getData(){
	$.ajax({
			url:'././leagueMatchAction.do?action=getLCMatchDate&page='+tempPage+'&pageNum=10&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				$(".center_context_tab").empty();
				var header_tr="<tr>"+
						"<td align='center' width='10%'  class='tab_header'>序号</td>"+
						"<td align='center' width='40%' 	class='tab_header'>联赛名称</td>"+
						"<td align='center' width='40%'  class='tab_header'>联赛全称</td>"+
						"<td align='center' width='10%'  class='tab_header'>联赛颜色</td>"+
					"</tr>";
				$(".center_context_tab").append(header_tr);
				for(var i=0;i<items.length;i++){
					var tr="<tr onclick='javascript:onclick_tr(this)' id="+items[i].matchId+">"+
						"<td align='center' width='10%' class='tab_content'>"+(i+1)+"</td>"+
						"<td align='center' width='40%'	class='tab_content'>"+items[i].matchName+"</td>"+
						"<td align='center' width='40%'	class='tab_content'>"+items[i].matchQc+"</td>"+
						"<td align='center' width='10%'  class='tab_content' style='background:"+items[i].matchColor+";' id="+items[i].matchColor+">"+items[i].matchColor+"</td>"+
						"</tr>";
						$(".center_context_tab").append(tr);
				}
				color_manage();
			}
	});
}
function pageData(_this){
	if($(_this).attr('id')=='begin'){
		tempPage=1;
	}else if($(_this).attr('id')=='last'){
		tempPage=pages;
	}else if($(_this).attr('id')=='back'){
		tempPage=tempPage-1;
	}else{
		tempPage=tempPage+1;
	}
	if(tempPage<=-1){
		tempPage=1
		return;
	}
	if(tempPage>=(pages+1)){
		tempPage=pages;
		return;
	}
	getData();
}
var color_val="";
var tr_id="";
 		$(function(){
 			$('#color_div_tab').find('td').bind("click",function(){
 				if($(this).text()=="x"){
 					return;
 				}
 				var temp_id=$(this).attr('id').replace("_","#");
 				$('#insert_color').css("background",temp_id);
 				$('#update_color').css("background",temp_id);
 				$('#updateColor_val').val(temp_id);
 				color_val=temp_id;
 			});
 		});
 		//行点击事件
 		function onclick_tr(_this){
 			if(tr_id==""){
 				$(_this).css("background","#ffff99");
 			}else{
 				var _id="#"+tr_id;
 				$(_id).css("background","#fff");
 				$(_this).css("background","#ffff99");
 			}
 			tr_id=$(_this).attr('id');
 		}
 		function color_click(_this){
	 		$('#color_div').toggle(400);
 		}
 		//添加联赛
 		function insert_data(){
 			$('#insert_color').removeAttr('style');
 			$('#insert_div').show(400);
 		}
 		//确定添加数据
 		function confirmInsert(){
 			var match_name=$('#insert_matchName').val();
 			var match_qc=$('#insert_matchQc').val();
 			match_name=encodeURI(encodeURI(match_name));
 			match_qc=encodeURI(encodeURI(match_qc));
 			color_val=color_val.replace("#","");
 			$.ajax({
 				url:'././leagueMatchAction.do?action=insertLCMatchData&matchName='+match_name+'&matchQc='+match_qc+'&matchColor='+color_val+'&r='+Math.random(),
 				type:'GET',
 				error:function(){alert('网络连接异常！！！')},
 				success:function(){
 					alert('添加成功！！！');
 					$('#insert_div').hide(400);
 					$('#color_div').hide(400);
 					load();
 				}
 			});
 		}
 		//修改联赛数据
 		function update_data(){
 			if(tr_id==""){
 				alert("请选择要修改的数据！！！");
 				return;
 			}
 			$('#update_div').show(400);
 			var _id="#"+tr_id;
 			var _name=$(_id).find('td').eq(1).text();
 			var _qc=$(_id).find('td').eq(2).text();
 			var _color=$(_id).find('td').eq(3).attr('id');
 			$('#update_matchName').val(_name);
 			$('#update_matchQc').val(_qc);
 			$('#update_color').css("background",_color);
 			$('#updateColor_val').val(_color);
 		}
 		//确定修改联赛数据
 		function confirmUpdate(){
 			var match_name=$('#update_matchName').val();
 			var match_qc=$('#update_matchQc').val();
 			var updateColor_val=$('#updateColor_val').val().replace("#","");
 			match_name=encodeURI(encodeURI(match_name));
 			match_qc=encodeURI(encodeURI(match_qc));
 			$.ajax({
 				url:'././leagueMatchAction.do?action=updateLCMatchData&matchId='+tr_id+'&matchName='+match_name+'&matchQc='+match_qc+'&matchColor='+updateColor_val+'',
 				type:'GET',
 				error:function(){alert('网络连接异常！！！')},
 				success:function(){
 					alert('修改成功！！！');
 					$('#update_div').hide(400);
 					$('#color_div').hide(400);
 					getData();
 				}
 			});
 		}
 		//颜色管理
 		function color_manage(){
 			$(color_div_tab).find('td').text("");
 			$.ajax({
				url:'././leagueMatchAction.do?action=getLCMatchDate&page=0&pageNum=0&r='+Math.random(),
				type:'GET',
				error:function(){alert('网络连接异常！！！')},
				success:function(w_list){
					var Item=eval("("+w_list+")");
					var items=Item.items;
					for(var i=0;i<items.length;i++){
						var col_id=items[i].matchColor.replace("#","#_");
						//alert(col_id+'-----------');
						$(col_id).text('x');
					}
				}
			});
 		}
 		
 		