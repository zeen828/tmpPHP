var returnPoint_data={
	'fd_data':function(beginTime,endTime,fdshu){
		$.ajax({
			url:'././fztxManageAction.do?action=returnPoint&beginTime='+beginTime+'&endTime='+endTime+'&fandianshu='+fdshu+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				var tr='';
				$('#fd_data').empty();
				for(var i=0;i<items.length;i++){
					tr+="<tr><td align='center' class='tab_content'>"+items[i].uName+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].uId+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].bets+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].fdBets+"</td></tr>";
				}
				$('#fd_data').append(tr);
				$('#num_id').text(items.length);
			}
		});
	}
}
function sel_data(){
	var reg = new RegExp("-","g");
	var beginTime=$('#startDate').val().replace(reg,"")+"000000";
	var endTime=$('#endDate').val().replace(reg,"")+"000000";
	var fdshu=$('#pointNum').val();
	returnPoint_data.fd_data(beginTime,endTime,fdshu);
}