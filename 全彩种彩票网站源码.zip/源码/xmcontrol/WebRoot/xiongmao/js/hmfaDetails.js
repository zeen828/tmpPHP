
var pageCount;//总页数
var currentPage;//当前页

function load()
{
	hmfaList(1);
}

function hmfaList(page)
{
	currentPage = page;
	var checkStatus = $('#checkStatus').val();
	var startDate = $('#startDate').val();
	var endDate = $('#endDate').val();
	$.ajax
	({
		url:'././hmfaAction.do?action=hmfaList&page='+page+'&checkStatus='+checkStatus+'&startDate='+startDate+'&endDate='+endDate,
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var hmfaList = data.hmfaList;
			var count = data.count;
			pageCount = data.pageCount;
			$('#num_id').text(count);
			$('#pageNum').text("共"+pageCount+"页");
			$('#notPrintBets').text(data.notPrintBets);
			$('#printBets').text(data.printBets);
			$('.context').empty();
			for(var i=0; i<hmfaList.length; i++)
			{
				var checkStatus = hmfaList[i].checkStatus;
				var button = "-";
				if(checkStatus==1) button = "<input type='button' value='详情' onclick='switchDetails(this)'/><input type='button' value='出票' onclick='checkHmfa(this)'/>";
				var trNode =
				"<tr>"+
					"<input type='hidden' value='"+hmfaList[i].hmfaId+"' id='hmfaId'/>"+
					"<td align='center' class='tab_content2'>"+hmfaList[i].serialNo+"</td>"+
					"<td align='center' class='tab_content2'>"+hmfaList[i].userNickName+"</td>"+
					"<td align='center' class='tab_content2'>"+hmfaList[i].lotName+"</td>"+
					"<td align='center' class='tab_content2'>"+hmfaList[i].manner+"</td>"+
					"<td align='center' class='tab_content2'>"+hmfaList[i].money+"</td>"+
					"<td align='center' class='tab_content2'>"+hmfaList[i].multiple+"</td>"+
					"<td align='center' class='tab_content2'>"+hmfaList[i].fqTime+"</td>"+
					"<td align='center' class='tab_content2'>"+button+"</td>"+
				"</tr>";
				$('.context').append(trNode);
				var tempList = hmfaList[i].tempList;
				if (checkStatus==1 && tempList.length>0)
				{
					var nn = "";
					if(i!=0) nn = "nn";
					var trNode2 = "<tr id='h_"+hmfaList[i].hmfaId+"' class='"+nn+"'><td colspan='9' align='right' class='tab_content2'><table class='center_context_tab' width='100%' cellspacing='0' cellpadding='0'><tbody>";
					for(var j=0; j<tempList.length; j++)
					{
						var printStatus = tempList[j].printStatus;
						var str = "";
						if(printStatus==0)
						{
							str = "不出票</td><td class='tab_content2' width='80'><input type='checkbox' value='"+tempList[j].spValue+"' name='print' checked/>出票";
						}
						else if(printStatus==2)
						{
							str = "不出票</td><td class='tab_content2' width='80'>已过期";
						}
						else
						{
							str = "已出票</td><td class='tab_content2' width='80'>";
						}
						trNode2 += "<tr style='background-color:#CCCCCC'><td align='right' class='tab_content2'><span style='margin-right:20'>投注号码：<span style='color:red'>"+tempList[j].num+"</span></span><span style='margin-right:20'>投注金额：<span style='color:red'>"+tempList[j].bets+"</span></span>"+str+"</td></tr>";	
					}
					trNode2 += "</tbody></table></td></tr>";
					$('.context').append(trNode2);
				}
			}
		}
	});
}
var checkStatusMap = {
	'0':'未分配',
	'1':'已分配'
}
//开关详情
function switchDetails(_this)
{
	var trNode = $(_this).parent().parent();
	var hmfaId = trNode.find("#hmfaId").val();
	if($("#h_"+hmfaId).attr("class")=='nn')
	{
		$("#h_"+hmfaId).attr("class","");
	}
	else
	{
		$("#h_"+hmfaId).attr("class","nn");	
	}
}

//审核方案
function checkHmfa(_this)
{
	if (confirm("确定出票？"))
	{
		var trNode = $(_this).parent().parent();
		var hmfaId = trNode.find("#hmfaId").val();
		var arrChk = $("#h_"+hmfaId).find("input[name='print']:checked");
		var printSpValues = "";//出票
		for (var i=0; i<arrChk.length; i++)
		{
			printSpValues += arrChk[i].value;
			if (i != arrChk.length-1)
			{
				printSpValues += "|";
			}
		}
		if (printSpValues=='')
		{
			alert("未选择出票");
			return;
		}
		$.ajax
		({
			url:'././hmfaAction.do?action=checkHmfa&hmfaId='+hmfaId+'&printSpValues='+printSpValues,
			type:'GET',
			error:function(){alert('出票失败！！！')},
			success:function(json)
			{
				json = eval("("+json+")");
				json = json.json[0];
				var type = json.type;
				if (type==0)
				{
					alert("出票成功");
				}
				else if (type==1)
				{
					alert("方案不存在");
				}
				else if (type==2)
				{
					alert("方案不存在或未选择出票");
				}
				else
				{
					alert("出票失败");
				}
				hmfaList(1);
			}
		 });
	}
}

//页数操作
function checkPage(_this)
{
	var tmpPage = 1;
	if($(_this).attr('id')=='aa'){
		tmpPage = pageCount;
	}else if($(_this).attr('id')=='back'){
		if (currentPage > 1){
			tmpPage = currentPage-1;
		}
	}else if($(_this).attr('id')=='next'){
		if (currentPage < pageCount){
			tmpPage = currentPage+1;	
		}
		if (currentPage >= pageCount){
			tmpPage = pageCount;	
		}
	}
	hmfaList(tmpPage);
}