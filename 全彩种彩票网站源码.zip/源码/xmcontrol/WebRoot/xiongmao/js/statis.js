var userName =null;
var beginTime = '';
var endTime = '';
//财务管理
function load(){
	userName=$('#uName').val();
	if(userName=='请输入用户名'){
		userName='';
	}
	userName=encodeURI(encodeURI(userName));
	beginTime=$('#startDate').val().replace('-','').replace('-','')+"000000";
	endTime=$('#endDate').val().replace('-','').replace('-','')+"235959";
	$('.account').empty();
	$.ajax({
		url:'././statisAction.do?action=statis&userName='+userName+'&beginTime='+beginTime+'&endTime='+endTime+'&r='+Math.random(),
		type:'POST',
		error:function(){alert('网络连接异常!!!!')},
		success:function(list){
			var tj_list=eval("("+list+")");
			var items=tj_list.items;
			if(userName==''){
				$('#wycz').text(items[0].wycz);
				$('#fzcz').text(items[0].fzcz);
				$('#txMoney').text(items[0].txMoney);
				$('#yjsMoney').text(items[0].yjsMoney);
				$('#wjsMoney').text(items[0].wjsMoney);
				$('#zjMoney').text(items[0].zjMoney);
				$('#balance').text(items[0].balance);
			}else{
				for(var i=0;i<items.length;i++){
					var tr="<tr>"+
							"<td  class='tab_content' align='center'>"+(i+1)+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].userName+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].wycz+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].fzcz+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].txMoney+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].zjMoney+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].yjsMoney+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].wjsMoney+"</td>"+
							"<td  class='tab_content' align='center'>"+items[i].balance+"</td>"+
						"</tr>"
						$('.account').append(tr);
				}
				
			}
			
		}
	});
}

function tj_toUserName(){
	$.ajax({
		url:'././statisAction.do?action=statis&userName=fdsbeginTime=20120620000000&endTime=20120719000000&r='+Math.random(),
		type:'GET',
		error:function(){alert('网络连接异常!!!!')},
		success:function(list){
			var tj_list=eval("("+list+")");
			var items=tj_list.items;
			$('#wycz').text(items[0].wycz);
			$('#fzcz').text(items[0].fzcz);
			$('#txMoney').text(items[0].txMoney);
			$('#yjsMoney').text(items[0].yjsMoney);
			$('#wjsMoney').text(items[0].wjsMoney);
			$('#zjMoney').text(items[0].zjMoney);
			$('#balance').text(items[0].balance);
		}
	});
}