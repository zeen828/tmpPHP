function usereLogin(){
	var loginName=document.getElementById("uName").value;
	var password=document.getElementById("pwd").value;
	if(!loginName)
	{
		alert("请填写用户名");
		return false;
	}
	 if(!password)
	{
		alert("请填写密码");
		return false;
	}
	$.ajax({
			url:'././loginAction.do?action=userLogin&uName='+loginName+'&pwd='+password+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('登录失败,请重新登录！！！')},
			success:function(w_list){
				check();
				//var Item=eval("("+w_list+")");
				//var items=Item.items;
			}
	});
}
function check(){
	window.location.href=url+"/LetouBack/main.jsp";
}