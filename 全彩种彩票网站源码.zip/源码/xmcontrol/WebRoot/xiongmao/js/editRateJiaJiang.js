
var pageCount;//总页数
var currentPage;//当前页

function load()
{
	editJiaJiangRateList(1);
}

function doChange()
{
	editJiaJiangRateList(1);
}

//加奖列表
function editJiaJiangRateList(page)
{
	currentPage = page;
	var userId = $('#userId').val();
	var gameCode = $('#gameCode').val();
	$.ajax
	({
		url:'././userManageAction.do?action=editJiaJiangRateList&page='+page+'&userId='+userId+'&gameCode='+gameCode,
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var items = data.items;
			var count = data.count;
			pageCount = data.pageCount;
			$('#num_id').text(count);
			$('#pageNum').text("共"+pageCount+"页");
			$('.context').empty();
			for(var i=0; i<items.length; i++)
			{
				var trNode =
				"<tr>"+
					"<input type='hidden' value='"+items[i].manner+"' id='manner'/>"+
					"<td align='center' class='tab_content'>"+items[i].mannerStr+"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='text' id='rate' value='"+items[i].rate+"'/> %"+
					"</td>"+
					"<td align='center' class='tab_content'>"+
						"<input type='button' value='更新' onclick='updateRate(this)'/>"+
					"</td>"+
				"</tr>";
				$('.context').append(trNode);
			}
			$('#data tbody tr:even').css("backgroundColor","#CCCCCC");
		}
	});
}

//修改汇率
function updateRate(_this)
{
	var trNode = $(_this).parent().parent();
	var rate = trNode.find("#rate").val();
	if (rate == '')
	{
		alert('配额不能为空！');
		return;
	}
	var manner = trNode.find("#manner").val();
	var userId = $('#userId').val();
	var gameCode = $('#gameCode').val();
	$.ajax
	({
		url:'././userManageAction.do?action=updateRate&rate='+rate+'&manner='+manner+'&userId='+userId+'&type=1&gameCode='+gameCode,
		type:'GET',
		error:function(){alert('更新失败！！！')},
		success:function(data)
		{
			if (data > 0)
			{
				alert('更新成功');
			}
		}
	 });
}

//页数操作
function checkPage(_this)
{
	var tmpPage = 1;
	if($(_this).attr('id')=='aa'){
		tmpPage = pageCount;
	}else if($(_this).attr('id')=='back'){
		if (currentPage > 1){
			tmpPage = currentPage-1;
		}
	}else if($(_this).attr('id')=='next'){
		if (currentPage < pageCount){
			tmpPage = currentPage+1;	
		}
		if (currentPage >= pageCount){
			tmpPage = pageCount;	
		}
	}
	editJiaJiangRateList(tmpPage);
}