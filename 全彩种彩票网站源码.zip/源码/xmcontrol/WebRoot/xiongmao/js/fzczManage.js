var clientId="";
var sourceId="";
function load(){
	$.ajax({
			url:'././fztxManageAction.do?action=getSource&uName='+userName+'&pwd='+pwd+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				for(var i=0;i<items.length;i++){
					var _option="<option value='"+items[i].sourceId+"'>"+items[i].source+"</option>";
					$('#_source').append(_option);
				}
			}
	});
}
function getAdminUserInfo(_this){//用户管理充值的js
	var trNode = $(_this).parent().parent();
	var nickName = trNode.find("#nickName").val();
	var _sourceId = trNode.find("#sourceId").val();//从userAdmin.js中获取的变量
	nickName =encodeURI(encodeURI(nickName));
	sourceId=$('#_source').val();
	//alert("_sourceId---"+_sourceId);
	if(sourceId==null || typeof(sourceId)=='undefined'){
		sourceId=_sourceId;//左国斌 此处给的是四合网站，已经写死了注意！2014-5-20:17:14
	}
	if(nickName==""){
		alert("请输入用户名！！！");
		return;
	}
	$.ajax({
			url:'././fztxManageAction.do?action=getUserInfo&uName='+userName+'&pwd='+pwd+'&sourceid='+sourceId+'&nickName='+nickName+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('无此用户！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				clientId=items[0].clientid;
				sourceId=items[0].sourceid;
				$('#userNickName').val(items[0].userNickName);
				$('#awardMeony').val(items[0].awardMeony);
				$('#dongMeony').val(items[0].dongMeony);
				$('#_meony').val(items[0].meony);
				$('.userInfo_div').show();
			}
	});
}
function getUserInfo(){
	var nickName=$('#nickName').val();
	nickName =encodeURI(encodeURI(nickName));
	sourceId=$('#_source').val();
	if(nickName==""){
		alert("请输入用户名！！！");
		return;
	}
	$.ajax({
			url:'././fztxManageAction.do?action=getUserInfo&uName='+userName+'&pwd='+pwd+'&sourceid='+sourceId+'&nickName='+nickName+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('无此用户！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				clientId=items[0].clientid;
				sourceId=items[0].sourceid;
				$('#userNickName').val(items[0].userNickName);
				$('#awardMeony').val(items[0].awardMeony);
				$('#dongMeony').val(items[0].dongMeony);
				$('#_meony').val(items[0].meony);
				$('.userInfo_div').show();
			}
	});
}
function chongzhi(){
	var bets=$('#bet').val();
	if(bets==""){
		alert("请输入金额！！！");
		return;
	}
	//window.location.href='/WebRoot/LetouBack/detailPage/chongzhi.jsp?uName='+userName+'&pwd='+pwd+'&clientid='+clientId+'&sourceid='+sourceId+'&bets='+bets;
	if(confirm("确定充值？"))
	{
		$.getJSON(url+"/LetouBack/detailPage/chongzhi.jsp?r="+Math.random(),{'uName':userName,'pwd':pwd,'clientid':clientId,'sourceid':sourceId,'bets':bets},function(json){
			var success = json.json[0].success;
			if (success.indexOf("0000")!=-1)
			{
				alert("冲值成功!!");
			}
			else if(success.indexOf("1111")!=-1)
			{
				alert("您的充值申请已经提交!等待确认...");
			}else{
				alert("充值失败!!");
			}
			$('.userInfo_div').hide();
		});
		/*
		$.ajax({
			url:'/WebRoot/LetouBack/detailPage/chongzhi.jsp?uName='+userName+'&pwd='+pwd+'&clientid='+clientId+'&sourceid='+sourceId+'&bets='+bets+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('充值失败！！！')},
			success:function(data){
				if (data.indexOf("0000")!=-1)
				{
					alert("冲值成功!!");
				}
				else
				{
					alert("冲值失败!!");
				}
				$('.userInfo_div').hide();
			}
		});
		*/
	}
	/*
	$.ajax({
			url:'././fztxManageAction.do?action=chongzhi&uName='+userName+'&pwd='+pwd+'&clientid='+clientId+'&sourceid='+sourceId+'&bets='+bets+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('充值失败！！！')},
			success:function(w_list){
				alert("充值成功！！！");
				$('.userInfo_div').hide();
			}
	});
	*/
}
function cannel(){
	$('.userInfo_div').hide();
}