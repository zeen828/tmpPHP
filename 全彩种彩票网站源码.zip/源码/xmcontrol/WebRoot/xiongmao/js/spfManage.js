McN_Map={
	'1':'1串1',
	'2':'2串1',
	'3':'3串1',
	'4':'3串3',
	'5':'3串4',
	'6':'4串1',
	'7':'4串4',
	'8':'4串5',
	'9':'4串6',
	'10':'4串11',
	'11':'5串1',
	'12':'5串5',
	'13':'5串6',
	'14':'5串10',
	'15':'5串16',
	'16':'5串20',
	'17':'5串26',
	'18':'6串1',
	'19':'6串6',
	'20':'6串7',
	'21':'6串15',
	'22':'6串20',
	'23':'6串22',
	'24':'6串35',
	'25':'6串42',
	'26':'6串50',
	'27':'6串57',
	'28':'7串1',
	'29':'7串7',
	'30':'7串8',
	'31':'7串21',
	'32':'7串35',
	'33':'7串120',
	'34':'7串127',
	'35':'8串1',
	'36':'8串8',
	'37':'8串9',
	'38':'8串28',
	'39':'8串56',
	'40':'8串70',
	'41':'8串247',
	'42':'8串255'
}
var topStatus={
	'0':'未置顶',
	'1':'已置顶'
}
var page;
var pageToUname;
var tempPage=1;
var uName="";
var _false="";
function load(){
	getRecordCountToUname();
}
//根据用户名查询合买方案总记录数
function getRecordCountToUname(){
	$.ajax({
			url:'././statisAction.do?action=getRecordCountToUname&status=0&uName='+uName+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				num=items[0].recordCount;
				page=Math.ceil(items[0].recordCount/3);
				$('#num_id').text(num);
				$('#pageNum').text("共"+page+"页");
				getAllDateToUname();
			}
	});
}
//根据用户名查询合买方案
function getAllDateToUname(){
		$.ajax({
			url:'././spfManageAction.do?action=getDateToUame&status=0&uName='+uName+'&page='+tempPage+'&pageCount=3&r='+Math.random(),
			type:'POST',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var spf_list=eval("("+w_list+")");
				var spfItems=spf_list.items;
				$('.center_context_tab').empty();
				var header_tr="<tr>"+
							"<td align='center' class='tab_header'>序号</td>"+
							"<td align='center' class='tab_header'>发起人</td>"+
							"<td align='center' class='tab_header'>方案金额</td>"+
							"<td align='center' class='tab_header'>每份金额</td>"+
							"<td align='center' class='tab_header'>过关方式</td>"+
							"<td align='center' class='tab_header'>进度</td>"+
							"<td align='center' class='tab_header'>倍数</td>"+
							"<td align='center' class='tab_header'>剩余份数</td>"+
							"<td align='center' class='tab_header'>是否置顶</td>"+
							"<td align='center' class='tab_header'>操作</td>"+
						"</tr>";
				$('.center_context_tab').append(header_tr);
				for(var i=0;i<spfItems.length;i++){
					var jd=(parseInt(spfItems[i].buyShare)/parseInt(spfItems[i].numShare)*100).toFixed(0);
					var surplusShare=parseInt(spfItems[i].numShare)-parseInt(spfItems[i].buyShare);
					var betWays=spfItems[i].betWay.split(",");
					var bdbet=(parseFloat(spfItems[i].sharePrice)*parseFloat(spfItems[i].bdShare)).toFixed(2);
					var betWay='';
					for(var j=0;j<betWays.length;j++){
						if(j==betWays.length-1){ 
							betWay=betWay+McN_Map[betWays[j]];
						}else{
							betWay=betWay+McN_Map[betWays[j]]+",";
						}
					}
					var tr="<tr id='"+spfItems[i].gameId+"'>"+
						"<td align='center' class='tab_content'>"+(i+1)+"</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].uName+"</td>"+
						"<td align='center' class='tab_content' id='"+bdbet+"'>"+spfItems[i].betMoney+"元</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].sharePrice+"元</td>"+
						"<td align='center' class='tab_content'>"+betWay+"</td>"+
						"<td align='center' class='tab_content' id='"+spfItems[i].status+"'>"+jd+"%</td>"+
						"<td align='center' class='tab_content' id='"+spfItems[i].royaltyRatio+"'>"+spfItems[i].betMultiples+"</td>"+
						"<td align='center' class='tab_content' id='"+spfItems[i].numShare+"'>"+surplusShare+"</td>"+
						"<td align='center' class='tab_content'>"+topStatus[spfItems[i].isTop]+"</td>"+
						"<td align='center' class='tab_content'>"+
						"<a href='javascript:void(0)' onClick='javascript:setTopStatus(this,0)'>取消置顶</a>&nbsp;&nbsp;"+
						"<a href='javascript:void(0)' onClick='javascript:setTopStatus(this,1)'>置顶</a>&nbsp;&nbsp;"+
						"<a href='javascript:void(0)' onClick='javascript:openDiv(this)'>详情</a>"+
						"</td>"+
					"</tr>";
					$('.center_context_tab').append(tr);
				}
			}
	});
}
//页数操作
function checkPage(_this){
	if($(_this).attr('id')=='begin'){
		tempPage=1;
	}else if($(_this).attr('id')=='last'){
		tempPage=page;
	}else if($(_this).attr('id')=='back'){
		tempPage=tempPage-1;
	}else{
		tempPage=tempPage+1;
	}
	if(tempPage<=-1){
		tempPage=1
		return;
	}
	if(tempPage>=(page+1)){
		tempPage=page;
		return;
	}
	if(_false=="true"||_false==""){
		getAllDateToUname();
	}else{
		getDataToStartScreen();
	}
}
//根据用户名搜索
function select_toUname(){
 	uName=encodeURI(encodeURI($('#uName').val()));
 	if(uName=="请输入用户名"){
		uName="";
	}
	tempPage=1;
	_false="true";
 	getRecordCountToUname();
 }
 //设置方案筛选条件
 var betWay="all";
 var projectStatus="all";
 var projectMoney="all";
 var projectJd="all"
 var sharePrice="all";
 var isEnsure="all";
 var projectRoyalty="all";
function onclic_color(_this){
 		for(var i=0;i<$(_this).parent().parent().find('a').length;i++){
 			$(_this).parent().parent().find('a').eq(i).removeClass();
 		}
 		$(_this).addClass('click_color');
 		var tr_id=$(_this).parent().parent().attr('id');
 		if(tr_id=="betWay"){
 			betWay=$(_this).attr('id');
 		}else if(tr_id=="projectStatus"){
 			projectStatus=$(_this).attr('id');
 		}else if(tr_id=="projectMoney"){
 			projectMoney=$(_this).attr('id');
 		}else if(tr_id=="projectJd"){
 			projectJd=$(_this).attr('id');
 		}else if(tr_id=="sharePrice"){
 			sharePrice=$(_this).attr('id');
 		}else if(tr_id=="isEnsure"){
 			isEnsure=$(_this).attr('id');
 		}else{
 			projectRoyalty=$(_this).attr('id');
 		}
 }
 //开始筛选
 var _str="";
function start_screen(){
	_str=betWay+','+projectStatus+','+projectMoney+','+projectJd+','+sharePrice+','+isEnsure+','+projectRoyalty;
	tempPage=1;
	getRecordCountToStartScreen();
	_false="false";
	$('#projectScreen').hide();
}
//通过筛选查询合买方案总记录数
function getRecordCountToStartScreen(){
	$.ajax({
			url:'././spfManageAction.do?action=getRecordCountToProjectScreen&str='+_str+'&page='+tempPage+'&pageCount=3&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var spf_list=eval("("+w_list+")");
				var items=spf_list.items;
				num=items[0].pageCount;
				page=Math.ceil(items[0].pageCount/3);
				$('#num_id').text(num);
				$('#pageNum').text("共"+page+"页");
				getDataToStartScreen(_str);
			}
	});	
}
//通过筛选查询合买方案
function getDataToStartScreen(){
	$.ajax({
			url:'././spfManageAction.do?action=getDataToProjectScreen&str='+_str+'&page='+tempPage+'&pageCount=3&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var spf_list=eval("("+w_list+")");
				var spfItems=spf_list.items;
				$('.center_context_tab').empty();
				var header_tr="<tr>"+
							"<td align='center' class='tab_header'>序号</td>"+
							"<td align='center' class='tab_header'>发起人</td>"+
							"<td align='center' class='tab_header'>方案金额</td>"+
							"<td align='center' class='tab_header'>每份金额</td>"+
							"<td align='center' class='tab_header'>过关方式</td>"+
							"<td align='center' class='tab_header'>进度</td>"+
							"<td align='center' class='tab_header'>倍数</td>"+
							"<td align='center' class='tab_header'>剩余份数</td>"+
							"<td align='center' class='tab_header'>是否置顶</td>"+
							"<td align='center' class='tab_header'>操作</td>"+
						"</tr>";
				$('.center_context_tab').append(header_tr);
				for(var i=0;i<spfItems.length;i++){
					var jd=(parseInt(spfItems[i].buyShare)/parseInt(spfItems[i].numShare)*100).toFixed(0);
					var surplusShare=parseInt(spfItems[i].numShare)-parseInt(spfItems[i].buyShare);
					var betWays=spfItems[i].betWay.split(",");
					var bdbet=(parseFloat(spfItems[i].sharePrice)*parseFloat(spfItems[i].bdShare)).toFixed(2);
					var betWay='';
					for(var j=0;j<betWays.length;j++){
						if(j==betWays.length-1){
							betWay=betWay+McN_Map[betWays[j]];
						}else{
							betWay=betWay+McN_Map[betWays[j]]+",";
						}
					}
					var tr="<tr id='"+spfItems[i].gameId+"'>"+
						"<td align='center' class='tab_content'>"+(i+1)+"</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].uName+"</td>"+
						"<td align='center' class='tab_content' id='"+bdbet+"'>"+spfItems[i].betMoney+"元</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].sharePrice+"元</td>"+
						"<td align='center' class='tab_content'>"+betWay+"</td>"+
						"<td align='center' class='tab_content' id='"+spfItems[i].status+"'>"+jd+"%</td>"+
						"<td align='center' class='tab_content' id='"+spfItems[i].royaltyRatio+"'>"+spfItems[i].betMultiples+"</td>"+
						"<td align='center' class='tab_content' id='"+spfItems[i].numShare+"'>"+surplusShare+"</td>"+
						"<td align='center' class='tab_content'>"+topStatus[spfItems[i].isTop]+"</td>"+
						"<td align='center' class='tab_content'>"+
						"<a href='javascript:void(0)' onClick='javascript:setTopStatus(this,0)'>取消置顶</a>&nbsp;&nbsp;"+
						"<a href='javascript:void(0)' onClick='javascript:setTopStatus(this,1)'>置顶</a>&nbsp;&nbsp;"+
						"<a href='javascript:void(0)' onClick='javascript:openDiv(this)'>详情</a>"+
						"</td>"+
					"</tr>";
					$('.center_context_tab').append(tr);
				}
			}
	});	
}

//设置置顶
function setTopStatus(_this,status){
	var gameId=$(_this).parent().parent().attr('id');
	$.ajax({
			url:'././spfManageAction.do?action=setTopStatus&gameId='+gameId+'&topStatus='+status+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('操作失败！！！')},
			success:function(w_list){
				alert("操作成功");
				if(_false=="true"||_false==""){
					getAllDateToUname();
				}else{
					getDataToStartScreen();
				}
			}
	});
}
//打开方案详情窗口
var spf={
	'3':'胜',
	'1':'平',
	'0':'负'
}
function openDiv(_this){
	var bets=$(_this).parent().parent().find('td').eq(2).text();
	var bdbet=$(_this).parent().parent().find('td').eq(2).attr('id');
	var sharePrice=$(_this).parent().parent().find('td').eq(3).text();
	var betWay=$(_this).parent().parent().find('td').eq(4).text();
	var jd=$(_this).parent().parent().find('td').eq(5).text();
	var status=$(_this).parent().parent().find('td').eq(5).attr('id');
	var Multiples=$(_this).parent().parent().find('td').eq(6).text();
	var userTc=$(_this).parent().parent().find('td').eq(6).attr('id');
	var share=$(_this).parent().parent().find('td').eq(7).attr('id');
	var tr="<tr height='24' style='background:#EEF7FF;'>"+
				"<td align='center' width='102'>总金额</td>"+
				"<td align='center' width='45'>倍数</td>"+
				"<td align='center' width='45'>份数</td>"+
				"<td align='center' width='69'>每份</td>"+
				"<td align='center' width='61'>发起人提成</td>"+
				"<td align='center' width='70'>彩票标示</td>"+
				"<td align='center' width='80'>保底金额</td>"+
				"<td align='center' width='80'>购买进度</td>"+
			"</tr>";
	$('#projectDetails01').empty();
	$('#projectDetails01').append(tr);
	var str="";
	if(status=="0"){
		str="发起成功";
	}else if(status=="-1"){
		str="已撤单";
	}else{
		str="<a href='javasript:void(0)'>详情</a>";
	}
	tr="<tr height='24'>"+
				"<td align='center' width='102'>￥"+bets+"</td>"+
				"<td align='center' width='45'>"+Multiples+"</td>"+
				"<td align='center' width='45'>"+share+"份</td>"+
				"<td align='center' width='69'>￥"+sharePrice+"</td>"+
				"<td align='center' width='61'>"+userTc+"%</td>"+
				"<td align='center' width='70'>"+str+"</td>"+
				"<td align='center' width='80'>￥"+bdbet+"</td>"+
				"<td align='center' width='80'>"+jd+"</td>"+
			"</tr>";
	$('#projectDetails01').append(tr);
	$('#_betWay').text(betWay);
	
	var gameId=$(_this).parent().parent().attr('id');
	$.ajax({
			url:'././spfManageAction.do?action=getProjectDetail&gameId='+gameId+'&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var spf_list=eval("("+w_list+")");
				var spfItems=spf_list.items;
				$('#changci').text(spfItems.length);
				var tr02="<tr height='24' style='background:#EEF7FF;'>"+
					"<td align='center' width='50'>赛事编号</td>"+
					"<td align='center' width='180'>主队vs客队</td>"+
					"<td align='center' width='45'>让球数</td>"+
					"<td align='center' width='50'>全场比分</td>"+
					"<td align='center' width='45'>赛果</td>"+
					"<td align='center' width='80'>奖金</td>"+
					"<td align='center' width='60'>你的选择</td>"+
					"<td align='center' width='43'>胆码</td>"+
				"</tr>";
				$('#projectDetails02').empty();
				$('#projectDetails02').append(tr02);
				for(var i=0;i<spfItems.length;i++){
					var spfs=spfItems[i].spf.split("/");
					var _spf="";
					for(var j=0;j<spfs.length;j++){
						if(j==spfs.length-1){
							_spf=_spf+spf[spfs[j]];
						}else{
							_spf=_spf+spf[spfs[j]]+",";
						}
					}
					tr02="<tr height='24'>"+
						"<td align='center' width='50'>"+spfItems[i].gameNum+"</td>"+
						"<td align='center' width='180'>"+spfItems[i].homeTeam+" VS "+spfItems[i].awayTeam+"</td>"+
						"<td align='center' width='45'>"+spfItems[i].letBallCount+"</td>"+
						"<td align='center' width='50'>"+spfItems[i].score+"&nbsp;</td>"+
						"<td align='center' width='45'>"+spfItems[i].gameResult+"&nbsp;</td>"+
						"<td align='center' width='80'>"+spfItems[i].moneyReward+"</td>"+
						"<td align='center' width='60'>"+_spf+"</td>"+
						"<td align='center' width='43'>X</td>"+
					"</tr>";
					$('#projectDetails02').append(tr02);
				}
			}
	});
	$('#project_detail').show();
}
//关闭方案详情窗口
function closeDiv(){
	$('#project_detail').hide();
	
}









































//得到合买方案总记录数
function getRecordCount(){
	$.ajax({
			url:'././spfManageAction.do?action=getRecordCount&status=0&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var Item=eval("("+w_list+")");
				var items=Item.items;
				num=items[0].recordCount;
				page=Math.ceil(items[0].recordCount/3);
				$('#num_id').text(num);
				$('#pageNum').text("共"+page+"页");
				getAllDate();
			}
	});
}
//得到所有合买方案
function getAllDate(){
	$.ajax({
			url:'././spfManageAction.do?action=getAllDate&status=0&page='+tempPage+'&pageCount=3&r='+Math.random(),
			type:'GET',
			error:function(){alert('网络连接异常！！！')},
			success:function(w_list){
				var spf_list=eval("("+w_list+")");
				var spfItems=spf_list.items;
				$('.center_context_tab').empty();
				var header_tr="<tr>"+
							"<td align='center' class='tab_header'>序号</td>"+
							"<td align='center' class='tab_header'>发起人</td>"+
							"<td align='center' class='tab_header'>方案金额</td>"+
							"<td align='center' class='tab_header'>每份金额</td>"+
							"<td align='center' class='tab_header'>过关方式</td>"+
							"<td align='center' class='tab_header'>进度</td>"+
							"<td align='center' class='tab_header'>倍数</td>"+
							"<td align='center' class='tab_header'>剩余份数</td>"+
							"<td align='center' class='tab_header'>操作</td>"+
						"</tr>";
				$('.center_context_tab').append(header_tr);
				for(var i=0;i<spfItems.length-1;i++){
					var jd=(parseInt(spfItems[i].buyShare)/parseInt(spfItems[i].numShare)*100).toFixed(0);
					var surplusShare=parseInt(spfItems[i].numShare)-parseInt(spfItems[i].buyShare);
					var betWays=spfItems[i].betWay.split(",");
					var betWay='';
					for(var j=0;j<betWays.length;j++){
						if(j==betWays.length-1){
							betWay=betWay+McN_Map[betWays[j]];
						}else{
							betWay=betWay+McN_Map[betWays[j]]+",";
						}
					}
					var tr="<tr>"+
						"<td align='center' class='tab_content'>"+(i+1)+"</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].uName+"</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].betMoney+"元</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].sharePrice+"元</td>"+
						"<td align='center' class='tab_content'>"+betWay+"</td>"+
						"<td align='center' class='tab_content'>"+jd+"%</td>"+
						"<td align='center' class='tab_content'>"+spfItems[i].betMultiples+"</td>"+
						"<td align='center' class='tab_content'>"+surplusShare+"</td>"+
						"<td align='center' class='tab_content'><a href='javascript:void(0)'>置顶</a>&nbsp;<a href='javascript:void(0)'>详情</a></td>"+
					"</tr>";
					$('.center_context_tab').append(tr);
				}
			}
	});
}