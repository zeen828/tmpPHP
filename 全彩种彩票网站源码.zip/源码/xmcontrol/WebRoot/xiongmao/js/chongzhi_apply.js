


//充值申请列表
function chongzhi_applyList()
{
	$.ajax
	({
		url:'././chongzhi_applyAction.do?action=chongzhi_applyList',
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var items = data.items;
			$('.context').empty();
			for(var i=0; i<items.length; i++)
			{
				var trNode="";
				if(isRight(grade)&& items[i].applyState=='0'){//如果是超级管理员权限,且没有被驳回处理时显示"确认充值,撤销充值,不同意充值"
					trNode=
						"<tr>"+
						     "<input type='hidden' value='"+items[i].applyId+"' id='applyId'/>"+//隐藏表单
						     "<td align='center' class='tab_content'>"+(i+1)+"</td>"+
						    "<td align='center' class='tab_content'>"+items[i].applyPerson+"</td>"+
							"<td align='center' class='tab_content'>"+formatTime(items[i].applyTime)+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].client_userId+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].client_userName+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].applyBet+"</td>"+
							"<td align='center' class='tab_content'>"+numToText(items[i].applyState)+"</td>"+
							//"<td align='center' class='tab_content'>"+items[i].applyReason+"</td>"+
							"<td align='center' class='tab_content'>"+
							
							"<input type='button' value='确认充值' onclick='applyAgree(this)'/>"+
							"<input type='button' value='不同意充值' onclick='applyDisAgree(this)'/>"+
							"<input type='button' value='撤销充值' onclick='applyCancel(this)'/>"+
							
						"</td>"+
						"</tr>";
					
				} else if(isRight(grade)&& items[i].applyState=='1'){//如果是超级管理员权限,且被驳回处理时显示"确认充值,撤销充值"
					trNode=
						"<tr>"+
						     "<input type='hidden' value='"+items[i].applyId+"' id='applyId'/>"+//隐藏表单
						     "<td align='center' class='tab_content'>"+(i+1)+"</td>"+
						    "<td align='center' class='tab_content'>"+items[i].applyPerson+"</td>"+
							"<td align='center' class='tab_content'>"+formatTime(items[i].applyTime)+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].client_userId+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].client_userName+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].applyBet+"</td>"+
							"<td align='center' class='tab_content'>"+numToText(items[i].applyState)+"</td>"+
							//"<td align='center' class='tab_content'>"+items[i].applyReason+"</td>"+
							"<td align='center' class='tab_content'>"+
							
							"<input type='button' value='确认充值' onclick='applyAgree(this)'/>"+
							//"<input type='button' value='不同意充值' onclick='applyDisAgree(this)'/>"+
							"<input type='button' value='撤销充值' onclick='applyCancel(this)'/>"+
							
						"</td>"+
						"</tr>";
					
				}
				else{
					 trNode =
						"<tr>"+
						   "<input type='hidden' value='"+items[i].applyId+"' id='applyId'/>"+//隐藏表单
					       "<td align='center' class='tab_content'>"+(i+1)+"</td>"+
						    "<td align='center' class='tab_content'>"+items[i].applyPerson+"</td>"+
							"<td align='center' class='tab_content'>"+formatTime(items[i].applyTime)+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].client_userId+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].client_userName+"</td>"+
							"<td align='center' class='tab_content'>"+items[i].applyBet+"</td>"+
							"<td align='center' class='tab_content'>"+numToText(items[i].applyState)+"</td>"+
						//	"<td align='center' class='tab_content'>"+items[i].applyReason+"</td>"+
							"<td align='center' class='tab_content'>"+
							
							"<input type='button' value='撤销充值' onclick='applyCancel(this)'/>"+
							
						"</td>"+
						"</tr>";
				}
				$('.context').append(trNode);
		
			}
			$('#data tbody tr:even').css("backgroundColor","#CCCCCC");
		}
	});
}
//同意充值
function applyAgree(_this){
	if (confirm("确定充值？")){
		var trNode = $(_this).parent().parent();
		var applyId = trNode.find("#applyId").val();//获取chongzhi_applyList()隐藏表单的值
		$.ajax
		({
			url:'././chongzhi_applyAction.do?action=ApplyAgree&applyId='+applyId,
			type:'GET',
			error:function(){alert('充值失败！！！')},
			success:function(data)
			{
				if (data == '0000')
				{
					alert('充值成功');
				}
				else{
					alert('充值失败');
				}
				chongzhi_applyList();
			}
		 });
	}
}
//不同意充值
function applyDisAgree(_this){
	if (confirm("确定返回处理？")){
		var trNode = $(_this).parent().parent();
		var applyId = trNode.find("#applyId").val();//获取chongzhi_applyList()隐藏表单的值
		$.ajax
		({
			url:'././chongzhi_applyAction.do?action=ApplyDisAgree&applyId='+applyId,
			type:'GET',
			error:function(){alert('提交失败！！！')},
			success:function(data)
			{
				if (data == '0000')
				{
					alert('提交成功');
				}
				else{
					alert('提交失败');
				}
				chongzhi_applyList();
			}
		 });
	}
}
//撤销充值申请
function applyCancel(_this){
	if (confirm("确定撤销申请处理？")){
		var trNode = $(_this).parent().parent();
		var applyId = trNode.find("#applyId").val();//获取chongzhi_applyList()隐藏表单的值
		$.ajax
		({
			url:'././chongzhi_applyAction.do?action=ApplyCancel&applyId='+applyId,
			type:'GET',
			error:function(){alert('提交失败！！！')},
			success:function(data)
			{
				if (data == '0000')
				{
					alert('提交成功');
				}
				else{
					alert('提交失败');
				}
				chongzhi_applyList();
			}
		 });
	}
}

//格式化时间的js
function formatTime(time){
	var dt = "";
	if (time != "" && time != 'null'){
		var year=time.substring(0,4);
		var month=time.substring(5,7);
		var day=time.substring(8,10);
		dt=year+"-"+month+"-"+day;
	}
	return dt;
}
//判断是否有权限确认充值和不同意充值0:表示有权限,1或非0表示没有权限
function isRight(grade){
	if (grade=='0'){
			return true;
	}else{
		return false;
	}
}
//程序加载列表
function myload()
{
	chongzhi_applyList();
}
function numToText(num){
	if(num=='0'){
		return "充值申请";
	}else if(num=='1'){
		return "充值申请被退回";
	}else{
		return "操作异常";
	}
}
