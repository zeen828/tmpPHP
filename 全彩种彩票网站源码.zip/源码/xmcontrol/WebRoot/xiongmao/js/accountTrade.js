
var pageCount;//总页数
var currentPage;//当前页

var tradeType_map = {
		"1004":"管理员辅助充值","1002":"提现申请","3083":"停赛退款","3085":"停赛退款","7001":"投注返点","1013":"网银充值","1006":"中奖派奖","1012":"注册充值","7003":"转款","1005":"管理员加奖","8001":"加奖","6003":"保底奖金","7004":"收款","6001":"充值赠送10%","1008":"代购撤单返款","1009":"合买撤单返款","1001":"充值","2023":"22选5代购投注","2024":"22选5代购追期","3026":"22选5合买保底","6002":"方案提成奖金","3012":"22选5合买参与","3040":"22选5合买个人撤单","3054":"22选5合买系统撤单","2007":"36选7代购投注","2008":"36选7代购追期","3017":"36选7合买保底","3003":"36选7合买参与","3031":"36选7合买个人撤单","3045":"36选7合买系统撤单","2009":"4场进球彩代购投注","2010":"4场进球彩代购追期","3019":"4场进球彩合买保底","3005":"4场进球彩合买参与","3033":"4场进球彩合买个人撤单","3047":"4场进球彩合买系统撤单","2011":"6场半全场代购投注","2012":"6场半全场代购追期","3020":"6场半全场合买保底","3006":"6场半全场合买参与","3034":"6场半全场合买个人撤单","3048":"6场半全场合买系统撤单","3084":"CPS佣金转入","5013":"半全场保底","5014":"半全场参与","5015":"半全场个人撤单","3061":"半全场合买保底","3081":"半全场合买参与","3066":"半全场合买系统撤单","5016":"半全场系统撤单","5005":"比分保底","5006":"比分参与","5007":"比分个人撤单","3060":"比分合买保底","3080":"比分合买参与","3070":"比分合买个人撤单","3065":"比分合买系统撤单","5008":"比分系统撤单","2017":"大乐透代购投注","2018":"大乐透代购追期","3023":"大乐透合买保底","3009":"大乐透合买参与","3037":"大乐透合买个人撤单","3051":"大乐透合买系统撤单","5029":"大小分保底","5030":"大小分参与","5031":"大小分个人撤单","5032":"大小分系统撤单","2021":"福彩3D代购投注","2022":"福彩3D代购追期","3025":"福彩3D合买保底","3011":"福彩3D合买参与","3039":"福彩3D合买个人撤单","3053":"福彩3D合买系统撤单","2001":"进球彩代购投注","2002":"进球彩代购追期","5038":"竞彩足球混投参与","2015":"排列5代购投注","2016":"排列5代购追期","3022":"排列5合买保底","3008":"排列5合买参与","3036":"排列5合买个人撤单","3050":"排列5合买系统撤单","2029":"排列三代购投注","2030":"排列三代购追期","3018":"排列三合买保底","3004":"排列三合买参与","3032":"排列三合买个人撤单","3046":"排列三合买系统撤单","2027":"七乐彩代购投注","2028":"七乐彩代购追期","3028":"七乐彩合买保底","3014":"七乐彩合买参与","3042":"七乐彩合买个人撤单","3056":"七乐彩合买系统撤单","2013":"七星彩代购投注","2014":"七星彩代购追期","3021":"七星彩合买保底","3007":"七星彩合买参与","3035":"七星彩合买个人撤单","3049":"七星彩合买系统撤单","5021":"让分胜负保底","5022":"让分胜负参与","5023":"让分胜负个人撤单","5024":"让分胜负系统撤单","5034":"让球胜平负参与","2005":"任选9代购投注","2006":"任选9代购追期","3016":"任选9合买保底","3002":"任选9合买参与","3030":"任选9合买个人撤单","3044":"任选9合买系统撤单","3059":"上下单双合买保底","3079":"上下单双合买参与","3069":"上下单双合买个人撤单","3064":"上下单双合买系统撤单","7002":"上线返点","2025":"深圳风采代购投注","2026":"深圳风采代购追期","3027":"深圳风采合买保底","3013":"深圳风采合买参与","3041":"深圳风采合买个人撤单","3055":"深圳风采合买系统撤单","5025":"胜分差保底","5026":"胜分差参与","5027":"胜分差个人撤单","5028":"胜分差系统撤单","5017":"胜负保底","2003":"胜负彩代购投注","2004":"胜负彩代购追期","3015":"胜负彩合买保底","3001":"胜负彩合买参与","3029":"胜负彩合买个人撤单","3043":"胜负彩合买系统撤单","5018":"胜负参与","5019":"胜负个人撤单","5020":"胜负系统撤单","5001":"胜平负保底","5002":"胜平负参与","5003":"胜平负个人撤单","3058":"胜平负合买保底","3078":"胜平负合买参与","3068":"胜平负合买个人撤单","3063":"胜平负合买系统撤单","5004":"胜平负系统撤单","2019":"双色球代购投注","2020":"双色球代购追期","3024":"双色球合买保底","3010":"猜冠军","3038":"双色球合买个人撤单","3052":"双色球合买系统撤单","5009":"总进球保底","5010":"总进球参与","5011":"总进球个人撤单","3062":"总进球数合买保底","3071":"总进球数合买参与","3082":"总进球数合买参与","3072":"总进球数合买个人撤单","3067":"总进球数系统撤单","5012":"总进球系统撤单","5036":"系统撤单","3099":"猜冠军","9999":"出票失败退款"
}

function load()
{
	var selectNode = "<option value=''>全部</option>";
	for (var key in tradeType_map)
	{
		selectNode += "<option value='" + key + "'>" + tradeType_map[key] + "</option>"
	}
	$("#tradeType").html(selectNode);
	accountTradeList(1);
}

//交易列表
function accountTradeList(page)
{
	currentPage = page;
	var searchName = $('#searchName').val();
	var unionId = $('#unionId').val();
	var serialNo = $('#serialNo').val();
	var tradeType = $('#tradeType').val();
	var startDate = $('#startDate').val();
	var endDate = $('#endDate').val();
	$.ajax
	({
		url:'././accountTradeAction.do?action=accountTradeList&page='+page+'&searchName='+encodeURIComponent(searchName)+'&serialNo='+serialNo+'&tradeType='+tradeType+'&startDate='+startDate+'&endDate='+endDate+'&unionId='+unionId,
		type:'GET',
		error:function(){alert('网络连接异常！！！')},
		success:function(data)
		{
			data = eval("("+data+")");
			var items = data.items;
			var count = data.count;
			pageCount = data.pageCount;
			var inComeSum = data.inComeSum;
			var payOutSum = data.payOutSum;
			$('#num_id').text(count);//总记录数
			$('#num_id2').text(inComeSum);//总收入数
			$('#num_id3').text(payOutSum);//总支出数
			
			$('#sellSum').text(data.sellSum);//总收入数
			$('#cancelSum').text(data.cancelSum);//总支出数
			$('#awardBetsSum').text(data.awardBetsSum);//总收入数
			$('#tcAwardBetsSum').text(data.tcAwardBetsSum);//总支出数
			$('#bets1012Sum').text(data.bets1012Sum);//总收入数
			$('#bets6001Sum').text(data.bets6001Sum);//总支出数
			$('#manmagerChongzhiSum').text(data.manmagerChongzhiSum);//总收入数
			$('#bankChongzhiSum').text(data.bankChongzhiSum);//总支出数
			
			$('#balance').text(data.balance);//总支出数
			$('#awardbets').text(data.awardbets);//总支出数
			$('#freezedmoney').text(data.freezedmoney);//总支出数
			$('#bets_').text(data.bets_);//总支出数
			
			
			
			
			
			$('#pageNum').text("共"+pageCount+"页");//共多少页
			$('.context').empty();
			for(var i=0; i<items.length; i++)
			{
				var trNode =
				"<tr>"+
				    "<td align='center' class='tab_content'><a href='http://218.244.145.26/letoula/useraccount/MannerDetail.jsp?id="+items[i].serialNo+"' target='_blank'>"+items[i].serialNo+"</a></td>"+
					"<td align='center' class='tab_content'>"+items[i].userName+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].inCome+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].payOut+"</td>"+
					"<td align='center' class='tab_content'>"+items[i].balance+"</td>"+
					"<td align='center' class='tab_content'>"+tradeType_map[items[i].tradeType]+"</td>"+
					"<td align='center' class='tab_content'>"+formatTime(items[i].tradeTime)+"</td>"+
				"</tr>";
				$('.context').append(trNode);
			}
			$('#data tbody tr:even').css("backgroundColor","#CCCCCC");
		}
	});
}

//Excel导出所有的交易列表  左国斌 2014-5-20
function exportAccountTradeList()
{
	var searchName = $('#searchName').val();
	var serialNo = $('#serialNo').val();
	var tradeType = $('#tradeType').val();
	var startDate = $('#startDate').val();
	var endDate = $('#endDate').val();
	window.location.href='././accountTradeAction.do?action=ExportAccountTradeList&searchName='+encodeURIComponent(searchName)+'&serialNo='+serialNo+'&tradeType='+tradeType+'&startDate='+startDate+'&endDate='+endDate;
}

//页数操作
function checkPage(_this)
{
	var tmpPage = 1;
	if($(_this).attr('id')=='aa'){
		tmpPage = pageCount;
	}else if($(_this).attr('id')=='back'){
		if (currentPage > 1){
			tmpPage = currentPage-1;
		}
	}else if($(_this).attr('id')=='next'){
		if (currentPage < pageCount){
			tmpPage = currentPage+1;	
		}
		if (currentPage >= pageCount){
			tmpPage = pageCount;	
		}
	}
	accountTradeList(tmpPage);
}

function formatTime(time){
	var dt = "";
	if (time != "" && time != 'null'){
		var year=time.substring(0,4);
		var month=time.substring(4,6);
		var day=time.substring(6,8);
		var hours=time.substring(8,10);
		var minute=time.substring(10,12);
		var seconds=time.substring(12,14);
		dt=year+"-"+month+"-"+day+" "+hours+":"+minute+":"+seconds;
	}
	return dt;
}