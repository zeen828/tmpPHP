 package com.jingCaiBack.dao;
 
 import java.io.PrintStream;
 import java.sql.SQLException;
 import java.util.List;
 import org.junit.Test;
 
 public class UserLoginDAOTest
 {
   UserLoginDAO dao = new UserLoginDAO();
 
   @Test
   public void testGetById() throws SQLException
   {
     System.out.println(this.dao.getById(29275));
   }
 
   @Test
   public void testGetList() throws SQLException
   {
     //List list = this.dao.getList("gg", "0,1", 0, 20, "101");
    // System.out.println(list.size());
   }
 
   @Test
   public void testGetCount() throws SQLException
   {
    // System.out.println(this.dao.getCount("g", "0,1", "101"));
   }
 }

