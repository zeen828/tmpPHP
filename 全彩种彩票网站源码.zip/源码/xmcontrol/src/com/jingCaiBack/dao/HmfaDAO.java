 package com.jingCaiBack.dao;
 
 import com.ibatis.sqlmap.client.SqlMapClient;
 import com.jingCaiBack.model.Hmfa;
 import java.sql.SQLException;
 import java.util.HashMap;
 import java.util.List;
 import java.util.Map;
 
 public class HmfaDAO extends BaseDAO
 {
   public Hmfa getById(int hmfaId)
     throws SQLException
   {
     return ((Hmfa)this.sqlMap.queryForObject("HmfaDAO.getById", Integer.valueOf(hmfaId)));
   }
 
   public Hmfa getBySerialNo(String serialNo) throws SQLException
   {
     return ((Hmfa)this.sqlMap.queryForObject("HmfaDAO.getBySerialNo", serialNo));
   }
 
   public List<Hmfa> getList(int start, int end, int checkStatus, String startTime, String endTime)
     throws SQLException
   {
     Map params = new HashMap();
     params.put("start", Integer.valueOf(start));
     params.put("end", Integer.valueOf(end));
     params.put("checkStatus", Integer.valueOf(checkStatus));
     params.put("startTime", startTime);
     params.put("endTime", endTime);
     return this.sqlMap.queryForList("HmfaDAO.getList", params);
   }
 
   public int getCount(int checkStatus, String startTime, String endTime) throws SQLException
   {
     Map params = new HashMap();
     params.put("checkStatus", Integer.valueOf(checkStatus));
     params.put("startTime", startTime);
     params.put("endTime", endTime);
     return ((Integer)this.sqlMap.queryForObject("HmfaDAO.getCount", params)).intValue();
   }
 }

