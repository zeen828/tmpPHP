 package com.jingCaiBack.dao;
 
 import com.ibatis.sqlmap.client.SqlMapClient;
 import com.jingCaiBack.model.Lan_qiuAgainst;
 import java.sql.SQLException;
 
 public class Lan_qiuAgainstDAO extends BaseDAO
 {
   public Lan_qiuAgainst getById(String againstId)
     throws SQLException
   {
     return ((Lan_qiuAgainst)this.sqlMap.queryForObject("Lan_qiuAgainstDAO.getById", againstId));
   }
 }

