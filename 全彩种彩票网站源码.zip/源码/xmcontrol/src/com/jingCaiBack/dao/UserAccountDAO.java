 package com.jingCaiBack.dao;
 
 import com.ibatis.sqlmap.client.SqlMapClient;
 import com.jingCaiBack.model.UserAccount;
 import java.sql.SQLException;
 import java.util.HashMap;
 import java.util.Map;
 
 public class UserAccountDAO extends BaseDAO
 {
   public UserAccount getById(int userId)
     throws SQLException
   {
     return ((UserAccount)this.sqlMap.queryForObject("UserAccountDAO.getById", Integer.valueOf(userId)));
   }
 
   public double getTotalMoney() throws SQLException
   {
     return ((Double)this.sqlMap.queryForObject("UserAccountDAO.getTotalMoney", null)).doubleValue();
   }
 
   public int update(int userId, double balance, double awardBets, double freezedMoney) throws SQLException
   {
     Map params = new HashMap();
     params.put("userId", Integer.valueOf(userId));
     params.put("balance", Double.valueOf(balance));
     params.put("awardBets", Double.valueOf(awardBets));
     params.put("freezedMoney", Double.valueOf(freezedMoney));
     return Integer.valueOf(this.sqlMap.update("UserAccountDAO.update", params)).intValue();
   }
 }

