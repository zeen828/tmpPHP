 package com.jingCaiBack.dao;
 
 import com.ibatis.sqlmap.client.SqlMapClient;
 import com.jingCaiBack.util.SqlMapClientFactory;
 import org.apache.log4j.Logger;
 
 public abstract class BaseDAO
 {
   protected final Logger _logger = Logger.getLogger(super.getClass());
   protected SqlMapClient sqlMap = SqlMapClientFactory.getInstance();
 }

