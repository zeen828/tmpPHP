 package com.jingCaiBack.dao;
 
 import org.junit.Test;
 
 public class TurnMoneyDAOTest
 {
   private TurnMoneyDAO dao = new TurnMoneyDAO();
 
   @Test
   public void testTurnMoney() throws Exception
   {
     this.dao.turnMoney(31410, 33290, 9850.0D);
   }
 }

