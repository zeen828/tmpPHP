 package com.jingCaiBack.dao;
 
 import java.io.PrintStream;
 import java.sql.SQLException;
 import java.util.List;
 import org.junit.Test;
 
 public class HmfaDAOTest
 {
   HmfaDAO dao = new HmfaDAO();
 
   @Test
   public void testGetById() throws SQLException
   {
     System.out.println(this.dao.getById(115355));
   }
 
   @Test
   public void testGetList() throws SQLException
   {
     String startTime = "20131120000000";
     String endTime = "20131124235959";
     int checkStatus = 0;
     int count = this.dao.getCount(checkStatus, startTime, endTime);
     List list = this.dao.getList(0, 12, checkStatus, startTime, endTime);
     System.out.println(count);
     System.out.println(list.size());
   }
 
   @Test
   public void testGetBySerialNo() throws SQLException
   {
     System.out.println(this.dao.getBySerialNo("1311242357530000000000184"));
   }
 }

