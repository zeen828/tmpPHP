 package com.jingCaiBack.dao;
 
 import java.io.PrintStream;
 import java.sql.SQLException;
 import java.util.List;
 import org.junit.Test;
 
 public class AccountTradeDAOTest
 {
   AccountTradeDAO dao = new AccountTradeDAO();
 
   @Test
   public void testGetList() throws SQLException
   {
     List list = this.dao.getList("1306251459490000000000711", 0, "", 0, 20, "20130401000000", "20130701000000","beikecai");
     System.out.println(list.size());
   }
 
   @Test
   public void testGetCount() throws SQLException
   {
     System.out.println(this.dao.getCount("", 28830, "7001", "20130401000000", "20130601000000","duomai"));
   }
 
   @Test
   public void testGetInComeSum() throws SQLException
   {
     System.out.println(this.dao.getInComeSum("", 28830, "", "20130523000000", "20130523235959","duomai"));
   }
 
   @Test
   public void testGetPayOutSum() throws SQLException
   {
     System.out.println(this.dao.getPayOutSum("", 28830, "7001", "20130401000000", "20130601000000","duomai"));
   }
 }
