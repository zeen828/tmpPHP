 package com.jingCaiBack.dao;
 
 import java.io.PrintStream;
 import java.sql.SQLException;
 import java.util.List;
 import org.junit.Test;
 
 public class UserRateDAOTest
 {
   UserRateDAO dao = new UserRateDAO();
 
   @Test
   public void testGetUserRateList() throws SQLException
   {
     List list = this.dao.getUserRateList(28830, 0, 0);
     System.out.println(list.size());
   }
 
   @Test
   public void testGetByTypeList() throws SQLException
   {
     List list = this.dao.getByTypeList(0);
     System.out.println(list.size());
   }
 }

