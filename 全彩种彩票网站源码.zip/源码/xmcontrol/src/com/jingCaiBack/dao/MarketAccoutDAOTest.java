 package com.jingCaiBack.dao;
 
 import com.jingCaiBack.model.MarketAccount;
 import com.jingCaiBack.util.Contants;
 import java.io.PrintStream;
 import java.sql.SQLException;
 import java.text.DecimalFormat;
 import org.junit.Test;
 
 public class MarketAccoutDAOTest
 {
   MarketAccountDAO dao = new MarketAccountDAO();
   AccountTradeDAO accountTradeDAO = new AccountTradeDAO();
 
   @Test
   public void testGetById() throws SQLException
   {
     System.out.println(this.dao.getById(1015));
   }
 
   @Test
   public void testGetByCreateTime() throws SQLException
   {
     System.out.println(this.dao.getByCreateTime(20131107L));
   }
 
   @Test
   public void testUpdate() throws SQLException
   {
     String createTime = "20131105";
     String startTime = createTime + "070000";
     String endTime = "20131106065959";
     double totalInCome = this.accountTradeDAO.getInComeSum("", 0, "", startTime, endTime,"");
     double totalPayOut = this.accountTradeDAO.getPayOutSum("", 0, "", startTime, endTime,"");
     double award = this.accountTradeDAO.getInComeSum("", 0, "1006", startTime, endTime,"");
     double bankCharge = this.accountTradeDAO.getInComeSum("", 0, "1013", startTime, endTime,"");
     double handCharge = this.accountTradeDAO.getInComeSum("", 0, "1004", startTime, endTime,"");
     double betRebate = this.accountTradeDAO.getInComeSum("", 0, "7001", startTime, endTime,"");
     double onLineRebate = this.accountTradeDAO.getInComeSum("", 0, "7002", startTime, endTime,"");
     double carry = this.accountTradeDAO.getPayOutSum("", 0, "1002", startTime, endTime,"");
     double schemeRebate = this.accountTradeDAO.getInComeSum("", 0, "6002", startTime, endTime,"");
     double activity = this.accountTradeDAO.getInComeSum("", 0, "1012", startTime, endTime,"");
     double bet = Double.parseDouble(Contants.DF.format(totalPayOut - totalInCome + award + bankCharge + handCharge + betRebate + onLineRebate - carry + schemeRebate + activity));
     MarketAccount market = this.dao.getByCreateTime(Long.parseLong(createTime));
     market.setCreateTime(Long.parseLong(createTime));
     market.setBet(bet);
     market.setAward(award);
     market.setBankCharge(bankCharge);
     market.setHandCharge(handCharge);
     market.setBetRebate(betRebate);
     market.setOnLineRebate(onLineRebate);
     market.setCarry(carry);
     market.setSchemeRebate(schemeRebate);
     market.setActivity(activity);
 
     this.dao.update(market);
   }
 }
