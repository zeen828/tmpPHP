 package com.jingCaiBack.dao;
 
 import com.ibatis.sqlmap.client.SqlMapClient;
 import com.jingCaiBack.model.UserRelation;
 import java.sql.SQLException;
 
 public class UserRelationDAO extends BaseDAO
 {
   public UserRelation getByNextLineId(int nextLineId)
     throws SQLException
   {
     return ((UserRelation)this.sqlMap.queryForObject("UserRelationDAO.getByNextLineId", Integer.valueOf(nextLineId)));
   }
 }
