 package com.jingCaiBack.dao;
 
 import com.jingCaiBack.model.ChipinTemp;
 import java.io.PrintStream;
 import java.sql.SQLException;
 import java.util.List;
 import org.junit.Test;
 
 public class ChipinTempDAOTest
 {
   ChipinTempDAO dao = new ChipinTempDAO();
 
   @Test
   public void testGetById() throws SQLException
   {
     System.out.println(this.dao.getById(115355));
   }
 
   @Test
   public void testGetBySerialNoList() throws SQLException
   {
     List list = this.dao.getBySerialNoList("1311242357530000000000184");
     System.out.println(list.size());
     System.out.println(((ChipinTemp)list.get(0)).getBets());
   }
 
   @Test
   public void testGetByHmfaSerialNoBets() throws SQLException
   {
     String startTime = "20131120000000";
     String endTime = "20131127235959";
     int bets = this.dao.getByHmfaSerialNoBets(0, startTime, endTime);
     System.out.println(bets);
   }
 }
