 package com.jingCaiBack.dao;
 
 import java.io.PrintStream;
 import java.sql.SQLException;
 import org.junit.Test;
 
 public class UserAccoutDAOTest
 {
   UserAccountDAO dao = new UserAccountDAO();
 
   @Test
   public void testGetById() throws SQLException
   {
     System.out.println(this.dao.getById(28830));
   }
 
   @Test
   public void testGetTotalMoney() throws SQLException
   {
     System.out.println(this.dao.getTotalMoney());
   }
 }

