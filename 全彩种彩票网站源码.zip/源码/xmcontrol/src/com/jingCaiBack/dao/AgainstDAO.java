 package com.jingCaiBack.dao;
 
 import com.ibatis.sqlmap.client.SqlMapClient;
 import com.jingCaiBack.model.Against;
 import java.sql.SQLException;
 
 public class AgainstDAO extends BaseDAO
 {
   public Against getById(long againstId)
     throws SQLException
   {
     return ((Against)this.sqlMap.queryForObject("AgainstDAO.getById", Long.valueOf(againstId)));
   }
 }

