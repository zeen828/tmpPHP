 package com.jingCaiBack.dao;
 
 import com.ibatis.sqlmap.client.SqlMapClient;
 import com.jingCaiBack.model.UserRate;
 import java.sql.SQLException;
 import java.util.HashMap;
 import java.util.List;
 import java.util.Map;
 
 public class UserRateDAO extends BaseDAO
 {
   public void insert(UserRate userRate)
     throws SQLException
   {
     this.sqlMap.insert("UserRateDAO.insert", userRate);
   }
 
   public UserRate getUserRate(int userId, int gameCode, int manner, int type)
     throws SQLException
   {
     Map params = new HashMap();
     params.put("userId", Integer.valueOf(userId));
     params.put("gameCode", Integer.valueOf(gameCode));
     params.put("manner", Integer.valueOf(manner));
     params.put("type", Integer.valueOf(type));
     return ((UserRate)this.sqlMap.queryForObject("UserRateDAO.getUserRate", params));
   }
 
   public List<UserRate> getUserRateList(int userId, int manner, int type)
     throws SQLException
   {
     Map params = new HashMap();
     params.put("userId", Integer.valueOf(userId));
     params.put("manner", Integer.valueOf(manner));
     params.put("type", Integer.valueOf(type));
     return this.sqlMap.queryForList("UserRateDAO.getUserRateList", params);
   }
 
   public List<UserRate> getByTypeList(int type)
     throws SQLException
   {
     return this.sqlMap.queryForList("UserRateDAO.getByTypeList", Integer.valueOf(type));
   }
 
   public int updateRate(UserRate userRate)
     throws SQLException
   {
     return Integer.valueOf(this.sqlMap.update("UserRateDAO.updateRate", userRate)).intValue();
   }
 }

