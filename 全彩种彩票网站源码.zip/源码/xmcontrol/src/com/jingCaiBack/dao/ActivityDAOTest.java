 package com.jingCaiBack.dao;
 
 import com.jingCaiBack.model.Activity;
 import java.io.PrintStream;
 import java.sql.SQLException;
 import java.util.List;
 import org.junit.Test;
 
 public class ActivityDAOTest
 {
   ActivityDAO dao = new ActivityDAO();
 
   @Test
   public void testGetById() throws SQLException
   {
     System.out.println(this.dao.getById(101));
   }
 
   @Test
   public void testInsert() throws SQLException
   {
     Activity activity = new Activity();
     activity.setActivityId(102);
     activity.setName("加奖");
     activity.setBeginTime("20121001000000");
     activity.setEndTime("20141230000000");
     this.dao.insert(activity);
   }
 
   @Test
   public void testUpdate() throws SQLException
   {
     Activity activity = this.dao.getById(103);
     if (activity == null)
       return;
     activity.setName("返点");
     System.out.println(this.dao.update(activity));
   }
 
   @Test
   public void testDelete()
     throws SQLException
   {
     Activity activity = this.dao.getById(103);
     if (activity == null)
       return;
     System.out.println(this.dao.delete(activity));
   }
 
   @Test
   public void testGetList()
     throws SQLException
   {
     List list = this.dao.getList(-1, 1);
     System.out.println(list.size());
   }
 
   @Test
   public void testGetCount() throws SQLException
   {
     System.out.println(this.dao.getCount());
   }
 }
