package com.jingCaiBack.dao;
 
import com.jingCaiBack.model.UserInfo;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

 public class UserInfoDAO extends BaseDAO
 { 
  public UserInfo getUserInfo(String userId) throws SQLException
   {
     return ((UserInfo)this.sqlMap.queryForObject("UserInfoDAO.getUserInfo", userId));
   }
  public List<UserInfo> getList(Map map) throws SQLException
  {
	  if (map == null){
		  return null;
	  }
	  return this.sqlMap.queryForList("UserInfoDAO.getList", map);
  }
  public Long getCount(Map map) throws SQLException
  {
	  if (map == null){
		  return 0L;
	  }
	  return (Long) this.sqlMap.queryForObject("UserInfoDAO.getCount", map);
  }
  public List<UserInfo> getAllList(Map map) throws SQLException{
	  if (map == null){
		  return null;
	  }
	  return this.sqlMap.queryForList("UserInfoDAO.getAllList", map);
  }
  
  public static void main(String[] args) throws Exception {
	  UserInfoDAO userInfoDao=new UserInfoDAO();
	  //UserInfo userInfo=userInfoDao.getUserInfo("39386");
	  //System.out.println("身份证--"+userInfo.getIdCardNumber());
	  //System.out.println("银行--"+userInfo.getCardAccount());
	  //System.out.println("银行卡号--"+userInfo.getBank());
	  //System.out.println("手机号--"+userInfo.getUserTel());
	  Map map =new HashMap();
	  //map.put("userNickName", "c");
	  // map.put("idCardNumber", "i");
	  //map.put("userTel", "ut");
	  map.put("loginTimes", "2");
	  map.put("endRecNo", 10000);
	  map.put("beginRecNo", 1);
	  List<UserInfo> list=userInfoDao.getList(map);
	  Long l=userInfoDao.getCount(map);
	  for (int i = 0; i < list.size(); i++) {
		System.out.println("登陆次数超过2的   "+list.get(i).getUserNickName()+"  登陆了  "+l
				+" 一共有 "+list.size()+"人");
	  }
 }

 }

