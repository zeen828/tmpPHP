package com.jingCaiBack.action;

import com.jingCaiBack.dao.ActivityDAO;
import com.jingCaiBack.model.Activity;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ActivityAction extends AbstractAction
{
  private ActivityDAO activitydao = new ActivityDAO();

  public ActionForward activityList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {
   int page = getIntParameter(request, "page");
   if (page < 0) page = 1;
    int start = (page - 1) * 10;
   int end = page * 10;
   List activityList = this.activitydao.getList(start, end);
    int count = this.activitydao.getCount();
    int pageCount = (count % 10 == 0) ? count / 10 : count / 10 + 1;
    StringBuilder sb = new StringBuilder();
    sb.append("{");
     sb.append("items:[");
    if ((activityList != null) && (activityList.size() > 0))
    {
       for (int i = 0; i < activityList.size(); ++i)
      {
         Activity activity = (Activity)activityList.get(i);
        String beginTime = activity.getBeginTime();
         String endTime = activity.getEndTime();
        beginTime = sdf2.format(sdf.parse(beginTime));
        endTime = sdf2.format(sdf.parse(endTime));
        sb.append("{");
        sb.append("activityId:'" + activity.getActivityId() + "'");
        sb.append(",");
        sb.append("activityName:'" + activity.getName() + "'");
        sb.append(",");
        sb.append("beginTime:'" + beginTime + "'");
       sb.append(",");
         sb.append("endTime:'" + endTime + "'");
        sb.append("}");
   if (i == activityList.size() - 1)
          continue;
       sb.append(",");
      }
    }

   sb.append("]");
  sb.append(",count:'" + count + "'");
 sb.append(",pageCount:'" + pageCount + "'");
sb.append("}");

 nocache(response);

response.setContentType("text/html;charset=UTF-8");
 PrintWriter out = response.getWriter();
 out.print(sb.toString());
return null;
  }
}
