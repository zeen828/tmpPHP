 package com.jingCaiBack.action;
 
 import com.jingCaiBack.util.MessageAuxiliary;
 import com.letousky.connector.Message;
 import com.letousky.connector.MessageTool;
 import com.letousky.exception.LotteryException;
 import java.io.IOException;
 import java.io.PrintStream;
 import java.io.PrintWriter;
 import java.net.URLDecoder;
 import java.util.ArrayList;
 import java.util.List;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;
 import org.apache.struts.actions.DispatchAction;
 
 public class kjManageAction extends DispatchAction
 {
   public ActionForward getVsDataToTime(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0238");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("startTime")).append("%23;");
     strBuffer.append(request.getParameter("endTime")).append("%23;");
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageCount")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       out.print("{gameId:'" + str[0] + "',gameName:'" + str[1] + 
         "',gameNum:'" + str[2] + "'," + "hostTeam:'" + str[3] + 
         "',visitingTeam:'" + str[4] + "',concedeNum:'" + str[5] + 
         "'," + "gameType:'" + str[6] + "',stopSellDate:'" + 
         str[7] + "',dsstopTime:'" + str[8] + "'," + 
         "fsstopTime:'" + str[9] + "',status:'" + str[10] + "'}" + 
         bsf);
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getVsCountToTime(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0239");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("startTime")).append("%23;");
     strBuffer.append(request.getParameter("endTime")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       out.print("{pageNum:'" + str[0] + "'}");
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getkjDetail(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     Message message = new Message();
     message.setOperaterCode("M0240");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("againstId")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     String[] result;
     try
     {
       result = new MessageTool().split(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     out.print("{items:[");
     out.print("{againstId:'" + result[0] + "',hostBanChangBiFen:'" + 
       result[10] + "',guestBanChangBiFen:'" + result[11] + "'," + 
       "hostQuanChangBiFen:'" + result[12] + 
       "',guestQuanChangBiFen:'" + result[13] + "',rangQiuResults:'" + 
       result[14] + "'," + "biFenResults:'" + result[15] + 
       "',zongJingQiuResults:'" + result[16] + "',banQuanResults:'" + 
       result[17] + "'," + "rangQiuAward:'" + result[18] + 
       "',biFenAward:'" + result[19] + "',zongJingQiuAward:'" + 
       result[20] + "'," + "banQuanAward:'" + result[21] + 
       "',rangQiuguoGuanResult:'" + result[22] + 
       "',biFenGuanResult:'" + result[23] + "'," + 
       "zongJingQiuGuanResult:'" + result[24] + 
       "',banQuanGuanResult:'" + result[25] + "'}");
     out.print("]}");
     return null;
   }
 
   public ActionForward setJdStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0237");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String str = URLDecoder.decode(request.getParameter("str"));
     String[] strs = str.split(",");
     String againstId = strs[0];
     String hostBanChangBiFen = strs[1];
     String guestBanChangBiFen = strs[2];
     String hostQuanChangBiFen = strs[3];
     String guestQuanChangBiFen = strs[4];
     String rangQiuResults = strs[5];
     String biFenResults = strs[6];
     String zongJingQiuResults = strs[7];
     String banQuanResults = strs[8];
     String rangQiuAward = strs[9];
     String biFenAward = strs[10];
     String zongJingQiuAward = strs[11];
     String banQuanAward = strs[12];
     String rangQiuguoGuanResult = strs[13];
     String biFenGuanResult = strs[14];
     String zongJingQiuGuanResult = strs[15];
     String banQuanGuanResult = strs[16];
     System.out.println(str);
     strBuffer.append(againstId).append("%23;");
     strBuffer.append(hostBanChangBiFen).append("%23;");
     strBuffer.append(guestBanChangBiFen).append("%23;");
     strBuffer.append(hostQuanChangBiFen).append("%23;");
     strBuffer.append(guestQuanChangBiFen).append("%23;");
     strBuffer.append(rangQiuResults).append("%23;");
     strBuffer.append(biFenResults).append("%23;");
     strBuffer.append(zongJingQiuResults).append("%23;");
     strBuffer.append(banQuanResults).append("%23;");
     strBuffer.append(rangQiuAward).append("%23;");
     strBuffer.append(biFenAward).append("%23;");
     strBuffer.append(zongJingQiuAward).append("%23;");
     strBuffer.append(banQuanAward).append("%23;");
     strBuffer.append(rangQiuguoGuanResult).append("%23;");
     strBuffer.append(biFenGuanResult).append("%23;");
     strBuffer.append(zongJingQiuGuanResult).append("%23;");
     strBuffer.append(banQuanGuanResult).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     return null;
   }
 
   public ActionForward getlcDataToTime(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0256");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("startTime")).append("%23;");
     strBuffer.append(request.getParameter("endTime")).append("%23;");
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageCount")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       out.print("{gameId:'" + str[0] + "',gameName:'" + str[1] + 
         "',gameNum:'" + str[2] + "'," + "hostTeam:'" + str[3] + 
         "',visitingTeam:'" + str[4] + "',concedeNum:'" + str[5] + 
         "'," + "gameType:'" + str[6] + "',stopSellDate:'" + 
         str[7] + "',dsstopTime:'" + str[8] + "'," + 
         "fsstopTime:'" + str[9] + "',status:'" + str[10] + "'}" + 
         bsf);
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getlcCountToTime(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0257");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("startTime")).append("%23;");
     strBuffer.append(request.getParameter("endTime")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       out.print("{pageNum:'" + str[0] + "'}");
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getlckjDetail(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     Message message = new Message();
     message.setOperaterCode("M0240");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("againstId")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     String[] result;
     try
     {
       result = new MessageTool().split(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     out.print("{items:[");
     out.print("{againstId:'" + result[0] + "',hostBanChangBiFen:'" + 
       result[10] + "',guestBanChangBiFen:'" + result[11] + "'," + 
       "hostQuanChangBiFen:'" + result[12] + 
       "',guestQuanChangBiFen:'" + result[13] + "',rangQiuResults:'" + 
       result[14] + "'," + "biFenResults:'" + result[15] + 
       "',zongJingQiuResults:'" + result[16] + "',banQuanResults:'" + 
       result[17] + "'," + "rangQiuAward:'" + result[18] + 
       "',biFenAward:'" + result[19] + "',zongJingQiuAward:'" + 
       result[20] + "'," + "banQuanAward:'" + result[21] + 
       "',rangQiuguoGuanResult:'" + result[22] + 
       "',biFenGuanResult:'" + result[23] + "'," + 
       "zongJingQiuGuanResult:'" + result[24] + 
       "',banQuanGuanResult:'" + result[25] + "'}");
     out.print("]}");
     return null;
   }
 
   public ActionForward setlcStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0253");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String str = URLDecoder.decode(request.getParameter("str"));
     String[] strs = str.split(",");
     System.out.println(strs.length + "======================");
     String againstId = strs[0];
     String sf = strs[1];
     String rf_sf = strs[2];
     String sfc = strs[3];
     String dsf = strs[4];
     String sf_award = strs[5];
     String rfsf_award = strs[6];
     String sfc_award = strs[7];
     String dsf_award = strs[8];
     String sf_gg = strs[9];
     String rfsf_gg = strs[10];
     String sfc_gg = strs[11];
     String dxf_gg = strs[12];
     String osfdcosore = "1";
     String dxfdctotalscore = "1";
     strBuffer.append(againstId).append("%23;");
     strBuffer.append(sf).append("%23;");
     strBuffer.append(rf_sf).append("%23;");
     strBuffer.append(sfc).append("%23;");
     strBuffer.append(dsf).append("%23;");
     strBuffer.append(sf_award).append("%23;");
     strBuffer.append(rfsf_award).append("%23;");
     strBuffer.append(sfc_award).append("%23;");
     strBuffer.append(dsf_award).append("%23;");
     strBuffer.append(sf_gg).append("%23;");
     strBuffer.append(rfsf_gg).append("%23;");
     strBuffer.append(sfc_gg).append("%23;");
     strBuffer.append(dxf_gg).append("%23;");
     strBuffer.append(osfdcosore).append("%23;");
     strBuffer.append(dxfdctotalscore).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     return null;
   }
 
   public static void main(String[] sfd) {
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0238");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append("20120501120000").append("%23;");
     strBuffer.append("20120525120000").append("%23;");
     strBuffer.append(1).append("%23;");
     strBuffer.append(10).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       for (int s = 0; s < str.length; ++s) {
         System.out.print(str[s] + "--");
       }
       System.out.println();
     }
   }
 }

