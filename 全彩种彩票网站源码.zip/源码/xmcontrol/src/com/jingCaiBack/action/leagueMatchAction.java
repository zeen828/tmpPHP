 package com.jingCaiBack.action;
 
 import com.jingCaiBack.util.MessageAuxiliary;
 import com.letousky.connector.Message;
 import com.letousky.connector.MessageTool;
 import com.letousky.exception.LotteryException;
 import java.io.IOException;
 import java.io.PrintStream;
 import java.io.PrintWriter;
 import java.io.UnsupportedEncodingException;
 import java.net.URLDecoder;
 import java.util.ArrayList;
 import java.util.List;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;
 import org.apache.struts.actions.DispatchAction;
 
 public class leagueMatchAction extends DispatchAction
 {
   public ActionForward getMatchDate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
 
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0219");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageNum")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try
     {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
 
     String bsf = ",";
     out.println("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       out.print("{matchId:'" + str[0] + "',matchName:'" + str[1] + 
         "',matchQc:'" + str[2] + "',matchColor:'" + str[3] + "'}" + 
         bsf);
     }
     out.println("]}");
     return null;
   }
 
   public ActionForward getPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
 
     Message message = new Message();
     message.setOperaterCode("M0220");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     String[] str;
     try
     {
       str = new MessageTool().split(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = str;
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String strs = (String)obj[i];
       out.print("{page:'" + strs + "'}");
     }
     out.println("]}");
     return null;
   }
 
   public ActionForward insertMatchData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws UnsupportedEncodingException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     Message message = new Message();
     message.setOperaterCode("M0217");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String matchName = URLDecoder.decode(request.getParameter("matchName"));
     String matchQc = URLDecoder.decode(request.getParameter("matchQc"));
     String matchColor = "#" + request.getParameter("matchColor");
     strBuffer.append(matchName).append("%23;");
     strBuffer.append(matchQc).append("%23;");
     strBuffer.append(matchColor).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     return null;
   }
 
   public ActionForward updateMatchData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws UnsupportedEncodingException
   {
     Message message = new Message();
     message.setOperaterCode("M0218");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String matchId = request.getParameter("matchId");
     String matchName = URLDecoder.decode(request.getParameter("matchName"));
     String matchQc = URLDecoder.decode(request.getParameter("matchQc"));
     String matchColor = "#" + request.getParameter("matchColor");
     strBuffer.append(matchId).append("%23;");
     strBuffer.append(matchName).append("%23;");
     strBuffer.append(matchQc).append("%23;");
     strBuffer.append(matchColor).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     return null;
   }
 
   public ActionForward getLCMatchDate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
 
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0259");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageNum")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
 
     String bsf = ",";
     out.println("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       out.print("{matchId:'" + str[0] + "',matchName:'" + str[1] + 
         "',matchQc:'" + str[2] + "',matchColor:'" + str[3] + "'}" + 
         bsf);
     }
     out.println("]}");
     return null;
   }
 
   public ActionForward getLCPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
 
     Message message = new Message();
     message.setOperaterCode("M0260");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     String[] str;
     try
     {
       str = new MessageTool().split(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = str;
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String strs = (String)obj[i];
       out.print("{page:'" + strs + "'}");
     }
     out.println("]}");
     return null;
   }
 
   public ActionForward insertLCMatchData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws UnsupportedEncodingException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     Message message = new Message();
     message.setOperaterCode("M0261");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String matchName = URLDecoder.decode(request.getParameter("matchName"));
     String matchQc = URLDecoder.decode(request.getParameter("matchQc"));
     String matchColor = "#" + request.getParameter("matchColor");
     strBuffer.append(matchName).append("%23;");
     strBuffer.append(matchQc).append("%23;");
     strBuffer.append(matchColor).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     return null;
   }
 
   public ActionForward updateLCMatchData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws UnsupportedEncodingException
   {
     Message message = new Message();
     message.setOperaterCode("M0262");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String matchId = request.getParameter("matchId");
     String matchName = URLDecoder.decode(request.getParameter("matchName"));
     String matchQc = URLDecoder.decode(request.getParameter("matchQc"));
     String matchColor = "#" + request.getParameter("matchColor");
     strBuffer.append(matchId).append("%23;");
     strBuffer.append(matchName).append("%23;");
     strBuffer.append(matchQc).append("%23;");
     strBuffer.append(matchColor).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     return null;
   }
 
   public ActionForward dsf(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
     return null;
   }
 
   public static void main(String[] arg) {
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0259");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append("0").append("%23;");
     strBuffer.append("0").append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     System.out.println(obj.length);
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       System.out.println(str[0]);
       System.out.println(str[1]);
       System.out.println(str[2]);
       System.out.println(str[3]);
     }
   }
 }

