 package com.jingCaiBack.action;
 
 import com.jingCaiBack.util.MessageAuxiliary;
 import com.letousky.connector.Message;
 import com.letousky.connector.MessageTool;
 import com.letousky.exception.LotteryException;
 import java.io.IOException;
 import java.io.PrintStream;
 import java.io.PrintWriter;
 import java.util.ArrayList;
 import java.util.List;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;
 import org.apache.struts.actions.DispatchAction;
 
 public class vsManageAction extends DispatchAction
 {
   public ActionForward getVsData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0221");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append("501").append("%23;");
     strBuffer.append("1").append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       out.print("{gameId:'" + str[0] + "',gameNum:'" + str[1] + 
         "',gameName:'" + str[2] + "'," + "hostTeam:'" + str[3] + 
         "',visitingTeam:'" + str[4] + "',concedeNum:'" + str[5] + 
         "'," + "stopSellDate:'" + str[6] + "',isJd:'" + str[7] + 
         "',dsstopTime:'" + str[8] + "'," + "fsstopTime:'" + 
         str[9] + "'}" + bsf);
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward setJdStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     Message message = new Message();
     message.setOperaterCode("M0222");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String gameId = new String(request.getParameter("gameId").getBytes(
       "ISO-8859-1"), "GBK");
     String fsstopTime = new String(request.getParameter("fsstopTime")
       .getBytes("ISO-8859-1"), "GBK");
     String isJd = new String(request.getParameter("isJd").getBytes(
       "ISO-8859-1"), "GBK");
     System.out.println(gameId);
     System.out.println(fsstopTime);
     System.out.println(isJd);
     strBuffer.append(gameId).append("%23;");
     strBuffer.append(fsstopTime).append("%23;");
     strBuffer.append(isJd).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     return null;
   }
 
   public ActionForward allTime(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     Message message = new Message();
     message.setOperaterCode("M0225");
     message.setOperaterNo("1111111");
     StringBuffer strBuffer = new StringBuffer();
     String gameId = new String(request.getParameter("gameId").getBytes(
       "ISO-8859-1"), "GBK");
     String time = new String(request.getParameter("time").getBytes(
       "ISO-8859-1"), "GBK");
     System.out.println(gameId);
     System.out.println(time);
     strBuffer.append(gameId).append("%23;");
     strBuffer.append(time).append("%23;");
     message.setBody(strBuffer.toString());
     MessageAuxiliary.messageToMessage(message);
     return null;
   }
 
   public static void main(String[] arg) {
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0221");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append("501").append("%23;");
     strBuffer.append("1").append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       for (int s = 0; s < str.length; ++s) {
         System.out.print(str[s] + "--");
       }
       System.out.println();
     }
   }
 }
