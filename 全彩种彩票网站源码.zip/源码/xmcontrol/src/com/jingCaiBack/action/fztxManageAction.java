package com.jingCaiBack.action;

import com.jingCaiBack.util.MessageAuxiliary;
import com.letousky.connector.Message;
import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import com.letousky.util.TimeUtil;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class fztxManageAction extends DispatchAction
{
  public ActionForward getSource(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws IOException
  {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0092");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     String Uname = new String(request.getParameter("uName").getBytes(
       "ISO-8859-1"), "GBK");
     String pwd = new String(request.getParameter("pwd").getBytes(
       "ISO-8859-1"), "GBK");
     strBuffer.append(Uname).append("%23;");
     strBuffer.append(pwd).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
    try {
       matchList = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
       throw lotteryException;
    }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {//下标取四合网站
       String[] str = (String[])obj[i];
       if (i == obj.length - 1) {
         bsf = "";
      }
       out.print("{source:'" + str[0] + "',sourceId:'" + str[1] + "'}" + 
         bsf);
    }
     out.print("]}");
     return null;
  }

  public ActionForward getUserInfo(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException
  {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     Message message = new Message();
     message.setOperaterCode("M0091");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     String Uname = new String(request.getParameter("uName").getBytes(
       "ISO-8859-1"), "utf-8");
     String pwd = new String(request.getParameter("pwd").getBytes(
       "ISO-8859-1"), "utf-8");
     String nickName = URLDecoder.decode(request.getParameter("nickName"),"utf-8");
   /*  nickName=new String(nickName.getBytes(
     "ISO-8859-1"), "utf-8");*/
     strBuffer.append(Uname).append("%23;");
     strBuffer.append(pwd).append("%23;");
     strBuffer.append(request.getParameter("sourceid")).append("%23;");
     strBuffer.append(nickName).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
    String[] result;
    try
    {
       result = new MessageTool().split(results);
    } catch (LotteryException lotteryException) {
       throw lotteryException;
    }
     out.print("{items:[");
     out.print("{userNickName:'" + result[0] + "',clientid:'" + result[3] + 
       "',sourceid:'" + result[4] + "'," + "awardMeony:'" + 
       result[5] + "',dongMeony:'" + result[6] + "',meony:'" + 
       result[7] + "'}");
     out.print("]}");
     return null;
  }

  public ActionForward chongzhi(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException
  {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     Message message = new Message();
     message.setOperaterCode("M0093");
     message.setOperaterNo(doSerialNo());
     StringBuffer strBuffer = new StringBuffer();
     String uName = new String(request.getParameter("uName").getBytes(
       "ISO-8859-1"), "GBK");
     String pwd = new String(request.getParameter("pwd").getBytes(
       "ISO-8859-1"), "GBK");
     strBuffer.append(uName).append("%23;");
     strBuffer.append(pwd).append("%23;");
     strBuffer.append(request.getParameter("clientid")).append("%23;");
     strBuffer.append(request.getParameter("bets")).append("%23;");
     strBuffer.append(126).append("%23;");
     strBuffer.append(request.getParameter("sourceid")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
    String[] result;
    try
    {
     result = new MessageTool().split(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
    return null;
  }

  private String doSerialNo() throws LotteryException {
    String values = "yyMMddHHmmssSSSSSSSSSSSSS";
    return TimeUtil.getDate(values);
  }

  public ActionForward getTxInfo(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws IOException
  {
    response.setContentType("text/html;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
    Message message = new Message();
    message.setOperaterCode("M0099");
    message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     String uName = request.getParameter("uName");
    String pwd = request.getParameter("pwd");
    String type = request.getParameter("type");
    String pageNum = request.getParameter("pageNum");
     String pageCount = request.getParameter("pageCount");
   System.out.println(uName + "," + pwd + "," + type + "," + pageNum + "," + 
     pageCount + "-----");
    strBuffer.append(uName).append("%23;");
    strBuffer.append(pwd).append("%23;");
  strBuffer.append(type).append("%23;");
    strBuffer.append(pageNum).append("%23;");
    strBuffer.append(pageCount).append("%23;");
    message.setBody(strBuffer.toString());
    String results = MessageAuxiliary.messageToMessage(message);
    List result = new ArrayList();
    try {
    result = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
    Object[] obj = result.toArray();
    String bsf = ",";
     out.print("{items:[");
    for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
        bsf = "";
      }
      String[] str = (String[])obj[i];
      out.print("{applyId:'" + str[0] + "',serialNo:'" + str[1] + 
        "',bets:'" + str[2] + "'," + "status:'" + str[3] + 
        "',applyTime:'" + str[4] + "',userId:'" + str[5] + 
        "',userNickName:'" + str[7] + "'," + "accountName:'" + 
       str[8] + "',bank:'" + str[9] + "',cardAccount:'" + 
        str[10] + "'," + "userTel:'" + str[11] + "',userMob:'" + 
         str[12] + "',balance:'" + str[13] + "'}" + bsf);
    }
   out.print("]}");
    return null;
  }

  public ActionForward getTxSum(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws IOException
  {
    response.setContentType("text/html;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();
   Message message = new Message();
     message.setOperaterCode("M0124");
     message.setOperaterNo("11111111");
    StringBuffer strBuffer = new StringBuffer();
   String uName = request.getParameter("uName");
     String pwd = request.getParameter("pwd");
    String type = request.getParameter("type");
    strBuffer.append(uName).append("%23;");
    strBuffer.append(pwd).append("%23;");
    strBuffer.append(type).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
    List result = new ArrayList();
    try {
     result = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
   Object[] obj = result.toArray();
   out.print("{items:[");
    for (int i = 0; i < obj.length; ++i) {
     String[] str = (String[])obj[i];
     out.print("{pageSum:'" + str[0] + "'}");
    }
   out.print("]}");
    return null;
  }

  public ActionForward txCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws IOException
  {
   response.setContentType("text/html;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();
    Message message = new Message();
    message.setOperaterCode("M0113");
    message.setOperaterNo("11111111");
    StringBuffer strBuffer = new StringBuffer();
     String uName = request.getParameter("uName");
     String pwd = request.getParameter("pwd");
    String userId = request.getParameter("userId");
     String bets = request.getParameter("bets");
    String serialNo = request.getParameter("serialNo");
    String applyId = request.getParameter("applyId");
    String status = request.getParameter("status");
    System.out.println(uName + "," + pwd + "," + userId + "," + bets + 
      "-----");
   strBuffer.append(uName).append("%23;");
     strBuffer.append(pwd).append("%23;");
     strBuffer.append(userId).append("%23;");
    strBuffer.append(bets).append("%23;");

    strBuffer.append(serialNo).append("%23;");
   strBuffer.append(applyId).append("%23;");
  strBuffer.append(status).append("%23;");
    message.setBody(strBuffer.toString());
    String results = MessageAuxiliary.messageToMessage(message);
    List result = new ArrayList();
    try {
     result = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }

     return null;
  }

  public ActionForward returnPoint(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws IOException
  {
   response.setContentType("text/html;charset=UTF-8");
   request.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();
   Message message = new Message();
   message.setOperaterCode("M0258");
    message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     String beginTime = request.getParameter("beginTime");
     String endTime = request.getParameter("endTime");
     String fandianshu = request.getParameter("fandianshu");
    strBuffer.append(beginTime).append("%23;");
     strBuffer.append(endTime).append("%23;");
    strBuffer.append(fandianshu).append("%23;");
    message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
    List result = new ArrayList();
    try {
      result = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
    Object[] obj = result.toArray();
    String d = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
      if (i == obj.length - 1) {
         d = "";
      }
      String[] str = (String[])obj[i];
      out.print("{uName:'" + str[0] + "',uId:'" + str[1] + "',bets:'" + 
        str[2] + "',fdBets:'" + str[3] + "',fdshu:'" + str[4] + 
        "'}" + d);
    }
   out.print("]}");
   return null;
  }

  public static void main(String[] arg) {
    Message message = new Message();
    message.setOperaterCode("M0258");
   message.setOperaterNo("11111111");
    StringBuffer strBuffer = new StringBuffer();
     String beginTime = "20120601000000";
    String endTime = "20120701000000";
     String fandianshu = "0.03";
   strBuffer.append(beginTime).append("%23;");
    strBuffer.append(endTime).append("%23;");
    strBuffer.append(fandianshu).append("%23;");
    message.setBody(strBuffer.toString());
    String results = MessageAuxiliary.messageToMessage(message);
     List result = new ArrayList();
    try {
      result = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
    Object[] obj = result.toArray();
     for (int i = 0; i < obj.length; ++i) {
      String[] str = (String[])obj[i];
     for (int s = 0; s < str.length; ++s) {
       System.out.print(str[s] + "---");
      }
 System.out.println();
    }
  }
}

