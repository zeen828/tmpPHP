 package com.jingCaiBack.action;
 
 import com.jingCaiBack.dao.CoreDAO;
import com.jingCaiBack.util.MD5;
import com.jingCaiBack.util.MessageAuxiliary;
 import com.letousky.connector.Message;
 import com.letousky.connector.MessageTool;
 import com.letousky.exception.LotteryException;

 import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
 import javax.servlet.http.HttpSession;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
 
 public class loginAction extends DispatchAction
 {
   String sqlStr=null;
   Map sqlMap=new HashMap();
   Map map=null;
   CoreDAO coreDao=new CoreDAO();
   public ActionForward userLogin(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException, SQLException
   {
	   
     HttpSession session = request.getSession();
     String uName = request.getParameter("uName");
     String pwd = request.getParameter("pwd");
     MD5 md5=new MD5();
     String pwd2 = md5.md5GB2312(pwd);
      sqlStr="select t1.num,t2.grade from (select count(1)num from adminuser where nickName='"+uName+"' and passwd ='"+pwd2+"')t1," +
      		"(select * from adminuser where nickName='"+uName+"' and passwd ='"+pwd2+"')t2 " ;
      sqlMap=new HashMap();
      sqlMap.put("sql", sqlStr);
      map=coreDao.getMap("Core.generalSelect", sqlMap);
      int i= Integer.valueOf(map.get("NUM").toString());
      if(i!=1){
    	  throw new LotteryException(); 
      }else{
    	  session.setAttribute("uName", uName);
    	  session.setAttribute("pwd", pwd);
    	  session.setAttribute("grade", map.get("GRADE"));
      }
      
  /*   if ((!("cpzg360".equals(uName))) || (!("xingcai360".equals(pwd))))
     {
       throw new LotteryException();
     }*/
   
     return null;
   }
 
   public static void main(String[] arg) {
   /*  Message message = new Message();
     message.setOperaterCode("M0042");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append("administrator").append("%23;");
     strBuffer.append("ntcrazyqazwsx").append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     String[] result = (String[])null;
     try {
       result = new MessageTool().split(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     for (int i = 0; i < result.length; ++i)
       System.out.println(result[i]);*/
	   MD5 md5=new MD5();
	     String pwd2 = md5.md5GB2312("123456");
	     System.out.println(pwd2);
	     //E10ADC3949BA59ABBE56E057F20F883E
   }
 }
