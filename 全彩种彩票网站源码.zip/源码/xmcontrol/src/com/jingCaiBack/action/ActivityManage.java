package com.jingCaiBack.action;

import com.jingCaiBack.util.MessageAuxiliary;
import com.letousky.connector.Message;
import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class ActivityManage extends DispatchAction
{
  public ActionForward inActivity(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {
    response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
    HttpSession session = request.getSession();
     Message message = new Message();
     message.setOperaterCode("M0120");
    message.setOperaterNo("1111111111");
    String content = URLDecoder.decode(request.getParameter("content"));
    String info = URLDecoder.decode(request.getParameter("info"));
     StringBuffer activiteBuf = new StringBuffer();
     activiteBuf.append(session.getAttribute("uName")).append("%23;");
    activiteBuf.append(session.getAttribute("pwd")).append("%23;");
    activiteBuf.append(request.getParameter("startDate")).append("%23;");
    activiteBuf.append(request.getParameter("endDate")).append("%23;");
    activiteBuf.append(content).append("%23;");
   activiteBuf.append(info).append("%23;");
    activiteBuf.append(request.getParameter("money")).append("%23;");
    message.setBody(activiteBuf.toString());
    String str = "0000";
    String results = MessageAuxiliary.messageToMessage(message);
    try {
     new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      str = lotteryException.getMessage();
    }
    out.print("{items:[{count:'" + str + "'}]}");
    return null;
  }

  public static void main(String[] fsd) {
   List chipinList = new ArrayList();
     Message message = new Message();
    message.setOperaterCode("M0120");
    StringBuffer activiteBuf = new StringBuffer();
    activiteBuf.append("administrator").append("%23;");
    activiteBuf.append("ntcrazyqazwsx").append("%23;");
    activiteBuf.append("20110806").append("%23;");
    activiteBuf.append("20110806").append("%23;");
    activiteBuf.append("ddddddddddd").append("%23;");
    activiteBuf.append("ddddddddddddd").append("%23;");
    activiteBuf.append("4444444444444").append("%23;");
    message.setOperaterNo("1111111111");
    message.setBody(activiteBuf.toString());

    String results = MessageAuxiliary.messageToMessage(message);
    try {
     chipinList = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
   throw lotteryException;
    }
   Object[] obj = chipinList.toArray();
    for (int i = 0; i < obj.length; ++i) {
     String[] str = (String[])obj[i];
     for (int j = 0; j < str.length; ++j)
       System.out.println(str[j] + "----");
    }
  }
}
