 package com.jingCaiBack.action;
 /****
  * 充值申请待办页面的Action
  */

import com.jingCaiBack.model.UserLogin;
import com.jingCaiBack.util.CommonUtil;
import com.jingCaiBack.util.Contants;
import com.jingCaiBack.util.MessageAuxiliary;
import com.jingCaiBack.util.NumberUtil;
import com.jingCaiBack.util.SqlUtil;
import com.letousky.connector.Message;

import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
 
 public class Chongzhi_applyAction extends AbstractAction
 {
  
	 //充值申请
   public ActionForward chongzhi_applyList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws Exception
   {
     request.setCharacterEncoding("UTF-8");
     
     SqlUtil sqlUtil=new SqlUtil();
     List applyList=sqlUtil.getListByCondition("CHONGZHI_APPLY", "APPLY_STATE", "'0','1'","in");//查询申请的或被驳回的申请记录
     
     StringBuilder sb = new StringBuilder();
     sb.append("{");
     sb.append("items:[");
     if ((applyList != null) && (applyList.size() > 0))
     {
    	 java.sql.Timestamp time=null;
       for (int i = 0; i < applyList.size(); ++i)
       {
         Map applyMap = (Map)applyList.get(i);
         if (applyMap.get("APPLY_TIME").getClass().getName().equals("oracle.sql.TIMESTAMP")){
        	 Class clz = applyMap.get("APPLY_TIME").getClass();
        	 Method m = clz.getMethod("timestampValue");
        	 time= (java.sql.Timestamp) m.invoke(applyMap.get("APPLY_TIME"));
        	 System.out.println("time=====" + time);
         }
         sb.append("{");
         sb.append("applyId:'" + applyMap.get("APPLY_ID") + "',");//申请编号
         sb.append("applyPerson:'" + applyMap.get("APPLY_PERSON") + "',");//申请人
         sb.append("applyTime:'" +time + "',");//申请时间
         sb.append("client_userId:'" + applyMap.get("CLIENT_USERID")+ "',");//充值的人的编号
         sb.append("client_userName:'" + applyMap.get("CLIENT_USERNAME")+ "',");//充值的人的姓名
         sb.append("applyBet:'" + applyMap.get("APPLY_BET").toString()+ "',");//充值金额
         sb.append("applyState:'" + applyMap.get("APPLY_STATE")+ "',");//充值状态
         sb.append("applyReason:'" + applyMap.get("APPLY_REASON")+ "'");//说明
         sb.append("}");
         if (i == applyList.size() - 1)
           continue;//如果是最后一个元素,这不要后面的",";
         sb.append(",");
       }
     }
     sb.append("]");
     sb.append("}");
     nocache(response);
     response.setContentType("text/html;charset=UTF-8");
     PrintWriter out = response.getWriter();
     out.print(sb.toString());
     return null;
   }
   //执行同意时的操作
   public ActionForward ApplyAgree(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   throws Exception
   {
	    SqlUtil sqlUtil=new SqlUtil();
	    String success="1111";
	    String applyId=request.getParameter("applyId");
	    Map applyMap=sqlUtil.getMapById("CHONGZHI_APPLY", "APPLY_ID", applyId);
	    HttpSession  session=request.getSession();//得到session
	    String uName=(String) session.getAttribute("uName");//登录人的用户名
	    String pwd=(String) session.getAttribute("pwd");//登录人的密码
	    Object clientid=applyMap.get("CLIENT_USERID");//充值人的用户编号
	    Object bets=applyMap.get("APPLY_BET");
	    Message message = new Message();//实例化message对象
	    message.setOperaterCode("M0093");//存入操作号
		message.setOperaterNo(CommonUtil.DOSERIALNO());//操作序列号
	    StringBuffer strBuffer = new StringBuffer();
	    strBuffer.append(uName).append("%23;");
	 	strBuffer.append(pwd).append("%23;");
	 	strBuffer.append(clientid.toString()).append("%23;");
	 	strBuffer.append(bets.toString()).append("%23;");
	 	strBuffer.append(126).append("%23;");
	 	strBuffer.append(request.getParameter("sourceid")==null?"1001":request.getParameter("sourceid")).append("%23;");
	 	message.setBody(strBuffer.toString());
	 	String results = MessageAuxiliary.messageToMessage(message);
	 	if (results.indexOf("0000")!=-1)
	 	{
	 		success = "0000";
	 	}
        nocache(response);
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        sqlUtil.updateById("CHONGZHI_APPLY", "APPLY_ID", applyId, "APPLY_STATE", "2");//同意充值时改为2,表示充值成功
        out.print(success);
       
        return null;
  }
   //执行不同意时的操作
   public ActionForward ApplyDisAgree(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   throws Exception
    {
	  SqlUtil sqlUtil=new SqlUtil();
	  String success="0000";
	  String applyId=request.getParameter("applyId");
      nocache(response);
      response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
      int i=sqlUtil.updateById("CHONGZHI_APPLY", "APPLY_ID", applyId, "APPLY_STATE", "1");//不同意充值时改为1,表示驳回
      if(i==-1){
	   //0000表示提交成功
      }else{
	   success="1111";//1111表示提交失败
     }
   
   out.print(success);
   return null;
  }
   public ActionForward ApplyCancel(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   throws Exception
    {
	   SqlUtil sqlUtil=new SqlUtil();
		  String success="0000";
		  String applyId=request.getParameter("applyId");
	      nocache(response);
	      response.setContentType("text/html;charset=UTF-8");
	      PrintWriter out = response.getWriter();
	      //int i=sqlUtil.updateById("CHONGZHI_APPLY", "APPLY_ID", applyId, "APPLY_STATE", "3");
	      int i=sqlUtil.deleteById("CHONGZHI_APPLY", "APPLY_ID", applyId);//撤销充值时,直接删除
	      if(i>0){
		   //0000表示提交成功
	      }else{
		   success="1111";//1111表示提交失败
	     }
	   
	   out.print(success);
	   return null;
 }
    
   
 }

