 package com.jingCaiBack.action;
 
 import com.jingCaiBack.util.MessageAuxiliary;
 import com.letousky.connector.Message;
 import com.letousky.connector.MessageTool;
 import com.letousky.exception.LotteryException;
 import java.io.IOException;
 import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
 import javax.servlet.http.HttpSession;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
 
 public class JianKongAction extends DispatchAction
 {
   public ActionForward jianKong(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
	     response.setContentType("text/html;charset=UTF-8");
	     request.setCharacterEncoding("UTF-8");
	     List chipinList = new ArrayList();
	     List listSec=new ArrayList();
	     PrintWriter out = response.getWriter();

	    Message message1= getFormatString("0");
	    String results = MessageAuxiliary.messageToMessage(message1);
	   
	   Message message2=getFormatString("1");
	   String results2= MessageAuxiliary.messageToMessage(message2);
	    try {
	     chipinList = new MessageTool().splits(results);
	     listSec= new MessageTool().splits(results2);
	    } catch (LotteryException lotteryException) {
	      throw lotteryException;
	    }
	    Object[] obj = chipinList.toArray();//监控状态0
	    Object[] obj2=listSec.toArray();
	/*     out.println("{items:[");
	    for (int i = 0; i < obj2.length; ++i) {//监控状态1
	    	if(obj[i]==null){
	    		continue;
	    	}
	     String[] str = (String[])obj[i];
	     out.print("{serialno:'" + str[0] +" tempId:'" + str[1] +
	        "',gameCode:'" + str[2] + "',sctime:'" + str[3] + 
	       "',vptime:'" + str[4] + "', bets:'" + str[5] + "'},");
	    }
	    out.println("]}");*/
	    request.setAttribute("chipinList", obj);
	    request.setAttribute("listSec", obj2);
	    System.out.println("左国斌看异常数据信息--------"+obj2);
	    return mapping.findForward("success");
   }
   
   public ActionForward betCancel(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   throws IOException
   {
	     response.setContentType("text/html;charset=UTF-8");
	     request.setCharacterEncoding("UTF-8");
	     List chipinList = new ArrayList();
	     List listSec=new ArrayList();
	     PrintWriter out = response.getWriter();
	     
	     String bet=request.getParameter("bet");
	     String serno=request.getParameter("serno");

	     Message message = new Message();
	     message.setOperaterCode("M0284");
	     message.setOperaterNo("1111111111");
	     StringBuffer messageBuf = new StringBuffer();
	     messageBuf.append(serno).append("%23;");
		 messageBuf.append(bet).append("%23;");
		 message.setBody(messageBuf.toString());
		 String results = MessageAuxiliary.messageToMessage(message);
	   
		 String[] result;
	    try {
	    	result = new MessageTool().split(results);
	    } catch (LotteryException lotteryException) {
	      throw lotteryException;
	    }
	    return mapping.findForward("success");
 }
   
 
   public static void main(String[] arg) {
     Message message = new Message();
     message.setOperaterCode("M0042");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append("administrator").append("%23;");
     strBuffer.append("ntcrazyqazwsx").append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     String[] result = (String[])null;
     try {
       result = new MessageTool().split(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     for (int i = 0; i < result.length; ++i)
       System.out.println(result[i]);
   }
   
   public Message getFormatString(String status)
   {
	   Message message = new Message();
	     message.setOperaterCode("M0283");
	     message.setOperaterNo("1111111111");
	     StringBuffer messageBuf = new StringBuffer();
		   messageBuf.append(status).append("%23;");
		   message.setBody(messageBuf.toString());
	     return message;

   }
 }
