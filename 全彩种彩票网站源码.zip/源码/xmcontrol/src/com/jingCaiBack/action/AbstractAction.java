package com.jingCaiBack.action;

import java.text.SimpleDateFormat;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.actions.DispatchAction;

public class AbstractAction extends DispatchAction
{
			protected static final int PAGE_SIZE = 10;
  			protected static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			protected static final SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			protected static final SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");

  protected int getIntParameter(HttpServletRequest request, String name)
  {
    try
    {
    		return Integer.parseInt(request.getParameter(name));
    }
    catch (Exception e) {
    }
    		return -1;
  }

  protected float getFloatParameter(HttpServletRequest request, String name)
  {
    try
    {
    	return Float.parseFloat(request.getParameter(name));
    }
    catch (Exception e) {
    }
    	return -1.0F;
  }

  protected void nocache(HttpServletResponse response)
  {
	  response.setHeader("Pragma", "No-cache");
	  response.setHeader("Cache-Control", "no-cache");
	  response.setHeader("Cache-Control", "no-store");
	  response.setDateHeader("Expires", 0L);
  }
}
