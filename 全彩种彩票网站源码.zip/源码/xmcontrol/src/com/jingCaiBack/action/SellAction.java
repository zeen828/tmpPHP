 package com.jingCaiBack.action;
 


 import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.jingCaiBack.util.DateUtil;
import com.jingCaiBack.dao.CoreDAO;
import com.jingCaiBack.util.SqlUtil;

 
 public class SellAction extends DispatchAction
 {
	 
	protected static final int PAGE_SIZE = 10;
	protected static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	protected static final SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	protected static final SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
    SqlUtil sqlUtil=new SqlUtil();
    CoreDAO coreDAO=new CoreDAO();
   public ActionForward sell(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws  Exception
   {
	   
	     response.setContentType("text/html;charset=UTF-8");
	     request.setCharacterEncoding("UTF-8");
	     //添加时间查询
	  	String startDate = request.getParameter("startDate");
	 	String endDate = request.getParameter("endDate");
	 	long startDateL=0L;
	 	long endDateL=0L;
	 	String status=request.getParameter("status");//5已完结,<5未完结
	 	
	 	 List list =sqlUtil.getListByCondition("sellCount", "1", "1", "");	
	 	 List resultList=new ArrayList();
	 	 for (int i = 0; i < list.size(); i++) {
	 		long money=0L;
	 		 Map boxMap=new HashMap();
			Map map=(Map)list.get(i);
			Object sellUserid=map.get("SELLUSERID");
			String conditionStr="";//定义查询条件变量
			//状态查询
			if(status!=null && !"".equals(status)){
				if("0".equals(status)){//全部
				}
				else if("1".equals(status)){//未结算
					conditionStr=" and hm.status<5";
				}else if("2".equals(status)){//结算
					conditionStr=" and hm.status=5";
				}
			}else{
				
			}
			
			//时间查询
			if(startDate!=null && !"".equals(startDate)){
					String startTime = startDate.replaceAll("\\D+", "") + "000000";
				conditionStr=conditionStr+" and hms.cyTime >="+startTime;
			}
			if(endDate!=null && !"".equals(endDate)){
				String endTime = endDate.replaceAll("\\D+", "") + "235959";
				conditionStr=conditionStr+" and hms.cyTime <=" +endTime ;
			}
			String sqlStr="select nvl(sum(hms.money),0)money from Hmusers hms left join hmfa hm on hms.serialno=hm.serialno where 1=1 "+conditionStr+" and hms.userid in "+
			"(select userid from user_info ui  left join sellcount sc on sc.selluserid=ui.SUPERMANSTATUS  where sc.selluserid='"+sellUserid+"')";
			List sumList=sqlUtil.getListBySql(sqlStr);
			if(sumList.size()>0){
				Map sumMap=(Map)sumList.get(0);
				Object moneyObj=sumMap.get("MONEY");
				if(moneyObj!=null){
				  money=Long.valueOf(moneyObj.toString());
				}
			}
			boxMap.put("map", map);
			boxMap.put("money", money);
			resultList.add(boxMap);
		 }
	 	Map resultMap=new HashMap();
	 	resultMap.put("startDate", startDate);
	 	resultMap.put("endDate", endDate);
	 	resultMap.put("status", status);
	    request.setAttribute("list", resultList);
	    request.setAttribute("resultMap", resultMap);
	    return mapping.findForward("success");
   }
 }
