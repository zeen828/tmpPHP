 package com.jingCaiBack.action;
 
 import com.jingCaiBack.util.MessageAuxiliary;
 import com.letousky.connector.Message;
 import com.letousky.connector.MessageTool;
 import com.letousky.exception.LotteryException;
 import java.io.IOException;
 import java.io.PrintWriter;
 import java.net.URLDecoder;
 import java.util.ArrayList;
 import java.util.List;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;
 import org.apache.struts.actions.DispatchAction;
 
 public class spfManageAction extends DispatchAction
 {
   public ActionForward getAllDate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0228");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(501).append("%23;");
     strBuffer.append(request.getParameter("status")).append("%23;");
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageCount")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       out.print("{gameId:'" + str[0] + "',transCode:'" + str[1] + 
         "',clientTransCode:'" + str[2] + "'," + "uId:'" + str[3] + 
         "',uName:'" + str[4] + "',lotteryType:'" + str[5] + "'," + 
         "betWay:'" + str[6] + "',issue:'" + str[7] + "',title:'" + 
         str[8] + "',describe:'" + str[9] + "'," + "isOpen:'" + 
         str[10] + "',isFaceAllUser:'" + str[11] + 
         "',isUploading:'" + str[12] + "'," + "royaltyRatio:'" + 
         str[13] + "',betMoney:'" + str[14] + "',betMultiples:'" + 
         str[15] + "'," + "numShare:'" + str[16] + 
         "',sharePrice:'" + str[17] + "',bdShare:'" + str[18] + 
         "'," + "buyShare:'" + str[19] + "',startTime:'" + str[20] + 
         "',betNum:'" + str[21] + "'," + "otherInfo:'" + str[22] + 
         "',rewardMoney:'" + str[23] + "',status:'" + str[24] + 
         "'," + "source:'" + str[25] + "',zjIntegral:'" + str[26] + 
         "'},");
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getRecordCount(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0229");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(501).append("%23;");
     strBuffer.append(request.getParameter("status")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       out.print("{recordCount:'" + str[0] + "'},");
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getDateToUame(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0230");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
 
     String uName = URLDecoder.decode(request.getParameter("uName"));
     strBuffer.append(uName).append("%23;");
     strBuffer.append(501).append("%23;");
     strBuffer.append("0,31").append("%23;");
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageCount")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
 
       String[] str = (String[])obj[i];
       out.print("{gameId:'" + str[0] + "',transCode:'" + str[1] + 
         "',clientTransCode:'" + str[2] + "'," + "uId:'" + str[3] + 
         "',uName:'" + str[4] + "',lotteryType:'" + str[5] + "'," + 
         "betWay:'" + str[6] + "',issue:'" + str[7] + "',title:'" + 
         str[8] + "',describe:'" + str[9] + "'," + "isOpen:'" + 
         str[10] + "',isFaceAllUser:'" + str[11] + 
         "',isUploading:'" + str[12] + "'," + "royaltyRatio:'" + 
         str[13] + "',betMoney:'" + str[14] + "',betMultiples:'" + 
         str[15] + "'," + "numShare:'" + str[16] + 
         "',sharePrice:'" + str[17] + "',bdShare:'" + str[18] + 
         "'," + "buyShare:'" + str[19] + "',startTime:'" + str[20] + 
         "',betNum:'" + str[21] + "'," + "otherInfo:'" + str[22] + 
         "',rewardMoney:'" + str[23] + "',status:'" + str[24] + 
         "'," + "source:'" + str[25] + "',zjIntegral:'" + str[26] + 
         "',isTop:'" + str[27] + "'}" + bsf);
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getRecordCountToUname(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0231");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     String uName = URLDecoder.decode(request.getParameter("uName"));
     strBuffer.append(501).append("%23;");
     strBuffer.append(uName).append("%23;");
     strBuffer.append("0,31").append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       out.print("{recordCount:'" + str[0] + "'}");
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getDataToProjectScreen(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0227");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     String _str = new String(request.getParameter("str").getBytes(
       "ISO-8859-1"), "GBK");
     String[] strs = _str.split(",");
     String betWay = strs[0];
     String projectStatus = strs[1];
     String projectMoney = strs[2];
     String projectJd = strs[3];
     String sharePrice = strs[4];
     String isEnsure = strs[5];
     String projectRoyalty = strs[6];
     strBuffer.append(501).append("%23;");
     strBuffer.append(betWay).append("%23;");
     strBuffer.append(projectStatus).append("%23;");
     strBuffer.append(projectMoney).append("%23;");
     strBuffer.append(projectJd).append("%23;");
     strBuffer.append(sharePrice).append("%23;");
     strBuffer.append(isEnsure).append("%23;");
     strBuffer.append(projectRoyalty).append("%23;");
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageCount")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       out.print("{gameId:'" + str[0] + "',transCode:'" + str[1] + 
         "',clientTransCode:'" + str[2] + "'," + "uId:'" + str[3] + 
         "',uName:'" + str[4] + "',lotteryType:'" + str[5] + "'," + 
         "betWay:'" + str[6] + "',issue:'" + str[7] + "',title:'" + 
         str[8] + "',describe:'" + str[9] + "'," + "isOpen:'" + 
         str[10] + "',isFaceAllUser:'" + str[11] + 
         "',isUploading:'" + str[12] + "'," + "royaltyRatio:'" + 
         str[13] + "',betMoney:'" + str[14] + "',betMultiples:'" + 
         str[15] + "'," + "numShare:'" + str[16] + 
         "',sharePrice:'" + str[17] + "',bdShare:'" + str[18] + 
         "'," + "buyShare:'" + str[19] + "',startTime:'" + str[20] + 
         "',betNum:'" + str[21] + "'," + "otherInfo:'" + str[22] + 
         "',rewardMoney:'" + str[23] + "',status:'" + str[24] + 
         "'," + "source:'" + str[25] + "',zjIntegral:'" + str[26] + 
         "',isTop:'" + str[27] + "'}" + bsf);
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward getRecordCountToProjectScreen(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0226");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     String _str = new String(request.getParameter("str").getBytes(
       "ISO-8859-1"), "GBK");
     String[] strs = _str.split(",");
     String betWay = strs[0];
     String projectStatus = strs[1];
     String projectMoney = strs[2];
     String projectJd = strs[3];
     String sharePrice = strs[4];
     String isEnsure = strs[5];
     String projectRoyalty = strs[6];
     strBuffer.append(501).append("%23;");
     strBuffer.append(betWay).append("%23;");
     strBuffer.append(projectStatus).append("%23;");
     strBuffer.append(projectMoney).append("%23;");
     strBuffer.append(projectJd).append("%23;");
     strBuffer.append(sharePrice).append("%23;");
     strBuffer.append(isEnsure).append("%23;");
     strBuffer.append(projectRoyalty).append("%23;");
     strBuffer.append(request.getParameter("page")).append("%23;");
     strBuffer.append(request.getParameter("pageCount")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       out.print("{pageCount:'" + str[0] + "'},");
     }
     out.print("]}");
     return null;
   }
 
   public ActionForward setTopStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0233");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("gameId")).append("%23;");
     strBuffer.append(request.getParameter("topStatus")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     return null;
   }
 
   public ActionForward getProjectDetail(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws IOException
   {
     response.setContentType("text/html;charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0232");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
     strBuffer.append(request.getParameter("gameId")).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     out.print("{items:[");
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] str = (String[])obj[i];
       out.print("{gameNum:'" + str[0] + "',homeTeam:'" + str[1] + 
         "',awayTeam:'" + str[2] + "'," + "letBallCount:'" + 
         str[3] + "',score:'" + str[4] + "',gameResult:'" + str[5] + 
         "'," + "moneyReward:'" + str[6] + "',spf:'" + str[7] + 
         "',danma:'" + str[8] + "'}" + bsf);
     }
     out.print("]}");
     return null;
   }
 
   public static void main(String[] arg) {
     List matchList = new ArrayList();
     Message message = new Message();
     message.setOperaterCode("M0230");
     message.setOperaterNo("11111111");
     StringBuffer strBuffer = new StringBuffer();
 
     strBuffer.append("").append("%23;");
     strBuffer.append(501).append("%23;");
     strBuffer.append("0").append("%23;");
     strBuffer.append(1).append("%23;");
     strBuffer.append(10).append("%23;");
     message.setBody(strBuffer.toString());
     String results = MessageAuxiliary.messageToMessage(message);
     try {
       matchList = new MessageTool().splits(results);
     } catch (LotteryException lotteryException) {
       throw lotteryException;
     }
     Object[] obj = matchList.toArray();
     String bsf = ",";
     for (int i = 0; i < obj.length; ++i) {
       if (i == obj.length - 1) {
         bsf = "";
       }
       String[] arrayOfString = (String[])obj[i];
     }
   }
 }

