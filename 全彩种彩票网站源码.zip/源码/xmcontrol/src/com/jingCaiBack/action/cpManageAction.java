package com.jingCaiBack.action;

import com.jingCaiBack.util.MessageAuxiliary;
import com.letousky.connector.Message;
import com.letousky.connector.MessageTool;
import com.letousky.exception.LotteryException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class cpManageAction extends DispatchAction
{
  public ActionForward m0213(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {
    response.setContentType("text/html;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
     PrintWriter out = response.getWriter();
    List chipinList = new ArrayList();
   Message message = new Message();
    message.setOperaterCode("M0213");
    message.setOperaterNo("1111111111");

     StringBuffer messageBuf = new StringBuffer();
     messageBuf.append(request.getParameter("gameCode")).append("%23;");
     messageBuf.append(request.getParameter("issue")).append("%23;");
     messageBuf.append(request.getParameter("status")).append("%23;");

     message.setBody(messageBuf.toString());

    String results = MessageAuxiliary.messageToMessage(message);
    try {
      chipinList = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
    Object[] obj = chipinList.toArray();
   for (int i = 0; i < obj.length; ++i) {
       String[] str = (String[])obj[i];
       out.print("{items:[{count:'" + str[0] + "'}]}");
    }
     return null;
  }

  public ActionForward m0214(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {
    response.setContentType("text/html;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
    List chipinList = new ArrayList();
     PrintWriter out = response.getWriter();

     Message message = new Message();
     message.setOperaterCode("M0214");
     message.setOperaterNo("1111111111");

 String gameCode = request.getParameter("gameCode");
    String status = request.getParameter("status");
     String pageNum = request.getParameter("pageNum");
    String pageCount = request.getParameter("pageCount");
   StringBuffer messageBuf = new StringBuffer();
   messageBuf.append(gameCode).append("%23;");
    messageBuf.append("").append("%23;");
     messageBuf.append(status).append("%23;");
    messageBuf.append(pageNum).append("%23;");
    messageBuf.append(pageCount).append("%23;");

   message.setBody(messageBuf.toString());

   String results = MessageAuxiliary.messageToMessage(message);
    try {
     chipinList = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
    Object[] obj = chipinList.toArray();
     out.println("{items:[");
    for (int i = 0; i < obj.length; ++i) {
     String[] str = (String[])obj[i];
     out.print("{tempId:'" + str[0] + "',serialno:'" + str[1] + 
        "',recordId:'" + str[2] + "',uName:'" + str[3] + 
       "',gameCode:'" + str[4] + "',manner:'" + str[5] + 
       "',record:'" + str[6] + "',multiple:'" + str[7] + 
       "',bets:'" + str[8] + "',chipinNums:'" + str[9] + 
        "',status:'" + str[10] + "'},");
    }
    out.println("]}");
    return null;
  }

  public static void main(String[] dsf) {
    List chipinList = new ArrayList();

     Message message = new Message();
    message.setOperaterCode("M0214");
    message.setOperaterNo("1111111111");
     StringBuffer messageBuf = new StringBuffer();
    messageBuf.append("501").append("%23;");
    messageBuf.append("").append("%23;");
    messageBuf.append("1").append("%23;");
    messageBuf.append(0).append("%23;");
    messageBuf.append(0).append("%23;");

    message.setBody(messageBuf.toString());

   String results = MessageAuxiliary.messageToMessage(message);
    try {
      chipinList = new MessageTool().splits(results);
    } catch (LotteryException lotteryException) {
      throw lotteryException;
    }
   Object[] obj = chipinList.toArray();
   for (int i = 0; i < obj.length; ++i) {
     String[] str = (String[])obj[i];
      for (int j = 0; j < str.length; ++j) {
      System.out.print(str[j] + "--");
      }
  System.out.println();
    }
  }
}
