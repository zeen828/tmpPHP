package com.jingCaiBack.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.upload.FormFile;

import com.jingCaiBack.dao.ChipinTempDAO;
import com.jingCaiBack.model.ChipinTemp;
import com.letousky.connector.Message;

public class ExcelUploadAction extends DispatchAction {
	private ChipinTempDAO chinChipinTempDAO = new ChipinTempDAO();

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ActionForward uploadExcel(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		String tempPath = "";

		List sameList = new ArrayList();
		List piaoList = new ArrayList();
		List list = new ArrayList();
		
		String startTime="";
		String endTime="";
		String startTimeDetail="";
		String endTimeDetail="";

		// 代表一个EXCEL文件
		Workbook wb = null;
		try {
			DiskFileUpload fu = new DiskFileUpload(); // 设置最大文件尺寸，这里是4MB

			fu.setSizeMax(4194304); // 设置缓冲区大小，这里是4kb
			fu.setSizeThreshold(4096); // 设置临时目录：
			fu.setRepositoryPath(tempPath); // 得到所有的文件：
			List fileItems = fu.parseRequest(request);

			startTime = ((FileItem) fileItems.get(1)).getString(); // 获取开始时间
			endTime = ((FileItem) fileItems.get(2)).getString(); // 获取结束时间

			startTimeDetail = startTime.replaceAll("-", "") + "000000";
			endTimeDetail = endTime.replaceAll("-", "") + "235959";

			FileItem fi = (FileItem) fileItems.get(0); // 获得文件名，这个文件名包括路径：
			String fileName = fi.getName(); // 在这里可以记录用户和文件信息

			wb = Workbook.getWorkbook(fi.getInputStream());
			if (wb == null) {
				return null;
			}
			// 得到excel 所有工作表
			Sheet[] sheets = wb.getSheets();
			if (sheets != null) {

				// 遍历各个工作表

				Sheet s = sheets[0];
				int columns = s.getColumns();
				int rows = s.getRows();

				System.out.println(columns + "  " + rows);
				System.out.println("出票中心派奖的：");
				if (columns > 0 || rows > 0) {
					for (int r = 1; r < rows; r++) {
						// 单元格getCell (行，列)
						Cell cell = s.getCell(0, r);
						System.out.print(cell.getContents() + "  -");// 输出单元格数据
						piaoList.add(cell.getContents());
					}
				}
			}
			list = chinChipinTempDAO.getBetsList(startTimeDetail, endTimeDetail);
			for (int i = 0; i < list.size(); i++) {
				ChipinTemp chipinTemp = (ChipinTemp) list.get(i);
				System.out.println(i + ":" + chipinTemp.getTempId() + ":"
						+ chipinTemp.getTempAwardBets());
				for (int j = 0; j < piaoList.size(); j++) {
					Long piaoId = Long.parseLong(piaoList.get(j).toString());
					if (chipinTemp.getTempId() == piaoId) {
						sameList.add(chipinTemp);
						break;
					}

				}
			}

			list.removeAll(sameList);
		} catch (Exception e) {
		} finally {
			if (wb != null) {
				wb.close();
			}
		}

		System.out.println("出票中心未派奖的：");

		for (int i = 0; i < list.size(); i++) {
			ChipinTemp chipinTemp = (ChipinTemp) list.get(i);
			System.out.println(chipinTemp.getTempId() + ":"
					+ chipinTemp.getSerialNo() + ":"
					+ chipinTemp.getTempAwardBets());
		}

		request.setAttribute("list", list);
		request.setAttribute("startTime", startTime);
		request.setAttribute("endTime", endTime);
		
		return mapping.findForward("success");
	}

/*	public Message getFormatString(String dateTimes) {
		Message message = new Message();
		message.setOperaterCode("M0283");
		message.setOperaterNo("1111111111");
		StringBuffer messageBuf = new StringBuffer();
		messageBuf.append(dateTimes).append("%23;");
		message.setBody(messageBuf.toString());
		return message;

	}*/
}
