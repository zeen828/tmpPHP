 package com.jingCaiBack.action;
 


 import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
 import java.util.HashMap;
 import java.util.List;
 import java.util.Map;

import javax.servlet.ServletOutputStream;
 import javax.servlet.http.HttpServletRequest;
 import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.commons.lang.StringUtils;
 import org.apache.struts.action.ActionForm;
 import org.apache.struts.action.ActionForward;
 import org.apache.struts.action.ActionMapping;

import com.jingCaiBack.dao.CoreDAO;
import com.jingCaiBack.dao.UserInfoDAO;
import com.jingCaiBack.model.AccountTrade;
import com.jingCaiBack.model.UserInfo;
import com.jingCaiBack.model.UserLogin;
import com.jingCaiBack.util.DateUtil;
import com.jingCaiBack.util.FormatUtil;
import com.jingCaiBack.util.MD5;
import com.jingCaiBack.util.SqlUtil;
 
 public class UserInfoAction extends AbstractAction
 {
   private UserInfoDAO userInfodao = new UserInfoDAO();
   SqlUtil sqlUtil=new SqlUtil();
   //查询列表
   public ActionForward userInfoList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
     throws Exception
   {

     request.setCharacterEncoding("UTF-8");
     int page = getIntParameter(request, "page");
     if (page < 0) page = 1;
     int start = (page - 1) * 10;
     int end = page * 10;
     
     Map<String,Object> map=new HashMap<String,Object>();
     String supermanstatus=request.getParameter("supermanstatus");
     String userNickName=request.getParameter("userNickName");
     String unionId = request.getParameter("unionId");
     String cardAccount=request.getParameter("cardAccount");
     String realName=request.getParameter("realName");
     String idCardNumber=request.getParameter("idCardNumber");
     String userTel=request.getParameter("userTel");
     String bank=request.getParameter("bank");
     String loginTimes=request.getParameter("loginTimes");
     
     Object sellUserIdObj =sqlUtil.getColumnNameById("sellcount", "sellUserName", supermanstatus, "sellUserId");//通过介绍人名称找到介绍人ID
	   if(supermanstatus!=null && !"".equals(supermanstatus.trim())){//用户输入的介绍人名称
		   map.put("supermanstatus", sellUserIdObj==null?"123456":sellUserIdObj.toString());
	   }
     if(userNickName!=null && !"".equals(userNickName.trim()) ){
    	 map.put("userNickName", "'%"+userNickName.trim()+"%'");
     }
     if(unionId!=null&&!"".equals(unionId.trim())){
    	 map.put("unionId", "'"+ unionId.trim()+"'");
     }
     if(cardAccount!=null && !"".equals(cardAccount.trim())){
    	 map.put("cardAccount", "'%"+cardAccount.trim()+"%'");
     }
     if(realName!=null && !"".equals(realName.trim())){
    	 map.put("realName", "'%"+realName.trim()+"%'");
     }
     if(idCardNumber!=null && !"".equals(idCardNumber)){
    	 map.put("idCardNumber", idCardNumber);
     }
     if(userTel!=null && !"".equals(userTel)){
    	 map.put("userTel", userTel);
     }
     if(bank!=null && !"".equals(bank.trim())){
    	 map.put("bank", "'%"+bank.trim()+"%'");
     }
     if(loginTimes!=null && !"".equals(loginTimes.trim())){
    	 map.put("loginTimes", loginTimes);
     }
     map.put("endRecNo", end);
     map.put("beginRecNo", start);
     
     List<UserInfo> userInfoList = this.userInfodao.getList(map);
     long count = this.userInfodao.getCount(map);
     long pageCount = (count % 10 == 0) ? count / 10 : count / 10 + 1;
     StringBuilder sb = new StringBuilder();
     sb.append("{");
     sb.append("items:[");
     if ((userInfoList != null) && (userInfoList.size() > 0))
     {
       for (int i = 0; i < userInfoList.size(); ++i)
       {
    	   UserInfo userInfo= userInfoList.get(i);
    	   Object sellUserNameObj =sqlUtil.getColumnNameById("sellcount", "sellUserId", userInfo.getSupermanstatus(), "sellUserName");
    	   if(sellUserNameObj==null){
    		   sellUserNameObj="beikecai";
    	   }
         sb.append("{");
         sb.append("userId:'" + userInfo.getUserId() + "',");
         sb.append("userNickName:'" + userInfo.getUserNickName() + "',");
         sb.append("cardAccount:'" + userInfo.getCardAccount() + "',");
         sb.append("realName:'" + userInfo.getRealName() + "',");
         sb.append("idCardNumber:'" + userInfo.getIdCardNumber() + "',");
         sb.append("userTel:'" + userInfo.getUserTel() + "',");
         sb.append("bank:'" + userInfo.getBank() + "',");
         if(unionId==null || "".equals(unionId)){
        	 if(userInfo.getUnionId()!=null){
        		 unionId =userInfo.getUnionId();
        	 }else{
        		 unionId = "beikecai";
        	 }
         }
         sb.append("unionId:'" + unionId+ "',");
         sb.append("supermanstatus:'" + sellUserNameObj.toString() + "',");
         sb.append("loginTimes:'" + userInfo.getLoginTimes() + "'");
         sb.append("}");
         if (i == userInfoList.size() - 1)
           continue;
         sb.append(",");
       }
     }
     sb.append("]");
     sb.append(",count:'" + count + "'");
     sb.append(",pageCount:'" + pageCount + "'");
     sb.append("}");
 
     nocache(response);
     response.setContentType("text/html;charset=UTF-8");
     PrintWriter out = response.getWriter();
     out.print(sb.toString());
     return null;
   }
   //导出查询列表
   public ActionForward ExportUserInfoList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)throws Exception{
	   
		request.setCharacterEncoding("UTF-8");
	     
	     Map<String,Object> map=new HashMap<String,Object>();
	     String userNickName=request.getParameter("userNickName");
	     String supermanstatus=request.getParameter("supermanstatus");
	     String cardAccount=request.getParameter("cardAccount");
	     String realName=request.getParameter("realName");
	     String idCardNumber=request.getParameter("idCardNumber");
	     String userTel=request.getParameter("userTel");
	     String bank=request.getParameter("bank");
	     String loginTimes=request.getParameter("loginTimes");
	     
	     Object sellUserIdObj =sqlUtil.getColumnNameById("sellcount", "sellUserName", supermanstatus, "sellUserId");//通过介绍人名称找到介绍人ID
		   if(supermanstatus!=null && !"".equals(supermanstatus.trim())){//用户输入的介绍人名称
				   map.put("supermanstatus", sellUserIdObj==null?"123456":sellUserIdObj.toString());
		   }
	     if(userNickName!=null && !"".equals(userNickName.trim()) ){
	    	 map.put("userNickName", "'%"+userNickName.trim()+"%'");
	     }
	     if(cardAccount!=null && !"".equals(cardAccount.trim())){
	    	 map.put("cardAccount", "'%"+cardAccount.trim()+"%'");
	     }
	     if(realName!=null && !"".equals(realName.trim())){
	    	 map.put("realName", "'%"+realName.trim()+"%'");
	     }
	     if(idCardNumber!=null && !"".equals(idCardNumber)){
	    	 map.put("idCardNumber", idCardNumber);
	     }
	     if(userTel!=null && !"".equals(userTel)){
	    	 map.put("userTel", userTel);
	     }
	     if(bank!=null && !"".equals(bank.trim())){
	    	 map.put("bank", "'%"+bank.trim()+"%'");
	     }
	     if(loginTimes!=null && !"".equals(loginTimes.trim())){
	    	 map.put("loginTimes", loginTimes);
	     }
	
		
		 List<UserInfo> userInfoList=userInfodao.getAllList(map);
		  //导出到excel文件中attachment/inline打开方式两种
		    String filename = new String("用户信息记录".getBytes("GBK"),"iso8859-1"); 
	        response.setContentType("application/vnd.ms-excel");
	        response.setHeader("Content-disposition",
	                "inline; filename="+filename
	                + DateUtil.toStringInYearMonthDayPattern(DateUtil
	                        .getNowPreciseToDay()) + ".xls");
	        ServletOutputStream os = response.getOutputStream();
	        WritableWorkbook workbook = Workbook.createWorkbook(os);
	        WritableSheet sheet = workbook.createSheet("日志", 0);

	        Label label = null;
	        label = new Label(0, 0, "用户编号");
	        sheet.addCell(label);
	        label = new Label(1, 0, "用户昵称");
	        sheet.addCell(label);
	        label = new Label(2, 0, "真实姓名");
	        sheet.addCell(label);
	        label = new Label(3, 0, "身份证号");
	        sheet.addCell(label);
	        label = new Label(4, 0, "银行名称");
	        sheet.addCell(label);
	        label = new Label(5, 0, "银行卡号");
	        sheet.addCell(label);
	        label = new Label(6, 0, "用户手机");
	        sheet.addCell(label);
	        label = new Label(7, 0, "登陆次数");
	        sheet.addCell(label);
	        label = new Label(8, 0, "介绍人");
	        sheet.addCell(label);

	        for (int i = 0; i < userInfoList.size(); i++) {
	        	UserInfo userInfo = (UserInfo) userInfoList.get(i);
	                //**用户编号**
					label = new Label(0, i + 1, userInfo.getUserId());
		            sheet.addCell(label);             
	                //**用户昵称**
	                label = new Label(1, i + 1, userInfo.getUserNickName());
	                sheet.addCell(label);
	                //**真实姓名**
	                label = new Label(2, i + 1, userInfo.getRealName());
	                sheet.addCell(label);
	                //**身份证号*
	                label = new Label(3, i + 1, userInfo.getIdCardNumber());
	                sheet.addCell(label);  
	                //**银行名称**
	                label = new Label(4, i + 1, userInfo.getCardAccount());
	                sheet.addCell(label); 
	                //**银行卡号**
	                label = new Label(5, i + 1, userInfo.getBank());
	                sheet.addCell(label); 
	                //**用户手机**
	                label = new Label(6, i + 1, userInfo.getUserTel());
	                sheet.addCell(label); 
	                //**登陆次数**
	                label = new Label(7, i + 1, String.valueOf(userInfo.getLoginTimes()));
	                sheet.addCell(label); 
	                //**介绍人**
	               /* Object sellUserNameObj =sqlUtil.getColumnNameById("sellcount", "sellUserId", userInfo.getSupermanstatus(), "sellUserName");
	         	    if(sellUserNameObj==null){
	         		   sellUserNameObj="beikecai";
	         	    }*/
	         	    String sellUserName=userInfo.getSellUserName();
	                label = new Label(8, i + 1, sellUserName);
	                sheet.addCell(label); 
	            }
	        
	        workbook.write();
	        workbook.close();
	        os.close(); 
	return null;
	   
   }
   public ActionForward getUserInfo(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws Exception
     {
		request.setCharacterEncoding("UTF-8");
		
		SqlUtil sqlUtil=new SqlUtil();
		
	   String userNickName=request.getParameter("userNickName");
	   //USERNICKNAME="窗前明光光";
	 /*  String passWord=request.getParameter("passWord");
	   if(!"".equals(passWord)&& passWord!=null){
		     MD5 md5=new MD5();
		     String userPassWord = md5.md5GB2312("passWord");
		     sqlUtil.updateById("user_login", "userId", userId, "userPassWord", userPassWord);
	   }*/
	   Map map=sqlUtil.getMapById("user_info", "USERNICKNAME", userNickName);
	  // String userNickName=FormatUtil.getDefault(map.get("USERNICKNAME"), "");
	   String cardAccount=FormatUtil.getDefault(map.get("CARDACCOUNT"), "");
	   String bank=FormatUtil.getDefault(map.get("BANK"), "");
	   String idCardNumber=FormatUtil.getDefault(map.get("IDCARDNUMBER"), "");
	   String userTel=FormatUtil.getDefault(map.get("USERTEL"), "");
	   
	   Map map2  = sqlUtil.getMapById("user_Login", "USERNICKNAME", userNickName);
	   String  refId =FormatUtil.getDefault(map2.get("REFID"), "");
	   String refOrderDate=FormatUtil.getDefault(map2.get("REFORDERDATE"), "");
	   String refRegisterDate=FormatUtil.getDefault(map2.get("REFREGISTERDATE"), "");
	   String refCallBack=FormatUtil.getDefault(map2.get("REFCALLBACK"), "");
	   String refRate=FormatUtil.getDefault(map2.get("REFRATE"), "");
	   String userType = FormatUtil.getDefault(map2.get("USERTYPE"), "");
	   
	   StringBuilder sb = new StringBuilder();
	     sb.append("{");
	     sb.append("items:[");
	     sb.append("{");
         sb.append("userNickName:'" + userNickName + "',");
         sb.append("cardAccount:'" + cardAccount + "',");
         sb.append("bank:'" + bank + "',");
         sb.append("idCardNumber:'" + idCardNumber + "',");
         sb.append("userTel:'" + userTel + "',");
         sb.append("refId:'" + refId + "',");
         sb.append("refOrderDate:'" + refOrderDate + "',");
         sb.append("refRegisterDate:'" + refRegisterDate + "',");
         sb.append("refRate:'" + refRate + "',");
         sb.append("userType:'" + userType + "',");
         sb.append("refCallBack:'" + refCallBack + "'");
         sb.append("}");
         sb.append("]");
         sb.append("}");
         nocache(response);
         response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter();
         out.print(sb.toString());
         return null;
	   
     }
   public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException{
	 // request.setCharacterEncoding("UTF-8");
	   String userNickName=new String(request.getParameter("userNickName").getBytes("ISO8859-1"), "UTF-8"); //request.getParameter("userNickName");
	   String cardAccount=new String(request.getParameter("cardAccount").getBytes("ISO8859-1"), "UTF-8");//request.getParameter("cardAccount");
	   String bank=new String(request.getParameter("bank").getBytes("ISO8859-1"), "UTF-8");//request.getParameter("bank");
	   String idCardNumber=request.getParameter("idCardNumber");
	   String userTel=request.getParameter("userTel");
	   String passWord=request.getParameter("passWord");
	   String  refId = request.getParameter("refId");
	   String refOrderDate=request.getParameter("refOrderDate");
	   String refRegisterDate=request.getParameter("refRegisterDate");
	   String refCallBack=request.getParameter("refCallBack");
	   String refRate=request.getParameter("refRate");
	   String userType = request.getParameter("userType");
	   
	   
	   //修改用户信息
	   CoreDAO coreDAO=new CoreDAO();
	   Map sqlMap=new HashMap();
	   
	   String sqlStr="update user_info set "+
	   		"cardAccount='"+cardAccount+
	   		"',bank='"+bank+
	   		"',idCardNumber='"+idCardNumber+
	   		"',userTel='"+userTel+
	   		"'  where" +
	   				" userNickName='"+userNickName+"'";
	   sqlMap.put("sql", sqlStr);
	   coreDAO.update("Core.generalUpdate", sqlMap);
	   
	   
	   
	   Map sqlMaps=new HashMap();
	   String sqlval="update user_login  set "+
								" refId='"+refId+
						   		"',refOrderDate="+refOrderDate+
						   		",refRegisterDate="+refRegisterDate+
						   		",refCallBack='"+refCallBack+
						   		"',REFRATE='"+refRate+
						   		"',userType='"+userType+
						   		"'  where" +
				   				" userNickName='"+userNickName+"'";
	   sqlMaps.put("sql", sqlval);
	   coreDAO.update("Core.generalUpdate", sqlMaps);
	   //修改密码
	   if(null!=passWord && !"".equals(passWord.trim())){
		   MD5 md5=new MD5();
		   passWord = md5.md5GB2312(passWord.trim());//MD5加密
		   sqlStr="update user_login set userPassWord='"+passWord+"' where userNickName='"+userNickName+"'";
		   sqlMap.put("sql", sqlStr);
		   coreDAO.update("Core.generalUpdate", sqlMap);
	   }
	   nocache(response);
       response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
       out.print("0000");//修改用户成功就提示
       return null;
   }
   
 }
 

