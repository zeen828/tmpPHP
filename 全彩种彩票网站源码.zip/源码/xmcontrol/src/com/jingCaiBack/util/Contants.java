 package com.jingCaiBack.util;
 
 import java.text.DecimalFormat;
 import java.text.SimpleDateFormat;
 import java.util.HashMap;
 import java.util.Map;
 
 public class Contants
 {
   public static final Map<Integer, String> GAMECODEMAP = new HashMap();
 
   public static final Map<Integer, String> JCMAP = new HashMap();
 
   public static final Map<Integer, String> STMAP = new HashMap();
 
   public static final Map<Integer, String> CTMAP = new HashMap();
 
   public static final DecimalFormat DF = new DecimalFormat("#.##");
 
   public static final int[] GAMECODES = { 501, 511, 502, 503, 504, 505, 506, 507, 508, 509, 510, 301, 302, 303, 304, 305, 102, 103, 106, 107 };
 
   public static final SimpleDateFormat YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");
   public static final SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
   public static final SimpleDateFormat YYYY_MM_DD_HH_MM_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   public static final SimpleDateFormat YYYYMMDDHHMMSS = new SimpleDateFormat("yyyyMMddHHmmss");
   public static final String OUT_TRADETYPE = "7003";
   public static final String IN_TRADETYPE = "7004";
 
   static
   {
     GAMECODEMAP.put(Integer.valueOf(501), "竞彩足球-胜平负");
     GAMECODEMAP.put(Integer.valueOf(502), "竞彩足球-比分");
     GAMECODEMAP.put(Integer.valueOf(503), "竞彩足球-总进球数");
     GAMECODEMAP.put(Integer.valueOf(504), "竞彩足球-半全场");
     GAMECODEMAP.put(Integer.valueOf(505), "竞彩篮球-胜负");
     GAMECODEMAP.put(Integer.valueOf(506), "竞彩篮球-让分胜负");
     GAMECODEMAP.put(Integer.valueOf(507), "竞彩篮球-胜分差");
     GAMECODEMAP.put(Integer.valueOf(508), "竞彩篮球-大小分");
     GAMECODEMAP.put(Integer.valueOf(509), "竞彩足球-混合过关");
     GAMECODEMAP.put(Integer.valueOf(510), "竞彩篮球-混合过关");
     GAMECODEMAP.put(Integer.valueOf(511), "竞彩足球-让球胜平负");
     GAMECODEMAP.put(Integer.valueOf(301), "北单-让球胜平负");
     GAMECODEMAP.put(Integer.valueOf(302), "北单-上下单双");
     GAMECODEMAP.put(Integer.valueOf(303), "北单-总进球数");
     GAMECODEMAP.put(Integer.valueOf(304), "北单-比分");
     GAMECODEMAP.put(Integer.valueOf(305), "北单-半全场胜平负");
     GAMECODEMAP.put(Integer.valueOf(102), "传统足球-胜负彩");
     GAMECODEMAP.put(Integer.valueOf(103), "传统足球-任选9");
     GAMECODEMAP.put(Integer.valueOf(106), "传统足球-4场半进球彩");
     GAMECODEMAP.put(Integer.valueOf(107), "传统足球-6场半全场");
 
     JCMAP.put(Integer.valueOf(1), "单关");
     JCMAP.put(Integer.valueOf(2), "2串1");
     JCMAP.put(Integer.valueOf(3), "3串1");
     JCMAP.put(Integer.valueOf(4), "3串3");
     JCMAP.put(Integer.valueOf(5), "3串4");
     JCMAP.put(Integer.valueOf(6), "4串1");
     JCMAP.put(Integer.valueOf(7), "4串4");
     JCMAP.put(Integer.valueOf(8), "4串5");
     JCMAP.put(Integer.valueOf(9), "4串6");
     JCMAP.put(Integer.valueOf(10), "4串11");
     JCMAP.put(Integer.valueOf(11), "5串1");
     JCMAP.put(Integer.valueOf(12), "5串5");
     JCMAP.put(Integer.valueOf(13), "5串6");
     JCMAP.put(Integer.valueOf(14), "5串10");
     JCMAP.put(Integer.valueOf(15), "5串16");
     JCMAP.put(Integer.valueOf(16), "5串20");
     JCMAP.put(Integer.valueOf(17), "5串26");
     JCMAP.put(Integer.valueOf(18), "6串1");
     JCMAP.put(Integer.valueOf(19), "6串6");
     JCMAP.put(Integer.valueOf(20), "6串7");
     JCMAP.put(Integer.valueOf(21), "6串15");
     JCMAP.put(Integer.valueOf(22), "6串20");
     JCMAP.put(Integer.valueOf(23), "6串22");
     JCMAP.put(Integer.valueOf(24), "6串35");
     JCMAP.put(Integer.valueOf(25), "6串42");
     JCMAP.put(Integer.valueOf(26), "6串50");
     JCMAP.put(Integer.valueOf(27), "6串57");
     JCMAP.put(Integer.valueOf(28), "7串1");
     JCMAP.put(Integer.valueOf(29), "7串7");
     JCMAP.put(Integer.valueOf(30), "7串8");
     JCMAP.put(Integer.valueOf(31), "7串21");
     JCMAP.put(Integer.valueOf(32), "7串35");
     JCMAP.put(Integer.valueOf(33), "7串120");
     JCMAP.put(Integer.valueOf(35), "8串1");
     JCMAP.put(Integer.valueOf(36), "8串8");
     JCMAP.put(Integer.valueOf(37), "8串9");
     JCMAP.put(Integer.valueOf(38), "8串28");
     JCMAP.put(Integer.valueOf(39), "8串56");
     JCMAP.put(Integer.valueOf(40), "8串70");
     JCMAP.put(Integer.valueOf(41), "8串247");
 
     STMAP.put(Integer.valueOf(1), "单关");
     STMAP.put(Integer.valueOf(2), "2串1");
     STMAP.put(Integer.valueOf(3), "2串3");
     STMAP.put(Integer.valueOf(4), "3串1");
     STMAP.put(Integer.valueOf(5), "3串4");
     STMAP.put(Integer.valueOf(6), "3串7");
     STMAP.put(Integer.valueOf(7), "4串1");
     STMAP.put(Integer.valueOf(8), "4串5");
     STMAP.put(Integer.valueOf(9), "4串11");
     STMAP.put(Integer.valueOf(10), "4串15");
     STMAP.put(Integer.valueOf(11), "5串1");
     STMAP.put(Integer.valueOf(12), "5串6");
     STMAP.put(Integer.valueOf(13), "5串16");
     STMAP.put(Integer.valueOf(14), "5串26");
     STMAP.put(Integer.valueOf(15), "5串31");
     STMAP.put(Integer.valueOf(16), "6串1");
     STMAP.put(Integer.valueOf(17), "6串7");
     STMAP.put(Integer.valueOf(18), "6串22");
     STMAP.put(Integer.valueOf(19), "6串42");
     STMAP.put(Integer.valueOf(20), "6串57");
     STMAP.put(Integer.valueOf(21), "6串63");
     STMAP.put(Integer.valueOf(22), "7串1");
     STMAP.put(Integer.valueOf(23), "8串1");
     STMAP.put(Integer.valueOf(24), "9串1");
     STMAP.put(Integer.valueOf(25), "10串1");
     STMAP.put(Integer.valueOf(26), "11串1");
     STMAP.put(Integer.valueOf(27), "12串1");
     STMAP.put(Integer.valueOf(28), "13串1");
     STMAP.put(Integer.valueOf(29), "14串1");
     STMAP.put(Integer.valueOf(30), "15串1");
 
     CTMAP.put(Integer.valueOf(1), "单式");
     CTMAP.put(Integer.valueOf(2), "复式");
   }
 
   public static void main(String[] args)
   {
   }
 }

