package com.jingCaiBack.util;

public class LotteryType
{
  public static final int spf = 501;
}

