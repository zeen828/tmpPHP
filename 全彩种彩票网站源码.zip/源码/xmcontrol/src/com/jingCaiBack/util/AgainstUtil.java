package com.jingCaiBack.util;

import com.jingCaiBack.dao.AgainstDAO;
import com.jingCaiBack.dao.Lan_qiuAgainstDAO;
import com.jingCaiBack.model.Against;
import com.jingCaiBack.model.Lan_qiuAgainst;
import java.io.PrintStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class AgainstUtil
{
   private static AgainstDAO againstDao = new AgainstDAO();
   private static Lan_qiuAgainstDAO lan_qiuAgainstDao = new Lan_qiuAgainstDAO();
  private static Map<String, String> f_numMap;
  private static Map<String, String> b_numMap;

  public static String getFNum(String key)
  {
    String value = "";
    try {
       if (f_numMap == null)
      {
        f_numMap = new HashMap();
      }
       if (f_numMap.size() > 5000)
      {
        f_numMap.clear();
      }
       value = (String)f_numMap.get(key);
       if (value == null)
      {
         Against against = againstDao.getById(Long.parseLong(key));
         if (against != null)
        {
           value = against.getAgainsthNum();
           f_numMap.put(key, value);
        }
      }
    } catch (SQLException e) {
       e.printStackTrace();
    }
     return value;
  }

  public static String getBNum(String key)
  {
     String value = "";
    try {
       if (b_numMap == null)
      {
         b_numMap = new HashMap();
      }
       if (b_numMap.size() > 5000)
      {
         b_numMap.clear();
      }
       value = (String)b_numMap.get(key);
       if (value == null)
      {
         Lan_qiuAgainst against = lan_qiuAgainstDao.getById(key);
         if (against != null)
        {
           value = against.getAgainsthNum();
           b_numMap.put(key, value);
        }
      }
    } catch (SQLException e) {
       e.printStackTrace();
    }
     return value;
  }

  public static void main(String[] args) {
     System.out.println(getFNum("6198"));
     System.out.println(getFNum("6198"));

     System.out.println(getBNum("244"));
     System.out.println(getBNum("244"));
  }
}
