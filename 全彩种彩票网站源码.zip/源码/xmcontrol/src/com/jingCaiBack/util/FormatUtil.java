package com.jingCaiBack.util;

public class FormatUtil {
	/**
	 * 给默认值
	 * @param object传入单个的对象
	 * @param defaultValue 默认值
	 * @return 返回一个字符串
	 */
	public static String getDefault(Object object,String defaultValue){
		if(object==null){
			return defaultValue;
		}
		return object.toString();
	}

}
