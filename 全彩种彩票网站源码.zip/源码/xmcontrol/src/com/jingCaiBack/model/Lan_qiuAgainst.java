 package com.jingCaiBack.model;
 
 public class Lan_qiuAgainst extends BaseModel
 {
   private static final long serialVersionUID = 1L;
   private String againstId;
   private String leagueName;
   private String leagueColor;
   private String againsthNum;
   private String hostTream;
   private String guestTream;
   private String concedeNum;
   private String smallType;
   private long stopselldate;
   private long dsstopTime;
   private long fsstopTime;
   private int proccessStatus;
   private String info;
   private int againstType;
   private String quanChangBiFen;
   private String sfResults;
   private String rfsfResults;
   private String sfcResults;
   private String dxResults;
   private String sfguoGuanResult;
   private String rfsfGuanResult;
   private String sfcGuanResult;
   private String dxGuanResult;
   private String sfAward;
   private String rfsfAward;
   private String sfcAward;
   private String dxAward;
   private String hostTreamRankings;
   private String guestTreamRankings;
   private String meanSp;
 
   public String getAgainstId()
   {
     return this.againstId; }
 
   public void setAgainstId(String againstId) {
     this.againstId = againstId; }
 
   public String getLeagueName() {
     return this.leagueName; }
 
   public void setLeagueName(String leagueName) {
     this.leagueName = leagueName; }
 
   public String getLeagueColor() {
     return this.leagueColor; }
 
   public void setLeagueColor(String leagueColor) {
     this.leagueColor = leagueColor; }
 
   public String getAgainsthNum() {
     return this.againsthNum; }
 
   public void setAgainsthNum(String againsthNum) {
     this.againsthNum = againsthNum; }
 
   public String getHostTream() {
     return this.hostTream; }
 
   public void setHostTream(String hostTream) {
     this.hostTream = hostTream; }
 
   public String getGuestTream() {
     return this.guestTream; }
 
   public void setGuestTream(String guestTream) {
     this.guestTream = guestTream; }
 
   public String getConcedeNum() {
     return this.concedeNum; }
 
   public void setConcedeNum(String concedeNum) {
     this.concedeNum = concedeNum; }
 
   public String getSmallType() {
     return this.smallType; }
 
   public void setSmallType(String smallType) {
     this.smallType = smallType; }
 
   public long getStopselldate() {
     return this.stopselldate; }
 
   public void setStopselldate(long stopselldate) {
     this.stopselldate = stopselldate; }
 
   public long getDsstopTime() {
     return this.dsstopTime; }
 
   public void setDsstopTime(long dsstopTime) {
     this.dsstopTime = dsstopTime; }
 
   public long getFsstopTime() {
     return this.fsstopTime; }
 
   public void setFsstopTime(long fsstopTime) {
     this.fsstopTime = fsstopTime; }
 
   public int getProccessStatus() {
     return this.proccessStatus; }
 
   public void setProccessStatus(int proccessStatus) {
     this.proccessStatus = proccessStatus; }
 
   public String getInfo() {
     return this.info; }
 
   public void setInfo(String info) {
     this.info = info; }
 
   public int getAgainstType() {
     return this.againstType; }
 
   public void setAgainstType(int againstType) {
     this.againstType = againstType; }
 
   public String getQuanChangBiFen() {
     return this.quanChangBiFen; }
 
   public void setQuanChangBiFen(String quanChangBiFen) {
     this.quanChangBiFen = quanChangBiFen; }
 
   public String getSfResults() {
     return this.sfResults; }
 
   public void setSfResults(String sfResults) {
     this.sfResults = sfResults; }
 
   public String getRfsfResults() {
     return this.rfsfResults; }
 
   public void setRfsfResults(String rfsfResults) {
     this.rfsfResults = rfsfResults; }
 
   public String getSfcResults() {
     return this.sfcResults; }
 
   public void setSfcResults(String sfcResults) {
     this.sfcResults = sfcResults; }
 
   public String getDxResults() {
     return this.dxResults; }
 
   public void setDxResults(String dxResults) {
     this.dxResults = dxResults; }
 
   public String getSfguoGuanResult() {
     return this.sfguoGuanResult; }
 
   public void setSfguoGuanResult(String sfguoGuanResult) {
     this.sfguoGuanResult = sfguoGuanResult; }
 
   public String getRfsfGuanResult() {
     return this.rfsfGuanResult; }
 
   public void setRfsfGuanResult(String rfsfGuanResult) {
     this.rfsfGuanResult = rfsfGuanResult; }
 
   public String getSfcGuanResult() {
     return this.sfcGuanResult; }
 
   public void setSfcGuanResult(String sfcGuanResult) {
     this.sfcGuanResult = sfcGuanResult; }
 
   public String getDxGuanResult() {
     return this.dxGuanResult; }
 
   public void setDxGuanResult(String dxGuanResult) {
     this.dxGuanResult = dxGuanResult; }
 
   public String getSfAward() {
     return this.sfAward; }
 
   public void setSfAward(String sfAward) {
     this.sfAward = sfAward; }
 
   public String getRfsfAward() {
     return this.rfsfAward; }
 
   public void setRfsfAward(String rfsfAward) {
     this.rfsfAward = rfsfAward; }
 
   public String getSfcAward() {
     return this.sfcAward; }
 
   public void setSfcAward(String sfcAward) {
     this.sfcAward = sfcAward; }
 
   public String getDxAward() {
     return this.dxAward; }
 
   public void setDxAward(String dxAward) {
     this.dxAward = dxAward; }
 
   public String getHostTreamRankings() {
     return this.hostTreamRankings; }
 
   public void setHostTreamRankings(String hostTreamRankings) {
     this.hostTreamRankings = hostTreamRankings; }
 
   public String getGuestTreamRankings() {
     return this.guestTreamRankings; }
 
   public void setGuestTreamRankings(String guestTreamRankings) {
     this.guestTreamRankings = guestTreamRankings; }
 
   public String getMeanSp() {
     return this.meanSp; }
 
   public void setMeanSp(String meanSp) {
     this.meanSp = meanSp;
   }
 }

