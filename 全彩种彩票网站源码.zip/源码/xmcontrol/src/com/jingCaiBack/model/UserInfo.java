 package com.jingCaiBack.model;
 
 public class UserInfo extends BaseModel
 {

	private String idCardNumber;// 身份证
    private String cardAccount;//银行名称
	private String bank;//银行卡号
	private String userTel;//联系电话
	private String userId;//用户编号
	private String userNickName;//用户昵称
	private String realName;//真实姓名
	private int loginTimes;//登陆次数--注意:user_login表中的字段
	private String supermanstatus;//来源编号
	private String sellUserName;//销售人员,
	private String  unionId ; //推荐用户注意:user_login表中的字段
	
	
	
	

	public String getSellUserName() {
		return sellUserName;
	}
	public void setSellUserName(String sellUserName) {
		this.sellUserName = sellUserName;
	}
	public String getSupermanstatus() {
		if(supermanstatus==null){
			return "111111";
		}
		return supermanstatus;
	}
	public void setSupermanstatus(String supermanstatus) {
		this.supermanstatus = supermanstatus;
	}
	
	public String getIdCardNumber() {
		if (idCardNumber==null){
			return "未填写";
		}
		return idCardNumber;
	}
	public void setIdCardNumber(String idCardNumber) {
		this.idCardNumber = idCardNumber;
	}
	public String getCardAccount() {
		if (cardAccount==null){
			return "未填写";
		}
		return cardAccount;
	}
	public void setCardAccount(String cardAccount) {
		this.cardAccount = cardAccount;
	}
	public String getBank() {
		if (bank==null){
			return "未填写";
		}
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getUserTel() {
		if (userTel==null){
			return "未填写";
		}
		return userTel;
	}
	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNickName() {
		if (userNickName==null){
			return "未填写";
		}
		return userNickName;
	}
	public void setUserNickName(String userNickName) {
		this.userNickName = userNickName;
	}
	public String getRealName() {
		if (realName==null){
			return "未填写";
		}
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public int getLoginTimes() {
		return loginTimes;
	}
	public void setLoginTimes(int loginTimes) {
		this.loginTimes = loginTimes;
	}
	public String getUnionId() {
		return unionId;
	}
	public void setUnionId(String unionId) {
		this.unionId = unionId;
	}
 }

