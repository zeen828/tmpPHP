package com.jingCaiBack.model;

public class Against extends BaseModel
{
  private static final long serialVersionUID = 1L;
  private int againstId;
  private String leagueName;
  private String leagueColor;
  private String againsthNum;
  private String hostTream;
  private String guestTream;
  private String concedeNum;
  private String smallType;
  private long stopselldate;
  private long dsstopTime;
  private long fsstopTime;
  private String hostBanChangBiFen;
  private String guestBanChangBiFen;
  private String hostQuanChangBiFen;
  private String guestQuanChangBiFen;
  private String sfcResults;
  private String rangQiuResults;
  private String biFenResults;
  private String zongJingQiuResults;
  private String banQuanResults;
  private String sfcGuoGuanResult;
  private String rangQiuguoGuanResult;
  private String biFenGuanResult;
  private String zongJingQiuGuanResult;
  private String banQuanGuanResult;
  private String sfcAward;
  private String rangQiuAward;
  private String biFenAward;
  private String zongJingQiuAward;
  private String banQuanAward;
  private String hostTreamRankings;
  private String guestTreamRankings;
  private String meanSp;
  private int proccessStatus;
  private String info;
  private int againstType;

  public int getAgainstId()
  {
     return this.againstId; }

  public void setAgainstId(int againstId) {
     this.againstId = againstId; }

  public String getLeagueName() {
     return this.leagueName; }

  public void setLeagueName(String leagueName) {
     this.leagueName = leagueName; }

  public String getLeagueColor() {
     return this.leagueColor; }

  public void setLeagueColor(String leagueColor) {
     this.leagueColor = leagueColor; }

  public String getAgainsthNum() {
     return this.againsthNum; }

  public void setAgainsthNum(String againsthNum) {
     this.againsthNum = againsthNum; }

  public String getHostTream() {
     return this.hostTream; }

  public void setHostTream(String hostTream) {
     this.hostTream = hostTream; }

  public String getGuestTream() {
     return this.guestTream; }

  public void setGuestTream(String guestTream) {
     this.guestTream = guestTream; }

  public String getConcedeNum() {
     return this.concedeNum; }

  public void setConcedeNum(String concedeNum) {
     this.concedeNum = concedeNum; }

  public String getSmallType() {
     return this.smallType; }

  public void setSmallType(String smallType) {
     this.smallType = smallType; }

  public long getStopselldate() {
     return this.stopselldate; }

  public void setStopselldate(long stopselldate) {
     this.stopselldate = stopselldate; }

  public long getDsstopTime() {
     return this.dsstopTime; }

  public void setDsstopTime(long dsstopTime) {
    this.dsstopTime = dsstopTime; }

  public long getFsstopTime() {
     return this.fsstopTime; }

  public void setFsstopTime(long fsstopTime) {
     this.fsstopTime = fsstopTime; }

  public String getHostBanChangBiFen() {
     return this.hostBanChangBiFen; }

  public void setHostBanChangBiFen(String hostBanChangBiFen) {
     this.hostBanChangBiFen = hostBanChangBiFen; }

  public String getGuestBanChangBiFen() {
     return this.guestBanChangBiFen; }

  public void setGuestBanChangBiFen(String guestBanChangBiFen) {
     this.guestBanChangBiFen = guestBanChangBiFen; }

  public String getHostQuanChangBiFen() {
    return this.hostQuanChangBiFen; }

  public void setHostQuanChangBiFen(String hostQuanChangBiFen) {
     this.hostQuanChangBiFen = hostQuanChangBiFen; }

  public String getGuestQuanChangBiFen() {
     return this.guestQuanChangBiFen; }

  public void setGuestQuanChangBiFen(String guestQuanChangBiFen) {
     this.guestQuanChangBiFen = guestQuanChangBiFen; }

  public String getRangQiuResults() {
     return this.rangQiuResults; }

  public void setRangQiuResults(String rangQiuResults) {
     this.rangQiuResults = rangQiuResults; }

  public String getBiFenResults() {
     return this.biFenResults; }

  public void setBiFenResults(String biFenResults) {
    this.biFenResults = biFenResults; }

  public String getZongJingQiuResults() {
     return this.zongJingQiuResults; }

  public void setZongJingQiuResults(String zongJingQiuResults) {
     this.zongJingQiuResults = zongJingQiuResults; }

  public String getBanQuanResults() {
     return this.banQuanResults; }

  public void setBanQuanResults(String banQuanResults) {
     this.banQuanResults = banQuanResults; }

  public String getRangQiuguoGuanResult() {
     return this.rangQiuguoGuanResult; }

  public void setRangQiuguoGuanResult(String rangQiuguoGuanResult) {
     this.rangQiuguoGuanResult = rangQiuguoGuanResult; }

  public String getBiFenGuanResult() {
     return this.biFenGuanResult; }

  public void setBiFenGuanResult(String biFenGuanResult) {
     this.biFenGuanResult = biFenGuanResult; }

  public String getZongJingQiuGuanResult() {
     return this.zongJingQiuGuanResult; }

  public void setZongJingQiuGuanResult(String zongJingQiuGuanResult) {
     this.zongJingQiuGuanResult = zongJingQiuGuanResult; }

  public String getBanQuanGuanResult() {
     return this.banQuanGuanResult; }

  public void setBanQuanGuanResult(String banQuanGuanResult) {
     this.banQuanGuanResult = banQuanGuanResult; }

  public String getRangQiuAward() {
     return this.rangQiuAward; }

  public void setRangQiuAward(String rangQiuAward) {
     this.rangQiuAward = rangQiuAward; }

  public String getBiFenAward() {
     return this.biFenAward; }

  public void setBiFenAward(String biFenAward) {
     this.biFenAward = biFenAward; }

  public String getZongJingQiuAward() {
     return this.zongJingQiuAward; }

  public void setZongJingQiuAward(String zongJingQiuAward) {
     this.zongJingQiuAward = zongJingQiuAward; }

  public String getBanQuanAward() {
     return this.banQuanAward; }

  public void setBanQuanAward(String banQuanAward) {
     this.banQuanAward = banQuanAward; }

  public int getProccessStatus() {
     return this.proccessStatus; }

  public void setProccessStatus(int proccessStatus) {
     this.proccessStatus = proccessStatus; }

  public String getInfo() {
     return this.info; }

  public void setInfo(String info) {
     this.info = info; }

  public int getAgainstType() {
     return this.againstType; }

  public void setAgainstType(int againstType) {
     this.againstType = againstType; }

  public String getSfcResults() {
     return this.sfcResults; }

  public void setSfcResults(String sfcResults) {
     this.sfcResults = sfcResults; }

  public String getSfcGuoGuanResult() {
     return this.sfcGuoGuanResult; }

  public void setSfcGuoGuanResult(String sfcGuoGuanResult) {
     this.sfcGuoGuanResult = sfcGuoGuanResult; }

  public String getSfcAward() {
     return this.sfcAward; }

  public void setSfcAward(String sfcAward) {
     this.sfcAward = sfcAward; }

  public String getHostTreamRankings() {
     return this.hostTreamRankings; }

  public void setHostTreamRankings(String hostTreamRankings) {
     this.hostTreamRankings = hostTreamRankings; }

  public String getGuestTreamRankings() {
    return this.guestTreamRankings; }

  public void setGuestTreamRankings(String guestTreamRankings) {
     this.guestTreamRankings = guestTreamRankings; }

  public String getMeanSp() {
     return this.meanSp; }

  public void setMeanSp(String meanSp) {
     this.meanSp = meanSp;
  }
}
