 package com.jingCaiBack.model;
 
 public class UserRate extends BaseModel
 {
   private int user_rateId;
   private int userId;
   private int gameCode;
   private int manner;
   private float rate;
   private int type;
   private transient String otherManner;
   private transient float nextLineRate;
 
   public int getUser_rateId()
   {
     return this.user_rateId; }
 
   public void setUser_rateId(int user_rateId) {
     this.user_rateId = user_rateId; }
 
   public int getUserId() {
     return this.userId; }
 
   public void setUserId(int userId) {
     this.userId = userId; }
 
   public int getGameCode() {
     return this.gameCode; }
 
   public void setGameCode(int gameCode) {
     this.gameCode = gameCode; }
 
   public int getManner() {
     return this.manner; }
 
   public void setManner(int manner) {
     this.manner = manner; }
 
   public float getRate() {
     return this.rate; }
 
   public void setRate(float rate) {
     this.rate = rate; }
 
   public int getType() {
     return this.type; }
 
   public void setType(int type) {
     this.type = type; }
 
   public float getNextLineRate() {
     return this.nextLineRate; }
 
   public void setNextLineRate(float nextLineRate) {
     this.nextLineRate = nextLineRate; }
 
   public String getOtherManner() {
     return this.otherManner; }
 
   public void setOtherManner(String otherManner) {
     this.otherManner = otherManner;
   }
 }
