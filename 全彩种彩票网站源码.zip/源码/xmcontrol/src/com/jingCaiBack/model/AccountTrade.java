package com.jingCaiBack.model;

public class AccountTrade extends BaseModel
{
  private int tradeId;
  private String serialNo;
  private String fromSerialNo;
  private int userId;
  private String tradeType;
  private String tradeTime;
  private double inCome;
  private double payOut;
  private int charge;
  private double balance;
  private int sourceId;
private String unionId ;//推荐用户 --- 注意， 是user_login表中的字段
  
  public int getTradeId()
  {
     return this.tradeId; }

  public void setTradeId(int tradeId) {
     this.tradeId = tradeId; }

  public String getSerialNo() {
     return this.serialNo; }

  public void setSerialNo(String serialNo) {
    this.serialNo = serialNo; }

  public String getFromSerialNo() {
     return this.fromSerialNo; }

  public void setFromSerialNo(String fromSerialNo) {
     this.fromSerialNo = fromSerialNo; }

  public int getUserId() {
     return this.userId; }

  public void setUserId(int userId) {
     this.userId = userId; }

  public String getTradeType() {
     return this.tradeType; }

  public void setTradeType(String tradeType) {
     this.tradeType = tradeType; }

  public String getTradeTime() {
     return this.tradeTime; }

  public void setTradeTime(String tradeTime) {
     this.tradeTime = tradeTime; }

  public double getInCome() {
     return this.inCome; }

  public void setInCome(double inCome) {
     this.inCome = inCome; }

  public double getPayOut() {
     return this.payOut; }

  public void setPayOut(double payOut) {
     this.payOut = payOut; }

  public int getCharge() {
    return this.charge; }

  public void setCharge(int charge) {
     this.charge = charge; }

  public double getBalance() {
     return this.balance; }

  public void setBalance(double balance) {
     this.balance = balance; }

  public int getSourceId() {
     return this.sourceId; }

  public void setSourceId(int sourceId) {
     this.sourceId = sourceId;
  }

public String getUnionId() {
	return unionId;
}

public void setUnionId(String unionId) {
	this.unionId = unionId;
}
  
}
