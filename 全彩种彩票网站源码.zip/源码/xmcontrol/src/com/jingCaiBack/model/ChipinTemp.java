package com.jingCaiBack.model;

public class ChipinTemp extends BaseModel
{
  private long tempId;
  private String serialNo;
  private String userNickName;
  private int gameCode;
  private String manner;
  private int record;
  private int multiple;
  private int bets;
  private String chipinNums;
  private String spValue; 
  private String voteProccessTime;//最后一次打印时间
  private double tempAwardBets;//中奖金额


  public double getTempAwardBets() {
	return tempAwardBets;
  }

 public void setTempAwardBets(double tempAwardBets) {
	this.tempAwardBets = tempAwardBets;
 }

 public long getTempId()
  {
     return this.tempId; }

  public void setTempId(long tempId) {
     this.tempId = tempId; }

  public String getSerialNo() {
     return this.serialNo; }

  public void setSerialNo(String serialNo) {
     this.serialNo = serialNo; }

  public String getUserNickName() {
     return this.userNickName; }

  public void setUserNickName(String userNickName) {
     this.userNickName = userNickName; }

  public int getGameCode() {
     return this.gameCode; }

  public void setGameCode(int gameCode) {
     this.gameCode = gameCode; }

  public String getManner() {
     return this.manner; }

  public void setManner(String manner) {
     this.manner = manner; }

  public int getRecord() {
     return this.record; }

  public void setRecord(int record) {
     this.record = record; }

  public int getMultiple() {
     return this.multiple; }

  public void setMultiple(int multiple) {
     this.multiple = multiple; }

  public int getBets() {
     return this.bets; }

  public void setBets(int bets) {
     this.bets = bets; }

  public String getChipinNums() {
     return this.chipinNums; }

  public void setChipinNums(String chipinNums) {
     this.chipinNums = chipinNums; }

  public String getSpValue() {
     return this.spValue; }

  public void setSpValue(String spValue) {
     this.spValue = spValue; }

public String getVoteProccessTime() {
	return voteProccessTime;
}

public void setVoteProccessTime(String voteProccessTime) {
	this.voteProccessTime = voteProccessTime;
}

 
  

}
