package com.jingCaiBack.model;

public class Hmfa extends BaseModel
{
  private long hmfaId;
  private String serialNo;
  private String userNickName;
  private int lotName;
  private String manner;
  private int money;
  private int multiple;
  private long fqTime;
  private String chipinNums;
  private int checkStatus;

  public long getHmfaId()
  {
     return this.hmfaId; }

  public void setHmfaId(long hmfaId) {
     this.hmfaId = hmfaId; }

  public String getSerialNo() {
     return this.serialNo; }

  public void setSerialNo(String serialNo) {
     this.serialNo = serialNo; }

  public String getUserNickName() {
     return this.userNickName; }

  public void setUserNickName(String userNickName) {
     this.userNickName = userNickName; }

  public int getLotName() {
     return this.lotName; }

  public void setLotName(int lotName) {
     this.lotName = lotName; }

  public String getManner() {
     return this.manner; }

  public void setManner(String manner) {
     this.manner = manner; }

  public int getMoney() {
     return this.money; }

  public void setMoney(int money) {
     this.money = money; }

  public int getMultiple() {
     return this.multiple; }

  public void setMultiple(int multiple) {
    this.multiple = multiple; }

  public long getFqTime() {
     return this.fqTime; }

  public void setFqTime(long fqTime) {
     this.fqTime = fqTime; }

  public String getChipinNums() {
     return this.chipinNums; }

  public void setChipinNums(String chipinNums) {
     this.chipinNums = chipinNums; }

  public int getCheckStatus() {
     return this.checkStatus; }

  public void setCheckStatus(int checkStatus) {
     this.checkStatus = checkStatus;
  }
}
