 package com.jingCaiBack.model;
 
 public class UserAccount extends BaseModel
 {
   private int userId;
   private double balance;
   private double awardBets;
   private double freezedMoney;
   private double bets;
   private double letou;
   private double freezedLetou;
   private long version;
   private long createTime;
 
   public int getUserId()
   {
     return this.userId; }
 
   public void setUserId(int userId) {
     this.userId = userId; }
 
   public double getBalance() {
     return this.balance; }
 
   public void setBalance(double balance) {
     this.balance = balance; }
 
   public double getBets() {
     return this.bets; }
 
   public void setBets(double bets) {
     this.bets = bets; }
 
   public double getAwardBets() {
     return this.awardBets; }
 
   public void setAwardBets(double awardBets) {
     this.awardBets = awardBets; }
 
   public double getFreezedMoney() {
     return this.freezedMoney; }
 
   public void setFreezedMoney(double freezedMoney) {
     this.freezedMoney = freezedMoney; }
 
   public double getLetou() {
     return this.letou; }
 
   public void setLetou(double letou) {
     this.letou = letou; }
 
   public double getFreezedLetou() {
     return this.freezedLetou; }
 
   public void setFreezedLetou(double freezedLetou) {
     this.freezedLetou = freezedLetou; }
 
   public long getVersion() {
     return this.version; }
 
   public void setVersion(long version) {
     this.version = version; }
 
   public long getCreateTime() {
     return this.createTime; }
 
   public void setCreateTime(long createTime) {
     this.createTime = createTime;
   }
 }

