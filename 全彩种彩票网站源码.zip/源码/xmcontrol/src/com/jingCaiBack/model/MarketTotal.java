 package com.jingCaiBack.model;
 
 public class MarketTotal extends BaseModel
 {
   private static final long serialVersionUID = 1L;
   private int count;
   private double betSum;
   private double awardSum;
   private double bankChargeSum;
   private double handChargeSum;
   private double betRebateSum;
   private double onLineRebateSum;
   private double carrySum;
   private double schemeRebateSum;
   private double activitySum;
   private double userMoneySum;
 
   public int getCount()
   {
     return this.count; }
 
   public void setCount(int count) {
     this.count = count; }
 
   public double getBetSum() {
     return this.betSum; }
 
   public void setBetSum(double betSum) {
     this.betSum = betSum; }
 
   public double getAwardSum() {
     return this.awardSum; }
 
   public void setAwardSum(double awardSum) {
     this.awardSum = awardSum; }
 
   public double getBankChargeSum() {
     return this.bankChargeSum; }
 
   public void setBankChargeSum(double bankChargeSum) {
     this.bankChargeSum = bankChargeSum; }
 
   public double getHandChargeSum() {
     return this.handChargeSum; }
 
   public void setHandChargeSum(double handChargeSum) {
     this.handChargeSum = handChargeSum; }
 
   public double getBetRebateSum() {
     return this.betRebateSum; }
 
   public void setBetRebateSum(double betRebateSum) {
     this.betRebateSum = betRebateSum; }
 
   public double getOnLineRebateSum() {
     return this.onLineRebateSum; }
 
   public void setOnLineRebateSum(double onLineRebateSum) {
     this.onLineRebateSum = onLineRebateSum; }
 
   public double getCarrySum() {
     return this.carrySum; }
 
   public void setCarrySum(double carrySum) {
     this.carrySum = carrySum; }
 
   public double getSchemeRebateSum() {
     return this.schemeRebateSum; }
 
   public void setSchemeRebateSum(double schemeRebateSum) {
     this.schemeRebateSum = schemeRebateSum; }
 
   public double getActivitySum() {
     return this.activitySum; }
 
   public void setActivitySum(double activitySum) {
     this.activitySum = activitySum; }
 
   public double getUserMoneySum() {
     return this.userMoneySum; }
 
   public void setUserMoneySum(double userMoneySum) {
     this.userMoneySum = userMoneySum;
   }
 }
