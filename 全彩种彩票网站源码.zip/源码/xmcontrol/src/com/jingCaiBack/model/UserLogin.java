 package com.jingCaiBack.model;
 
 public class UserLogin extends BaseModel
 {
   private int loginId;
   private int userId;
   private String loginName;
   private String userPassWord;
   private int type;
   private String activityIds;
   private String userNickName;
   private String registerTime;//注册时间
   private String sourceId;//客户端类型
   
 


public String getSourceId() {
	return sourceId;
}

public void setSourceId(String sourceId) {
	this.sourceId = sourceId;
}

public String getRegisterTime() {
	return registerTime;
}

public void setRegisterTime(String registerTime) {
	this.registerTime = registerTime;
}

public String getUserNickName() {
	return userNickName;
}

public void setUserNickName(String userNickName) {
	this.userNickName = userNickName;
}

public int getLoginId()
   {
     return this.loginId; }
 
   public void setLoginId(int loginId) {
     this.loginId = loginId; }
 
   public int getUserId() {
     return this.userId; }
 
   public void setUserId(int userId) {
     this.userId = userId; }
 
   public String getLoginName() {
     return this.loginName; }
 
   public void setLoginName(String loginName) {
     this.loginName = loginName; }
 
   public String getUserPassWord() {
     return this.userPassWord; }
 
   public void setUserPassWord(String userPassWord) {
     this.userPassWord = userPassWord; }
 
   public int getType() {
     return this.type; }
 
   public void setType(int type) {
     this.type = type; }
 
   public String getActivityIds() {
     return this.activityIds; }
 
   public void setActivityIds(String activityIds) {
     this.activityIds = activityIds;
   }
 }

