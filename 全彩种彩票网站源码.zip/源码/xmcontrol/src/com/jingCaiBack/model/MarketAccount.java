 package com.jingCaiBack.model;
 
 public class MarketAccount extends BaseModel
 {
   private int marketId;
   private long createTime;
   private double bet;
   private double award;
   private double bankCharge;
   private double handCharge;
   private double betRebate;
   private double onLineRebate;
   private double carry;
   private double schemeRebate;
   private double activity;
   private double userMoney;
 
   public int getMarketId()
   {
     return this.marketId; }
 
   public void setMarketId(int marketId) {
     this.marketId = marketId; }
 
   public long getCreateTime() {
     return this.createTime; }
 
   public void setCreateTime(long createTime) {
     this.createTime = createTime; }
 
   public double getBet() {
     return this.bet; }
 
   public void setBet(double bet) {
     this.bet = bet; }
 
   public double getAward() {
     return this.award; }
 
   public void setAward(double award) {
     this.award = award; }
 
   public double getBankCharge() {
     return this.bankCharge; }
 
   public void setBankCharge(double bankCharge) {
     this.bankCharge = bankCharge; }
 
   public double getHandCharge() {
     return this.handCharge; }
 
   public void setHandCharge(double handCharge) {
     this.handCharge = handCharge; }
 
   public double getBetRebate() {
     return this.betRebate; }
 
   public void setBetRebate(double betRebate) {
     this.betRebate = betRebate; }
 
   public double getOnLineRebate() {
     return this.onLineRebate; }
 
   public void setOnLineRebate(double onLineRebate) {
     this.onLineRebate = onLineRebate; }
 
   public double getCarry() {
     return this.carry; }
 
   public void setCarry(double carry) {
     this.carry = carry; }
 
   public double getSchemeRebate() {
     return this.schemeRebate; }
 
   public void setSchemeRebate(double schemeRebate) {
     this.schemeRebate = schemeRebate; }
 
   public double getActivity() {
     return this.activity; }
 
   public void setActivity(double activity) {
     this.activity = activity; }
 
   public double getUserMoney() {
     return this.userMoney; }
 
   public void setUserMoney(double userMoney) {
     this.userMoney = userMoney;
   }
 }

