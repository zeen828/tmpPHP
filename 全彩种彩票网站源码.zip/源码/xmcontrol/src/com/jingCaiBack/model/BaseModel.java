package com.jingCaiBack.model;

import java.io.Serializable;

public abstract class BaseModel
  implements Serializable
{
  private static final long serialVersionUID = 6354895930673801990L;
}
