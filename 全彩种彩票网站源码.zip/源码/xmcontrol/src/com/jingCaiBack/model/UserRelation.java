 package com.jingCaiBack.model;
 
 public class UserRelation extends BaseModel
 {
   private int userId;
   private int nextLineId;
   private String nextLineName;
 
   public int getUserId()
   {
     return this.userId; }
 
   public void setUserId(int userId) {
     this.userId = userId; }
 
   public int getNextLineId() {
     return this.nextLineId; }
 
   public void setNextLineId(int nextLineId) {
     this.nextLineId = nextLineId; }
 
   public String getNextLineName() {
     return this.nextLineName; }
 
   public void setNextLineName(String nextLineName) {
     this.nextLineName = nextLineName;
   }
 }
