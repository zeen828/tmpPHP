package com.jingCaiBack.model;

public class Activity extends BaseModel
{
  private int activityId;
  private String name;
  private String beginTime;
  private String endTime;

  public int getActivityId()
  {
     return this.activityId; }

  public void setActivityId(int activityId) {
     this.activityId = activityId; }

  public String getName() {
     return this.name; }

  public void setName(String name) {
     this.name = name; }

  public String getBeginTime() {
     return this.beginTime; }

  public void setBeginTime(String beginTime) {
     this.beginTime = beginTime; }

  public String getEndTime() {
     return this.endTime; }

  public void setEndTime(String endTime) {
     this.endTime = endTime;
  }
}
