/**
* AJAX���������ú󣬷���һ���ַ���
*/
var http;
var type;

function ajax(url){
	http=getXmlHttpRequest();
	
	http.open("post",url,true);
	
	if(type=="1"){
		alert("xx");
		http.onreadystatechange = rrr;
	}else{
		alert("xx2");
		http.onload = rrr;
    	http.onerror = rrr;
	}
	http.send();
	
	//return unescape(http.responseText);	
}

function rrr(){
	alert(http.readyState);
	if(type=="1"){
		alert(http.readyState);
		if(http.readyState == 4){
			alert(http.responseText);
		}

	}else{
		alert(http.responseText);
	}
	
}

//������������ͣ�����xmlhttp����
function getXmlHttpRequest(){
	var xmlhttp=null;  
	
	
	if (window.ActiveXObject){  
		try{  
        	xmlhttp = new ActiveXObject("Msxml2.XMLHTTP.5.0");
   		}catch(e){  
        	try{  
            	xmlhttp = new ActiveXObject("Msxml2.XMLHTTP.4.0")  
        	}catch(e){  
            	try{  
                	new ActiveXObject("Msxml2.XMLHTTP")  
           		}catch(e){  
                	try{
						new ActiveXObject("Microsoft.XMLHTTP")
					}catch(e){
						
					}  
            	}  
        	}  
    	}
		
		type = "1";
	}  
	
	if (!xmlhttp&&window.XMLHttpRequest) {  
		xmlhttp = new XMLHttpRequest();  
		type = "2";
	}  
	
	if(!xmlhttp){
		alert("XMLHTTP������! ����ϵ��վ������Ա��")
	}
	
	return xmlhttp;
}