function init(objName,value){
	//ȡ�ö��������
	var type = this.document.getElementById(objName).type;
	
	if(type=="text" || type =="textarea" || type == "hidden"){
		inputInit(objName,value);
	}else if(type=="checkbox"){
		checkBoxInit(objName,value);
	}else if(type=="radio"){
		radioGuoupInit(objName,value);
	}else if(type=="select-one"){
		selectInit(objName,value);
	}else if(type=="select-multiple"){
		selectInit(objName,value);
	}
}

//֧�ְ�Ƕ���
function selectInit(selectElementID,selectedForValue){
	//�����Ϸ��Լ���
	if(null==selectElementID||null==selectedForValue){
		return;	
	}
	
	var selValueArray = selectedForValue.split(",");
	var selectObj = this.document.getElementById(selectElementID);
	if(null==selectObj||selectedForValue==""){
		return;
	}
	
	var selectLength = selectObj.length;
	for(var a=0;a<selValueArray.length;a++){
		for (var i = 0; i<selectLength ; i++){
			if (selectObj[i].value == selValueArray[a]){
				selectObj[i].selected  = true ;
			}
		}
	}
}

function radioGuoupInit(radioElementName,checkedForValue){
	var radioObj = document.getElementsByName(radioElementName);
	var radioLength = radioObj.length;
	//alert(radioLength+"\n"+radioElementName+"\n"+checkedForValue);
	for (var i = 0; i<radioLength ; i ++){
		if (radioObj[i].value == checkedForValue){
			radioObj[i].checked  = true ;
		}
	}
}

//checkedForValue֧�ְ�Ƕ���
function checkBoxInit(checkBoxElementName,checkedForValue){
	var checkBoxObj = document.getElementsByName(checkBoxElementName);
	var checkedForValueArray = checkedForValue.split(",");
	for(var m=0;m<checkBoxObj.length;m++){
		var isChecked = false;
		for(var n=0;n<checkedForValueArray.length;n++){
			if(checkBoxObj[m].value==checkedForValueArray[n]){
				isChecked = true;
				break;
			}
		}
		if(isChecked){
			checkBoxObj[m].checked  = true ;
		}
	}
}

function displayCtrlInit(elementID,value,condition){
	var e = this.document.getElementById(elementID);
	if (condition == value){
		e.style.display = "";
	}else{
		e.style.display = "none";
	}
}


function displayOrHide(elementID){
	var e = this.document.getElementById(elementID);
	if (e.style.display == ""){
		e.style.display = "none";
	}else{
		e.style.display = "";
	}
}


function inputInit(elementID,value){
	var obj = this.document.getElementById(elementID);
	obj.value = value;
}

//Ԥ����ͼƬ
//imagesStrΪ,�ָ����ַ���
function loadImages(imagesStr){
	
	var imagesArray = imagesStr.split(",");
	
	var image = new Image();
	
	for(var i = 0;i<imagesArray.length;i++){
		image.src = imagesArray[i];
	}
	
}
