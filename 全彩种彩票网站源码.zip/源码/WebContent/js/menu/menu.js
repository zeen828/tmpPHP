// �˵�����
var sMenuHr="<tr><td align=left valign=middle height=2><TABLE border=0 cellpadding=0 cellspacing=0 width=90 height=2><tr><td height=1 class=HrShadow><\/td><\/tr><tr><td height=1 class=HrHighLight><\/td><\/tr><\/TABLE><\/td><\/tr>";
var sMenu1="<TABLE border=0 cellpadding=0 cellspacing=0 class=Menu width=140><tr><td width=18 valign=bottom align=center style='background:url(../../../admin/editor/Include/sysimage/contextmenu.gif);background-position:bottom;'><\/td><td width=70 class=RightBg><TABLE border=0 cellpadding=0 cellspacing=0>";

var StyleMenuHeader = "<head><link href=\"../skin/blue/css/menu/context_menu.css\" type=\"text/css\" rel=\"stylesheet\"></head><body scroll=\"no\" onConTextMenu=\"event.returnValue=false;\">";

var sMenu2="<\/TABLE><\/td><\/tr><\/TABLE>";

// �˵�
var oPopupMenu = null;
oPopupMenu = window.createPopup();

// ȡ�˵���
function getMenuRow(s_Disabled, s_Event, s_Image, s_Html) {
	var s_MenuRow = "";
	s_MenuRow = "<tr><td align=left valign=middle><TABLE border=0 cellpadding=0 cellspacing=0 width=132><tr "+s_Disabled+"><td valign=middle height=20 class=MouseOut onMouseOver=this.className='MouseOver'; onMouseOut=this.className='MouseOut';";
	if (s_Disabled==""){
		s_MenuRow += " onclick=\"parent."+s_Event+";parent.oPopupMenu.hide();\"";
	}
	s_MenuRow += ">"
	if (s_Image !=""){
		s_MenuRow += "&nbsp;<img border=0 src='' width=0 height=0 align=absmiddle "+s_Disabled+">";
	}else{
		s_MenuRow += "&nbsp;";
	}
	s_MenuRow += s_Html+"<\/td><\/tr><\/TABLE><\/td><\/tr>";
	return s_MenuRow;

}

// ȡ��׼��format�˵���
function getFormatMenuRow(menu, html, image){
	var s_Disabled = "";
	//if (!eWebEditor.document.queryCommandEnabled(menu)){
	//	s_Disabled = "disabled";
	//}
	var s_Event = "format('"+menu+"')";
	var s_Image = menu+".gif";
	if (image){
		s_Image = image;
	}
	return getMenuRow(s_Disabled, s_Event, s_Image, html)
}