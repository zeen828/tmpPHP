// JavaScript Document
$(function(){
	var sw = 1;
	$("#banner .num a").mouseover(function(){
		sw = $(".num a").index(this);
		myShow(sw);
	});
	function myShow(i){
		$("#banner .num a").eq(i).addClass("cur").siblings("a").removeClass("cur");
		$("#banner ul li").eq(i).stop(true,true).fadeIn(600).siblings("li").fadeOut(600);
		$("#banner ol li").eq(i).stop(true,true).fadeIn(600).siblings("li").fadeOut(600);
	}
	//����ֹͣ������������ʼ����
	$("#banner").hover(function(){
		if(myTime){
		   clearInterval(myTime);
		}
	},function(){
		myTime = setInterval(function(){
		  myShow(sw)
		  sw++;
		  if(sw==5){sw=0;}
		} , 5000);
	});
	//�Զ���ʼ
	var myTime = setInterval(function(){
	   myShow(sw)
	   sw++;
	   if(sw==5){sw=0;}
	} , 3500);
})