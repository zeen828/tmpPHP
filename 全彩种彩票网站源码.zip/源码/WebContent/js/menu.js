
$(document).ready(function(){
	$(".menu li").hover(function(){
			$(this).addClass("hover");
			$(this).children("ul").show();
			$(".menu li ul li").removeClass("hover");
		},function(){
			$(this).removeClass("hover");
			$(this).children("ul").hide();
			$(".menu li ul li").removeClass("hover");
		}
	); 
	
})