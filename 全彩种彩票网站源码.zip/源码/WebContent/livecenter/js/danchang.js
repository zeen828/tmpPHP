

function showdata(){
	var cookiestr  ='' , zbool = false,fbool = false;
	var time = $('#sel_expert').val();
	$.getJSON("../letoula/data/result_footballdcbifen.jsp?r="+Math.random(),{'time':time},function(items){
		items = items.items;
		var cookieList = setting.GetCookie('dcbifen');
		$('.sy').empty();
    	var tr = '';
    	$('.jinqiu').hide();			
		for(var i =0; i < items.length; i++){
			cookiestr += items[i].bid+"|"+items[i].qcbifen+"|"+items[i].hostred+"|"+items[i].guestred+",";
			var sp = items[i].sp.split("|");
			var reg = /[0-90]/;
			var trcolor = ((i+1) % 2) == 0 ? "rgb(233, 243, 255)" : "#ffffff";
			var refaImg = reg.test(items[i].nowtext) ? '<img src="'+url+'/livecenter/img/time.gif" />' : '';
			var caiguotext = '<span>'+sp[0]+'</span><span>'+sp[1]+'</span><span>'+sp[2]+'</span>' , qcbifen = items[i].qcbifen.split("-") , rangqiu = '' , ztdc='',ftdc='';
			if(items[i].qcbifen.length >= 3){
				if(cookieList  && cookieList!=''){
					if(typeof(cookieList) != 'object'){
						cookieList = cookieList.split(",");
					}
					if(cookieList.length > 3){
						var list = cookieList[i].split("|");
						if(items[i].bid==list[0]){
							if(items[i].qcbifen != list[1]){
								qb = list[1].split("-");
								if(document.getElementById('jqtc').checked){
									var jq = "" , imgs_l = "" , imgs_r = "";
									if(qcbifen[0] != qb[0]){
										jq = '<em class="scoreSuccess">'+qcbifen[0]+'</em><em class="q_b_f">-</em><em>'+qcbifen[1]+'</em>';
										imgs_l = '<img src="'+url+'/livecenter/img/jinqiu_l.gif" width="100" height="25" />';
										ztdc="ywl";
									}else if(qcbifen[1] != qb[1]){
										jq = '<em>'+qcbifen[0]+'</em><em class="q_b_f">-</em><em class="scoreSuccess">'+qcbifen[1]+'</em>';
										imgs_r = '<img src="'+url+'/livecenter/img/jinqiu_r.gif" width="100" height="25" />';
										ftdc="ywl";
									}
									var tables = '<table width="100%" id="score_event_list" border="0" cellspacing="0" cellpadding="0">'+
    										  '<tr><td colspan="2" class="tdone">'+items[i].marketName+'</td></tr>'+
    										  '<tr><td colspan="2"><span class="d_name">'+items[i].hostName+'</span><span class="q_b">'+jq+'</span><span class="d_name">'+items[i].guestName+'</span></td></tr>'+
    										  '<tr><td class="toright" width="160">'+imgs_l+'</td><td class="toleft" width="160">'+imgs_r+'</td></tr>'+
    										  '</table>';
    										  
									var off = $('#tr_'+items[i].bid+' > .toright').offset();
									$('.jinqiu').html(tables).show().css({"left":off.left,"top":off.top+26});
								}
								if(document.getElementById('jqs').checked){
									$('.sy').html('<audio src="'+url+'/livecenter/img/493.mp3" autoplay="true" playcount="-1"></audio>');
								}
							}
							
							if((items[i].hostred!=list[2] && items[i].hostred!=' ') || (items[i].guestred!=list[3] && items[i].guestred!=' ')){
								if(document.getElementById('hps').checked){
									$('.sy').html('<audio src="'+url+'/livecenter/img/494.WAV" autoplay="true" playcount="-1"></audio>');
								}
								if(items[i].hostred!=list[2]) ztdc="ywl";
								else if(items[i].guestred!=list[3]) ftdc="ywl";
							}
						}
					}
					
				}
				
				var rq = items[i].rangqiu.replace(/[()]/g,"");
				if(rq < 0){
					qcbifen[0] = parseInt(qcbifen[0])+parseInt(rq);
				}else if(rq > 0){
					qcbifen[1] = parseInt(qcbifen[1])+parseInt(rq);
				}
				
				items[i].qcbifen = '<b class="font_red">'+items[i].qcbifen+'</b>';
				if(qcbifen[0] > qcbifen[1]){
					caiguotext = '<span class="sps">'+sp[0]+'</span><span>'+sp[1]+'</span><span>'+sp[2]+'</span>';
				}else if(qcbifen[0] == qcbifen[1]){
					caiguotext = '<span>'+sp[0]+'</span><span class="spp">'+sp[1]+'</span><span>'+sp[2]+'</span>';
				}else if(qcbifen[0] < qcbifen[1]){
					caiguotext = '<span>'+sp[0]+'</span><span>'+sp[1]+'</span><span class="spf">'+sp[2]+'</span>';
				}
			}
			if(items[i].bcbifen.length >= 3 && items[i].nowtext.indexOf('完') != '-1'){
				items[i].bcbifen = '<span class="font_red">'+items[i].bcbifen+'</span>';
				items[i].caiguo = '<b class="font_red">'+items[i].caiguo+'</b>';
			}else if(items[i].bcbifen.length >= 3){
				items[i].bcbifen = '<span class="font_blue">'+items[i].bcbifen+'</span>';
				items[i].caiguo = '<b class="font_blue">'+items[i].caiguo+'</b>';
			}
			if(items[i].rangqiu!=0){
				rangqiu = '<span class="font_red">'+items[i].rangqiu+'</font>';
			}else{
				rangqiu = '';
			}
			var hredpai = '' , gredpai ='';
			if(items[i].hostred!=' '){
				hredpai = 'redpai';
			}
			if(items[i].guestred!=' '){
				gredpai = 'redpai';
			}
			items[i].img = items[i].img.substring(items[i].img.lastIndexOf('/')+1,items[i].img.length);
			var img = items[i].img.indexOf('gif') != -1 ? '<img title="'+items[i].tq+'" src="'+url+'/livecenter/img/'+items[i].img+'">' : '';
			tr+='<tr id="tr_'+items[i].bid+'" style="background-color:'+trcolor+'"><td>'+items[i].seriano+'</td><td style="background-color:'+items[i].color+';color:#fff">'+items[i].marketName+'</td>'+
				'<td>'+setting.axyformatTime(items[i].startime)+'</td><td>'+items[i].nowtext+refaImg+'</td><td class="'+ztdc+' toright"><span class="'+hredpai+'">'+items[i].hostred+'</span>'+items[i].hostName+rangqiu+'</td>'+
				'<td>'+items[i].qcbifen+'</td><td class="'+ftdc+' toleft">'+items[i].guestName+'<span class="'+gredpai+'">'+items[i].guestred+'</span></td><td>'+items[i].bcbifen+'</td>'+
				'<td>'+img+'</td><td class="sptd">'+caiguotext+'</td>'+
				'<td>'+items[i].caiguo+'</td></tr>';
				
		}
		cookiestr = cookiestr.substring(0,cookiestr.length-1);
		$('.dc_body').html(tr);
		setting.SetCookie('dcbifen',cookiestr);
	});
	
	setTimeout('showdata()',5000);
}


function selOnchange(){
	combin_loadMain();
}

function combin_loadMain(){
	setting.SetCookie('dcbifen','');
 	showdata();
}
$(function(){
	combin_loadMain();
});
