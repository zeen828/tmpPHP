

function showdata(){
	var cookiestr  ='' , fh = "~";
	var time = $('#sel_expert').val();
	$.getJSON("../letoula/data/result_baskedballbifen.jsp?r="+Math.random(),{'time':time},function(items){
		items = items.items;
		var cookieList = setting.GetCookie('lanqiubifen');
		$('.jinqiu').hide();
    	var table = '';
		for(var i =0; i < items.length; i++){
				
				var ztdc='',ftdc='',zongfen='',status = parseInt(items[i].status.replace(/\\s/g,""));
				if(cookieList  && cookieList!=''){
					if(typeof(cookieList) != 'object'){
						cookieList = cookieList.split(",");
					}
					if(cookieList.length > 3){
						var list = cookieList[i].split("|");
						if(items[i].bid==list[0]){
							if(items[i].zhubifen != list[1] || items[i].kebifen != list[2]){
								var qb0 = list[1],qb1 = list[2];
								if(document.getElementById('jqs').checked){
									$('.sy').html('<audio src="'+url+'+/livecenter/img/493.mp3" autoplay="true" playcount="-1"></audio>');
								}
								if(items[i].zhubifen != list[1]) ztdc="ywl";
								else if(items[i].kebifen != list[2]) ftdc="ywl";
							}
						}
					}
					
				}
				if(items[i].status!='未开始' && items[i].status!='完'){
					var status = items[i].status.split(' ');
					items[i].status = ""+status[0]+"  <font color='red'>" + status[1] +"</font>";
				}
				var kejie = items[i].kejie.split("~"),zhujie = items[i].zhujie.split("~");
				if(items[i].kebifen!=' ' && items[i].zhubifen!=' '){
					zongfen = parseInt(items[i].kebifen) + parseInt(items[i].zhubifen);
				}
				if(items[i].nowtext==' '){
					items[i].nowtext = ".";
				}
				var sfsp = splitAry(items[i].sfsp,fh),rfsfsp = items[i].rfsfsp.split('~'),dxfsp = items[i].dxfsp.split('~');
				var dxfsp1 = dxfsp[1] + "   小分："+ dxfsp[2];
				var keduibifen = parseInt(kejie[0])+parseInt(kejie[1])+parseInt(kejie[2])+parseInt(kejie[3]);
				var zhuduibifen = parseInt(zhujie[0])+parseInt(zhujie[1])+parseInt(zhujie[2])+parseInt(zhujie[3]);
				var quanchangbifen = keduibifen + zhuduibifen;
				keduibifen = keduibifen ? keduibifen : '';
				zhuduibifen = zhuduibifen ? zhuduibifen : '';
				quanchangbifen = quanchangbifen ? quanchangbifen : '';
				table+='<table class="BoxTable" width="100%" cellspacing="0" cellpadding="0">'+
					   '<tr class="tr0_'+items[i].bid+'"><th   style="background-color:'+items[i].color+'">'+items[i].marketname+'</th><th width="130">'+items[i].status+'</th>'+
					   '<th>一节</th><th>二节</th><th>三节</th><th>四节</th><th width="48">全场</th><th width="48">总分</th><th width="55">胜负</th><th width="100">让分胜负</th><th width="125">大小分</th><th colspan="2">其他</th></tr>'+
					   
					   '<tr class="tr1_'+items[i].bid+'"><td>'+items[i].seriano+'</td><td>'+items[i].guestname+'</td><td>'+kejie[0]+'</td><td>'+kejie[1]+'</td>'+
					   '<td>'+kejie[2]+'</td><td>'+kejie[3]+'</td><td class="'+ftdc+'"><b class="font_red">'+keduibifen+'</b></td><td rowspan="2">'+quanchangbifen+'</td><td>'+sfsp[0]+'</td>'+
					   '<td align="right"><span style="float:right;margin-right:10px;">'+rfsfsp[0]+'</span></td><td align="right">大分：'+dxfsp[0]+'</td><td><a class="ou" href="http://info.sporttery.com/basketball/info/bk_match_mnl.php?m='+items[i].mid+'" target="_blank">欧</a></td><td><a class="xi" href="http://info.sporttery.com/basketball/info/bk_match_info.php?m='+items[i].mid+'" target="_blank">析</a></td></tr>'+
					   
					   '<tr class="tr2_'+items[i].bid+'"><td>'+setting.axyformatTime(items[i].startime)+'</td><td>'+items[i].hostname+'[主]</td><td>'+zhujie[0]+'</td><td>'+zhujie[1]+'</td>'+
					   '<td>'+zhujie[2]+'</td><td>'+zhujie[3]+'</td><td class="'+ztdc+'"><b class="font_red">'+zhuduibifen+'</b></td><td>'+sfsp[1]+'</td>'+
					   '<td align="right"><span style="float:left;margin-left:10px;">'+rfsfsp[1]+'</span><span style="float:right;margin-right:10px;">'+rfsfsp[2]+'</span></td><td align="right">'+dxfsp1+'</td><td><a class="xun" href="http://info.sporttery.com/basketball/info/bk_match_news.php?m='+items[i].mid+'" target="_blank">讯</a></td><td><a class="cha" href="http://info.sporttery.com/basketball/hdc_odds.php?mid='+items[i].mid+'" target="_blank">查</a></td></tr>'+
					   
					   '<tr class="tr3_'+items[i].bid+'"><td class="beizhu" colspan="13">'+items[i].nowtext+'</td></tr></table>'
					   
			cookiestr += items[i].bid+"|"+items[i].zhubifen+"|"+items[i].kebifen+",";
				
		}
		cookiestr = cookiestr.substring(0,cookiestr.length-1);
		$('.bfmain').html(table);
		setting.SetCookie('lanqiubifen',cookiestr);
	});
	
	setTimeout('showdata()',5000);
}


function selOnchange(){
	combin_loadMain();
}
function splitAry(str,fh){
	return str.split(fh);
}
function combin_loadMain(){
	setting.SetCookie('lanqiubifen','');
 	showdata();
}
$(function(){
	combin_loadMain();
});
