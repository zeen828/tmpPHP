
ZQ.betJson = {}; //总投注详情
ZQ.betArr = [];  //过滤详情为数组
ZQ.countBet=0; //投注金额
ZQ.notes=0; //注数
ZQ.muliptile=1; //倍数
ZQ.tzNumber=''; //投注号码
ZQ.spzValue = ''; //投注SP
ZQ.wasMuster='';  //过关方式
ZQ.OptimizationStr = ''; //奖金优化串
ZQ.biggestPrize = 0;
ZQ.ClearanceType=0; //0单一彩种 , 1混合过关
ZQ.MarKetClearx={
	'r':[],
	's':[],
	'q':[]
}; //赛事筛选

function show_encounter(){
	
	$.getJSON(url+"/letoula/data/winsFlat.jsp?r="+Math.random(),{'smalltype':'504','type':gzStyle[0]},function(items){
		var it = items.items;
		var tr = '' , table = '<table class="entronTab" cellspacing="0" cellpadding="0" id="table0" width="998">',day=0 , day_count = 0;
		for(var i=0;i < it.length; i++)
		{
			
			var spvalue = it[i].spvalue.split("|");
			var stoptime = it[i].stopTime.split(" ");
			var itNext = it[i+1] ? it[i+1] : it[i];
			var stoptimeNext = it[i+1] ? it[i+1].stopTime.split(" ") : it[i].stopTime.split(" ");
			var date = new Date(stoptime[0]);
			var dateNext = new Date(stoptimeNext[0]);
			var ServiceTime = new Date();
			ServiceTime.setTime(javaAgras.datemillis);
			var tt=parseInt(create_class.stringformat(ServiceTime));
			var at=parseInt(it[i].stopTime.replace(/[-A-Za-z\(\)\+@#:\s]/g,""));
			if(at < tt){
				continue;
			}
			day_count++;
			if(!create_class.contains(ZQ.MarKetClearx.r,it[i].concedenum)){
				ZQ.MarKetClearx.r.push({'sat':it[i].concedenum,'dx':bet_config.countNum(it,it[i].concedenum,'concedenum'),'id':it[i].id});
			}
			if(!create_class.contains(ZQ.MarKetClearx.s,it[i].leagueName)){
				ZQ.MarKetClearx.s.push({'sat':it[i].leagueName,'dx':bet_config.countNum(it,it[i].leagueName,'leagueName'),'id':it[i].id});
			}
			if(!create_class.contains(ZQ.MarKetClearx.q,'星期'+it[i].againstNum.charAt(1))){
				ZQ.MarKetClearx.q.push({'sat':'星期'+it[i].againstNum.charAt(1),'dx':bet_config.countNum(it,it[i].againstNum,'againstNum'),'id':it[i].id});
			}
			var trCls = "" , concedenumTd = "";
			if(parseInt(it[i].concedenum)>0){
				it[i].concedenum = "+"+it[i].concedenum;
				concedenumTd = "redTdColor";
			}else{
				concedenumTd = "greenTdColor";
			}
			if(i % 2 != 0)
			{
				trCls = "greyTr";
			}
			
			var newat = at.toString();
			var groupTime = parseInt(newat.toString().substring(0,8));
			if(parseInt(newat.substring(8,14)) < 60000){
				groupTime = groupTime - 1;
			}
			groupTime = groupTime.toString();
			var gst =  groupTime.substring(0,4) +'/' +groupTime.substring(4,6) +'/'+ groupTime.substring(6,8);
			var days = today[new Date(gst).getDay()];
			var newxt = itNext.stopTime.replace(/[-A-Za-z\(\)\+@#:\s]/g,"");
			var nextTime = parseInt(newxt.substring(0,8));
			if(parseInt(newxt.substring(8,14)) < 60000){
				nextTime = nextTime -1;
			}
			nextTime = nextTime.toString();
			var nextgst =  nextTime.substring(0,4) +'/' +nextTime.substring(4,6) +'/'+ nextTime.substring(6,8);
			var nextdays = today[new Date(nextgst).getDay()];
			
			
			tr+='<tr class="'+trCls+'" lg="'+it[i].leagueName+'"  vt="'+it[i].guestTream+'"  rq="'+it[i].concedenum+'" id="'+it[i].id+'" stopdate="'+it[i].stopTime+'" gamenum="'+it[i].againstNum+'" hostteam="'+it[i].hostteam+'" arrySerial="'+i+'"><td width="116"><span style="float:left; line-height:34px">'+it[i].againstNum+'</span><span class="leaugeName" style="background-color:'+it[i].leagueColor+';">'+it[i].leagueName.substring(0,3)+'</span></td><td width="55" class="timeEntron">'+
					'<span  class="jz" title="截止时间：'+it[i].stopTime+'" >'+it[i].stopTime.substring(11, 13) + ":"+ it[i].stopTime.substring(14, 16)+'</span>'+
      				'<span title="开赛时间：'+it[i].stopselldate+'" class="ks" style="display:none">'+it[i].stopselldate.substring(11, 13) + ":"+ it[i].stopselldate.substring(14, 16)+'</span>'+
				'</td><td width="251" class="tream"><em class="tmr_l">'+it[i].hostTreamRankings+'</em><a href="#" class="tmr_l">'+it[i].hostteam.substring(0,5)+'</a><span class="tmr_z">VS</span><a href="#" class="tmr_r">'+it[i].guestTream.substring(0,5)+'</a><em class="tmr_r">'+it[i].guestTreamRankings+'</em></td><td width="381"><div class="bet_odds">'+
				
					'<span class="cut_odds_bq" data-sp="'+it[i].winwinrate504+'" value="3_3" data-s="t3_3" data-gamenum="504">'+it[i].winwinrate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].winlevelrate504+'" value="3_1" data-s="t3_1" data-gamenum="504">'+it[i].winlevelrate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].winloserate504+'" value="3_0" data-s="t3_0" data-gamenum="504">'+it[i].winloserate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].levelwinrate504+'" value="1_3" data-s="t1_3" data-gamenum="504">'+it[i].levelwinrate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].levellevelrate504+'" value="1_1" data-s="t1_1" data-gamenum="504">'+it[i].levellevelrate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].levelloserate504+'" value="1_0" data-s="t1_0" data-gamenum="504">'+it[i].levelloserate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].losewinrate504+'" value="0_3" data-s="t0_3" data-gamenum="504">'+it[i].losewinrate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].loselevelrate504+'" value="0_1" data-s="t0_1" data-gamenum="504">'+it[i].loselevelrate504+'</span>'+
					'<span class="cut_odds_bq" data-sp="'+it[i].loseloserate504+'" value="0_0" data-s="t0_0" data-gamenum="504">'+it[i].loseloserate504+'</span>'+
					
					'</div></td><td width="79" class="xyo"><a href="../../Odds.do?action=soccer&id='+it[i].id+'" target="_blank">变</a>/<a href="/match/oupan'+it[i].m2+'" target="_blank">欧</a>/<a href="/match/xi'+it[i].m2+'" target="_blank">析</a></td>'+
					'<td width="118"><div class="oupei"><span>'+spvalue[0]+'</span><span>'+spvalue[1]+'</span><span>'+spvalue[2]+'</span></div></td></tr>';
					
					
			if(groupTime!=nextTime  && it[i].againstNum.charAt(1)!=itNext.againstNum.charAt(1)){
				day++;
				it[i] = it[i-1] ? it[i-1] : it[i];
				var formatDate='<tr class="bet_dateTr"><td colspan="7" class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+' <a href="#">'+day_count+'场比赛可投注</a><s class="doul_arrow" /></td></tr>';
				table+=formatDate+tr+'</table><table class="entronTab" cellspacing="0" id="table'+day+'" cellpadding="0" width="998">';
				tr = ''; 
				day_count = 0;
			}
			
			if(i==it.length-1)
			{
				it[i] = it[i-1] ? it[i-1] : it[i];
				table += '<tr class="bet_dateTr"><td colspan="7" class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+' <a href="#">'+day_count+'场比赛可投注</a><s class="doul_arrow" /></td></tr>'+tr + "</table>";
			}
		}
		bet_config.ClearFx();
		$('.encounterMain').html(table);
		$.domHover($('.entronTab tbody tr'),'#fff8dc');
		$.domSpanBack($('.bet_odds span'),'over');
		bet_config.spclick();
	});
	
};

var bet_config = {
	'spclick':function(){
		$('.bet_odds span').click(function(){
			var _class = $(this).attr('class');
			var HTMLOBJECT_TR = $(this).parents('tr');
			var id = HTMLOBJECT_TR.attr('id');
			if(_class.indexOf('yeswin')==-1)
			{
				$(this).addClass('yeswin');
				$.Accession($(this),$('.sedan'));
			}else
			{
				$(this).removeClass('yeswin');
			}
			var betArr = $(HTMLOBJECT_TR).find('td:eq(3) > div > span.yeswin');
			var bet = [] , arrs = [] , arrnumber = [] , HybridStrings=[];
			for(var k = 0; k < betArr.length;k++)
			{
				var gn = $(betArr).eq(k).attr('data-gamenum'),
					sp = $(betArr).eq(k).attr('data-sp'),
					s = $(betArr).eq(k).attr('data-s'),
					val = $(betArr).eq(k).attr('value');
				bet.push({'gn':gn,'sp':sp,'s':s,'val':val});
				arrs.push(sp);
				arrnumber.push(val);
				HybridStrings.push(val+':'+sp+':'+HTMLOBJECT_TR.attr('gamenum')+'~');
			}
			var hbsg = HybridStrings.join('|');
			ZQ.betJson[id]={'id':id,'ht':HTMLOBJECT_TR.attr('hostteam'),'vt':HTMLOBJECT_TR.attr('vt'),'lg':HTMLOBJECT_TR.attr('lg'),'gamenum':HTMLOBJECT_TR.attr('gamenum'),'stopselldate':HTMLOBJECT_TR.attr('stopselldate'),'rq':HTMLOBJECT_TR.attr('rq'),'gall':'0','arrs':arrs,'arrnumber':arrnumber,'hbsg':hbsg,'bet':bet};
			if(betArr.length<=0){
				delete ZQ.betJson[id];
			}
			bet_config.totalBouns();
		});
		
		$('.radio_ck').click(function(){
			bet_config.marKetClick();
			$.offsetScr('betbottom','BettingRegion');
			$.offsetTopTitle('encounterMain','marketTitle');
		});
	},
	'totalBouns':function(){
		var Yes_bet = ZQ.betJson;
		ZQ.betArr = [];
		var count = this.objectCount(Yes_bet);
		ZQ.betArr = create_class.timeSort(ZQ.betArr);
		$('.the_selected').text(count);
		var betTr = '' , wfstr = '' ,wf = [] , maxCount = '0';
		for(var k=0;k<ZQ.betArr.length;k++)
		{
			var betObject = ZQ.betArr[k];
			var bettingNumber = betObject.bet;
			var _HMC = '';
			for(var l=0;l<bettingNumber.length;l++)
			{
				wf.push(bettingNumber[l].gn);
				var rq = bettingNumber[l].gn == '511' ? betObject.rq : '';
				_HMC+='<a href="#">'+rq+all_config[bettingNumber[l].gn][bettingNumber[l].val]+'</a>';	
			}
			if(gzStyle[0]=='0'){
				betTr+='<tr><td class="btl9">'+betObject.gamenum+'</td><td>'+betObject.ht.substring(0,3)+'</td><td>'+betObject.vt.substring(0,3)+'</td><td class="btlxz">'+_HMC+'</td>'+
					'<td class="btl9"><input type="checkbox" onclick="bet_config.glbdr(this)" class="gallbladder" value="'+betObject.id+'"/></td><td><s class="delbet" data-del="'+betObject.id+'" onclick="javascript:bet_config.delOption(this)" /></td></tr>';
			}else if(gzStyle[0]=='1')
			{
				betTr+='<tr><td class="btl9">'+betObject.gamenum+'</td><td>'+betObject.ht.substring(0,3)+'</td><td>'+betObject.vt.substring(0,3)+'</td><td class="btlxz">'+_HMC+'</td>'+
					'<td><s class="delbet" data-del="'+betObject.id+'" onclick="javascript:bet_config.delOption(this)" /></td></tr>';
			}
		}
		wf=this.Arrdel(wf);
		$('.TZ_tab').html(betTr);
		if(wf.length == 0){
			wfstr = '';
		}else{
			wfstr = all_config[wf[0]].name;
			ZQ.ClearanceType=0;
			javaAgras.gameid = wf[0];
			wf.sort(function(a,b){return a-b});
			maxCount = all_config[wf[wf.length-1]].mcn;
			count = count > maxCount ? maxCount : count;
		}
		
		if(gzStyle[0]=='0'){
			$('.musterMain,.musterMain span.ipt').hide();
			$('.mstTx').show();
			$('.listMatch  ul  li,.listMatch  ul  li span').hide();
			if(count >= 2)
			{
				$('.mstTx').hide();
				$('.musterMain').show().find('span:lt('+(count-1)+')').show();
				$('.musterMain').find('span').not(':lt('+(count-1)+')').find('input').attr('checked',false);
				if(count>=3){
					$('.listMatch  ul  li:lt('+(count-2)+')').show().find('span').show();
				}
			}
			this.gallOption();
		}
		$('.wfwz').text(wfstr);
		this.CountAward();
	},
	'delOption':function(_this){
		var delType = $(_this).attr("data-del");
		if(delType=='all')
		{
			var fa = confirm("您确定要删除所有比赛吗？");
			if(fa==true){
				for(var bs in ZQ.betJson){
					delete ZQ.betJson[bs];
					$("#"+bs+" > td > div.bet_odds > span.yeswin").removeClass('yeswin');
				}
			}
		}else
		{
			delete ZQ.betJson[delType];
			$("#"+delType+" > td > div.bet_odds > span.yeswin").removeClass('yeswin');
		}
		bet_config.totalBouns();
		this.CountAward();
	},
	'glbdr':function(_this){
		var valid =_this.value;
		ZQ.betJson[valid].gall = _this.checked==true ? '1' : '0';
		this.gallOption('gl');
	},
	'gallOption':function(bsbox){
		var count = ZQ.betArr;
		if(ZQ.betArr.length <= 0)
		{
			$('.ipt input').attr('checked',false);
			return;
		}
		var optioncheck = $('.ipt > input:checked');
		var rcarr = [];
		for(var i=0;i<optioncheck.length;i++)
		{
			var rc = $(optioncheck).eq(i).parent('span').attr('id');
			rcarr.push(typeMap[rc][0].charAt(0));
		}
		rcarr.sort(function(a,b){return a-b});
		var minRc = parseInt(rcarr[0]);
		if(minRc == ZQ.betArr.length)
		{
			$('.gallbladder').attr({'disabled':true,'checked':false});
		}else
		{
			if($('.gallbladder:checked').length == (minRc - 1)){
				$('.gallbladder:not(:checked)').attr('disabled',true);
			}else if($('.gallbladder:checked').length > (minRc - 1))
			{
				$('.gallbladder').attr({'disabled':false,'checked':false});
			}
		}
		if((bsbox=='rc' && optioncheck.length==0) || (bsbox=='gl' && $('.gallbladder:checked').length==0))
		{
			$('.gallbladder').attr({'disabled':false,'checked':false});
		}
		this.CountAward();
	},
	'CountAward':function(){
		var sa = new Array(); //不为胆码数组
		var sb = new Array(); //有胆数组
		var b0=0,b1=0,zhushu=0,maxprice = 0;
		var OverPortfolio = ZQ.betArr;
		var spValArr = [] , spvalue=[] , tznumber = [] , hy = [] , cn = [];
		ZQ.muliptile = parseInt($('#multipleTx').val());
		for(var k =0; k < OverPortfolio.length;k++)
		{
			spvalue.push(OverPortfolio[k].id+','+OverPortfolio[k].arrs.join('/')+','+OverPortfolio[k].gall);
			tznumber.push(OverPortfolio[k].id+','+OverPortfolio[k].arrnumber.join('/')+','+OverPortfolio[k].gall);
			hy.push(OverPortfolio[k].hbsg);
			if(OverPortfolio[k].gall == '1'){
				sb.push(OverPortfolio[k].bet.length);
				b0++;b1++;
			}else
			{
				sa.push(OverPortfolio[k].bet.length);
			}
			var vp = OverPortfolio[k].arrs.join(',');
			spValArr.push(vp.split(',').sort(asc));
		}
		ZQ.spzValue = spvalue.join('//');
		ZQ.tzNumber = tznumber.join('//');
		spArr = spValArr;
		var chosenStyle = $(".ipt input:checked");
		if(chosenStyle.length<=0)
		{
			$('#minprize,#maxprize,#betMoney').text(0);
		}else{
			if(gzStyle[0] == '0'){
				if(ZQ.ClearanceType==0){
					var gte = [];
					$(chosenStyle).each(function(i,v){
						cn.push(v.value);
						var pt = $(v).next().text().replace("串","-");
						gte.push(pt);
						zhushu += parseInt(myCalc(pt,'1',sa,sb,b0,b1));
					});
					ggWay = gte;
					gusuan();
				}else
				{
					var tempstr = hy.join(',');
					ZQ.OptimizationStr = tempstr;
					$(chosenStyle).each(function(i,v){
						cn.push(v.value);
						var xzcg = $(v).next().text().split('串');
						var passway = typeMap['r'+xzcg[0]+'c'+xzcg[1]];
						var pwy = []; 
						for(var b = 0; b < passway.length;b++)
						{
							pwy.push(passway[b].charAt(0));
						}
						var psy = pwy.join(',');
						if(xzcg[2]>1){
							yh_MainLoad(tempstr,xzcg[0],'0');
							var zbin = newArrbin;
							for(var a = 0; a < zbin.length; a++)
							{
								var arrsp = zbin[a].ArrSp.split(",");
								var newTempstr = '';
								for(var s = 0;s<arrsp.length;s++)
								{
									newTempstr += s+":"+arrsp[s]+":"+"bx~,";
								}
								newTempstr=newTempstr.substring(0,newTempstr.length-1);
								yh_MainLoad(newTempstr,psy,'0');
								zhushu += newArrbin.length;
								maxprice+=bet_config.maxCountPrice(newArrbin);
							}
						}else
						{
							yh_MainLoad(tempstr,psy,'0');
							zhushu += newArrbin.length;
							maxprice+=bet_config.maxCountPrice(newArrbin);
						}
					});
					$("#maxprize").text(maxprice.toFixed(2));
					ZQ.biggestPrize = maxprice.toFixed(2);
				}
				
			}else if(gzStyle[0] == '1'){
				cn.push('1');
				zhushu = setting.dan_Gbounrs(ZQ.tzNumber);
			}
			ZQ.wasMuster = cn.join(',');
			ZQ.notes = zhushu;
			ZQ.countBet = zhushu * ZQ.muliptile * 2;
			$('#betMoney').text(ZQ.countBet);
		}
	},
	'maxCountPrice':function(nrb){
		var maxpc = 0;
		for(var i =0; i < nrb.length;i++)
		{
			maxpc += parseFloat(nrb[i].m);
		}
		return maxpc;
	},
	'objectCount':function(o){
		var count =0;
		for(var gs in o)
		{
			ZQ.betArr.push(ZQ.betJson[gs]);
			count++;
		}
		return count;
	},
	'Arrdel':function(Arr_) { 
		var a = {}, c = [], l = Arr_.length; 
		for (var i = 0; i < l; i++) { 
			var b = Arr_[i]; 
			var d = (typeof b) + b; 
			if (a[d] === undefined) { 
				c.push(b); 
				a[d] = 1; 
			} 
		} 
		return c; 
	},
	'mltOnkeyUp':function(){
		
		var _this=arguments[0],
			val=parseInt(_this.value);
			
		if(val > 500000) {
			_this.value='500000';
		}
		
		if(isNaN(_this.value) || val <= 0 || _this.value.indexOf('.')!=-1){
		
		   _this.value=1;
		}
		
		ZQ.muliptile=_this.value;
		
		this.CountAward();
	},
	'rise_reduce_control':function(v){
		if(v == 'r')
		{
			ZQ.muliptile += 1;
		}else
		{
			var m = ZQ.muliptile - 1;
			ZQ.muliptile = m < 1 ? 1 : m;
		}
		var countBet = ZQ.notes * ZQ.muliptile * 2;
		var mpz = (parseFloat(ZQ.biggestPrize) * parseFloat(ZQ.muliptile)).toFixed(2);
		$("#betMoney").text(countBet);
		$("#maxprize").text(mpz);
		$("#multipleTx").val(ZQ.muliptile);
		ZQ.countBet = countBet;
	},
	'seaDetails':function(nd,sh,txt){
		var off_top=document.documentElement.scrollTop;
		var off_left=document.documentElement.scrollLeft; 
        create_class.centertical(ZQ.$(nd));
        $('.eroorMsg').text(txt);
		sh == 's' ? $('#bd,#'+nd+'').show() : $('#bd,#'+nd+'').hide();
	},
	'ClearFx':function(){
		for(var cx in ZQ.MarKetClearx)
		{
			var mA = ZQ.MarKetClearx[cx];
			var li = '';
			if(cx == 'r')
			{
				for(var i=0;i<mA.length;i++)
				{
					var d_n = '非让球';
					if(mA[i].sat.indexOf('-')==-1){
						mA[i].sat = '+' + mA[i].sat;
					}
					li+='<li><input type="checkbox" class="radio_ck" c="'+mA[i].dx+'" id="rq_'+mA[i].sat+'" m="0" checked="true" />'+d_n+'['+mA[i].dx+'场]</li>';
				}
				$('.rqlist > ul').html(li);
			}else if(cx == 's')
			{
				for(var i=0;i<mA.length;i++)
				{
					li+='<li><input type="checkbox" class="radio_ck" c="'+mA[i].dx+'" id="lg'+mA[i].id+'" m="'+mA[i].sat+'" checked="true"/>'+mA[i].sat.substring(0,4)+'['+mA[i].dx+'场]</li>';
				}
				$('.sslist > ul').html(li);
			}else{
				for(var i=0;i<mA.length;i++)
				{
					li+='<li><input type="checkbox"  class="radio_ck" c="'+mA[i].dx+'" id="day'+mA[i].sat+'" m="周'+mA[i].sat.charAt(2)+'" checked="true"/>'+mA[i].sat+'['+mA[i].dx+'场]</li>';
				}
				$('.sjlist > ul').html(li);
			}
		}
	},
	'countNum':function(s,v,v1){
		var count = 0;
		for(var l =0; l<s.length;l++){
			var sValue = s[l][v1];
			if(v1=='againstNum')
			{
				sValue = s[l][v1].substring(0,2);
				v = v.substring(0,2);
			}
			if(sValue==v)
			{
				count++;
			}
		}
		return count;
	},
	'marKetClick':function(){
		$('.entronTab tbody tr').show();
		var notcheck = $('.shaxlist ul li input:not(:checked)');
		var yc = 0;
		for(var i=0;i<notcheck.length;i++)
		{
			var id = $(notcheck).eq(i).attr('id');
			if(id.indexOf('rq')!=-1)
			{
				var rqm = $('.entronTab tbody tr[rq*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(rqm).hide();
				yc+=$(rqm).length;
			}else if(id.indexOf('lg')!=-1){
				var lqm = $('.entronTab tbody tr[lg*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(lqm).hide();
				yc+=$(lqm).length;
			}else
			{
				var gmm = $('.entronTab tbody tr[gamenum*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(gmm).hide();
				yc+=$(gmm).length;
			}
		}
		$('.redtxtc').text(yc);
	},
	'AllMarket':function(str){
		var sarr = str.split('_');
		if(sarr[1] == 'qx')
		{
			$('.'+sarr[0]+' > ul > li > input').attr('checked',true);
		}else if(sarr[1] == 'fx')
		{
			var zk = $('.'+sarr[0]+' > ul > li > input:not(:checked)');
			var jk = $('.'+sarr[0]+' > ul > li > input:checked');
			$(zk).attr('checked',true);
			$(jk).attr('checked',false);
			
		}else if(sarr[1] == 'qq')
		{
			$('.'+sarr[0]+' > ul > li > input').attr('checked',false);
		}
		this.marKetClick();
	},
	/*
	*投注提交
	*/
	'submitInformation':function(mx){
		
		if(gzStyle[0] == '0'){
			if(ZQ.tzNumber.indexOf('//') <= 0){
			
				this.seaDetails('blk2','s',betting_yz.x);
				return;
			}
			else if(ZQ.wasMuster.length<=0){
			
				this.seaDetails('blk2','s',betting_yz.c);
				return;
			}
		}else
		{
			if(ZQ.wasMuster.length<=0){
			
				this.seaDetails('blk2','s',betting_yz.s);
				return;
			}
		}
		$('.jzTime').val('');   								//截至时间
		$('.muliptile').val(ZQ.muliptile);							//倍数
		$('.tzNumber').val(ZQ.tzNumber); 							//投注号码
		$('.zhushu').val(ZQ.notes);										//注数
		$('.price').val(parseFloat(ZQ.countBet).toFixed(2));				//投注金额
		$('.ZQMcN').val(ZQ.wasMuster);										//McN
		$('.spzValue').val(ZQ.spzValue.replace(/[" "]/g,""));		//sp值
		$('.moneyFw').val('0-0');									//奖金范围
		$('.tempstr').val(ZQ.OptimizationStr);								//优化数据 
		$('.gameCode').val(javaAgras.gameid);						//玩法
		
		var mcnArray=ZQ.wasMuster.split(',');
		var rmrn='';
		for(var s=0;s<mcnArray.length;s++){
			rmrn+=McN_Map[mcnArray[s]]+',';
		}
		rmrn=rmrn.substring(0,rmrn.lastIndexOf(','));
		
		$('.McN').val(rmrn);
		
		var d='$',cos='';
		for(var i=0;i<ZQ.betArr.length;i++){
			var arr = ZQ.betArr[i];
			var pl=arr.arrs.join('_');
			var spf=arr.arrnumber.join('/');
			cos+=arr.gamenum+','+arr.ht+','+arr.vt+','+arr.rq+','+spf+','+pl+','+arr.id+d;
		}
		cos=cos.substring(0,cos.lastIndexOf('$'));
		$('.inf').val(cos);
		var fromPanl = "";
		
		if(mx=='yh'){
			if(ZQ.muliptile!=1){
				alert("奖金优化只支持1倍优化");
				return;
			}
			fromPanl = "prizereview";
			var cc = ZQ.wasMuster.split(",");
			for(var d = 0 ; d<cc.length; d++)
			{
				if(McN_Map[cc[d]].indexOf('串1')==-1){
					alert("奖金优化只支持串1过关！");
					return;
				}
			}
		}else if(mx='m'){
			fromPanl = "myform";
		}
		ZQ.$(fromPanl).submit();
	}
};
 
$(function(){
	var sy = all_config[javaAgras.gameid][javaAgras.type+javaAgras.gameid];
	$('.lottery_nav ul li').removeClass().eq(sy).addClass('lothot');
	show_encounter();
	$(".time_k_j p").click(function(){
			$(this).addClass('timeOk').siblings().removeClass();
			$('.timeEntron span').hide();
			if($(this).text() == '截止'){
				$('.jz').show();
			}else{
				$('.ks').show();
			}
	});
	$(".ipt > input").bind('click',function(){
		bet_config.gallOption('rc');
		bet_config.CountAward();
	});
	$.divClientShow('buy_list','buylistcon','buylistcon_lik','listMain');
	$.McNShow('ddMatch','matchrc','matchzk','listMatch');
	$.offsetScr('betbottom','BettingRegion');
	$.offsetTopTitle('encounterMain','marketTitle');
});