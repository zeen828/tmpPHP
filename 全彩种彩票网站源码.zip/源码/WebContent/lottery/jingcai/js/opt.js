var Y = {};
var marketitem = {};
var stecn = [];
Y.submitList = [];
Y.newKa = [];
var danMa = danma.split(',');
this.betMarketItem = function(){
	var infoArr = info.split('$');
	for(var l = 0; l < infoArr.length; l++)
	{
		var ia = infoArr[l].split(',');
		marketitem[ia[6]] = {'gamenum':ia[0],'host':ia[1],'guest':ia[2],'rq':ia[3],'number':ia[4],'sp':ia[5],'id':ia[6]};
	}
	//alert(marketitem.length+'---'+marketitem['57093']+'---'+marketitem['57093'].gamenum);
};
this.show_Viwe_Market = function(){
	$.getJSON(""+url+"/letoula/data/selmarket.jsp?r="+Math.random(),{'marketId':marketid},function(Item){
		var item = Item.items;
		var tr='';
		for(var i = 0; i < item.length; i++){
			var betmarket = marketitem[item[i].id]; var numView = '' , cg = '';
			var dm = create_class.containsArray(danMa,item[i].id) ? '√' : '×';
			var betNum = betmarket.number.split('/');
			for(var k = 0; k < betNum.length; k++)
			{
				var code = gamecode;
				if(code=='509')
				{
					if(betNum[k].indexOf('R')!=-1)
					{
						code = '511';
					}
					else if(betNum[k].indexOf('B')!=-1)
					{
						code = '503';
					}
					else if(betNum[k].indexOf('_')!=-1)
					{
						code = '504';
					}
					else if(betNum[k].indexOf(':')!=-1)
					{
						code = '502';
					}
					else{
						code = '501';
					}
				}
				
				numView += '<span>' + all_config[gamecode][betNum[k]] + '[' + item[i]['wf'+code+betNum[k]] + ']</span>';
			}
			if(i == 0) {
				cg = '<td rowspan="'+item.length+'">'+mcn+'</td>';
			}
			tr+='<tr><td>'+betmarket.gamenum+'</td><td>'+betmarket.host+' VS '+betmarket.guest+'</td><td>'+dm+'</td><td class="numtd">'+numView+'</td>'+cg+'</tr>';
		}
		$('#jq_add_matchList').html(tr);
	});
};
/**博热优化
*/
this.benOptimize = function(amount, prizeArr){
	var sumF = 0,returnArr = [];
	 for(var j=0;j<prizeArr.length;j++){
	     sumF += Math.ceil(amount/prizeArr[j]);
	     returnArr[returnArr.length] = Math.ceil(amount/prizeArr[j]);
	  }
	  if(sumF - (amount/2) <= 0){//实际注数不足理论注数，默认加到第一注
	     var _k1 = (amount/2) + returnArr[0] - sumF;
	     returnArr[0] = _k1;
	    }else{//实际注数多于理论注数，先设置所有注数为1，再从第一注开始加
	     return prizeOptimize(amount, prizeArr);
	   }
	     return returnArr;
};
/**博冷优化
*/
this.coolOptimize = function(amount, prizeArr){
	var sumF = 0,returnArr = [];
	 for(var j=0;j < prizeArr.length;j++){
	     sumF += Math.ceil(amount/prizeArr[j]);
	     returnArr[returnArr.length] = Math.ceil(amount/prizeArr[j]);
	  }
	  if(sumF - (amount/2) <= 0){//实际注数不足理论注数，默认加到第一注
	     var _k1 = (amount/2) + returnArr[returnArr.length-1] - sumF;
	     returnArr[returnArr.length-1] = _k1;
	    }else{//实际注数多于理论注数，先设置所有注数为1，再从第一注开始加
	     return prizeOptimize(amount, prizeArr);
	   }
	     return returnArr;
};
/**
* 平均优化
*/
this.prizeOptimize = function(amount, prizeArr){
			var zs = amount/2;
	     	var sumF = 1,temF = 0,returnArr = [],lockSum = 0,lockCount = 0;
	     	for(var j=0;j<prizeArr.length-1;j++){
	     		sumF += prizeArr[prizeArr.length-1]/prizeArr[j];
	     		returnArr[returnArr.length] = prizeArr[prizeArr.length-1]/prizeArr[j];
	     	}
	     	returnArr[returnArr.length] = 1;
	     	temF = zs/sumF;
	     	var zzs = 0,flag = false;
	     	for(var m=0;m<returnArr.length;m++){
	     		
	     			if(temF*returnArr[m] < 1){
		     			returnArr[m] = Math.ceil(temF*returnArr[m]);
		     		}else{
		     			returnArr[m] = Math.round(temF*returnArr[m]);
		     		}
	     		
	     		zzs += returnArr[m];
	     	}
	     	//验证注数是否一致
	     	if(zzs <= zs){
	     		//平均分配
	     		var _ye = zs - zzs;
	     		while(_ye > 0){
	     			for(var k=0;k<returnArr.length;k++){
	     				if(_ye <= 0){
	     					break;
	     				}
	     				
	     					returnArr[k] += 1;
	     					_ye --;
	     				
	     			}
	     		}
	     	}else{//实际注数多于理论注数
	     		//先从多的里面减去注数，看是否能达到平衡，如若不行，先设置所有注数为1，再从第一注开始加
	     		var oye = zzs - zs;_index = 0;
	     		for(var _index=0;oye > 0 && _index<returnArr.length;_index++){
	     	
		     			if(returnArr[_index]-Math.ceil(amount/prizeArr[_index]) > 0){
		     				var unitZs = returnArr[_index]-Math.ceil(amount/prizeArr[_index]);
		     				if(oye < unitZs){
		     					returnArr[_index] = Math.ceil(amount/prizeArr[_index])+(unitZs-oye);
		     					oye = 0;
		     				}else{
		     					oye -= unitZs;
		     					returnArr[_index] = Math.ceil(amount/prizeArr[_index]);
		     				}
		     			}
	     			
	     		}
	     		if(oye > 0){
	     			if(flag && (lockSum+(prizeArr.length-lockCount)) < zs){
	     				sumF = 1,temF = 0,returnArr = [];
	     				for(var j=0;j<prizeArr.length-1;j++){
	     					
	     						sumF += prizeArr[prizeArr.length-1]/prizeArr[j];
	     						returnArr[returnArr.length] = prizeArr[prizeArr.length-1]/prizeArr[j];
	     					
	     		     	}
	     			
	     					returnArr[returnArr.length] = multipleCache[prizeArr.length-1];
	     				
	     				temF = (zs-lockSum)/sumF,zzs = 0;
	     				for(var m=0;m<returnArr.length;m++){
	     					
		    	     			if(temF*returnArr[m] < 1){
		    		     			returnArr[m] = Math.ceil(temF*returnArr[m]);
		    		     		}else{
		    		     			returnArr[m] = Math.round(temF*returnArr[m]);
		    		     		}
	     					
	     					zzs += returnArr[m];
	    		     	}
	     				if(zzs <= zs){
	     		     		//平均分配
	     		     		var _ye = zs - zzs;
	     		     		while(_ye > 0){
	     		     			for(var k=0;k<returnArr.length;k++){
	     		     				if(_ye <= 0){
	     		     					break;
	     		     				}
	     		     				if(!lockMatchCache[k]){
	     		     					returnArr[k] += 1;
	     		     					_ye --;
	     		     				}
	     		     			}
	     		     		}
	     		     	}else{
	     		     		var _ye = zzs - zs;
	     		     		while(_ye > 0){
	     		     			for(var k=0;k<returnArr.length;k++){
	     		     				if(_ye <= 0){
	     		     					break;
	     		     				}
	     		     				if(!lockMatchCache[k] && returnArr[k] > 1){
	     		     					returnArr[k] -= 1;
	     		     					_ye --;
	     		     				}
	     		     			}
	     		     		}
	     		     	}
	     			}else{
			     		var _ye = zs - returnArr.length;
			     		var tempArr = [];
			     		for(var k=0;k<returnArr.length;k++){
		     				tempArr[tempArr.length] = 1;
		     				
			     		}
			     		var _index = 0;
			     		while(_ye != 0){
			     			if(_ye >= returnArr[_index]){
			     				tempArr[_index] = returnArr[_index];
			     				_ye -= (returnArr[_index] - 1);
			     			}else{
			     				tempArr[_index] = _ye+1;
			     				_ye = 0;
			     			}
			     			_index++;
			     		}
			     		returnArr = tempArr;
	     			}
	     		}
	     	}
	     	//最后验证是否有不盈利的单，如有进行平衡处理
	     	var _low = _high = 0;
 			for(var r=0;r<returnArr.length;r++){

 					if(returnArr[r]-Math.ceil(amount/prizeArr[r]) < 0){
 						_low += (Math.ceil(amount/prizeArr[r])-returnArr[r]);
 					}else if(returnArr[r]-Math.ceil(amount/prizeArr[r]) > 0){
 						_high += (returnArr[r]-Math.ceil(amount/prizeArr[r]));
 					}
 				
 			}
 			if(_low > 0 && _low <= _high){
 				for(var r=0;r<returnArr.length;r++){
 					if(_low == 0)
 						break;

 	 					if(returnArr[r]-Math.ceil(amount/prizeArr[r]) > 0){
 	 						if((returnArr[r]-Math.ceil(amount/prizeArr[r])) <= _low){
 	 							_low -= (returnArr[r]-Math.ceil(amount/prizeArr[r]));
 	 							returnArr[r] = Math.ceil(amount/prizeArr[r]);
 	 						}else{
 	 							returnArr[r] -= _low;
 	 							_low = 0;
 	 						}
 	 					}

 	 			}
 				for(var r=0;r<returnArr.length;r++){
 	 				
 	 					if(returnArr[r]-Math.ceil(amount/prizeArr[r]) < 0){
 							returnArr[r] = Math.ceil(amount/prizeArr[r]);
 	 					}
 	 		
 	 			}
 			}
	     	return returnArr;
};
this.binCommet = function(arrbin,pr){
	var radioVal = $('.xuanz').val(),tempMoney = parseInt($('#jq_plan_amount').val());
	var ka = [];
	var spArr = [];
	var binList = [];
	for(var l =0; l < arrbin.length; l++)
	{
		arrbin[l] = arrbin[l].substring(0,arrbin[l].length-1);
		var aba = arrbin[l].split('-');
		var danzhu = 1;
		for(var d=0;d<aba.length;d++){
			var arbn = aba[d].split(':');
			danzhu = danzhu * arbn[2];
		}
		danzhu = setting.FixedFloatTwo(danzhu*2);
		spArr.push(danzhu);
		binList.push({'arrbins':arrbin[l],'danzhus':danzhu});
	}
	spArr.sort(function(a,b){return a-b});
	binList.sort(function(a,b){return a.danzhus - b.danzhus});
	if(pr > 0){
		if(radioVal=='1'){
			ka = prizeOptimize(tempMoney,spArr);
		}else if(radioVal=='2'){
			ka = benOptimize(tempMoney,spArr);
		}else if(radioVal=='3'){
			ka = coolOptimize(tempMoney,spArr);
		}
		Y.newKa = ka;
		appendHTML(binList,ka);
	}else{
		for(var j=0;j<spArr.length;j++){
	     	ka[ka.length] = 1;
		 }
		 Y.newKa = ka;
		appendHTML(binList,ka);
	}
	
};
this.appendHTML = function(list,ka){
	var tr = '' , ReallyMoney = 0;
	var brounsArr = [];Y.submitList=[];
	for(var i=0;i<list.length;i++)
	{
		var arr = list[i].arrbins;
		var newarrac = arr.substring(0,arr.length-1);
		var aba = newarrac.split('-');
		var overdanzhu = '',danzhu=1;
		var substr = '';
		for(var l=0;l<aba.length;l++){
			var asb = aba[l].split(':');
			var betmarketList = marketitem[asb[3]];
			var hostname = '<span class="l" title="'+betmarketList.host+'">'+betmarketList.gamenum+betmarketList.host+'</span>';
			var rq = asb[1].indexOf('R')!=-1 ?  '<span class="font_red" style="padding-left: 5px; float: left;">'+betmarketList.rq+'</span>' : '';
			var numbers = '<span class="y">'+rq+all_config[asb[0]][asb[1]]+'</span>';
			overdanzhu += '<div class="danzhu1">' + hostname + numbers + '</div>';
			danzhu = danzhu * asb[2];
			substr += betmarketList.gamenum+'->'+asb[1]+';';
		}
		var lilun = setting.FixedFloatTwo(danzhu*ka[i]*2);
		danzhu = setting.FixedFloatTwo(danzhu*2);
		if(ka[i]>0){
			brounsArr.push(lilun);
		}
		substr = substr.substring(0,substr.length-1);
		substr += ' ' + ka[i] +' '+ (ka[i]*2) + ' ' + aba.length+'串1';
		if(ka[i]>0){
			ReallyMoney += ka[i] * 2;
			Y.submitList.push(substr);
		}
		tr+='<tr><td>'+(i+1)+'</td><td>'+overdanzhu+' <span class="danzhubrouns">= '+danzhu+'</span></td><td><i class="dgq_jia" onclick="zzz_Jian('+i+')"></i><input type="text" name="input" onkeyup="txtOnChange('+i+',this)" class="shadow_input multiple_input" type="text" value="'+ka[i]+'"/><i class="dgq_jian" onclick="zzz_Jia('+i+')"></i></td><td><strong class="font_red">'+lilun+'</strong></td></tr>';
	}
	brounsArr.sort(function(a,b){return a-b});
	$('#jq_view_prize').text(brounsArr[0]+'~'+brounsArr[brounsArr.length-1]);
	$('#jq_hit_amount').text(ReallyMoney);
	$('#yh_add_betList').html(tr);
};
this.TXT_Price = function(){
	if(checkPrice()){
		split_injection();
	}
};
this.zzz_Jian = function(suy){
	Y.newKa[suy] = parseInt(Y.newKa[suy]) - 1;
	if(Y.newKa[suy]<0){
		Y.newKa[suy] = 0;
		alert("您调节的奖金不能小于0");
	}else{
		appendHTML(zuzList(stecn),Y.newKa);
	}
	
}
this.zzz_Jia = function(suy){
	Y.newKa[suy] = parseInt(Y.newKa[suy]) + 1;
	appendHTML(zuzList(stecn),Y.newKa);
}
this.TXTOnkeyval = function(){
	var nka = [];
	for(var i=0;i<stecn.length;i++){
		nka[i]=0;	
	}
	appendHTML(zuzList(stecn),nka);
}
this.txtOnChange = function(suy,_this){
	var val = parseInt(_this.value);
	if(isNaN(val)){
		val = _this.value = 1;
	}else if(val<0){
		val = _this.value=0;
	}else if(val>1000000){
		val = _this.value=1000000;
	}
	Y.newKa[suy] = val;
	appendHTML(zuzList(stecn),Y.newKa);
};
this.zuzList = function(zl){
	var dataList = [];
	for(var i=0;i<zl.length;i++){
		var zlobj = zl[i].substring(0,zl[i].length-1);
		var aba = zlobj.split('-');
		var danzhu = 1;
		for(var d=0;d<aba.length;d++){
			var arbn = aba[d].split(':');
			danzhu = danzhu * arbn[2];
		}
		danzhu = setting.FixedFloatTwo(danzhu*2);
		dataList.push({'arrbins':zl[i],'danzhu':danzhu});
	}
	dataList.sort(function(a,b){return a.danzhu-b.danzhu});
	return dataList;
};
this.checkPrice = function(){
	var val = $('#jq_plan_amount').val();
	if(val==''){
		create_class.seaDetails('blk2','s','计划购买金额不能为空！','error','');
		return false;
	}else if(isNaN(val)){
		create_class.seaDetails('blk2','s','请正确输入计划购买金额！','error','');
		return false;
	}else if(parseInt(val) % 2 != 0){
		create_class.seaDetails('blk2','s','输入金额必须是2的倍数!','error','');
		return false;
	}else if(parseInt(val) < countMoney){
		create_class.seaDetails('blk2','s',"计划购买金额至少需要"+countMoney+"元！",'error','');
		return false;
	}else if(parseInt(val)>1000000){
		create_class.seaDetails('blk2','s','输入计划购买金额最大支持100万元！','error','');
		return false;
	}
	return true;
};
this.closeWindow = function(u){ 
    	$('#'+u).hide();
    	$('#bd').hide();
};
this.submitMain = function(){
	//alert("1 "+url);
	if(checkPrice()){
		//alert("2  "+url);
		$.getJSON(""+url+"/PutForwordAction.do?action=checkUserLogin&r="+Math.random(),{'a':'b'},function(item){
			//alert("3  "+url);
			//alert("4  "+item.result);
				if(item.result=='0'){
					var subMoney = parseInt($('#jq_hit_amount').text());
					if(subMoney < countMoney || subMoney<=0){
						create_class.seaDetails('blk2','s','请正确输入购买金额并优化','error','');
						return;
					}
					$('#subMoney').val(subMoney);
					$('#subeachPrice').val(subMoney);
					$('#subchipinNums').val(Y.submitList.join("|"));
					document.getElementById('FormSubmit').submit();
				}else{
					setting.login();
				}
			});
	}
};
this.split_injection = function(){
	var chosen = mcn.split(',');
	stecn = [];
	for(var i = 0; i < chosen.length; i++)
	{
		OverArry=[];
		var xzcg = chosen[i].split('串');
		var passway = typeMap['r'+xzcg[0]+'c'+xzcg[1]];
		var pwy = []; 
		for(var b = 0; b < passway.length;b++)
		{
			pwy.push(passway[b].charAt(0));
		}
		var psy = pwy.join(',');
		var methods =0;
		if(xzcg[1]>1)methods=1;
		else methods=0;
		
		var hy = tempstr.split('$');
		var newHY =	newhy.split('$');
		startRecon(hy,psy,methods,danMa,xzcg[0]);
		for(var s=0;s<OverArry.length;s++)
		{
			stecn.push(OverArry[s]);
		}
		//var maxprice = parseFloat(reconBonus(newHY,psy,methods,danMa,xzcg[0]));
	}
	this.binCommet(stecn,countMoney);
};
$(function(){
	betMarketItem();
	show_Viwe_Market();
	split_injection();
	$('.yhradio').click(function(){
		$('.yhradio').attr('checked',false).removeClass('xuanz');
		$(this).attr('checked',true).addClass('xuanz');
	});
});