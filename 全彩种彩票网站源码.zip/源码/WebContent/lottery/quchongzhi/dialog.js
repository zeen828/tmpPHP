function get(id){
    return document.getElementById(id);
}

function find(cls){
    return document.querySelectorAll(cls);
}

function openDialog(id){
    dialog = get(id);
    var shade = document.createElement("div");
    shade.style.backgroundColor = "transparent";
    shade.style.position = "fixed";
    shade.style.width = "100%";
    shade.style.height = "100%";
    shade.style.zIndex = 19;
    shade.style.top = 0;
    shade.style.left= 0;

    var closables = find("#" + id + " .closable");
    var length = closables.length;
    for(var i = 0; i < length; ++i){
        var c = closables[i];
        c.addEventListener("click", function(){
            for(var j = 0; i < length; ++j){
                var cc = closables[j];
               // alert(cc);
                //alert(cc.text());
                cc.removeEventListener("click");
            }
            document.body.removeChild(shade);
            dialog.style.display = "none";
			//window.close();
        });
    }

    document.body.appendChild(shade);
    dialog.style.zIndex = 20;
    dialog.style.display = "block";
    _xgresize(dialog);
}

function _xgresize(div){
    var winWidth = window.innerWidth;
    var winHeight = window.innerHeight;
    var width = div.clientWidth;
    var height = div.clientHeight;

    div.style.left = ((winWidth - width) / 2) + "px";
    div.style.top = ((winHeight - height) / 2) + "px";
}
function quxiao(){
	window.close();
}
(function(){
    "use strict";
    window.onload = init;
    window.onresize = function(){
        var dialog = get("dialog");
        dialog && _xgresize(dialog);
    }

    function init(){
        openDialog("dialog");
    }
})();

