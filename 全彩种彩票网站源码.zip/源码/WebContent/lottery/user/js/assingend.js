KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="20";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){
		var e_y_a='';
		pages = parseInt(pages);
		var countY = Math.ceil(ey);
		var next=pages >= ey ? ey : pages+1;
		var fist=pages <= 1 ? "1" : pages-1;
		var startY=0,endY=ey > 5 ? 8 : ey;
		if(pages>=5){
			startY = pages - 5; 
			endY   = ey - pages + 5 > ey ? ey :  pages + 5;
		}
		
		e_y_a+="<font color='#fff'>共有"+KO.countEvery+"条记录，共有"+Math.ceil(ey)+"页</font><a href='javascript:void(0)' onclick=ShowCostumData('1','"+KO.U.Every+"') class='h_l'>◀</a><a href='javascript:void(0)' onclick=ShowCostumData('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'>◀◀</a>";
		var cls='';
		for(var e=startY;e<endY;e++){
			if(e<ey){
				if(e==(pages-1)) cls='an_x_z';
				else cls='';
				e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=ShowCostumData("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			}else{
				break;
			}
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=ShowCostumData('"+next+"','"+KO.U.Every+"') class='next'>▶▶</a><a href='javascript:void(0)' onclick=ShowCostumData('"+countY+"','"+KO.U.Every+"') class='h_l'>▶</a>";
		//e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		//"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='gray'>共"+countY+"页,"+(ey*parseInt(t_s))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	
	var ps=$("#govalue").val();
	ShowCostumData(ps,KO.U.Every);
}

function CostumDate_del(id){

	$.getJSON(url+'/letoula/data/tary_del_yq.jsp?r='+Math.random(),{'id':id},function(requestText){
		
		if(requestText.result == '0000') {
			ShowCostumData(KO.U.Pages,KO.U.Every);
		}else{
			alert(requestText.result);
		}
	});
}
function CostumDate_add(autoid,gameCode,starNikeName,canyuNikeName,canyuMoney){
	
	var canyuMoney = $('#canyuMoney').val();

	$.getJSON(url+'/letoula/data/tary_save_yq.jsp?r='+Math.random(),{'gameCode':gameCode,'starNikeName':starNikeName,'canyuNikeName':canyuNikeName,'canyuMoney':canyuMoney},function(requestText){
		
		if(requestText.result == '0000') {
			CostumDate_del(autoid);
			ShowCostumData(KO.U.Pages,KO.U.Every);
		}else{
			alert(requestText.result);
		}
	});
}
function show_tr(_this){
  			
  	if(_this.className=='star') $(_this).removeClass('star').addClass('end').parents('tr').next('tr').show();
  	else $(_this).removeClass('end').addClass('star').parents('tr').next('tr').hide();
  			
}
function ShowCostumData(p,e){
	
	$('.loding').show();
	KO.U.Pages = p;
	KO.U.Every = e;
	
	$.getJSON(url+'/letoula/data/tary_select_binvi.jsp?r='+Math.random(),{'userNickName':nikeName,'pages':KO.U.Pages,'every':KO.U.Every},function(JSON){
		
		var items = JSON.items;
		
		var tr='';
		if(items.length == 0) tr = '<tr><td colspan="10">没有找到相关的记录！</td></tr>';
		$('.b_r_table > tbody,.f_an_page,#rc_t_ty').empty();
		KO.countEvery=items.length;
		var ey=parseInt(JSON.record)/parseInt(KO.U.Every);
		ey = ey < 1 ? 1 : ey;
		paging1(ey,p);
		
		$(items).each(function(i,v){
			var listBg = i % 2 == 0 ? 'WhiteBg' : 'ContentLight';
			tr += '<tr class="'+listBg+'"><td><strong>'+lotName[v.lotName]+'</strong></td><td>'+v.startUserNickName+'</td><td>'+setting.allformattime(v.messageStartTime)+'</td><td><a href="javascript:void(0)" style="margin-right:10px;" onclick="show_tr(this)" class="star">接受邀请</a><a href="javascript:void(0)" onclick=CostumDate_del("'+v.autoHmId+'")>拒绝邀请</a></td></tr><tr style="display:none"><td class="custom-td" colspan="4" align="left">请输入定制跟单金额：<input type="text" id="canyuMoney" /><input type="button" class="d_blue" onclick=CostumDate_add("'+v.autoHmId+'","'+v.lotName+'","'+v.startUserNickName+'","'+nikeName+'") value="提交"/></td></tr>';
		});
		$('#dingzhi_my_list > tbody').html(tr);
		$('.loding').hide();
	});
}
 $(function(){
	$('.page a').click(function(){
		$(this).siblings().removeClass();
		$(this).addClass('an_x_z');
		KO.U.Every=$(this).text();
		ShowCostumData(KO.U.Pages,KO.U.Every);
	})
 })
 