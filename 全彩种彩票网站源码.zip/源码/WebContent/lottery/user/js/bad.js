
function $_(o){
	return document.getElementById(o);
};
function showErr(viewHtml,msg,wt){
	wt == 'cpp' ? $('#CPPasswordTrue').hide() :  $('#PasswordNewTrue').hide();
	$('#'+viewHtml).show().find('.wrongbg01').html(msg);
};
function showOK(viewHtml,wt){
	wt == 'cpp' ? $('#CPPasswordWrong').hide() :  $('#PasswordNewWrong').hide();
	$('#'+viewHtml).show();
};
function checkPassword(){
	var pwd = $_('PasswordNew').value;
	var len = pwd.length;
	if(len == 0){
		showErr('PasswordNewWrong','请输入密码','pss');
		return false;
	}
	else if(len<6){
		showErr('PasswordNewWrong','您输入的密码不足6位，请重新输入','pss');
		return false;
	}else if(len>15){
		showErr('PasswordNewWrong','您输入的密码超过15位，请换个密码','pss');
		return false;
	} else if (pwd==user)
	{
		showErr('PasswordNewWrong','密码不能够与用户名一致！请重新输入','pss');
		return false;
	}
	var cat = /^[\x20-\x7f]+$/;
	if(!(cat.test(pwd))) {
		showErr('PasswordNewWrong','密码请勿包含中文','pss');
		return false;
	}
	showOK('PasswordNewTrue','pss');
	showPassLevel(true);
	return true;
};
var lvl=0;
function showPassLevel(ishide){
	lvl = results('PasswordNew'), ishide = ishide || false, isrealone = lvl;
	if(lvl==1 || lvl==2){
		$('#PasswordNewTrue').hide();
        lvl = 1;
	} else if(lvl == 3){
        lvl = 2;
    } else {
        lvl = 3;
    }
	var lvlName = {1:'弱',2:'中',3:'强'};
	if(lvl) {
        if(ishide) {
            if(lvl==1) {
            	showErr('PasswordNewWrong','密码强度很弱，建议重新输入','pss');
                $('#passwordStrength').removeClass().addClass('strength0').show().text(lvlName[lvl]);
            } else if(lvl==2){
            	showOK('PasswordNewTrue','pss');
            	 $('#passwordStrength').removeClass().addClass('strength1').show().text(lvlName[lvl]);
            }else if(lvl==3){
            	showOK('PasswordNewTrue','pss');
            	 $('#passwordStrength').removeClass().addClass('strength2').show().text(lvlName[lvl]);
            }
            
        } else {
        	$('#passwordStrength').removeClass().addClass('strength'+lvl).show().text(lvlName[lvl]);
        }
    }
};
function results(pwdinput){
	var maths,smalls,bigs,corps,cat,num;
	var str = $_(pwdinput).value
	var len = str.length;

	var cat = /.{16}/g
	if(len == 0)return 1;
	if(len > 16){$_(pwdinput).value = str.match(cat)[0];}
	cat = /.*[\u4e00-\u9fa5]+.*$/
	if(cat.test(str)) {
		showErr('PasswordNewWrong','密码请勿包含中文','pss');
		return false;
	}
	cat = /\d/;
	var maths = cat.test(str);
	cat = /[a-z]/;
	var smalls = cat.test(str);
	cat = /[A-Z]/;
	var bigs = cat.test(str);
	var corps = corpses(pwdinput);
	var num = maths+smalls+bigs+corps;;

	if(len<6){return 1;}

	if(len>=6&&len<=8){
		if(num == 1) return  1;
		if(num == 2 || num == 3) return  2;
		if(num == 4) return  3;
	}

	if(len>8 && len<=11){
		if(num == 1) return 2;
		if(num == 2) return 3;
		if(num == 3) return 4;
		if(num == 4) return 5;
	}

	if(len>11){
		if(num == 1) return 3;
		if(num == 2) return 4;
		if(num  > 2) return 5;
	}
};
function corpses(pwdinput){
	var cat = /./g
	var str = $_(pwdinput).value;
	var sz = str.match(cat)
	for(var i=0;i<sz.length;i++){
		cat = /\d/;
		maths_01 = cat.test(sz[i]);
		cat = /[a-z]/;
		smalls_01 = cat.test(sz[i]);
		cat = /[A-Z]/;
		bigs_01 = cat.test(sz[i]);
		if(!maths_01&&!smalls_01&&!bigs_01){return  true;}
	}
	return false;
};
function checkPassword2(){
	if($_('CPPassword').value == ''){
		showErr('CPPasswordWrong','请再次输入密码','cpp');
		return false;
	}
	if($_('PasswordNew').value != $_('CPPassword').value){
		showErr('CPPasswordWrong','密码不一致，请重新输入','cpp');
		return false;
	}else{
		showOK('CPPasswordTrue','cpp');
		return true;
	}
};
function ChangePassword(){
	var newPassFlag = checkPassword();
	var repeatPass = checkPassword2();
	if(newPassFlag && repeatPass){
		var oldPassword = $_('OldPassword').value;
		var newPassword = $_('PasswordNew').value;
		var gread = lvl;
		$.getJSON('../../PutForwordAction.do?action=ChangePassword&r='+Math.random(),{'oldPassword':oldPassword,'newPassword':newPassword,'gread':gread},function(List){
			create_class.seaDetails('blk2','s',List.result);
		});
	}
};
function checkOntroSub(){
		$.getJSON(url+'/letoula/data/alipay_cash.jsp?r='+Math.random(),{'money':money},function(cash){
			if(cash.result == '0000'){
				create_class.seaDetails('blk2','s','提款成功！');
				location.href="tikuan_details.jsp";
			}else
			{
				create_class.seaDetails('blk2','s',cash.result);
				return;
			}
		})
	}
	

function checkOntro(){
		
		var t_pr = balance;
		var z_name=$('#z_name').val();
		var money = document.getElementById('txMoney').value;
		var t_name= document.getElementById('trueName').value;
		
		if(t_name.length <= 0){
			
			create_class.seaDetails('blk2','s','请输入您的真实姓名！');
			return;
		}else if(money.length <= 0){
			create_class.seaDetails('blk2','s','请输入您要提取的金额！');
			return;
		}else if(isNaN(money)){
			create_class.seaDetails('blk2','s','您输入的金额不是数字，请重新输入！');
			return;
		}else if(z_name != t_name){
			create_class.seaDetails('blk2','s','您输入的不是真实姓名，请重新输入！');
			return;
		}else if(parseFloat(money) < 0.1){
			create_class.seaDetails('blk2','s','提取金额至少0.1元以上！');
			return;
			
		}else if(parseFloat(t_pr) < parseFloat(money)){
			
			create_class.seaDetails('blk2','s','提取金额不能大于您的账户余额！');
			return;
		}else{
			document.getElementById('checkForm').submit();
		}
		
		
	}
//身份 绑定
function userbanding(){
	var name=$('#name').val();
	var identityNum=$('#identityNum').val();
	var confirmIdentityNum=$('#confirmIdentityNum').val();
	if(checkNum(identityNum)=="false"){
		alert("身份证号码有误,请填写正确的身份证号码");
		return;
	}
	if(name==""){
		alert("请输入真实姓名！！！");
		return;
	}
	if(identityNum==""){
		alert("请输入身份证号码！！！");
		return;
	}
	if(confirmIdentityNum!=identityNum){
		alert("两次输入的身份证号码不一致！！！");
		return;
	}
	name=encodeURI(name);
	$.getJSON("../data/identityBind.jsp?r="+Math.random(),{name:name,identityNum:identityNum},function(items){
		if(items.items[0].strs=="0000"){
			alert("绑定成功！！！");
			location.reload();
		}else{
			alert("绑定失败！！！");
		}
	});
}
function checkNum(idcards){
	  var idcard=idcards;
	  var flg="";
	  var Errors=new Array("验证通过!","身份证号码位数不对!","身份证号码出生日期超出范围或含有非法字符!","身份证号码校验错误!","身份证地区非法!");
	  var area={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外"}
	  var idcard,Y,JYM;
	  var S,M;
	  var idcard_array = new Array();
	  idcard_array = idcard.split("");
	  if(area[parseInt(idcard.substr(0,2))]==null) flg="false";//alert( Errors[4]);
	  switch(idcard.length){
	    case 15:
	      if ((parseInt(idcard.substr(6,2))+1900) % 4 == 0 || ((parseInt(idcard.substr(6,2))+1900) % 100 == 0 && (parseInt(idcard.substr(6,2))+1900) % 4 == 0 )){
	        ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/;//测试出生日期的合法性
	      }
	      else{
	        ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/;//测试出生日期的合法性
	      }
	      if(ereg.test(idcard))
	      	flg="true";
	        //alert( Errors[0]);
	      else
	        //alert( Errors[2]);
	        flg="false";
	    break;
	  case 18:
	    if ( parseInt(idcard.substr(6,4)) % 4 == 0 || (parseInt(idcard.substr(6,4)) % 100 == 0 && parseInt(idcard.substr(6,4))%4 == 0 )){
	      	ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/;//闰年出生日期的合法性正则表达式
	    }
	    else{
	    	ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/;//平年出生日期的合法性正则表达式
	    }
	    if(ereg.test(idcard)){
	      S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7 + (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9 + (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10 + (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5 + (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8 + (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4 + (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2 + parseInt(idcard_array[7]) * 1 + parseInt(idcard_array[8]) * 6 + parseInt(idcard_array[9]) * 3 ;
	      Y = S % 11;
	      M = "F";
	      JYM = "10X98765432";
	      M = JYM.substr(Y,1);
	      if(M == idcard_array[17])
	        //alert( Errors[0]);
	        flg="true";
	      else
	        //alert( Errors[3]);
	        flg="false";
	    }
	    else
	      //alert( Errors[2]);
	      flg="false";
	    break;
	  default:
	    //alert( Errors[1]);
	    flg="false";
	    break;
  }
  return flg;
}