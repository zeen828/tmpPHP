KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="4";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;
function paging(ey,pages){
		var e_y_a='';
		pages = parseInt(pages);
		var countY = Math.ceil(ey);
		var next=pages >= ey ? ey : pages+1;
		var fist=pages <= 1 ? "1" : pages-1;
		var startY=0,endY=ey > 5 ? 8 : ey;
		if(pages>=5){
			startY = pages - 5; 
			endY   = ey - pages + 5 > ey ? ey :  pages + 5;
		}
		
		e_y_a+="<font color='#000'>共有"+KO.countEvery+"条记录，共有"+Math.ceil(ey)+"页</font><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('1','"+KO.U.Every+"') class='h_l'>◀</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'>◀◀</a>";
		var cls='';
		for(var e=startY;e<endY;e++){
			if(e<ey){
				if(e==(pages-1)) cls='an_x_z';
				else cls='';
				e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=ShowBuyLotteryDate("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			}else{
				break;
			}
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=ShowBuyLotteryDate('"+next+"','"+KO.U.Every+"') class='next'>▶▶</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+countY+"','"+KO.U.Every+"') class='h_l'>▶</a>";
		//e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		//"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='gray'>共"+countY+"页,"+(ey*parseInt(t_s))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}


function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	
	var ps=$("#govalue").val();
	ShowBuyLotteryDate(ps,KO.U.Every);
}

function ShowBuyLotteryDate(p,e){//解决了我的账户最近投注记录的不显示 ，左国斌 5-14
	$(".loding").show();
	var gameCode  = ""; 
	var status    = "";
	//条件查询
	if( KO.$('lotName')==null &&  KO.$('lotType')==null){
		gameCode="0";
		status="0";
	}else{
		gameCode=KO.$('lotName').value;//要加上.value这个属性，不然我的投注没结果
		status=KO.$('lotType').value;
		//alert(status);
	}
	 
	var xtDate = setting.getDateMonth(KO.$('startDate').value,KO.$('endDate').value);
	var beginTime = setting.formatTime(KO.$('startDate').value);
	var endTime   = KO.$('endDate').value.replace(/[-]/g,"")+"235959";
	var t_c=parseInt(setting.loadDate(KO.U.d,'s').substring(5,7))-2;
	t_c = t_c < 10 ? '0'+t_c : t_c;
	etm =  KO.U.d.getFullYear()+""+t_c+"01000000";
	if(xtDate > 60) {
		alert("您选择的时间段超过了2个月,请从新选择");
		$(".loding").hide();
		return;
	}
	KO.U.Pages = p;
	KO.U.Every = e;
	$.getJSON(url+'/letoula/data/buyLottery_records.jsp?r='+Math.random(),{'userid':userid,'gameid':gameCode,'status':status,'beginTime':beginTime,'endTime':endTime,'pages':KO.U.Pages,'every':KO.U.Every},function(list){
		var tr = '';
		var items = list.items;
		if(items.length == 0) tr = '<tr><td colspan="10">没有找到相关的记录！</td></tr>';
		$('#user_buy_list > tbody,.f_an_page,#rc_t_ty').empty();
		KO.countEvery=parseInt(list.recod);//总记录数
		KO.U.buyCountMoney=0;
		var ey=parseInt(list.recod)/parseInt(KO.U.Every);//页数
		ey = ey < 1 ? 1 : ey;
		paging(ey,p);
		
		for(var i=0;i<items.length;i++){
			var tzway='';
		 		var way=items[i].bettingType.split(',');
		 	
		 		if(items[i].gameid == '102' || items[i].gameid == '103' || items[i].gameid=='106' || items[i].gameid=='107'){
		 		
		 			tzway=Game_Map[items[i].bettingType];
		 			
		 		}else if(items[i].gameid == '301' || items[i].gameid == '302' || items[i].gameid=='303' || items[i].gameid=='304' || items[i].gameid=='305' ){
		 			
		 			for(var s=0;s<way.length;s++){
		 			
		 				tzway+=DC_McN_Map[way[s]]+'/';
		 			}
		 			tzway=tzway.substring(0,tzway.lastIndexOf('/'));
		 			
		 		}else{
		 		
		 			for(var s=0;s<way.length;s++){
		 			
		 				tzway+=McN_Map[way[s]]+'/';
		 			}
		 			tzway=tzway.substring(0,tzway.lastIndexOf('/'));
		 		}
		 	var listBg = i % 2 == 0 ? 'WhiteBg' : 'ContentLight';
			tr += 
				'<tr class="'+listBg+'">'+
				'<td>'+lotName[items[i].gameid]+'</td>'+//彩种
				'<td>'+setting.allformattime(items[i].starTime)+'</td>'+//投注时间
			    '<td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].rgPrice)+'</b></td>'+//投注金额
			    '<td>'+items[i].status+'</td>';//结算状态
			    if(items[i].gameid==701)
			    	{
			    		//alert(lotName[items[i].gameid]);
			    		 tr+= '<td><a href="'+url+'/member/chamtion_details.jsp?id='+items[i].trnNumber+'" target="_blank" class="blue">查看</a></td>'
						   +'</tr>';
			    	}
			    else
			    	{
			   tr+= '<td><a href="'+url+'/member/serNoScheme_details.jsp?id='+items[i].trnNumber+'" target="_blank" class="blue">查看</a></td>'
			   +'</tr>';
			    	}
			KO.U.buyCountMoney+=parseFloat(items[i].rgPrice);//当前页汇总购买
		}
		
		KO.U.buyCountMoney=parseFloat(KO.U.buyCountMoney).toFixed(2);//当前页汇总购买
		KO.U.CountRgMoney=parseFloat(list.countRgPrice).toFixed(2);//时间段内总共购买
		KO.U.CountZjMoney=parseFloat(list.countZjPrice).toFixed(2);//奖金

		$("#user_buy_list > tbody").html(tr);
		$('.nowMoney').text(KO.U.buyCountMoney);//当前页汇总购买
		$('.countMoney').text(KO.U.CountRgMoney);//时间段内总共购买
		$('.countBrouns').text(KO.U.CountZjMoney);//奖金
		$(".loding").hide();
	});
}
/**
 * 导出Excel
 */
function ExportBuyLotteryDate(){
	var gameCode  = ""; 
	var status    = "";
	//条件查询
	if( KO.$('lotName')==null &&  KO.$('lotType')==null){
		gameCode="0";
		status="0";
	}else{
		gameCode=KO.$('lotName').value;//要加上.value这个属性，不然我的投注没结果
		status=KO.$('lotType').value;
	}
	var beginTime = setting.formatTime(KO.$('startDate').value);
	var endTime   = KO.$('endDate').value.replace(/[-]/g,"")+"235959";
	window.location.href=url+'/letoula/data/buyLottery_records.jsp?userid='+userid+'&gameid='+gameCode+'&status='+status+'&beginTime='+beginTime+'&endTime='+endTime;


}


 $(function(){
	$('.page a').click(function(){
		$(this).siblings().removeClass();
		$(this).addClass('an_x_z');
		KO.U.Every=$(this).text();
		ShowBuyLotteryDate(KO.U.Pages,KO.U.Every);
	})
 })
 