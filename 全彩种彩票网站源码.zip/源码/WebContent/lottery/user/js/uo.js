
//区域表单结束
$.getJSON(url+"/letoula/data/showUser.jsp?r="+Math.random(),function(items){
		var address=items.items[0].address.split(',');
		var sex=items.items[0].sex;
		var phone=items.items[0].phone;
		
		var qusition01=items.items[0].pwdQuestion01;
		var answer01=items.items[0].pwdAnswer01;
		var qusition02=items.items[0].pwdQuestion02;
		var answer02=items.items[0].pwdAnswer02;
		var email=items.items[0].email;
		if(sex=="男"){
			$('#sex1').attr("checked",true);
		}
		if(sex=="女"){
			$('#sex2').attr("checked",true);
		}
		$("#phone").val(phone);
		$("#email").val(email);
		
		//$("#qusition01").val(qusition01);
		$("#answer01").val(answer01);
		//$("#qusition02").val(qusition02);
		$("#answer02").val(answer02);
		
		$('#qusition01').append("<option selected=selected>"+qusition01+"</option>");
		$('#qusition02').append("<option selected=selected>"+qusition02+"</option>");
		
		if(address.length >= 2){
			$('#province').append("<option selected=selected>"+decodeURI(address[0])+"</option>");
			$('#city').append("<option selected=selected>"+decodeURI(address[1])+"</option>");
			$('#district').append("<option selected=selected>"+decodeURI(address[2])+"</option>");
		}
		
});
//用户信息保存
function userInfoSave(){
	var sex = $("input[name='sex'][type='radio']:checked").val();
	var address=$("#province > option:selected").text()+','+$('#city > option:selected').text()+','+$('#district > option:selected').text();
	var phone=$("#phone").val();
	
	var qusition01=$("#qusition01").val();
	var answer01=$("#answer01").val();
	var qusition02=$("#qusition02").val();
	var answer02=$("#answer02").val();
	var email=$("#email").val();
	
	if(sex==undefined){
		//create_class.seaDetails('blk2','s','请选择性别！');
		alert("请选择性别！");
		return;
	}
	if(address==""){
		//create_class.seaDetails('blk2','s','请选择地址！');
		alert("请选择地址！");
		return;
	}
	if(phone==""){
		//create_class.seaDetails('blk2','s','请填写电话！');
		alert("请填写电话！");
		return;
	}
	
	if(qusition01==""){
		alert("请选择新问题一！");
		return;
	}
	if(answer01==""){
		alert("请回答新问题一！");
		return;
	}
	if(qusition02==""){
		alert("请选择新问题二！");
		return;
	}
	if(answer02==""){
		alert("请回答新问题二！");
		return;
	}
	if(email==""){
		alert("请填写电子邮箱！");
		return;
	}
	address=encodeURI(address);
	$.getJSON(url+"/letoula/data/info.jsp?r="+Math.random(),{'sex':sex,'address':address,'phone':phone,'qusition01':qusition01,'answer01':answer01,'qusition02':qusition02,'answer02':answer02,'email':email},function(items){
		if(items.items[0].str=="0000"){
			alert("保存成功！！！");
			window.close(); 
		}else{
			alert("保存失败！！！");
		}
	});
}

