KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="10";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;
 
function paging(ey,pages){
		var e_y_a='';
		pages = parseInt(pages);
		var countY = Math.ceil(ey);
		var next=pages >= ey ? ey : pages+1;
		var fist=pages <= 1 ? "1" : pages-1;
		var startY=0,endY=ey > 5 ? 8 : ey;
		if(pages>=5){
			startY = pages - 5; 
			endY   = ey - pages + 5 > ey ? ey :  pages + 5;
		}
		
		e_y_a+="<font color='#000'>共有"+KO.countEvery+"条记录，共有"+Math.ceil(ey)+"页</b><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('1','"+KO.U.Every+"') class='h_l'>◀</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'>◀◀</a>";
		var cls='';
		for(var e=startY;e<endY;e++){
			if(e<ey){
				if(e==(pages-1)) cls='an_x_z';
				else cls='';
				e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=ShowBuyLotteryDate("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			}else{
				break;
			}
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=ShowBuyLotteryDate('"+next+"','"+KO.U.Every+"') class='next'>▶▶</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+countY+"','"+KO.U.Every+"') class='h_l'>▶</a>";
		//e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		//"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='gray'>共"+countY+"页,"+(ey*parseInt(t_s))+"条记录</font>";
		
		$('.f_an_page').html(e_y_a);
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData(){
	
	var ps=$("#govalue").val();
	ShowBuyLotteryDate(ps,KO.U.Every);
}

function ShowBuyLotteryDate(p,e){
	$('.loding').show();
	var xtDate = setting.getDateMonth(KO.$('startDate').value,KO.$('endDate').value);
	var status    = KO.$("trnType").value;
	var beginTime = setting.formatTime(KO.$('startDate').value);
	var endTime   = KO.$('endDate').value.replace(/[-]/g,"")+"235959";
	var c_j=parseInt(KO.$('endDate').value.substring(5,7))-parseInt(KO.$('startDate').value.substring(5,7));
	var t_c=parseInt(setting.loadDate(KO.U.d,'s').substring(5,7))-2;
	t_c = t_c < 10 ? '0'+t_c : t_c;
	etm =  KO.U.d.getFullYear()+""+t_c+"01000000";
	

	
	KO.U.Pages = p;
	KO.U.Every = e;
	$.getJSON(url+'/letoula/data/account_details_list.jsp?r='+Math.random(),{'starTime':beginTime,'endTime':endTime,'pages':KO.U.Pages,'every':KO.U.Every,'buyType':status},function(list){
		//alert(111)
		var tr = '';
		var items = list.items;
	
		if(list.result!='0000'){
			alert(list.result);
			return;
		}
		if(items.length == 0) tr = '<tr><td colspan="10">您选择的时间段内 ，没有找到相关的记录！</td></tr>';
		
		KO.countEvery=parseInt(list.recod);
		var ey=parseInt(list.recod)/parseInt(KO.U.Every);
		ey = ey < 1 ? 1 : ey;
		paging(ey,p);
			
		for(var i=0;i<items.length;i++){
		
			var listBg = i % 2 == 0 ? 'WhiteBg' : 'ContentLight';
			if(status=='0' || status=='1006'){
				tr += '<tr class="'+listBg+'"><td>'+setting.allformattime(items[i].buyTime)+'</td><td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].lncome)+'</b></td>'+
				'<td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].ede)+'</b></td><td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].balance)+'</b></td><td>'+items[i].buyType+'</td><td><a href='+url+'/member/serNoScheme_details.jsp?id='+items[i].transactionNumber+' target="_blank">'+items[i].OrderNumber+'</a></td>'+
				'<td>'+items[i].source+'</td></tr>';
			}
			else if(status == '1002'){
				
				tr += '<tr class="'+listBg+'"><td>'+setting.allformattime(items[i].buyTime)+'</td><td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].lncome)+'</b></td>'+
				'<td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].ede)+'</b></td><td>'+items[i].buyType+'</td><td><a href="javascript:void(0)">'+items[i].transactionNumber+'</a></td>'+
				'<td>'+items[i].OrderNumber+'</td></tr>';
			}
			else if(status != '3')
			{
				
				tr += '<tr class="'+listBg+'"><td>'+setting.allformattime(items[i].buyTime)+'</td><td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].lncome)+'</b></td>'+
				'<td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].ede)+'</b></td><td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].balance)+'</b></td><td>'+items[i].OrderNumber+'</td>'+
				'<td>'+items[i].source+'</td></tr>';
				
			}else if(status == '3'){
				
				tr += '<tr class="'+listBg+'"><td>'+setting.allformattime(items[i].buyTime)+'</td><td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].ede)+'</b></td>'+
				'<td class="r_l">￥<b class="font_red">'+setting.numberFixed(items[i].lncome)+'</b></td><td>'+items[i].buyType+'</td><td><a href='+url+'/member/serNoScheme_details.jsp?id='+items[i].transactionNumber+' target="_blank">'+items[i].OrderNumber+'</a></td>'+
				'<td>'+items[i].source+'</td></tr>';
			}
			
		}
		$('.RightWidth_contenttab01 > tbody').html(tr);
		$('.loding').hide();
	});
	
	
}
/**
 * 导出Excel
 */
function ExportBuyLotteryDate(){
	var status    = KO.$("trnType").value;
	var beginTime = setting.formatTime(KO.$('startDate').value);
	var endTime   = KO.$('endDate').value.replace(/[-]/g,"")+"235959";
	window.location.href=url+'/letoula/data/account_details_list.jsp?buyType='+status+'&starTime='+beginTime+'&endTime='+endTime;


}



 $(function(){
	$('.page a').click(function(){
		$(this).siblings().removeClass();
		$(this).addClass('an_x_z');
		KO.U.Every=$(this).text();
		ShowBuyLotteryDate(KO.U.Pages,KO.U.Every);
	})
 })
 