var inputs = ['idcar','truename','tlePhone'];
var tips = {};
var _status = {};
var _isclick = {};
var isMouseDown = false;
var validCode="";
var isExit=false;

function $_(o){
	return document.getElementById(o);
}
function showErr(input, msg){
    var info = $('#'+input).parent().find('.info');
    info.show();
    if(input == 'reg_password') $('#psw_rank').hide();
   $('#'+input+'_err').html(msg).show();
   $('#'+input+'_tip,' + '#'+input+'_ok').hide();
};
function showOK(input){
    $('#'+input+'_tip').hide();
    $('#'+input+'_err').hide();
	$('#'+input+'_ok').css('display', 'block');
};
function checkInput(input){
	switch(input){
		case 'reg_username':
			_status['reg_username'] = checkUsername();
			break;
		case 'reg_password':
			_status['reg_password'] = checkPassword();
			break;
		case 'reg_password2':
			_status['reg_password2'] = checkPassword2();
			break;
		case 'idcar':
			_status['idcar'] = checkIdcard();
			break;
		case 'truename':
			_status['truename'] = checkturename();
			break;
		case 'tlePhone':
			_status['tlePhone'] = checktelPhone();
			break;

	}
	return _status[input];
};
function checktelPhone(){
	var telPhone = $_('tlePhone').value;
	if((/^18\d{9}$/g).test(telPhone)||(/^13\d{9}$/g).test(telPhone)||(/^15[0,1,2,3,4,5,6,7,8,9]\d{8}$/g.test(telPhone)))
    {
//        showOK('tlePhone');
    	$.getJSON(url+"/letoula/data/checkMobile.jsp?r="+Math.random(),{"mobile":telPhone},function(items){
    		if(items.items[0].strs!="0"){
    			//alert("对不起，该手机号码已经存在！");
    			isExit=true;
    			return _checkMobile({'code':-1, 'msg':'对不起，该手机号码已经存在！'});
    		}else{
    			showOK('tlePhone');
    			isExit=false;
    			return _checkMobile({'code':1, 'msg':'success'});
    		}
    	});
    }else
    {
          showErr('tlePhone', '您输入的手机号码不正确！');
          return false;
    }
	
};
function checkturename(){
	var truename = $_('truename').value;
	var m = /^[\u4e00-\u9faf]+$/;
	var flag = m.test(truename);
	if(!flag){
 		 showErr('truename', '真实姓名仅支持中文汉字！');
         return false;
	}else if(truename.length<2){
		 showErr('truename', '真实姓名输入错误！');
         return false;
	}
	 showOK('truename');
     return true;
};
function checkIdcard() {
			 var idcard = $_('idcar').value;
             var idcard_array = new Array();
             idcard_array = idcard.split("");

             switch (idcard.length) {
                 case 15:
                     if ((parseInt(idcard.substring(6, 2)) + 1900) % 4 == 0 || ((parseInt(idcard.substring(6, 2)) + 1900) % 100 == 0 && (parseInt(idcard.substring(6, 2)) + 1900) % 4 == 0)) {
                         ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/; //测试出生日期的合法性   
                     } else {
                         ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/; //测试出生日期的合法性   
                     }
                     if (ereg.test(idcard)) {
                          showOK('idcar');
             			  return true;
                     }
                     else {
                         showErr('idcar', '身份证号码有误，请检查确认！');
                         return false;
                     }
                     break;

                 case 18:
                     //18位身份号码检测   
                     //出生日期的合法性检查    
                     //闰年月日:((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))   
                     //平年月日:((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))   
                     if (parseInt(idcard.substring(6, 4)) % 4 == 0 || (parseInt(idcard.substring(6, 4)) % 100 == 0 && parseInt(idcard.substring(6, 4)) % 4 == 0)) {
                         ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/; //闰年出生日期的合法性正则表达式   
                     } else {
                         ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/; //平年出生日期的合法性正则表达式   
                     }
                     if (ereg.test(idcard)) {//测试出生日期的合法性   
                         //计算校验位   
                         S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7
     + (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9
     + (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10
     + (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5
     + (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8
     + (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4
     + (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2
     + parseInt(idcard_array[7]) * 1
     + parseInt(idcard_array[8]) * 6
     + parseInt(idcard_array[9]) * 3;
                         Y = S % 11;
                         M = "F";
                         JYM = "10X98765432";
                         M = JYM.substring(Y, Y + 1); /*判断校验位*/
                         if (M == idcard_array[17].toUpperCase()) {
                              showOK('idcar');
             				  return true;
                         }
                         else {
                         	 showErr('idcar', '身份证号码有误，请检查确认！');
                             return false;
                         }
                     }
                     else {
                          showErr('idcar', '身份证号码有误，请检查确认！');
                          return false;
                     }
                     break;

                 default:
                      showErr('idcar', '身份证号码有误，请检查确认！');
                      return false;
             }
             
             showOK('idcar');
             return true;
         };
//含中文的字符串长度
function getStrLen(str){
	var len = 0;
	var cnstrCount = 0;
	for(var i = 0 ; i < str.length ; i++){
		if(str.charCodeAt(i)>255)
		cnstrCount = cnstrCount + 1 ;
	}
	len = str.length + cnstrCount;
	return len;
}
function checkUsername(){
	var user = $_('reg_username').value;
	var len = getStrLen(user);
	if(len < 4){
		return _checkUsername({'code':-1, 'msg':'对不起，用户名长度至少应为4个字符'});
	}else if(len > 16){
		return _checkUsername({'code':-1, 'msg':'对不起，用户名长度不要超过16个字符'});
	}
	var uName=encodeURI(user);
	$.getJSON("../data/checkUserName.jsp?r="+Math.random(),{uName:uName,nickName:""},function(items){
		if(items.items[0].strs!="0"){
			return _checkUsername({'code':-1, 'msg':'对不起，该用户名已经存在！'});
		}else{
			return _checkUsername({'code':1, 'msg':'success'});
		}
	});
};
function _checkUsername(json){
	if(json.code<0){
        var remsg = json.msg.split('|||'),msg = remsg[0],name_tj = remsg[1];
		showErr('reg_username', msg);
	}else{
		showOK('reg_username');
	}
	_status['reg_username'] = json.code > 0;
	return json.code > 0 ? true : false;
};


function _checkMobile(json){
	if(json.code<0){
        var remsg = json.msg.split('|||'),msg = remsg[0],name_tj = remsg[1];
		showErr('tlePhone', msg);
	}else{
		showOK('tlePhone');
	}
	_status['tlePhone'] = json.code > 0;
	return json.code > 0 ? true : false;
};

function checkColid(o)
{
	//alert(isExit);
	if(isExit)
	{
		alert("注册的手机号码已经存在，请换个手机号码！");
		return false;
	}
	var telPhone = $_('tlePhone').value;
	$.getJSON(url+"/letoula/data/checkColid.jsp?r="+Math.random(),{"telPhone":telPhone},function(items){
		//alert(items.items[0].strs);
		validCode=items.items[0].strs;
		
	});
	time(o);
}

var wait=60;
function time(o) {
        if (wait == 0) {
            o.removeAttribute("disabled");            
            o.value="获取验证码";
            wait = 60;
        } else {
            o.setAttribute("disabled", true);
            o.value="重新发送(" + wait + ")";
            wait--;
            setTimeout(function() {
                time(o)
            },
            1000)
        }
    }


function checkPassword(){
	var user = $_('reg_username').value;
	var pwd = $_('reg_password').value;
	var len = pwd.length;
	if(len == 0){
		showErr('reg_password','请输入密码');
		return false;
	}
	else if(len<6){
		showErr('reg_password','您输入的密码不足6位，请重新输入');
		return false;
	}else if(len>15){
		showErr('reg_password','您输入的密码超过15位，请换个密码');
		return false;
	} else if (pwd==user)
	{
		showErr('reg_password','密码不能够与用户名一致！请重新输入');
		return false;
	}
	var cat = /^[\x20-\x7f]+$/;
	if(!(cat.test(pwd))) {
		showErr('reg_password','密码请勿包含中文');
		return false;
	}
	showOK('reg_password');
	showPassLevel(true);
	return true;
};
function showPassLevel(ishide){
	var lvl = results('reg_password'), ishide = ishide || false, isrealone = lvl;
	if(lvl==1 || lvl==2){
		$_('reg_password_err').innerHTML = '&nbsp;';
		$('#reg_password_ok').hide();
        lvl = 1;
	} else if(lvl == 3){
        lvl = 2;
    } else {
        lvl = 3;
    }
	var lvlName = {1:'弱',2:'中',3:'强'};
	if(lvl) {
        if(ishide) {
            $('#reg_password_tip, #reg_password_err, #psw_rank').hide();
            if(isrealone==1) {
                showErr('reg_password','密码强度很弱，建议重新输入');
            } else {
               showOK('reg_password');
            }
        } else {
            $('#reg_password_tip, #reg_password_err, #reg_password_ok').hide();
            $('#psw_rank').html('<div><em>'+lvlName[lvl]+'</em><p class="rank_'+lvl+'"><span></span></p></div>').show();
        }
    }
};
function corpses(pwdinput){
	var cat = /./g
	var str = $_(pwdinput).value;
	var sz = str.match(cat)
	for(var i=0;i<sz.length;i++){
		cat = /\d/;
		maths_01 = cat.test(sz[i]);
		cat = /[a-z]/;
		smalls_01 = cat.test(sz[i]);
		cat = /[A-Z]/;
		bigs_01 = cat.test(sz[i]);
		if(!maths_01&&!smalls_01&&!bigs_01){return  true;}
	}
	return false;
};
function results(pwdinput){
	var maths,smalls,bigs,corps,cat,num;
	var str = $_(pwdinput).value
	var len = str.length;

	var cat = /.{16}/g
	if(len == 0)return 1;
	if(len > 16){$_(pwdinput).value = str.match(cat)[0];}
	cat = /.*[\u4e00-\u9fa5]+.*$/
	if(cat.test(str)) {
		showErr('reg_password','密码请勿包含中文');
		return false;
	}
	cat = /\d/;
	var maths = cat.test(str);
	cat = /[a-z]/;
	var smalls = cat.test(str);
	cat = /[A-Z]/;
	var bigs = cat.test(str);
	var corps = corpses(pwdinput);
	var num = maths+smalls+bigs+corps;

	if(len<6){return 1;}

	if(len>=6&&len<=8){
		if(num == 1) return  1;
		if(num == 2 || num == 3) return  2;
		if(num == 4) return  3;
	}

	if(len>8 && len<=11){
		if(num == 1) return 2;
		if(num == 2) return 3;
		if(num == 3) return 4;
		if(num == 4) return 5;
	}

	if(len>11){
		if(num == 1) return 3;
		if(num == 2) return 4;
		if(num  > 2) return 5;
	}
};
function checkPassword2(){
	if($_('reg_password2').value == ''){
		showErr('reg_password2','请再次输入密码');
		return false;
	}
	if($_('reg_password').value != $_('reg_password2').value){
		showErr('reg_password2','密码不一致，请重新输入');
		return false;
	}else{
		showOK('reg_password2');
		return true;
	}
};
function fade(begin, to, fn, tt){
        setStyle('opacity', 1); //ui建议去掉渐变
        return false;
        clearInterval(this.timer);
        this.timer=fx(function (f, i){
            setStyle('opacity', f(begin,to));
        }, fn)
    };
function InputOnFocus(e){
	var srcEle=e.srcElement?e.srcElement:e.target, info = $(srcEle).parent().find('.info');
    $(srcEle).addClass('focus');
    info.show();
};

function InputOnBlur(e){
	var srcEle=e.srcElement?e.srcElement:e.target, info = $(srcEle).parent().find('.info');
	$(srcEle).removeClass('focus');
    if(srcEle.id != 'reg_username' && $_(srcEle.id).value=='') info.hide();
	return $(srcEle).val() != '' ? checkInput(srcEle.name) : false;
};

function InputKeyUp(e){
	var srcEle=e.srcElement?e.srcElement:e.target, info = $(srcEle).parent().find('.info'),iid = srcEle.id, vv = $_(iid).value, ll = vv.length;
    if(ll==0) {
        $('#'+iid+'_err, #'+iid+'_ok').hide();
        $('#'+iid+'_tip').show();
        if(iid == 'reg_password') $('#psw_rank').hide();
    } else {
        if(iid == 'reg_password' && ll>=6 && ll<=15) showPassLevel();
        if(iid == 'reg_username' && ll>=4) checkUsername();
    }
};
function initInput(){
	var len = inputs.length;
	for(var i=0;i<len;i++){
		var inpt = $_(inputs[i]);
		if(window.addEventListener){  //FF
			inpt.addEventListener("focus",InputOnFocus,false);
            inpt.addEventListener("keyup",InputKeyUp,false);
            inpt.addEventListener("blur",InputOnBlur,false);
		}else{  //IE chrome
			inpt.attachEvent("onfocus",InputOnFocus);
            inpt.attachEvent("onkeyup",InputKeyUp);
            inpt.attachEvent("onblur",InputOnBlur);
		}
		_status[inputs[i]] = false;
	}
};

function checkForm(){
	var colid = $_('colid').value;
	if($('year18').checked==false){
		alert('您必须同意我们的服务条款才可以注册');
		return false;
	}
	var len = inputs.length;
	for(var i=0;i<len;i++){
		if(!_status[inputs[i]]){
			$(inputs[i]).focus();
			return !!checkInput(inputs[i]);
		}
	}
	if(colid.length==0)
	{
		alert('请输入短信验证码！');
		return false;
	}
	if(validCode!=colid){
		alert('对不起，短信验证码不正确！');
		return false;
		//return _checkUsername({'code':-1, 'msg':'对不起，验证码不正确！'});
	}else{
		return true;
		//return _checkUsername({'code':1, 'msg':'success'});
	}
	$_('subfrm').disabled = "disabled";
	return true;
};

