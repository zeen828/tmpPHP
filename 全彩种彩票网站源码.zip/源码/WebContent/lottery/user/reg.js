var inputs = ['reg_username','reg_password','reg_password2'];
var tips = {};
var _status = {};
var _isclick = {};
var isMouseDown = false;

function $_(o){
	return document.getElementById(o);
}
function showErr(input, msg){
    var info = $('#'+input).parent().find('.info');
    info.show();
    if(input == 'reg_password') $('#psw_rank').hide();
   $('#'+input+'_err').html(msg).show();
   $('#'+input+'_tip,' + '#'+input+'_ok').hide();
};
function showOK(input){
    $('#'+input+'_tip').hide();
    $('#'+input+'_err').hide();
	$('#'+input+'_ok').css('display', 'block');
};
function checkInput(input){
	switch(input){
		case 'reg_username':
			_status['reg_username'] = checkUsername();
			break;
		case 'reg_password':
			_status['reg_password'] = checkPassword();
			break;
		case 'reg_password2':
			_status['reg_password2'] = checkPassword2();
			break;

	}
	return _status[input];
};
//含中文的字符串长度
function getStrLen(str){
	var len = 0;
	var cnstrCount = 0;
	for(var i = 0 ; i < str.length ; i++){
		if(str.charCodeAt(i)>255)
		cnstrCount = cnstrCount + 1 ;
	}
	len = str.length + cnstrCount;
	return len;
}
function checkUsername(){
	var user = $_('reg_username').value;
	var len = getStrLen(user);
	if(len < 4){
		return _checkUsername({'code':-1, 'msg':'对不起，用户名长度至少应为4个字符'});
	}else if(len > 16){
		return _checkUsername({'code':-1, 'msg':'对不起，用户名长度不要超过16个字符'});
	}
	var uName=encodeURI(user);
	$.getJSON("../data/checkUserName.jsp?r="+Math.random(),{uName:uName,nickName:""},function(items){
		if(items.items[0].strs!="0"){
			return _checkUsername({'code':-1, 'msg':'对不起，该用户名已经存在！'});
		}else{
			return _checkUsername({'code':1, 'msg':'success'});
		}
	});
};
function _checkUsername(json){
	if(json.code<0){
        var remsg = json.msg.split('|||'),msg = remsg[0],name_tj = remsg[1];
		showErr('reg_username', msg);
	}else{
		showOK('reg_username');
	}
	_status['reg_username'] = json.code > 0;
	return json.code > 0 ? true : false;
};
function checkPassword(){
	var user = $_('reg_username').value;
	var pwd = $_('reg_password').value;
	var len = pwd.length;
	if(len == 0){
		showErr('reg_password','请输入密码');
		return false;
	}
	else if(len<6){
		showErr('reg_password','您输入的密码不足6位，请重新输入');
		return false;
	}else if(len>15){
		showErr('reg_password','您输入的密码超过15位，请换个密码');
		return false;
	} else if (pwd==user)
	{
		showErr('reg_password','密码不能够与用户名一致！请重新输入');
		return false;
	}
	var cat = /^[\x20-\x7f]+$/;
	if(!(cat.test(pwd))) {
		showErr('reg_password','密码请勿包含中文');
		return false;
	}
	showOK('reg_password');
	showPassLevel(true);
	return true;
};
function showPassLevel(ishide){
	var lvl = results('reg_password'), ishide = ishide || false, isrealone = lvl;
	if(lvl==1 || lvl==2){
		$_('reg_password_err').innerHTML = '&nbsp;';
		$('#reg_password_ok').hide();
        lvl = 1;
	} else if(lvl == 3){
        lvl = 2;
    } else {
        lvl = 3;
    }
	var lvlName = {1:'弱',2:'中',3:'强'};
	if(lvl) {
        if(ishide) {
            $('#reg_password_tip, #reg_password_err, #psw_rank').hide();
            if(isrealone==1) {
                showErr('reg_password','密码强度很弱，建议重新输入');
            } else {
               showOK('reg_password');
            }
        } else {
            $('#reg_password_tip, #reg_password_err, #reg_password_ok').hide();
            $('#psw_rank').html('<div><em>'+lvlName[lvl]+'</em><p class="rank_'+lvl+'"><span></span></p></div>').show();
        }
    }
};
function corpses(pwdinput){
	var cat = /./g
	var str = $_(pwdinput).value;
	var sz = str.match(cat)
	for(var i=0;i<sz.length;i++){
		cat = /\d/;
		maths_01 = cat.test(sz[i]);
		cat = /[a-z]/;
		smalls_01 = cat.test(sz[i]);
		cat = /[A-Z]/;
		bigs_01 = cat.test(sz[i]);
		if(!maths_01&&!smalls_01&&!bigs_01){return  true;}
	}
	return false;
};
function results(pwdinput){
	var maths,smalls,bigs,corps,cat,num;
	var str = $_(pwdinput).value
	var len = str.length;

	var cat = /.{16}/g
	if(len == 0)return 1;
	if(len > 16){$_(pwdinput).value = str.match(cat)[0];}
	cat = /.*[\u4e00-\u9fa5]+.*$/
	if(cat.test(str)) {
		showErr('reg_password','密码请勿包含中文');
		return false;
	}
	cat = /\d/;
	var maths = cat.test(str);
	cat = /[a-z]/;
	var smalls = cat.test(str);
	cat = /[A-Z]/;
	var bigs = cat.test(str);
	var corps = corpses(pwdinput);
	var num = maths+smalls+bigs+corps;;

	if(len<6){return 1;}

	if(len>=6&&len<=8){
		if(num == 1) return  1;
		if(num == 2 || num == 3) return  2;
		if(num == 4) return  3;
	}

	if(len>8 && len<=11){
		if(num == 1) return 2;
		if(num == 2) return 3;
		if(num == 3) return 4;
		if(num == 4) return 5;
	}

	if(len>11){
		if(num == 1) return 3;
		if(num == 2) return 4;
		if(num  > 2) return 5;
	}
};
function checkPassword2(){
	if($_('reg_password2').value == ''){
		showErr('reg_password2','请再次输入密码');
		return false;
	}
	if($_('reg_password').value != $_('reg_password2').value){
		showErr('reg_password2','密码不一致，请重新输入');
		return false;
	}else{
		showOK('reg_password2');
		return true;
	}
};
function fade(begin, to, fn, tt){
        setStyle('opacity', 1); //ui建议去掉渐变
        return false;
        clearInterval(this.timer);
        this.timer=fx(function (f, i){
            setStyle('opacity', f(begin,to));
        }, fn)
    };
function InputOnFocus(e){
	var srcEle=e.srcElement?e.srcElement:e.target, info = $(srcEle).parent().find('.info');
    $(srcEle).addClass('focus');
    info.show();
};

function InputOnBlur(e){
	var srcEle=e.srcElement?e.srcElement:e.target, info = $(srcEle).parent().find('.info');
	$(srcEle).removeClass('focus');
    if(srcEle.id != 'reg_username' && $_(srcEle.id).value=='') info.hide();
	return $(srcEle).val() != '' ? checkInput(srcEle.name) : false;
};

function InputKeyUp(e){
	var srcEle=e.srcElement?e.srcElement:e.target, info = $(srcEle).parent().find('.info'),iid = srcEle.id, vv = $_(iid).value, ll = vv.length;
    if(ll==0) {
        $('#'+iid+'_err, #'+iid+'_ok').hide();
        $('#'+iid+'_tip').show();
        if(iid == 'reg_password') $('#psw_rank').hide();
    } else {
        if(iid == 'reg_password' && ll>=6 && ll<=15) showPassLevel();
        if(iid == 'reg_username' && ll>=4) checkUsername();
    }
};
function initInput(){
	var len = inputs.length;
	for(var i=0;i<len;i++){
		var inpt = $_(inputs[i]);
		if(window.addEventListener){  //FF
			inpt.addEventListener("focus",InputOnFocus,false);
            inpt.addEventListener("keyup",InputKeyUp,false);
            inpt.addEventListener("blur",InputOnBlur,false);
		}else{  //IE chrome
			inpt.attachEvent("onfocus",InputOnFocus);
            inpt.attachEvent("onkeyup",InputKeyUp);
            inpt.attachEvent("onblur",InputOnBlur);
		}
		_status[inputs[i]] = false;
	}
};

function checkForm(){
	if($_('year18').checked==false){
		alert('您必须同意我们的服务条款才可以注册');
		return false;
	}
	var len = inputs.length;
	for(var i=0;i<len;i++){
		if(!_status[inputs[i]]){
			$(inputs[i]).focus();
			return !!checkInput(inputs[i]);
		}
	}
	$_('subfrm').disabled = "disabled";
	return true;
};
