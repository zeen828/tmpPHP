﻿

function details_submit(as){
	var parmas=as.getAttribute('sb').split(',');
	KO.$('userName').value  =	 parmas[0];
	KO.$('muliptiles').value =	 parmas[1];
	KO.$('Copis').value     =    parmas[2];
	KO.$('copisPrice').value=    parmas[3];
	KO.$('bdCopies').value  =    parmas[4];
	KO.$('progress').value  =	 parmas[5];
	KO.$('tzway').value     =	 parmas[6];
	KO.$('csm').value   	=    parmas[8];
	KO.$('starTime').value  =    parmas[9];
	KO.$('endTime').value   =    parmas[10];
	KO.$('id').value   		=    parmas[11];
	KO.$('Trading').value   =    parmas[12];
	KO.$('sycopies').value  =    parmas[13];
	KO.$('rgCopis').value   =    parmas[14];
	KO.$('listform').moneyFw.value   =    parmas[7];
	KO.$('listform').gameCode.value  =    parmas[15];
	if(parseInt(parmas[15]) < 505 )
		KO.$('listform').action = './letoula/jczq/list_Details.jsp';
	else
		KO.$('listform').action = './letoula/jclq/list_Details.jsp';
	KO.$('listform').submit();
}

//滚动插件
(function($){
$.fn.extend({
        Scroll:function(opt,callback){
                //参数初始化
                if(!opt) var opt={};
                var _this=this.find(""+opt.dv+":first");
                var lineH=15, //获取行高
                        line=opt.line?parseInt(opt.line,10):parseInt(this.height()/lineH,10), //每次滚动的行数，默认为一屏，即父容器高度
                        speed=opt.speed?parseInt(opt.speed,10):300, //卷动速度，数值越大，速度越慢（毫秒）
                        timer=opt.timer?parseInt(opt.timer,10):2000; //滚动的时间间隔（毫秒）
                if(line==0) line=1;
                var upHeight=0-line*lineH;
                //滚动函数
                scrollUp=function(){
                        _this.animate({
                                marginTop:upHeight
                        },speed,function(){
                                for(i=1;i<=line;i++){
                                        _this.find(""+opt.sa+":first").appendTo(_this);
                                }
                                _this.css({marginTop:0});
                        });
                }
                //鼠标事件绑定
                _this.hover(function(){
                        clearInterval(timerID);
                },function(){
                        timerID=setInterval("scrollUp()",timer);
                }).mouseout();
        }       
})
})(jQuery);



$(document).ready(function(){
	
	setting.showMultiples(100);
	$("#marquee").Scroll({line:1,dv:'div',sa:'div',speed:300,timer:3000});
	
	$('.help_head ul li').mouseover(function(){
		$('.helpheadliv').removeClass('helpheadliv').addClass('helpheadlio');
		$(this).removeClass('helpheadlio').addClass('helpheadliv');
		$('.help_content div').hide();
		switch($(this).index()){
			case 0:$('.lc').show();break;
			case 1:$('.aq').show();break;
			case 2:$('.xs').show();break;
		}
	})
	
	
	$('.itnLotteryMenu ul li').bind('click',function(){
		
		$(this).siblings().attr('class','');
		this.className='itnxz';
	})
	

	$.getJSON('./letoula/data/buy_hot_Single.jsp?r='+Math.random(),{'parame':'args'},function(items){
		
			var buyItems = items.BuyItems,wgItems  = items.wgItems;
			
			$(buyItems).each(function(i,v){
				
				var tzway='';
		 		var way=v.way.split(',');
		 		for(var s=0;s<way.length;s++){
		 			tzway+=McN_Map[way[s]]+'/';
		 		}
		 		tzway=tzway.substring(0,tzway.lastIndexOf('/'));
		 		
				var progress=parseFloat(v.rgCopis/v.countCopis*100).toFixed(2),
				name = v.userName.length > 9 ? v.userName+'**' : v.userName,
				sy_copies=v.countCopis-v.rgCopis,
				tr = "<tr><td valign='center'>"+name +"</td><td valign='center'><font color='#ff0000' class='m_l'>￥"+v.btPrice+"</font></td>"+
    				  "<td><font color='#ff0000' style='font:10px Arial;'>"+progress+"%</font><div class='pg'><div class='jd' id='sp"+i+"'></div></div></td>"+
    				  "<td valign='center'><a onclick='details_submit(this)' sb='"+v.userName+","+v.multiples+","+v.countCopis+","+v.copisPrice+","+v.bdCopies+","+progress+","+tzway+","+v.moneyFw+","+v.csm+","+v.starTime+","+v.endTime+","+v.id+","+v.Trading+","+sy_copies+","+v.rgCopis+","+v.gameType+"' class='rg'>参与</a></td></tr><tr>";
    			$(tr).appendTo('#chippedTab > tbody');  
    			//KO.$('sp'+i+'').style.width = progress+'%';
			})
			
			for(var s=0;s<wgItems.length;s++){
				if(s > 7) break;
				var name = wgItems[s].nikeName.length > 13 ? wgItems[s].nikeName+'**' : wgItems[s].nikeName;
				
				$("<tr><td>"+(s+1)+"</td><td>"+wgItems[s].nikeName+"</td><td class='price'  align='right'><font class='m_l'>￥"+wgItems[s].award+"</font></td><td><a href='./letoula/useraccount/index.jsp?l=1&url=usertouzhu/anther_single.jsp&u="+wgItems[s].nikeName+"' class='dz'>定制</a></td></tr>").appendTo('#rankingTab > tbody');
			}
			
	});

	showDz();
	
	 
});

window.onscroll=function(){
  		var num_scroll_top = 0;
        if(document.body.scrollTop){
           num_scroll_top=document.body.scrollTop;
        }
        else{
           num_scroll_top=document.documentElement.scrollTop;
        }    
        $("#bd").css("top",num_scroll_top);
 }