Ext = {};//Ext = {};
Ext.javapackage = function() {
	var a = arguments, o = null, i, j, d, rt;
	for (i = 0;i < a.length; ++i) {
		d = a[i].split(".");
		rt = d[0];
		eval('if (typeof ' + rt + ' == "undefined"){' + rt + ' = {};} o = '
				+ rt + ';');
		for (j = 1;j < d.length; ++j) {
			o[d[j]] = o[d[j]] || {};
			o = o[d[j]];
		}
	}
};

Ext.apply = function(o, c, defaults){
    if(defaults){
        // no "this" reference for friendly out of scope calls
        Ext.apply(o, defaults);
    }
    if(o && c && typeof c == 'object'){
        for(var p in c){
            o[p] = c[p];
        }
    }
    return o;
};

/*====================Array====================*/
Ext.apply(Array.prototype, {
    indexOf : function(o){
       for (var i = 0, len = this.length; i < len; i++){
 	      if(this[i] == o) return i;
       }
 	   return -1;
    },
    remove : function(o){
       var index = this.indexOf(o);
       if(index != -1){
           this.splice(index, 1);
       }
    }
});

/*====================String====================*/
Ext.apply(String.prototype, {
	trim : function() {
		return this.replace(/(\s*$)/g, "").replace(/(^\s*)/g, "");//先去掉结尾空格，再去掉开头空格。
	},
	format : function() {
    	var args = Array.prototype.slice.call(arguments, 0);
    	return this.replace(/\{(\d+)\}/g, function(m, i){return args[i];});
    },
	formatAry : function() {
		var a=arguments;
		if(typeof arguments[0]=="object"){
			a=arguments[0];
		}
		var args = Array.prototype.slice.call(a, 0);
    	return this.replace(/\{(\d+)\}/g, function(m, i){return args[i];});
	},
    zero2int: function() {
    	if(parseInt(this)!=0)return parseInt(this);
    	return parseInt(this.replace(/^0/,""));
    },
    clearZero: function(){
    	var t=""+this;
		if(t[0]=="0"){
			t=this.replace(/^0/,"");
			t=clearZear(t);
		}
		return t;
	},
	string2int: function(){//前面n个0的字符串变数字
		var t=""+this;
		while((/^0/.test(t)))t=t.replace(/^0/,"");
		return /^\d+$/.test(t)?parseInt(t):t;
	}
});

/*====================Function====================*/
Ext.apply(Function.prototype, {
    createCallback : function(/*args...*/){
        var args = arguments;
        var method = this;
        return function() {
            return method.apply(window, args);
        };
    },
    createDelegate : function(obj, args, appendArgs){
        var method = this;
        return function() {
            var callArgs = args || arguments;
            if(appendArgs === true){
                callArgs = Array.prototype.slice.call(arguments, 0);
                callArgs = callArgs.concat(args);
            }else if(typeof appendArgs == "number"){
                callArgs = Array.prototype.slice.call(arguments, 0); // copy arguments first
                var applyArgs = [appendArgs, 0].concat(args); // create method call params
                Array.prototype.splice.apply(callArgs, applyArgs); // splice them in
            }
            return method.apply(obj || window, callArgs);
        };
    },
    defer : function(millis, obj, args, appendArgs){
        var fn = this.createDelegate(obj, args, appendArgs);
        if(millis){
            return setTimeout(fn, millis);
        }
        fn();
        return 0;
    },
    createSequence : function(fcn, scope){
        if(typeof fcn != "function"){
            return this;
        }
        var method = this;
        return function() {
            var retval = method.apply(this || window, arguments);
            fcn.apply(scope || this || window, arguments);
            return retval;
        };
    },
    createInterceptor : function(fcn, scope){
        if(typeof fcn != "function"){
            return this;
        }
        var method = this;
        return function() {
            fcn.target = this;
            fcn.method = method;
            if(fcn.apply(scope || this || window, arguments) === false){
                return;
            }
            return method.apply(this || window, arguments);
        };
    }
});