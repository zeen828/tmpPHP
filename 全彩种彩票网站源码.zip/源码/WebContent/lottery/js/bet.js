var inputs = ['sbConpies','side','schmeTitle','description'];
var _status = {};
var subFlag = false;

function $_(o){
	return document.getElementById(o);
}

function payofftcChange(){
	var payofftc = $("#comm").val();
	$("#payofftc").val(payofftc);
};
function checkTitle(){
	var title = $('#schmeTitle').val();
	if(title==''){
		title = "合买中大奖,不在是梦";
		$('#schmeTitle').val(title);
	}
	$("#title").val(title);
};
function checkDesciption(){
	var decortion = $('#description').text();
	if(decortion==''){
		 decortion = '此单太绝,跟单必盈';
		 $('#description').text(decortion);
	}
	$("#subdescription").val(decortion);
};
function checkCopies(){
	var copies = $('#sbConpies').val();
	if(copies=='' || isNaN(copies) || parseInt(copies)<1){
		$('#sbConpies').val('');
		$('#uRgE').show().text('您至少要认购1元');
		subFlag = false;
		return;
	}else if(parseInt(copies)>parseInt(money)){
		$('#sbConpies').val(money);
		$('#uRgE').hide();
	}else{
		$('#uRgE').hide();
	}
	$("#betcopies").val($("#sbConpies").val());//sbCopies
	//alert("copies--"+copies);
	subFlag = true;
};
function checkSide(){
	var side = $('#side').val();
	var copies = $('#sbConpies').val();
	if(side=='' || isNaN(side) || parseInt(side)<1){
		$('#side').val('');
		$('#baodi').show().text('您至少要保底1元');
		subFlag = false;
		return;
	}else if(parseInt(side)>(parseInt(money)-parseInt(copies))){
		$('#side').val(parseInt(money)-parseInt(copies));
		$('#baodi').hide();
	}else{
		$('#baodi').hide();
	}
	$("#ensures").val(side);
	subFlag = true;
};
function InputOnFocus(e){
	var srcEle=e.srcElement?e.srcElement:e.target, info = $(srcEle).parent().find('.info');
    $(srcEle).addClass('focus');
    info.show();
};
function checkInput(input){
	switch(input){
		case 'sbConpies':
			_status['sbConpies'] = checkCopies();
			break;
		case 'side':
			_status['side'] = checkSide();
			break;
		case 'schmeTitle':
			_status['schmeTitle'] = checkTitle();
			break;
		case 'description':
			_status['description'] = checkDesciption();
			break;

	}
	return _status[input];
};
function InputOnFocus(e){
	var srcEle=e.srcElement?e.srcElement:e.target;
	srcEle.focus();
    srcEle.select();
};
function InputOnBlur(e){
	var srcEle=e.srcElement?e.srcElement:e.target;
	checkInput(srcEle.name);
};

function InputKeyUp(e){
	var srcEle=e.srcElement?e.srcElement:e.target,iid = srcEle.id, vv = $_(iid).value, ll = vv.length;
    if(iid == 'sbConpies') checkCopies();
    if(iid == 'side') checkSide();
};
function initInput(){
	var len = inputs.length;
	for(var i=0;i<len;i++){
		var inpt = $_(inputs[i]);
		if(window.addEventListener){  //FF
			inpt.addEventListener("focus",InputOnFocus,false);
            inpt.addEventListener("keyup",InputKeyUp,false);
            inpt.addEventListener("blur",InputOnBlur,false);
		}else{  //IE chrome
			inpt.attachEvent("onfocus",InputOnFocus);
            inpt.attachEvent("onkeyup",InputKeyUp);
            inpt.attachEvent("onblur",InputOnBlur);
		}
		_status[inputs[i]] = false;
	}
};
function submitAllForm(){
	if(!subFlag)
	{
		create_class.seaDetails('blk2','s','合买信息有误,请检查完善后提交.','success',Y.S);
		return;
	}
};
$(function(){
	initInput();
	$('#downside').click(function(){
		if($(this).attr('checked')){
			var copies = parseInt($('#sbConpies').val());
			//alert("111  "+copies);
			if((copies+1) > money){
				$('#sbConpies').val(copies-1);
			}
			$('#side').val('1').attr('disabled',false);
			$('#ensures').val($('#side').val());
		}else{
			$('#side').val('0').attr('disabled',true);
		}
	});
	
	$('.betSetting').click(function(){
		$('.betSetting').attr('checked',false);
		$(this).attr('checked',true);
		var id = $(this).attr('id');
		var value = $(this).val();
		if(id=='hm'){
			$('#subcopies').val(money);
			$('#subeachPrice').val('1');
			$("#payofftc").val($('#comm').val());
			$("#betcopies").val($('#sbConpies').val());
			//alert($('#sbConpies').val());
			$("#ensures").val($('#side').val());
			$("#title").val($('#schmeTitle').val());
			$("#subdescription").val($('#description').text());
			$('.hmtr').show();
		}else{
			$('#subcopies').val('1');
			$('#subeachPrice').val(money);
			$("#payofftc").val('0');
			$("#betcopies").val('1');
			$("#ensures").val('0');
			$("#title").val('合买中大奖,不在是梦');
			$("#subdescription").val('此单太绝,跟单必盈');
			$('.hmtr').hide();
		}
		$('#hmfaType').val(value);
	});
});

function getComm(val)
{
	$("#payofftc").val($('#comm').val());
}

function getOpen(){
	 var radios = document.getElementsByName("gk");
	  for ( var i = 0; i < radios.length; i++) {
	  if (radios[i].checked==true) {
	      var val=radios[i].value;
	      console.info(val);
	      $("#isopen").val(val);
	   }
	  }
}