
KO.Y={};
KO.Y.Trading=AG.Trading;
KO.Y.User=AG.user();
KO.Y.CP='份';
KO.Y.CR='元';
KO.Y.Pages="1";
KO.Y.Every="10";
KO.countEvery="0";
KO.S = url+'/letoula/hmdt/hm_center.jsp';
KO.LS = url+'/letoula/jclq/project_list.jsp?gameid='+'';//此处


$('.yh_tab ul li').bind('click',function(){
	$(this).siblings().removeClass();
	$(this).removeClass().addClass('hovertab4');
	$('.list_table').hide().eq($(this).index()).show();

	if($(this).index()==1) showUserData(KO.Y.Trading,"1",KO.countEvery); 
	else showUserData(KO.Y.Trading,KO.Y.Pages,"10"); 
})


function Chipped_in_submit(_this,trading){
	
	var copies=$(".buyt1").val(); 
	if(copies == ''){
		alert("请输入您要购买的份数！");
		return;
	}else if(copies == '0'){
		alert("购买份数不能为0份！");
		return;
	}
	//create_class.seaDetails('blk2','s','您好！投注中....','success',KO.S);
	$.getJSON(url+"/letoula/data/Chipped_in_submit.jsp?r="+Math.random(),{'gameid':AG.gameid,'Trading':trading,'copies':copies},function(su){
		
		if(su.result=='0000'){
			create_class.seaDetails('blk2','s','您好！您参与合买成功！','success',KO.S);
		}else{
			
			//create_class.seaDetails('blk2','s','您好！'+su.result+'','error',KO.S);
			if(su.result=='S050'){
				//create_class.seaDetails('blk2','s','您好！余额不足,请充值!<a href="#">充值</a>','error',KO.S);
				jQuery.alertWindow("温馨提示:","您的余额不足!");

			}else{
				
				create_class.seaDetails('blk2','s','您好！购买出错!可能是系统繁忙!','error',KO.S);
			}
		}
	})
	
}
function over_t(l){
	
	var u = l == 'l' ? KO.LS : KO.S;
	create_class.seaDetails('blk2','h','','success',u);
		
}

function showUserData(t,p,e){
	KO.Y.Pages=p;
	KO.Y.Every=e;
	var Count_Record='';
	var My_Record='<tr><td>暂时没有您的认购信息 </td></tr>';
	
	$.getJSON(url+"/letoula/data/list_user_data.jsp?r="+Math.random(),{'Trading':t,'pages':KO.Y.Pages,'every':KO.Y.Every},function(items){
		var article = items.record; //总条数
		var c_pis=0,c_pic=0,gr='',trc='';  //购买总份数
		var List = items.items;
		$('.countList,.myList,.f_an_page').empty();
		KO.countEvery=items.record;
		var ey=parseInt(items.record)/parseInt(KO.Y.Every);
		ey = ey < 1 ? 1 : Math.ceil(ey);
		
		create_class.paging(ey,p);
		My_Record='';
		var m = 0;
		for(var i=0;i<List.length;i++){
			
			gr = List[i].userName==AG.Lcd_user ? 'red' : 'gray';
			List[i].userName = List[i].hmtype == '1' ? List[i].userName.charAt(0)+"*****":List[i].userName;
			var bili = parseFloat(List[i].price / (List[i].totalcopies * List[i].each) * 100).toFixed(2);
			if(i==0){
	    		Count_Record+="<tr><td>"+(i+1)+"</td><td>"+List[i].userName+"(发起人)</td><td>￥"+List[i].price+"</td><td>"+bili+"%</td><td>"+create_class.string2timeHS(List[i].buyTime)+"</td><td><font color='red'>￥"+List[i].yesMoney+"</font></td></tr>";
			}else{
	    		Count_Record+="<tr><td>"+(i+1)+"</td><td>"+List[i].userName+"</td><td>￥"+List[i].price+"</td><td>"+bili+"%</td><td>"+create_class.string2timeHS(List[i].buyTime)+"</td><td><font color='red'>￥"+List[i].yesMoney+"</font></td></tr>";

			}
    					  
    		if(KO.Y.User==List[i].userName){
    			m++;
    			My_Record+="<tr><td>"+m+"</td><td>"+List[i].userName+"</td><td>￥"+List[i].price+"</td><td>"+bili+"%</td><td>"+create_class.string2timeHS(List[i].buyTime)+"</td><td><font color='red'>￥"+List[i].yesMoney+"</font></td></tr>";
    					  
    		}
    		
		}
		
		if(List.length<=0){
			Count_Record = "<tr><td colspan='6'>您好！暂无合买跟单用户</td></tr>";
		}
	
		if(KO.Y.User == 'null' || KO.Y.User == ''){
			My_Record = "<tr><td colspan='7'>您好！您还未登陆请<a href='#headMain'>登陆</a></td></tr>";
		}
		
		$('.h_p').text(KO.countEvery);
		$(Count_Record).appendTo('.countList');
		$(My_Record).appendTo('.myList');
	});
	
}
function mltOnkeyUps(){
		
		var _this=arguments[0],
			val=parseInt(_this.value),
			reg=/^(0|[1-9][0-9]*)$/g;
		var fs=AG.shengFen;
		if(!reg.test(_this.value) || val <= 0 || val>fs){
			
		   _this.value=1;
		   if(val>fs){
		   		
		   		_this.value=fs;
		   }
		}
		
		var bfb = parseFloat(parseInt(_this.value) / parseInt(AG.shengFen) * 100).toFixed(2);
		$('.buypercent').text(bfb+'%');
		$('.countMoney').text('￥'+(parseInt(_this.value)*AG.copisPrice)+'.00');
}
function isopenchange(_this,SerNo){
	
	var val = _this.value;

	var oldisOpen = $('.isopens').text();
	var index=_this.selectedIndex; 
	var txt=_this.options[index].innerHTML;
	if(txt == oldisOpen){
		alert("您状态已是"+oldisOpen+",请不要重复提交");
		return;
	}
	
	$.getJSON(url+"/letoula/data/isopen_update.jsp?r="+Math.random(),{'Trading':SerNo,'isopen':val},function(rs){
		var result = rs.result;
		
		if(result == '0000'){
			$('.isopens').slideDown();
			$('.isopens').hide(3000);
		}else{
			alert("修改方案状态失败！");
		}
		
	});
}
$(function(){

	showUserData(KO.Y.Trading,KO.Y.Pages,KO.Y.Every);
	

});

window.onscroll=function(){
  		var num_scroll_top = 0;
        if(document.body.scrollTop){
           num_scroll_top=document.body.scrollTop;
        }
        else{
           num_scroll_top=document.documentElement.scrollTop;
        }    
        $("#bd").css("top",num_scroll_top);
 }