_$ = function(id) {
	return document.getElementById(id)
};
Ext.javapackage("Lux", "Lux.Constant", "Lux.Rand", "Lux.Math",
		"Lux.CommitHelp", "Lux.Msg");
Lux.Msg = {
	upLoadErr : '请先登录!',
	footMsg : '您的选择不符合该彩种玩法规则!',
	addMsg : '不符合的操作规则!',
	issueNull : '当前该彩票不在销售状态!',
	issueNullChase : '当前该彩票不在销售状态,不提供追期!',
	noChase : '至少要选投一注,才能追期!'
};
Lux.Constant = {
	redMax : 6,
	blueMax : 1,
	addRange : 14,
	clearMsg : "是否清空所有已选数据!",
	commitMsg : "您提交的数据不符合规范!",
	autoChase : 10
};
Lux.Rand = {
	randtime : 700,
	randnum : 0,
	hasRandnum : 0,
	objInterval : null,
	scrollInterval : null,
	min : 0,
	max : 3
};
Lux.Ball = function(json) {
	this.json = json;
	this.originColor = json.originColor;
	this.nowColor = json.nowColor;
	this.txt = json.txt;
	this.val = json.val;
	this.obj = json.obj;
	this.init();
};
Lux.Ball.prototype.restColor = function() {
	this.originColor = this.json.originColor;
	this.nowColor = this.json.nowColor;
};
Lux.Ball.prototype.restBall = function() {
	this.restColor();
	this.obj.removeClass().addClass(this.nowColor);
};
Lux.Ball.prototype.changeColor = function() {
	this.obj.removeClass(this.nowColor).addClass(this.originColor);
	var temp = this.originColor;
	this.originColor = this.nowColor;
	this.nowColor = temp;
};
Lux.Ball.prototype.changeTxt = function(newTxt) {
	if (typeof newTxt != "undefined")
		this.obj[0].innerHTML = newTxt;
	return this.obj[0].innerHTML.trim();
};
Lux.Ball.prototype.changeVal = function(newVal) {
	this.obj.val(newVal);
	return this.obj.val().trim();
};
Lux.Ball.prototype.click = function() {
	if (this.originColor == this.nowColor)
		return;
	this.changeColor();
};
Lux.Ball.prototype.init = function() {
	this.txt = this.obj[0].innerHTML.trim();
	this.val = this.obj[0].value;
};
Lux.Mt = function(json) {
	this.obj = json.obj;
	this.redAry = [];
	this.blueAry = [];
	this.maxLen = json.maxLen;
	this.selectAry = [];
};
Lux.Mt.prototype.add = function(rary) {
	this.redAry = rary;
	if (this.obj[0].options.length >= this.maxLen) {
		alert("不能超过投注限额{0}注!".format(this.maxLen));
		return false;
	};
	try {
		var txt = "{0}".format(rary.join(" "));
		this.obj[0].options.add(new Option(txt, txt.replace(/ /g, "/")));
		this.selectAry.push( {
			redAry : this.redAry
		});
	} catch (exception) {
		return false;
	}
	return true;
};
Lux.Mt.prototype.selectItem = function() {
	if (this.obj[0].options.length == 0) {
		return null;
	}
	return this.selectAry[this.obj[0].selectedIndex];
};
Lux.Mt.prototype.selected = function() {
	var ary = [], s = this.obj[0];
	for (var i = s.options.length - 1;i >= 0; i--)
		if (s.options[i].selected)
			ary.push(s.options[i].index);
	return ary;
};
Lux.Mt.prototype.removeSelected = function() {
	var ary = this.selected();
	for (var i = this.selectAry.length - 1;i >= 0; i--)
		if (ary.indexOf(i) >= 0)
			this.selectAry.splice(i, 1);
	for (var s = this.obj[0], i = s.options.length - 1;i >= 0; i--)
		if (s.options[i].selected)
			s.remove(s.options[i].index);
};
Lux.Mt.prototype.removeAt = function(index) {
	this.selectAry.splice(index, 1);
	this.obj[0].remove(index);
};
Lux.Mt.prototype.removeAll = function() {
	this.selectAry.length = 0;
	this.obj[0].options.length = 0;
};
Lux.Mt.prototype.clearSelected = function() {
	for (var s = this.obj[0], i = s.options.length - 1;i >= 0; i--)
		if (s.options[i].selected)
			s.options[i].selected = false;
};
Lux.Count = function(json) {
	this.bets = json.bets;
	this.flag = json.flag;
	this.wagerLine = json.wagerLine;
	this.agio = json.agio;
	this.wager = json.wager;
	this.times = json.times;
	this.basicSum = json.basicSum;
	this.mt = json.mt;
	this.midCount = $("#midCount font");
};
Lux.Count.prototype.clear = function() {
	this.wager[0].innerHTML = "0";
	this.times[0].innerHTML = "1";
	this.basicSum[0].innerHTML = "0";
	if (this.midCount.length) {
		this.midCount[0].innerHTML = "0";
		this.midCount[1].innerHTML = "0.00";
	}
};
Lux.Count.prototype.countWager = function() {
	this.wager[0].innerHTML = (this.mt.obj[0].options.length);
};
Lux.Count.prototype.countSum = function() {
	this.countWager();
	this.basicSum[0].innerHTML = parseInt(this.wager[0].innerHTML.trim())
			* parseInt(this.times[0].innerHTML.trim())
			* parseInt(this.bets.innerHTML.trim());
	if (this.midCount.length) {
		this.midCount[0].innerHTML = this.wager[0].innerHTML;
		this.midCount[1].innerHTML = parseInt(this.bets.innerHTML.trim())
				* parseInt(this.wager[0].innerHTML.trim());
	}
	if (/^-/.test(this.wager[0].innerHTML)) {
		this.clear();
		this.mt.removeSelected();
		alert("您最终的投注不符合规则");
	}
};
Lux.Math.JieCheng = function(n) {
	for (var i = n;i > 1; i--) {
		n = n * (i - 1);
	}
	return n;
};
Lux.Math.Cmn = function(m, n) {
	if (m == n)
		return 1;
	var down = Lux.Math.JieCheng(n);
	var up = Lux.Math.JieCheng(m);
	var mid = Lux.Math.JieCheng(n - m);
	return down / (up * mid);
};
LuxOpen = function(id) {
	this.backid = "_xdf_fe";
	this.init();
};
LuxOpen.prototype.init = function() {
	_$("loadTxt").innerHTML = "系统正在处理您的请求，请稍等...";
	var back = _$(this.backid);
	if (back == null) {
		var div = document.createElement("div");
		div.innerHTML = "<div id='{0}' style='position:absolute;z-index:10000;top:0px;left:0px;width:1px;height:1px;background-color:#E5EFFC;-moz-opacity:0.7;filter:alpha(opacity=70);'></div>"
				.format(this.backid);
		document.body.appendChild(div.firstChild);
	}
};
LuxOpen.prototype.webDark = function(id) {
	var back = _$(this.backid);
	if (back != null) {
		var iWidth = document.body.scrollWidth;
		if (iWidth < 1000) {
			iWidth = 1000;
		}
		var iHeight = document.body.scrollHeight;
		if (iHeight < 1000) {
			iHeight = 1000;
		}
		back.style.width = iWidth + "px";
		back.style.height = iHeight + "px";
	}
	_$("loadImg").style.top = document.documentElement.offsetHeight / 2
			- (22 + 100) + "px";
	_$("loadImg").style.left = document.documentElement.offsetWidth / 2 - 109
			+ "px";
	_$("loadImg").style.display = "block";
};
LuxOpen.prototype.clearDark = function() {
	var back = _$(this.backid);
	_$("loadImg").style.display = "none";
	if (back != null) {
		back.style.width = "1px";
		back.style.height = "1px";
	}
};
Lux.CommitHelp.ajaxCommit = function(obj, url, leno) {
	var gu = _$("goodUse");
	if (gu == undefined) {
		alert("您尚未登录,请先登录再进行投注,谢谢合作!");
		if (parent == window) {
			//location.href = history.back();
			return;
		} else {
			//parent.location.href = history.back();
			return;
		}
		return;
	} else {
		if (parseInt(gu.innerHTML.trim()) == 0) {
			alert("您的余额不足,请尽快充值!");
			return false;
		}
	}
	leno.webDark();
	obj.chaseCondition = "0";
	$
			.ajax( {
				type : "POST",
				dataType : "json",
				url : url,
				data : obj,
				success : function(json) {
					if (json.result != '0000') {
						alert(json.errorMessage);
						leno.clearDark();
						return;
					}
					_$("loadTxt").innerHTML = "您的操作已经完成,祝您中奖!";
					alert("投注成功,谢谢您的参与!");
					leno.clearDark();
					_$('CommitCB').click();
					gu.innerHTML = json.goodUse;
					_$("freeUse").innerHTML = json.freeUse;
					try {
						parent.document.getElementById('loginMoney').innerHTML = json.goodUse;
					} catch (e) {
					}
				}
			});
};
Lux.CommitHelp.commit = function(ary, url) {
	var frm = $("#frm input");
	for (var i = 0;i < ary.length; i++) {
		frm[i].value = ary[i];
	}
	if (typeof url != "undefined")
		_$("frm").action = url;
	_$("frm").submit();
};
tautog = function(objs, jsonObj, ary) {
	var ary = [];
	for (var i = 0, json = jsonObj;i < objs.length; i++) {
		json.obj = $(objs[i]);
		ary[i] = (new Lux.Ball(json));
	};
	return ary;
};
clearAllBall = function(redBalls, getValBalls) {
	if (redBalls)
		for (var i = 0;i < redBalls.length; i++) {
			redBalls[i].restBall();
		}
	if (getValBalls)
		for (var i = 0;i < getValBalls.length; i++) {
			getValBalls[i].obj[0].innerHTML = "";
		}
	Lux.Constant.addRange = Lux.Constant.redMax;
};
judgeGetVal = function(getValBalls) {
	var j = 0;
	for (var i = 0;i < getValBalls.length; i++)
		if (getValBalls[i].obj[0].innerHTML.trim() != "")
			++j;
	return j;
};
scrollAddMt = function(red, blue) {
	var a, b;
	if (red)
		a = getRandAry(red.min, red.max, red.len);
	if (blue)
		b = getRandAry(blue.min, blue.max, blue.len);
	if (this.mt.add(a ? a : undefined, b ? b.sort() : undefined)) {
		++Lux.Rand.hasRandnum;
		this.countSum();
	} else {
		scrollBallClear();
		return;
	}
	if (Lux.Rand.hasRandnum == Lux.Rand.randnum)
		scrollBallClear();
};
scrollBall = function() {
	btnsState(true);
	Lux.Rand.scrollInterval = setInterval(
			"$('.getArea li').html(xRandom(Lux.Rand.min,Lux.Rand.max));", 20);
};
scrollBallClear = function() {
	$('.getArea li').html("").value = "100";
	clearInterval(Lux.Rand.scrollInterval);
	Lux.Rand.scrollInterval = null;
	clearInterval(Lux.Rand.objInterval);
	Lux.Rand.objInterval = null;
	Lux.Rand.hasRandnum = 0;
	btnsState(false);
};
btnsState = function(fl) {
	var randBtns = $(".rand input[@name=randBtn]").attr("disabled", fl);
	var btnAreas = $("#btnArea input").attr("disabled", fl);
	var cmtBtn = _$("commitBtn").disabled = fl;
};
getRandAry = function(_min, _max, _aryLen) {
	var a = [], z = 0;
	z = (xRandom(_min, _max));
	a.push(z == 2 ? 3 : z);
	while (a.length < _aryLen) {
		z = xRandom(_min, _max);
		if (z == 2)
			z++;
		a.push(z);
	}
	return a;
};
xRandom = function(_min, _max) {
	return parseInt(Math.random() * (_max - _min + 1) + _min);
};
/** welcome to discuss,we will be go foward together!qq50170524*/
clearCmtBtnMoney = function() {
	_$("midCount").getElementsByTagName("font")[0].innerHTML = "0";
	_$("midCount").getElementsByTagName("font")[1].innerHTML = "0.00";
};