﻿
var chooseArray=[];  //作为中转
var fileterArray=[]; //提取出来的最后选择s p f
var CyleList=[]; //选择的场次
var OKArray=[]; //确定场次
var  SPArray=[];
var spv=[];
var ZQ={};
var xhr;

ZQ.ArraySort=0;
ZQ.stopTime=0;
ZQ.tr=[];
ZQ.m=0;
ZQ.p=1;
ZQ.dv=[];
ZQ.table=[];
ZQ.span='--';
ZQ.$=function(ele) { return document.getElementById(ele); };
ZQ.zs='0';
ZQ.pc='0.00';
ZQ.maxpc='0.00';
ZQ.minTime='--';
ZQ.cc=0;
ZQ.muliptile=1;
ZQ.McN='';
ZQ.Y='元';
ZQ.orders=[3,1,0];
ZQ.tzNumber='';
ZQ.gemeCode='501';
ZQ.MaximumBonus=1;  //最大奖金
ZQ.MinimumBonus=1;  //最小奖金
ZQ.Fw='';
ZQ.S = url;
ZQ.Record =[0,0,0,0];
ZQ.Record_fw=[360000,60000,10000,1000];
ZQ.Record_i = 0;


var setting={
	'login':function(){
		ZQ.$('loginEntrance').style.display='block';
		ZQ.$('bd').style.display='block';
	},
	'loginDialog': function(){			// 当用户未登陆时,打开对话框提醒
		var dialog = ZQ.$("loginEntrance");
		dialog.style.display='block';
		dialog.style.position = 'fixed';
		dialog.style.top = ((window.innerHeight - dialog.clientHeight) / 3) + "px";
		dialog.style.left = ((window.innerWidth - dialog.clientWidth) / 2) + "px";
		
		var bd = ZQ.$("bd");
		bd.style.display='block';
		bd.style.position = 'fixed';
		bd.style.top = "0";
	},
	'loginClose':function(){
		ZQ.$('loginEntrance').style.display='none';
		ZQ.$('bd').style.display='none';
	},
	'unLogin':function(){
		$.ajax({
			url:''+rootUrl+'/LoginAction.do?action=unLogin&r='+Math.random(),
			type:'GET',
			error:function(){alert("error");},
			success:function(result){
	      	    	
	      	    	$('.userMsg').html(''+
	      			'<a style="padding-right:10px; color:#fff;" href="javascript:setting.login()">登录</a>  '+
	      			'<a style="color:#fff" href="'+url+'/member/reg.jsp" target="_blank" class="registered">免费注册</a>');
	      	    	window.location.href=url+"/index.jsp";//退出时跳到首页
	      	    	//window.location.reload();//退出账户时全局刷新--左国斌（4-22）
				}
		})
	},
	'checkLogin':function(){
		$.getJSON(""+url+"/PutForwordAction.do?action=checkUserLogin&r="+Math.random(),{'a':'b'},function(item){
			if(item.result=='0'){
				var flag = document.getElementById('ok_raw').checked;
    			if(!flag){
	    			alert("您需同意《贝壳彩票网代购协议》！");
    			}else{
					document.getElementById('FormSubmit').submit();
				}
			}else{
				setting.login();//左国斌
				//window.location.href=url+"/member/login.jsp";
				//alert("请先登陆后购买");
			}
		});
	},
	'dan_Gbounrs':function(s){
		var number = s.split("//");
		var zhushu=0;
		for(var i = 0 ; i < number.length; i++){
			if(number[i]){
				var n = number[i].split(",")[1].split("/");
				zhushu+=n.length;
			}
		}
		return zhushu;
	},
	'seaDetailsTop':function(n_vs_d,s_vs_h,txt,sta,url){
		var off_top=document.documentElement.scrollTop;
		var off_left=document.documentElement.scrollLeft; 
        ZQ.$(n_vs_d).style.top=(off_top+100)+"px";
        ZQ.$(n_vs_d).style.left=(document.body.clientWidth/2-250)+"px";
        
        $('.eroorMsg').text(txt);
		if(s_vs_h == 's') 
		{
			 $('#'+n_vs_d+'').show();
		}else
		{
			 $('#'+n_vs_d+'').hide();
			 if(url)
			 {
			 	location.href = url;
			 } 
		}
		
		sta == 'success' ? $('.state').removeClass('error').addClass('success') : $('.state').removeClass('success').addClass('error');
	},
	'showMultiples':function(count){
		for(var i=1;i<count;i++){
			$('#multiples').append("<option value='"+i+"'>"+i+"</option>");
		}
	},
	'marketTimes':function(d,count){
		var ot = '';
		//获取系统时间 
		var LSTR_ndate=new Date(); 
		var LSTR_Year=LSTR_ndate.getYear(); 
		var LSTR_Month=LSTR_ndate.getMonth(); 
		var LSTR_Date=LSTR_ndate.getDate(); 
		//处理 
		for(var i=0;i<count;i++){
			var uom = new Date(LSTR_Year,LSTR_Month,LSTR_Date); 
			uom.setDate(uom.getDate()-i);//取得系统时间的前一天,重点在这里,负数是前几天,正数是后几天 
			var LINT_MM=uom.getMonth(); 
			LINT_MM++; 
			var LSTR_MM=LINT_MM >= 10?LINT_MM:("0"+LINT_MM) 
			var LINT_DD=uom.getDate(); 
			var LSTR_DD=LINT_DD >= 10?LINT_DD:("0"+LINT_DD) 
			//得到最终结果 
			uom = LSTR_ndate.getFullYear() + "-" + LSTR_MM + "-" + LSTR_DD; 
			ot += '<option value="'+uom+'">'+uom+'</option>';
		}

		return ot;
	},
	'SetCookie':function(name,value){
		var Days = 1; //此 cookie 将被保存 30 天
    	var exp  = new Date();    //new Date("December 31, 9998");
    	exp.setTime(exp.getTime() + Days*24*60*60*1000);
    	document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
	},
	'GetCookie':function(name){
		var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
     	if(arr != null) return unescape(arr[2]); return null;
	},
	'FixedFloatTwo':function(n){
		return parseFloat(n).toFixed(2);
	},
	'getDateMonth':function(sDate1,sDate2){
		var  aDate,  oDate1,  oDate2,  iDays;  
       aDate  =  sDate1.split("-");
       oDate1  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0]);    //转换为12-18-2006格式  
       aDate  =  sDate2.split("-");
       oDate2  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0]);  
       iDays  =  parseInt(Math.abs(oDate1  -  oDate2)  /  1000  /  60  /  60  /24);    //把相差的毫秒数转换为天数  
       return  iDays;
	},
	'formatTime':function(str){return str.replace(/[-]/g,"")+"000000";},
	'loadDate':function(d,z){
		var month=(d.getMonth()+1) < 10 ? '0'+(d.getMonth()+1) : (d.getMonth()+1);
		var h=d.getDate() < 10 ? '0'+(d.getDate()) : (d.getDate());
		if(z == 's') h = "01";
		return d.getFullYear()+'-'+month+'-'+h;
	},
	'numberFixed':function(numStr){
		return parseFloat(numStr).toFixed(2);
	},
	'MP4_FLASH':function(src){
	
		var mp = '<object id="flyWmp" height="44px" width="200px" classid="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
				'<param name="URL" value="'+src+'" />'+
				'<param name="AutoStart" value="true" />'+
				'<param name="enableContextMenu" value="-1" />'+
				'<param name="EnableTracker" value="false" />'+
				'<embed id="flyWmp1" height="44px" width="200px" src="'+src+'" type="application/x-mplayer2">'+
				'</embed>'+
				'</object>';
				
				return mp;
	},
	'dingzhiStatus':{'0':'进行中','1':'已结束','2':'已取消'},
	'allformattime':function(s){return s.substring(0,4) + '-' + s.substring(4,6) + '-' + s.substring(6,8)+' '+s.substring(8, 10) + ":"+ s.substring(10, 12)+ ":"+ s.substring(12, 14)},
	'eitFormattime':function(s){return s.substring(0,4) + '-' + s.substring(4,6) + '-' + s.substring(6,8)},
	'axyformatTime':function(s){return s.substring(4, 6) + "-"+ s.substring(6, 8) + " " + s.substring(8, 10) + ":"+ s.substring(10, 12)+ ":"+ s.substring(12, 14);}

};
var today = ['日','一','二','三','四','五','六'];
var typeMap={
	'r1c1':['1_1'],'r2c1':['2_1'],	'r3c1':['3_1'],	'r4c1':['4_1'],	'r5c1':['5_1'],	'r6c1':['6_1'],	'r7c1':['7_1'],	'r8c1':['8_1'],	'r3c3':['2_3'],	'r3c4':['2_3','3_1'],
	'r4c4':['3_4'],	'r4c5':['3_4','4_1'],	'r4c6':['2_6'],	'r4c11':['2_6','3_4','4_1'],	'r5c5':['4_5'],	'r5c6':['4_5','5_1'],	'r5c10':['2_10'],
	'r5c16':['3_10','4_5','5_1'],	'r5c20':['2_10','3_10'],	'r5c26':['2_10','3_10','4_5','5_1'],	'r6c6':['5_6'],	'r6c7':['5_6','6_1'],	'r6c15':['2_15'],
	'r6c20':['3_20'],	'r6c22':['4_15','5_6','6_1'],	'r6c35':['2_15','3_20'],	'r6c42':['3_20','4_15','5_6','6_1'],	'r6c50':['2_15','3_20','4_15'],
	'r6c57':['2_15','3_20','4_15','5_6','6_1'],	'r7c7':['6_7'],	'r7c8':['6_7','7_1'],	'r7c21':['5_21'],	'r7c35':['4_35'],	'r7c120':['2_21','3_35','4_35','5_21','5_7','7_1'],
	'r8c8':['7_8'],	'r8c9':['7_8','8_1'],	'r8c28':['6_28'],	'r8c56':['5_56'],	'r8c70':['4_70'],	'r8c247':['2_28','3_56','4_70','5_56','6_28','7_8','8_1']
},DC_TYPE_MAP={
	'r1c1':['1_1'],
	'r2c1':['2_1'],
	'r2c3':['1_2','2_1'],
	'r3c1':['3_1'],
	'r3c4':['2_3','3_1'],
	'r3c7':['1_3','2_3','3_1'],
	'r4c1':['4_1'],
	'r4c5':['3_4','4_1'],
	'r4c11':['2_6','3_4','4_1'],
	'r4c15':['1_4','2_6','3_4','4_1'],
	'r5c1':['5_1'],
	'r5c6':['4_5','5_1'],
	'r5c16':['3_10','4_5','5_1'],
	'r5c26':['2_10','3_10','4_5','5_1'],
	'r5c31':['1_5','2_10','3_10','4_5','5_1'],
	'r6c1':['6_1'],
	'r6c7':['5_6','6_1'],
	'r6c22':['4_15','5_6','6_1'],
	'r6c42':['3_20','4_15','5_6','6_1'],
	'r6c57':['2_15','3_20','4_15','5_6','6_1'],
	'r6c63':['1_6','2_15','3_20','4_15','5_6','6_1'],'r7c1':['7_1'],'r8c1':['8_1'],
	'r9c1':['9_1'],'r10c1':['10_1'],'r11c1':['11_1'],'r12c1':['12_1'],'r13c1':['13_1'],'r14c1':['14_1'],'r15c1':['15_1']
},McN_Map={
	'1':'单关','2':'2串1',
	'3':'3串1','4':'3串3','5':'3串4',
	'6':'4串1','7':'4串4','8':'4串5','9':'4串6','10':'4串11',
	'11':'5串1','12':'5串5','13':'5串6','14':'5串10','15':'5串16','16':'5串20','17':'5串26',
	'18':'6串1','19':'6串6','20':'6串7','21':'6串15','22':'6串20','23':'6串22','24':'6串35','25':'6串42','26':'6串50','27':'6串57',
	'28':'7串1','29':'7串7','30':'7串8','31':'7串21','32':'7串35','33':'7串120','34':'7串127',
	'35':'8串1','36':'8串8','37':'8串9','38':'8串28','39':'8串56','40':'8串70','41':'8串247','42':'8串255'
},DC_McN_Map={
	'1':'单关','2':'2串1',
	'3':'2串3','4':'3串1','5':'3串4',
	'6':'3串7','7':'4串1','8':'4串5','9':'4串11','10':'4串15',
	'11':'5串1','12':'5串6','13':'5串16','14':'5串26','15':'5串31','16':'6串1','17':'6串7',
	'18':'6串22','19':'6串42','20':'6串57','21':'6串63','22':'7串1','23':'8串1','24':'9串1','25':'10串1','26':'11串1','27':'12串1',
	'28':'13串1','29':'14串1','30':'15串1'
},Game_Map={
	'1':'单式','2':'复式'
},setting_status={
	'-3':'系统撤单','-2':'个人撤单','-1':'废票','0':'发起成功','1':'处理成功','2':'打印成功','3':'出票成功','4':'已搅奖','5':'已派奖'
},setting_manner={
	'1':'过关代购','2':'合买发起'
},all_config={
	'501':{
		'3':'胜','1':'平','0':'负',
		'src':'ballv1.js',
		'name':'胜平负',
		'0_0501':'0',
		'1_1501':'0',
		'mcn':'8'
	},
	'502':{
		'4#3':'胜其它','4#4':'平其它','3#4':'负其它','1#0':'1:0','2#0':'2:0','2#1':'2:1','3#0':'3:0','3#1':'3:1','3#2':'3:2','4#0':'4:0','4#1':'4:1','4#2':'4:2','5#0':'5:0','5#1':'5:1','5#2':'5:2',
		'0#0':'0:0','1#1':'1:1','2#2':'2:2','3#3':'3:3',
		'0#1':'0:1','0#2':'0:2','1#2':'1:2','0#3':'0:3','1#3':'1:3','2#3':'2:3','0#4':'0:4','1#4':'1:4','2#4':'2:4','0#5':'0:5','1#5':'1:5','2#5':'2:5',
		'src':'ballv4.js',
		'name':'比分',
		'0_0502':'1',
		'1_1502':'2',
		'mcn':'4'
	},
	'503':{
		'0':'0球','1':'1球','2':'2球','3':'3球','4':'4球','5':'5球','6':'6球','7':'7+球',
		'0B':'0球','1B':'1球','2B':'2球','3B':'3球','4B':'4球','5B':'5球','6B':'6球','7B':'7+球',
		'src':'ballv5.js',
		'name':'总进球',
		'0_0503':'3',
		'1_1503':'2',
		'mcn':'6'
	},
	'504':{
		'3_3':'胜胜','3_1':'胜平','3_0':'胜负','1_3':'平胜','1_1':'平平','1_0':'平负','0_3':'负胜','0_1':'负平','0_0':'负负',
		'src':'ballv6.js',
		'name':'半全场',
		'0_0504':'4',
		'1_1504':'3',
		'mcn':'4'
	},
	'513':{
		'src':'ballv2.js',
		'name':'混合过关',
		'0_0513':'0'
	},
	'514':{
		'src':'ballv8.js',
		'name':'混合过关(二选一)',
		'0_0514':'6'
	},
	'509':{
		'3':'胜','1':'平','0':'负','3R':'胜','1R':'平','0R':'负',
		'src':'ballv7.js',
		'name':'混合过关',
		'0_0509':'5'
	},
	'511':{
		'3':'胜','1':'平','0':'负','3R':'胜','1R':'平','0R':'负',
		'src':'ballv3.js',
		'name':'让球胜平负',
		'0_0511':'0',
		'1_1511':'1',
		'mcn':'8'
	},
	'505':{
		'0':'主负','1':'主胜',
		'src':'ballv9.js',
		'name':'胜负',
		'0_0505':'0',
		'1_1505':'0'
	},
	'506':{
		'0':'主负','1':'主胜','0D':'让分主负','1D':'让分主胜',
		'src':'ballv10.js',
		'name':'让分胜负',
		'0_0506':'1',
		'1_1506':'1'
	},
	'507':{
		'01':'客1-5','02':'客6-10','03':'客11-15','04':'客16-20','05':'客21-25','06':'客26+',
		'51':'主1-5','52':'主6-10','53':'主11-15','54':'主16-20','55':'主21-25','56':'主26+',
		'src':'ballv11.js',
		'name':'胜分差',
		'0_0507':'2',
		'mcn':'4'
	},
	'508':{
		'1':'大分','2':'小分','1B':'大分','2B':'小分',
		'src':'ballv12.js',
		'name':'大小分',
		'0_0508':'3',
		'1_1508':'2'
	},
	'510':{
		'src':'ballv13.js',
		'name':'混合过关',
		'0_0510':'4'
	},
	'301':{
		'3':'胜','1':'平','0':'负',
		'src':'ballv14.js',
		'name':'让球胜平负',
		'0_0301':'0',
		'mcn':'15'
	},
	'302':{
		'sd':'上单','ss':'上双','xd':'下单','xs':'下双',
		'src':'ballv15.js',
		'name':'上下单双',
		'0_0302':'1',
		'mcn':'6'
	},
	'303':{
		'0':'0球','1':'1球','2':'2球','3':'3球','4':'4球','5':'5球','6':'6球','7':'7+球',
		'src':'ballv16.js',
		'name':'总进球数',
		'0_0303':'2',
		'mcn':'6'
	},
	'304':{
		'4#3':'胜其它','4#4':'平其它','3#4':'负其它','1#0':'1:0','2#0':'2:0','2#1':'2:1','3#0':'3:0','3#1':'3:1','3#2':'3:2','4#0':'4:0','4#1':'4:1','4#2':'4:2','5#0':'5:0','5#1':'5:1','5#2':'5:2',
		'0#0':'0:0','1#1':'1:1','2#2':'2:2','3#3':'3:3',
		'0#1':'0:1','0#2':'0:2','1#2':'1:2','0#3':'0:3','1#3':'1:3','2#3':'2:3','0#4':'0:4','1#4':'1:4','2#4':'2:4','0#5':'0:5','1#5':'1:5','2#5':'2:5',
		'src':'ballv17.js',
		'name':'比分',
		'0_0304':'3',
		'mcn':'3'
	},
	'305':{
		'3_3':'胜胜','3_1':'胜平','3_0':'胜负','1_3':'平胜','1_1':'平平','1_0':'平负','0_3':'负胜','0_1':'负平','0_0':'负负',
		'src':'ballv18.js',
		'name':'半全场',
		'0_0305':'4',
		'mcn':'6'
	},
	'102':{
		'3':'胜','1':'平','0':'负',
		'src':'ballv19.js',
		'name':'胜负彩'
	},
	'103':{
		'3':'胜','1':'平','0':'负',
		'src':'ballv20.js',
		'name':'任选九场'
	},
	'106':{
		'z0':'主0球','z1':'主1球','z2':'主2球','z3':'主3+球','k0':'客0球','k1':'客1球','k2':'客2球','k3':'客3+球',
		'src':'ballv21.js',
		'name':'四场进球'
	},
	'107':{
		'b3':'半场(胜)','b1':'半场(平)','b0':'半场(负)','q3':'全场(胜)','q1':'全场(平)','q0':'全场(负)',
		'src':'ballv22.js',
		'name':'六场半全场'
	}
	
},
betting_yz={x:'您好，请至少选取两场比赛！',c:'您好，请选择过关方式',s:'您好，请至少选取一场比赛！',lsn:'您好，请填写用户名',lsp:'您好，请填写密码'},
lotName={'501':'竞彩胜平负','502':'竞彩比分','503':'竞彩总进球','504':'竞彩半全场','511':'让球胜平负','505':'竞彩胜负','506':'让分胜负','507':'竞彩胜分差','508':'竞彩大小分','509':'竞足混投','510':'竞蓝混投','102':'足彩胜负彩','103':'足彩任9','106':'足彩4场进球','107':'足彩6场半全','301':'单场胜平负','302':'单场上下单双','303':'单场总进球数','304':'单场比分','305':'单场半全场','701':'猜冠军','201':'双色球'},

create_class={
	'stopBubble':function(o,e){
		this.chooseStreak(o);
		if(window.navigator.appVersion.indexOf('MSIE')!=-1) 
		window.event.cancelBubble = true;
		else e.stopPropagation();
	},
	'chooseStreak':function(){
		
		var parameters=create_class.chooseStreak.arguments,_this=parameters[0];
		var rows = $(_this).parents('tr');var ord=_this;
		var c = 0;
		if(_this.className=='weight'){
			ord = $(_this).find('input[type=checkbox]');
			$(ord).attr("checked") ? $(ord).attr("checked",false) : $(ord).attr("checked",true);
			c = _this.cellIndex-8;
		}else{
			c = $(ord).parent('td').index() - 8;
		}
		
		var r=$(rows).attr('arrySerial'),
			gamenum=$(rows).attr('gamenum'),
			hostteam=$(rows).attr('hostteam'),
			stopdate=$(rows).attr('stopdate'),
			rq=$(rows).attr('rq'),
			vt=$(rows).attr('vt'),
			id=$(rows).attr('id'),
			SpOrder=$(ord).attr('order'),
			SpValue=$(ord).val();
			
			if(!this.allChoose(ord,r)){
				
				if(!$(ord).attr("checked")){
				
					chooseArray[r][c]='--';
					SPArray[r][c]='--';
					$(ord).parent('td').css("background","white");
				
				}
				else{	
					chooseArray[r][c]=SpOrder;
					SPArray[r][c]=SpValue;
					$(ord).parent('td').css("background","yellow");
				}
			}
			
			CyleList[r]=[gamenum,hostteam,rq,vt,stopdate,chooseArray[r],SPArray[r],id];
			
			create_class.CeList(CyleList);
	},
	'allClear':function(l){
		chooseArray[l]=[];
		SPArray[l]=[];
	},
	'assignment':function(VS,itemSerial){
		
		var w = VS == 'sv' ?  ZQ.orders : VS;
		
		$(w).each(function(v,s){
			
			VS=='sv' ? chooseArray[itemSerial][v]=s : SPArray[itemSerial][v]=s.value;
			
		})
		
	},
		/*
	** arguments[2]
	** agrObj 当前对象
	***itemSerial  序号
	*/
	'allChoose':function(agrObj,itemSerial){
		var pr=$(agrObj).parents('tr').find('td > input[type=checkbox]');
		if($(agrObj).attr('class')=='all'){
			this.assignment('sv',itemSerial);
			pr.attr('checked',true).parent('td').css("backgroundColor","yellow");
			this.assignment(pr,itemSerial);
			$(agrObj).attr('class','allClear');
			$(agrObj).text('清');
			return true;
		}else if(agrObj.className=='allClear'){
			
			this.allClear(itemSerial);
			$(agrObj).attr('class','all');
			$(agrObj).text('全');
			pr.attr('checked',false).parent('td').css("backgroundColor","white");
			return true;
		}
		return false;
	},
	'CeList':function(cs){
		
		var cb=0;
		
		for(var j=0;j<cs.length;j++){
			
			OKArray[j]=[];
			fileterArray[j]=[];
			if(cs[j].length==0 || !cs[j][5] || cs[j][5].length==0) continue;
			var or=cs[j][5];
			var sp=cs[j][6];
			var l=0,n=0;
			ZQ.span='';
			spv[j]=[];
			
			$(sp).each(function(s,p){
				
				if(''+p!='undefined' && p!='--'){
					
					spv[j][n]=p; n++;
				}
			})
			$(or).each(function(v,s){
			
				if(''+s!='undefined' && s!='--'){
					ZQ.span+="<span class='x_s' data_sg='"+s+"'>"+spf[s]+"</span>";
					fileterArray[j][l]=s; l++;
					OKArray[j]=[cs[j][cs[j].length-1],fileterArray[j],cs[j][0],cs[j][1],cs[j][2],cs[j][3],cs[j][4],spv[j],"0"];
				}
			
			})
			
			
			if(ZQ.span.length!=0){
				
				cb++;
			}
		
		}

		cb > 8 ? cb=8 : cb=cb; 
		create_class.showHidden(cb);
		ZQ.minTime=cs[0][4];
		create_class.Calculation_bonus();
	},
	'oay':function(_this){
		
		var ca=_this.className.toString();
		
		OKArray[ca.charAt(2)][2] = _this.checked ? "1" : "0";
		
	},
	/*
	* 奖金范围
	*/
	'bonusRange':function(streakList,l){
		streakList=streakList.sort(function(a,b){return a-b;});
		var strakItemsMin = streakList.slice(0,l);
		var strakItemsMax = streakList.slice(streakList.length-l,streakList.length);
		ZQ.MinimumBonus=this.for_Range(strakItemsMin);
		ZQ.MaximumBonus=this.for_Range(strakItemsMax);
		return parseFloat(ZQ.MinimumBonus).toFixed(2)+'-'+parseFloat(ZQ.MaximumBonus).toFixed(2)+ZQ.Y;
	},
	'for_Range':function(rangeItems){
	
		var bonus = 1;
		for(var i=0;i<rangeItems.length;i++){
			bonus *= parseFloat(rangeItems[i]);
		}
		return bonus*ZQ.muliptile*2;
	},
	'Calculation_bonus':function(){
	
		
		var McN=$('#passWay').val(),d=',',sl='//',SPxv=[],tzNumber='',spzValue='';
		ZQ.MinimumBonus=1,ZQ.MaximumBonus=1;
		for(var i=0;i<OKArray.length;i++){
			
			if(OKArray[i] && OKArray[i][1]){
				tzNumber+=OKArray[i][0]+','+OKArray[i][1].toString().replace(/[,]/g,"/")+','+OKArray[i][OKArray[i].length-1]+'//';
				spzValue+=OKArray[i][0]+','+OKArray[i][7].toString().replace(/[,]/g,"/")+','+OKArray[i][OKArray[i].length-1]+'//';
				var s_xv=OKArray[i][7];
				for(var s=0;s<s_xv.length;s++){
					SPxv.push(s_xv[s]);
				}				
			}
		}
		
		ZQ.tzNumber=tzNumber.substring(0,tzNumber.length-2);
		ZQ.spzValue=spzValue.substring(0,spzValue.length-2);
		ZQ.Fw=this.bonusRange(SPxv,ZQ.tzNumber.split('//').length);
		
		McN==null ? McN="" : McN=McN;
		ZQ.McN=McN;
		
		if(McN.length <= 0 || ZQ.cc<=1){
			
			ZQ.zs='0'; ZQ.pc='0.00'; ZQ.maxpc='0.00';
			$('.tzPrice').text('￥'+parseFloat(ZQ.pc).toFixed(2));
			$('.priceFw').text('0-0'+ZQ.Y);
		}
		
		$.get("./letoula/data/calculate_money.jsp?r="+Math.random(),{mcn:ZQ.McN,tzNumber:ZQ.tzNumber},function(zhushu){
			
			ZQ.zs=zhushu;
			ZQ.pc=zhushu*2*ZQ.muliptile;
			$('.tzPrice').text('￥'+parseFloat(ZQ.pc).toFixed(2));
			$('.priceFw').text(ZQ.Fw);
		});
		
	},
	'over_t':function(){
	
		$('#blk2,#bd').hide();
		
	},
	'filterFnWin':function(){
		var ovs=CyleList.join('_');
		window.open('../jczq/filter/gl_main.jsp?ovs='+ovs,"newwindow",'height=600,width=1000,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no');
	},
	'submitInformation':function(){
		
		if(ZQ.tzNumber.indexOf('//') <= 0 ){
			
			create_class.seaDetails('blk2','s','您好！您至少要选择两场比赛！','error',ZQ.S);
			
			return;
		}
		else if(ZQ.McN.length <=0 ){
			
			create_class.seaDetails('blk2','s','您好！请选择过关方式！','error',ZQ.S);
			
			return;
		}
		
		ZQ.$('jzTime').value=ZQ.minTime;
		ZQ.$('muliptile').value=ZQ.muliptile;
		ZQ.$('tzNumber').value=ZQ.tzNumber;
		ZQ.$('zhushu').value=ZQ.zs;
		ZQ.$('price').value=parseFloat(ZQ.pc).toFixed(2);
		ZQ.$('ZQMcN').value=ZQ.McN;
		ZQ.$('gameCode').value='501';
		ZQ.$('spzValue').value=ZQ.spzValue.replace(/[" "]/g,"");
		ZQ.$('moneyFw').value=ZQ.Fw;
		
		var mcnArray=ZQ.McN.split(',');
		var rmrn='';
		for(var s=0;s<mcnArray.length;s++){
			rmrn+=McN_Map[mcnArray[s]]+',';
		}
		rmrn=rmrn.substring(0,rmrn.lastIndexOf(','));
		
		ZQ.$('McN').value=rmrn;
		
		var d='$',cos='';
		
		for(var i=0;i<OKArray.length;i++){
		
			if(OKArray[i].length==0) continue;
			
			var pl=OKArray[i][7].join('_');
			var spf=OKArray[i][1].join('/');
			
			
			cos+=OKArray[i][2]+','+OKArray[i][3]+','+OKArray[i][5]+','+OKArray[i][4]+','+spf+','+pl+d;
		}
		cos=cos.substring(0,cos.lastIndexOf('$'));
		
		ZQ.$('inf').value=cos;
		
		ZQ.$('ksform').submit();
	},
	'showHidden':function(cc){
		$('#passWay').empty();
		
		for(var c=0;c<=cc;c++){
			if(c>1 && c<=8) {
				
				var b=0;
				
				switch(c){
					case 4: b = 6; break;
					case 5: b = 11; break;
					case 6: b = 18; break;
					case 7: b = 28; break;
					case 8: b = 35; break;
					default: b = c; break;
				}
				
				$("#passWay").append("<option value='"+b+"' selected='selected' class='mcn'>"+c+"x1</option>");
				
			}
			
		}
	},
	'return_mcn':function(str,lotName){
		
		
		str = str.split(',');
		
		var result='';
		
		for(var i=0;i<str.length;i++){
			
		switch(lotName){
			case '501':
			case '502':
			case '503':
			case '511':
			case '509':
			case '504':result+=McN_Map[str[i]]+',';
			break;
			case '505':
			case '506':
			case '507':
			case '510':
			case '508':result+=McN_Map[str[i]]+',';
			break;
			case '301':
			case '302':
			case '303':
			case '304':
			case '305':result+=DC_McN_Map[str[i]]+',';
			break;
			case '102':
			case '103':
			case '106':
			case '107':result+=Game_Map[str[i]]+',';
			break;
		}
		
			
		}
		result = result.substring(0,result.lastIndexOf(','));
		return result;
	},
	'today_time':function(){
	
		var date=new Date();
	
		var year=date.getFullYear(),
		month=date.getMonth()+1,
		day=date.getDate(),
		hours=date.getHours(),
		minutes=date.getMinutes(),
		seconds=date.getSeconds(),
		work=date.getDay();
		
		
		month=month<10?'0'+month:month;
		day=day<10?'0'+day:day;
		hours=hours<10?'0'+hours:hours;
		hours=hours<10?'0'+hours:hours;
		seconds=seconds<10?'0'+seconds:seconds;
		minutes=minutes<10?'0'+minutes:minutes;
		
		var workItem=['一','二','三','四','五','六','日'];

		 $('.today_time').text(year+'年'+month+'月'+day+'日 '+'星期'+workItem[work-1]+'    '+hours+':'+minutes+':'+seconds);
		 
		 setTimeout('create_class.today_time()',1000);

	},
	'mltOnkeyUp':function(){
	
		var _this=arguments[0],
			val=parseInt(_this.value);
	
		if(val > 99999) {
			_this.value='99999';
		}
		
		if(isNaN(_this.value) || val <= 0 || _this.value.indexOf('.')!=-1){
		
		   _this.value=1;
		}
		
		ZQ.muliptile=_this.value;
		
		ZQ.pc=parseFloat(ZQ.zs*2*ZQ.muliptile).toFixed(2);
		$('.pc').text('￥'+parseFloat(ZQ.zs*2*ZQ.muliptile).toFixed(2));
		$('.maxpc').text(parseFloat(ZQ.maxpc*ZQ.muliptile).toFixed(2)+'元');
	},
	'timeSort':function(item){
		
		for(var i=0;i<item.length-1;i++){
		for(var s=0;s<item.length-i-1;s++){
			if(item[s].gamenum>item[s+1].gamenum){
				var temp=item[s];
				item[s]=item[s+1];
				item[s+1]=temp;
			}
			}
		}
		return item;
	},
	'intSort':function(item){
		
		for(var i=0;i<item.length-1;i++){
		for(var s=0;s<item.length-i-1;s++){
			if(parseInt(item[s].gamenum)>parseInt(item[s+1].gamenum)){
				var temp=item[s];
				item[s]=item[s+1];
				item[s+1]=temp;
			}
			}
		}
		return item;
	},
	/*
	*desc 升序   asc 降序
	*/
	'Sort_field':function(Ary,filed,orderBye){
		
		//var o_A='',t_A='';
		for(var i=0;i < Ary.length-1;i++)
		{
			for(var s=0;s < Ary.length-i-1;s++)
			{
				/*if(orderBye == 'desc' || orderBye=='')
				{
					o_A = Ary[s],t_A=Ary[s+1];
				}else
				{
					o_A = Ary[s+1],t_A=Ary[s];
				}*/
				if(parseInt(Ary[s][filed]) < parseInt(Ary[s+1][filed]))
				{
					var temp=Ary[s];
					Ary[s]=Ary[s+1];
					Ary[s+1]=temp;
				}
			}
		}
		return Ary;
	},
	'hidden_S':function(){
		
		var parameters=create_class.hidden_S.arguments;
		
		if(parameters[0].charAt(0)=='d'){
			parameters[1].parentNode.parentNode.style.display="none";
		}
		
	},
	'showNode':function(){
		
		var parameters=create_class.showNode.arguments;
		
		$(parameters).each(function(i,v){
			
			v.className='';
		})
	},
	'centertical':function(obj){
		var pleft = 0;
		var ptop = 0;
		var winWidth = 0; 
		var winHeight = 0;
		var _hh = $(obj).height();
		var _ww = $(obj).width();
		var _scrollHeight = $(document).scrollTop();//获取当前窗口距离页面顶部高度 
		var _obj = obj;
		//获取窗口宽度 
		if (window.innerWidth) 
		winWidth = window.innerWidth; 
		else if ((document.body) && (document.body.clientWidth)) 
		winWidth = document.body.clientWidth; 
		//获取窗口高度 
		if (window.innerHeight) 
		winHeight = window.innerHeight; 
		else if ((document.body) && (document.body.clientHeight)) 
		winHeight = document.body.clientHeight; 
		//通过深入Document内部对body进行检测，获取窗口大小 
		if (document.documentElement && document.documentElement.clientHeight && document.documentElement.clientWidth) { 
		winHeight = document.documentElement.clientHeight; 
		winWidth = document.documentElement.clientWidth; 
		} 		
		  ptop = (winHeight-_hh)/2+_scrollHeight-100;
		  pleft = (winWidth-_ww)/2;
		_obj.style.top=ptop+"px";
		_obj.style.left=pleft+"px";
	},
	'seaDetails':function(n_vs_d,s_vs_h,txt,sta,url){
	
		var off_top=document.documentElement.scrollTop;
		var off_left=document.documentElement.scrollLeft; 
		this.centertical(ZQ.$(n_vs_d));
        
        $('.eroorMsg').text(txt);
		if(s_vs_h == 's') 
		{
			 $('#bd,#'+n_vs_d+'').show();
		}else
		{
			 $('#bd,#'+n_vs_d+'').hide();
			 if(url)
			 {
			 	location.href = url;
			 } 
		}
		
		sta == 'success' ? $('.state').removeClass('error').addClass('success') : $('.state').removeClass('success').addClass('error');
		
	},
	/*
	* 战绩
	*/
	'Record_zhanJ':function(money,uid){
		
		money = parseInt(money);
		
		ZQ.Record[ZQ.Record_i] = parseInt(money / ZQ.Record_fw[ZQ.Record_i]);
		var s = money - (ZQ.Record[ZQ.Record_i]*ZQ.Record_fw[ZQ.Record_i]);
		if(s >= ZQ.Record_fw[ZQ.Record_fw.length-1]){
				
			ZQ.Record_i++;

			this.Record_zhanJ(s,uid);
		}else
		{
			return '<span></span>';
		}
		var rec_span = '',rec_cls = 'g_star';
		if(money!=0){
			
			for(var l = 0; l < ZQ.Record.length; l++)
			{
				
				rec_cls = Record_class[l];
				
				ZQ.Record[l] = ZQ.Record[l] > 5 ? 5 : ZQ.Record[l];
				
				var level = 0;
				for(var k = 0 ; k < ZQ.Record[l] ; k++)
				{
					level++;
				}
				if(level > 0){
					rec_span+='<span class='+rec_cls+level+' style="cursor:pointer" onclick=create_class.Record_S('+uid+')></span>';
				}
			}
		}	
			ZQ.Record_i = 0;
			return rec_span;
		
	},
	/*
		ey 总页数
		pages 当前页
	*/
	'paging':function(ey,pages,showUserData){
		var e_y_a='';
		pages = parseInt(pages);
		var countY = Math.ceil(ey);
		var next=pages >= ey ? ey : pages+1;
		var fist=pages <= 1 ? "1" : pages-1;
		var startY=0,endY=ey > 5 ? 8 : ey;
		if(pages>=5){
			startY = pages - 5; 
			endY   = ey - pages + 5 > ey ? ey :  pages + 5;
		}
		e_y_a+="<font color='#333333'>共有"+KO.countEvery+"条记录，共有"+Math.ceil(ey)+"页</font><a href='javascript:void(0)' onclick=showUserData('"+KO.Y.Trading+"','1','"+KO.Y.Every+"') class='h_l'>◀</a><a href='javascript:void(0)' onclick=showUserData('"+KO.Y.Trading+"','"+fist+"','"+KO.Y.Every+"') title='上一页' class='pre'>◀◀</a>";
		var cls='';
		for(var e=startY;e<endY;e++){
			if(e<ey){
				if(e==(pages-1)) cls='an_x_z';
				else cls='';
				e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showUserData("'+KO.Y.Trading+'","'+(e+1)+'","'+KO.Y.Every+'")>'+(e+1)+'</a>';
			}else{
				break;
			}
		}
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showUserData('"+KO.Y.Trading+"','"+next+"','"+KO.Y.Every+"') class='next'>▶▶</a><a href='javascript:void(0)' onclick=showUserData('"+KO.Y.Trading+"','"+ey+"','"+KO.Y.Every+"') class='h_l'>▶</a>";
		//e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='this.ValidataPage("+ey+",this)' id='govalue'  />"+
		//"<input type='button' class='btn' onclick=this.loadPageData() value='GO'></span>";
		$(e_y_a).appendTo('.f_an_page');
	},
	'ValidataPage':function(ey,_this){
		var pg=parseInt(_this.value);
		
		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
	},
	'loadPageData':function(showUserData){
		var ps=$("#govalue").val();
		 showUserData(KO.Y.Trading,ps,KO.Y.Every);
	},
	'Record_S':function(uid){
		ShowBuyLotteryDate(KO.U.Pages,KO.U.Every,uid);
		this.seaDetails('blk1','s');
	},
	'onblurAndonkeyUp':function(_this,str,_event){
		if(_event == 'onfocus')
		{
			_this.value = _this.value.indexOf(str)!=-1 ? _this.value = '' : _this.value;		
		}
		else if(_event == 'onblur')
		{
			_this.value = _this.value ? _this.value : str;
		}
	},
	'A_hide_D':function(_class1 , _class2 , _class3 , _class4){
		$('.'+_class1 + ' > .marsk,.' +_class1+ ' > .'+_class4).hide();
		$('.'+_class2).removeClass().addClass(_class3).find('s').removeClass().addClass('buylist_icon');
	},
	'McN_hide':function(_class1 , _class2 , _class3 , _class4){
		$('.'+_class4).hide();
		$('.'+_class2).show();
	},
	'string2timeHS':function(s){return s.substring(0, 4) + "-" + s.substring(4, 6) + "-"+ s.substring(6, 8) + " " + s.substring(8, 10) + ":"+ s.substring(10, 12) + ":" + s.substring(12, 14);},
	'stringformat':function(d){
		var de=d.getDate() < 10 ? '0'+d.getDate() : d.getDate();
		var month=(d.getMonth()+1) < 10 ? '0'+(d.getMonth()+1) : (d.getMonth()+1);
		var hours=d.getHours() < 10 ? '0'+d.getHours() : d.getHours();
		var minutes=d.getMinutes() < 10 ? '0'+d.getMinutes() : d.getMinutes();
		var secon=d.getSeconds() < 10 ? '0'+d.getSeconds() : d.getSeconds();
		return ''+d.getFullYear()+month + de + hours + minutes + secon;
	},
	'navergater':function(){
		var versions = window.navigator.appVersion;
		if(versions.indexOf('MSIE')!=-1)
		{
			return 0;
		}else if(versions.indexOf('Safari')!=-1)
		{
			return 1;
		}else
		{
			return 2;
		}
	},
	'containsArray':function(arr,element){
		for (var i = 0; i < arr.length; i++) {
	        if (arr[i] == element) {
	            return true;
	        }
	    }
	    return false;
	},
	'contains':function (arr,element) {
	    for (var i = 0; i < arr.length; i++) {
	        if (arr[i].sat == element) {
	            return true;
	        }
	    }
	    return false;
	},	
	'containsAll':function (arr,par,element) {
	    for (var i = 0; i < arr.length; i++) {
	        if (arr[i].ArrSp+"--"+arr[i].ArrStrNum+"--"+arr[i].ArrXh == element) {
	            return true;
	        }
	    }
	    return false;
	},
	'marketarrow':function(_this){
		var cln = $('.mrs').find('s').attr('class');
		if(cln == 'marKetArrow_s'){
			$('.mrs').find('s').removeClass().addClass('marKetArrow');
			$('.marketSx').hide();
		}else
		{
			$('.mrs').find('s').removeClass().addClass('marKetArrow_s');
			$('.marketSx').show();
		}
	},
	'formatTime':function(str){return str.replace(/[-]/g,"");},
	'axyformatTimeTwo':function(s){return s.substring(4, 6) + "-"+ s.substring(6, 8) + " " + s.substring(8, 10) + ":"+ s.substring(10, 12);},
	'axyformatTime':function(s){return s.substring(4, 6) + "-"+ s.substring(6, 8) + " " + s.substring(8, 10) + ":"+ s.substring(10, 12)+ ":"+ s.substring(12, 14);},
	'loadDate':function(d,z){
		d.setDate(d.getDate()-1);
		var month=(d.getMonth()+1) < 10 ? '0'+(d.getMonth()+1) : (d.getMonth()+1);
		var h=d.getDate() < 10 ? '0'+ d.getDate() : d.getDate();
		return d.getFullYear()+'-'+month+'-'+h;
	}
},
Record_class={'0':'g_hg','1':'g_jg','2':'g_jz','3':'g_star'},
spf={'0':'负','1':'平','3':'胜'},
times={'0':'星期日','1':'星期一','2':'星期二','3':'星期三','4':'星期四','5':'星期五','6':'星期六'};

$(function(){
	$.extend({
		domHover:function(dom , color)
			{
				var parentColor = "";
				$(dom).hover(function(){
					$(this).find('td div.bet_odds span').addClass('trover');
					parentColor = $(this).css('backgroundColor');
					$(this).css('backgroundColor',color);
				},function(){
					$(this).css('backgroundColor',parentColor);
					$(this).find('td div.bet_odds span').removeClass('trover');
				});
			},
		domSpanBack:function(dom,c){
				$(dom).hover(function(){
					$(this).addClass(c);
				},function(){
					$(this).removeClass(c);
				});
		},
		divClientShow:function(_class1 , _class2 , _class3 , _class4)
		{
			$('.'+_class2+',.'+_class3+'').click(function(){
				var _class = $(this).attr('class');
				if(_class==_class2)
				{
					$(this).removeClass().addClass(_class3).find('s').removeClass().addClass('buyicon_lik');
					$('.'+_class1 + ' > .marsk,.' +_class1+ ' > .'+_class4).show();
				}else
				{
					$(this).removeClass().addClass(_class2).find('s').removeClass().addClass('buylist_icon');
					$('.'+_class1 + ' > .marsk,.' +_class1+ ' > .'+_class4).hide();
				}
			});
		},
		McNShow:function(_class1 , _class2 , _class3 , _class4)
		{
			$('.'+_class2+',.'+_class3+'').click(function(){
				var _class = $(this).attr('class');
				if(_class==_class2)
				{
					
					$(this).hide();
					$('.'+_class3).find('s').removeClass().addClass('buyicon_lik');
					$('.'+_class4).show();
				}else
				{
					$('.'+_class2).show();
					$('.'+_class4).hide();
				}
			});
		},
		offsetScr:function(call1,call2){
			var screenHeight=window.screen.height;
			var bottomHeight = $("."+call1).offset().top;
			if(bottomHeight > screenHeight){
				$('.'+call2).css('position','fixed');
				$(window).scroll( function() { 
					var scrolltop = 0;
					var vsn = create_class.navergater();
					if(vsn==0 || vsn==2)
					{
						scrolltop = document.documentElement.scrollTop;
					}else
					{
						scrolltop = document.body.scrollTop;
					}
					var psn = $('.'+call2).css('position');
					if(bottomHeight-(window.screen.height+scrolltop) > 0 && psn == 'relative'){
						$('.'+call2).css('position','fixed');
					}else if(bottomHeight-(window.screen.height+scrolltop) <=0 && psn == 'fixed'){
						$('.'+call2).css('position','relative');
					}
				});
			}
			
		},
		offsetTopTitle:function(call1,call2){
				$(window).scroll( function() {
					var bottomHeight = $("."+call1).offset().top;
					var scrolltop = 0;
					var vsn = create_class.navergater();
					if(vsn==0 || vsn==2)
					{
						scrolltop = document.documentElement.scrollTop;
					}else
					{
						scrolltop = document.body.scrollTop;
					}
					var psn = $('#'+call2).attr('class');
					if(bottomHeight <=  scrolltop && psn!='toptables'){
						$('#'+call2).addClass('toptables');
					}else if(bottomHeight > scrolltop && psn == 'toptables'){
						$('#'+call2).removeClass('toptables');
					}
				});
			
		},
		xlbtnstar:function(parentXl){
			$('.'+parentXl+' > .topsxbox').hover(function(){
		 	 	$(this).find('.xlbtn').addClass('xlbtnB').find('em').addClass('xlbtnem');
		 	 	$(this).find('.pxdiv').show();
		 	},function(){
		 	 	$(this).find('.xlbtn').removeClass('xlbtnB').find('em').removeClass('xlbtnem');
		 	 	$(this).find('.pxdiv').hide();
		 	});
		},
		Accession:function(obj,Fixed){
			var buyoff = Fixed.offset();
			var buyleft = buyoff.left , buytop = buyoff.top;
			var _tObOff = obj.offset();
			var _tleft = _tObOff.left , _ttop = _tObOff.top;
			var width = _tleft - buyleft + obj.width() , height = buytop - _ttop + Fixed.height();
			var cls = "Accession" + Math.random().toString().replace(/[.]/g,'');
			$('<div class="'+cls+' buy_list amitn"><div class="buylistcon amitn"><span class="buyTx">已选<i class="the_selected">0</i>场<s class="buylist_icon"></s></span><span class="sedan">[设胆]</span></div></div>').appendTo('body');
			$('.'+cls).css({
			'left':_tleft,
			'top':_ttop,
			'height':36,
			'width':102,
			'display':'block',
			'position':'absolute',
			'float':'left',
			'zIndex':'10000'});
			$('.'+cls).animate({
				left:buyleft,top:buytop-30
			},500).hide(200);
		}
	});
});

function showDz(){

$.getJSON("./letoula/data/winsFlat.jsp?r="+Math.random(),{smalltype:"501"},function(items){
	
	items=items.items;
	var todayTime=new Date();
    var tt=parseInt(create_class.stringformat(todayTime));
    
	var tr='';
	 var lg = items.length > 9 ? 9 : items.length;
	 $('.ftl').empty();
	for(var i=0;i<lg;i++){
			chooseArray[i]=[];
			CyleList[i]=[];
			fileterArray[i]=[];
			OKArray[i]=[];
			SPArray[i]=[];
			var jz_nn = '';
			ZQ.stopTime  = items[i].stopselldate.substring(8,10);
    		var at=parseInt(items[i].stopTime.replace(/[-A-Za-z\(\)\+@#:\s]/g,""));
    		
    		var tzSp = '<td width="9%" class="weight" onclick=create_class.stopBubble(this,event)><input type="checkbox"  order="3" onclick=create_class.stopBubble(this,event) value="'+items[i].winrate501+'" />'+parseFloat(items[i].winrate501).toFixed(2)+'</td>'+
      				'<td width="9%" class="weight" onclick=create_class.stopBubble(this,event)><input type="checkbox"  order="1" onclick=create_class.stopBubble(this,event) value="'+items[i].levelrate501+'" />'+parseFloat(items[i].levelrate501).toFixed(2)+'</td>'+
      				'<td width="9%" class="weight" onclick=create_class.stopBubble(this,event)><input type="checkbox" order="0" onclick=create_class.stopBubble(this,event) value="'+items[i].loserate501+'" />'+parseFloat(items[i].loserate501).toFixed(2)+'</td>';
  			if(at < tt){
  				tzSp = '<td width="9%" class="weight"></td><td width="9%" class="weight"></td><td width="9%" class="weight"></td>';
  				jz_nn = 'jz_nn';
				lg++;
				lg = lg > items.length ? items.length : lg;
  			}
  			
  			var anysy = items[i].stopTime.substring(0,10);
  			var vt=items[i].visitingteam.substring(0,3),ht=items[i].hostteam.substring(0,3);
 			if(items[i].visitingteam.length < 3 ) vt = items[i].visitingteam.substring(0,1)+'&nbsp;&nbsp;&nbsp;&nbsp;'+items[i].visitingteam.substring(1,2);
 			if(items[i].hostteam.length < 3 ) 	ht =items[i].hostteam.substring(0,1)+'&nbsp;&nbsp;&nbsp;&nbsp;'+items[i].hostteam.substring(1,2);
 			
			tr+="<tr class='"+jz_nn+"' vt='"+items[i].visitingteam+"' rq='"+items[i].concedenum+"' id='"+items[i].id+"' stopdate='"+items[i].stopselldate+"' gamenum='"+items[i].gamenum+"' hostteam='"+items[i].hostteam+"' arrySerial='"+i+"'>"+
      			"<td width='62'>"+items[i].gamenum+"</td>"+
      			"<td width='64' style='background-color:"+items[i].color+";color:#fff'>"+items[i].gamename.substring(0,3)+"</td>"+
      			"<td width='58' title='"+items[i].stopTime+"'>"+items[i].stopTime.substring(11, 13) + ":"+ items[i].stopTime.substring(14, 16)+"</td>"+
      			"<td width='61' class='td_rt'><a href='javascript:void(0)' title="+items[i].hostteam+">"+ht+"</a></td>"+
      			"<td width='32' class='weight c_t'>"+items[i].concedenum+"</td>"+
      			"<td width='61' class='td_lt'><a href='javascript:void(0)' title="+items[i].visitingteam+">"+vt+"</a></td>"+
      			"<td width='33'>"+parseFloat(items[i].o).toFixed(2)+"</td>"+
      			"<td width='35'>"+parseFloat(items[i].h).toFixed(2)+"</td>"+
      			"<td width='35'>"+parseFloat(items[i].u).toFixed(2)+"</td>"+
      			'<td width="9%" class="ays"><a href="../letoula/axy/analysis.jsp?no='+no[items[i].gamenum.charAt(1)]+''+items[i].gamenum.substring(2,5)+'&issue='+anysy.replace(/[-]/g,"")+'" target="_blank">析</a><a href="../letoula/axy/nowyOdds.jsp?no='+no[items[i].gamenum.charAt(1)]+''+items[i].gamenum.substring(2,5)+'&issue='+anysy.replace(/[-]/g,"")+'" target="_blank">亚</a><a href="../letoula/axy/nowouOdds.jsp?no='+no[items[i].gamenum.charAt(1)]+''+items[i].gamenum.substring(2,5)+'&issue='+anysy.replace(/[-]/g,"")+'" target="_blank">欧</a></td>'+tzSp+
      			"<td width='33'><a href='javascript:void(0)' class='all' id='q_x' onclick='create_class.chooseStreak(this)'>全</a></td>"+
      			"</tr>";
	}
	
	$(tr).appendTo($('.ftl'));
	//$('.typ').text($('.ftl > tr[class!=jz_nn]').length);
	$('.typ').text( items.length);
});
}
var no={'一':'1','二':'2','三':'3','四':'4','五':'5','六':'6','日':'7'};