var K = {};
K.status = 'success';
K.S = agrs.url+'/letoula/useraccount/serNoScheme_details.jsp?id=';
K.L = agrs.url+'/letoula/error.jsp';
var ar ={'0':'负','1':'平','3':'胜','3R':'让球胜','1R':'让球平','0R':'让球负','0B':'0','1B':'1','2B':'2','3B':'3','4B':'4','5B':'5','6B':'6','7B':'7','3_3':'胜胜','3_1':'胜平','3_0':'胜负','1_3':'平胜','1_1':'平平','1_0':'平负','0_3':'负胜','0_1':'负平','0_0':'负负'};
function closeWindow(u){   
    	/*window.opener = null;   
    	window.open('', '_self', '');   
    	window.close();  */
    	var local = K.status == 'error' ? K.L : K.S;
    	window.location.href=local;
}
	
function doExchange(doubleArrays){ 
	var len=doubleArrays.length; 
	if(len>=2){ 
		var len1=doubleArrays[0].length; 
		var len2=doubleArrays[1].length; 
		var newlen=len1*len2; 
		var temp=new Array(newlen); 
		var index=0; 
		for(var i=0;i<len1;i++){
			for(var j=0;j<len2;j++){
				temp[index]=doubleArrays[0][i]+doubleArrays[1][j];
				index++;
			}
		}
		var newArray=new Array(len-1);
		for(var i=2;i<len;i++){
			newArray[i-1]=doubleArrays[i];
		}
		newArray[0]=temp;
		return doExchange(newArray);
	}
	else{
		return doubleArrays[0];
	}
}
	
var newCArry=[] , NumSpArray=[] , combin=[] ,bsTemp = 0 ,newArrbin = [],newKa=[];
	
function myfind(has, other, n) {
	if (n == 0) {
		newCArry.push(has.join(","));
		return;
	}
	if (other.length < n) {
		return;
	}
	var one = other.shift();
	var newhas = has.concat();
	var newother = other.concat();
	has.push(one);
	myfind(has, other, n-1);
	myfind(newhas, newother, n);
	return has;
}

function yh_Main(msr,ctype){
	if(ctype > msr.length){
		return;
	}
	NumSpArray=[];
	myfind(new Array(),msr.split(","),ctype);
	for(var p=0;p<newCArry.length;p++){
		var ar = newCArry[p].split(",");
		var tempArrone=[];
		for(var j=0;j<ar.length;j++){
			var arj = ar[j].split("|");
			var arjk = [];
			if(arj.length>1){
				for(var k=0;k<arj.length;k++){
					arjk.push(arj[k]);
				}
				tempArrone.push(arjk);
			}else{
				tempArrone.push(arj[0].split("$_"));
			}
		}
		NumSpArray.push(tempArrone);
	}
}
	
function doCombin(arr,pr){
	var bs = pr / 2;
	var retOne=arr;
	var comAry=[];
	for(var b=0;b<retOne.length;b++){
	var ret = retOne[b].ret;
	for(var l=0;l<ret.length;l++){
		var rt = ret[l].substring(0,ret[l].length-1);
		rt = rt.split("~");
		var ArrStrNum = "" ,ArrSp="",ArrXh="";var m=1;
		for(var v=0;v<rt.length;v++){
			var rtv = rt[v].split(":");
			ArrStrNum += rtv[0]+",";
			ArrSp     += rtv[1]+",";
			ArrXh	  += rtv[2]+",";
			m = m * parseFloat(rtv[1]);
		}
		ArrSp = ArrSp.substring(0,ArrSp.length-1);
		ArrStrNum = ArrStrNum.substring(0,ArrStrNum.length-1);
		ArrXh = ArrXh.substring(0,ArrXh.length-1);
		m = parseFloat(m * 2).toFixed(2);
		comAry.push({"ArrSp":ArrSp,"ArrStrNum":ArrStrNum,"m":m,"s":l,"z":1,"csm":m,"ArrXh":ArrXh});
		}
	}
	binCommet(comAry,pr/2-comAry.length);
}
/**博热优化
*/
function benOptimize(amount, prizeArr){
	var sumF = 0,returnArr = [];
	 for(var j=0;j<prizeArr.length;j++){
	     sumF += Math.ceil(amount/prizeArr[j]);
	     returnArr[returnArr.length] = Math.ceil(amount/prizeArr[j]);
	  }
	  if(sumF - (amount/2) <= 0){//实际注数不足理论注数，默认加到第一注
	     var _k1 = (amount/2) + returnArr[0] - sumF;
	     returnArr[0] = _k1;
	    }else{//实际注数多于理论注数，先设置所有注数为1，再从第一注开始加
	     return prizeOptimize(amount, prizeArr);
	   }
	     return returnArr;
}
/**博冷优化
*/
function coolOptimize(amount, prizeArr){
	var sumF = 0,returnArr = [];
	 for(var j=0;j < prizeArr.length;j++){
	     sumF += Math.ceil(amount/prizeArr[j]);
	     returnArr[returnArr.length] = Math.ceil(amount/prizeArr[j]);
	  }
	  if(sumF - (amount/2) <= 0){//实际注数不足理论注数，默认加到第一注
	     var _k1 = (amount/2) + returnArr[returnArr.length-1] - sumF;
	     returnArr[returnArr.length-1] = _k1;
	    }else{//实际注数多于理论注数，先设置所有注数为1，再从第一注开始加
	     return prizeOptimize(amount, prizeArr);
	   }
	     return returnArr;
}
/**
* 平均优化
*/
function prizeOptimize(amount, prizeArr){
			var zs = amount/2;
	     	var sumF = 1,temF = 0,returnArr = [],lockSum = 0,lockCount = 0;
	     	for(var j=0;j<prizeArr.length-1;j++){
	     		sumF += prizeArr[prizeArr.length-1]/prizeArr[j];
	     		returnArr[returnArr.length] = prizeArr[prizeArr.length-1]/prizeArr[j];
	     	}
	     	returnArr[returnArr.length] = 1;
	     	temF = zs/sumF;
	     	var zzs = 0,flag = false;
	     	for(var m=0;m<returnArr.length;m++){
	     		
	     			if(temF*returnArr[m] < 1){
		     			returnArr[m] = Math.ceil(temF*returnArr[m]);
		     		}else{
		     			returnArr[m] = Math.round(temF*returnArr[m]);
		     		}
	     		
	     		zzs += returnArr[m];
	     	}
	     	//验证注数是否一致
	     	if(zzs <= zs){
	     		//平均分配
	     		var _ye = zs - zzs;
	     		while(_ye > 0){
	     			for(var k=0;k<returnArr.length;k++){
	     				if(_ye <= 0){
	     					break;
	     				}
	     				
	     					returnArr[k] += 1;
	     					_ye --;
	     				
	     			}
	     		}
	     	}else{//实际注数多于理论注数
	     		//先从多的里面减去注数，看是否能达到平衡，如若不行，先设置所有注数为1，再从第一注开始加
	     		var oye = zzs - zs;_index = 0;
	     		for(var _index=0;oye > 0 && _index<returnArr.length;_index++){
	     	
		     			if(returnArr[_index]-Math.ceil(amount/prizeArr[_index]) > 0){
		     				var unitZs = returnArr[_index]-Math.ceil(amount/prizeArr[_index]);
		     				if(oye < unitZs){
		     					returnArr[_index] = Math.ceil(amount/prizeArr[_index])+(unitZs-oye);
		     					oye = 0;
		     				}else{
		     					oye -= unitZs;
		     					returnArr[_index] = Math.ceil(amount/prizeArr[_index]);
		     				}
		     			}
	     			
	     		}
	     		if(oye > 0){
	     			if(flag && (lockSum+(prizeArr.length-lockCount)) < zs){
	     				sumF = 1,temF = 0,returnArr = [];
	     				for(var j=0;j<prizeArr.length-1;j++){
	     					
	     						sumF += prizeArr[prizeArr.length-1]/prizeArr[j];
	     						returnArr[returnArr.length] = prizeArr[prizeArr.length-1]/prizeArr[j];
	     					
	     		     	}
	     			
	     					returnArr[returnArr.length] = multipleCache[prizeArr.length-1];
	     				
	     				temF = (zs-lockSum)/sumF,zzs = 0;
	     				for(var m=0;m<returnArr.length;m++){
	     					
		    	     			if(temF*returnArr[m] < 1){
		    		     			returnArr[m] = Math.ceil(temF*returnArr[m]);
		    		     		}else{
		    		     			returnArr[m] = Math.round(temF*returnArr[m]);
		    		     		}
	     					
	     					zzs += returnArr[m];
	    		     	}
	     				if(zzs <= zs){
	     		     		//平均分配
	     		     		var _ye = zs - zzs;
	     		     		while(_ye > 0){
	     		     			for(var k=0;k<returnArr.length;k++){
	     		     				if(_ye <= 0){
	     		     					break;
	     		     				}
	     		     				if(!lockMatchCache[k]){
	     		     					returnArr[k] += 1;
	     		     					_ye --;
	     		     				}
	     		     			}
	     		     		}
	     		     	}else{
	     		     		var _ye = zzs - zs;
	     		     		while(_ye > 0){
	     		     			for(var k=0;k<returnArr.length;k++){
	     		     				if(_ye <= 0){
	     		     					break;
	     		     				}
	     		     				if(!lockMatchCache[k] && returnArr[k] > 1){
	     		     					returnArr[k] -= 1;
	     		     					_ye --;
	     		     				}
	     		     			}
	     		     		}
	     		     	}
	     			}else{
			     		var _ye = zs - returnArr.length;
			     		var tempArr = [];
			     		for(var k=0;k<returnArr.length;k++){
		     				tempArr[tempArr.length] = 1;
		     				
			     		}
			     		var _index = 0;
			     		while(_ye != 0){
			     			if(_ye >= returnArr[_index]){
			     				tempArr[_index] = returnArr[_index];
			     				_ye -= (returnArr[_index] - 1);
			     			}else{
			     				tempArr[_index] = _ye+1;
			     				_ye = 0;
			     			}
			     			_index++;
			     		}
			     		returnArr = tempArr;
	     			}
	     		}
	     	}
	     	//最后验证是否有不盈利的单，如有进行平衡处理
	     	var _low = _high = 0;
 			for(var r=0;r<returnArr.length;r++){

 					if(returnArr[r]-Math.ceil(amount/prizeArr[r]) < 0){
 						_low += (Math.ceil(amount/prizeArr[r])-returnArr[r]);
 					}else if(returnArr[r]-Math.ceil(amount/prizeArr[r]) > 0){
 						_high += (returnArr[r]-Math.ceil(amount/prizeArr[r]));
 					}
 				
 			}
 			if(_low > 0 && _low <= _high){
 				for(var r=0;r<returnArr.length;r++){
 					if(_low == 0)
 						break;

 	 					if(returnArr[r]-Math.ceil(amount/prizeArr[r]) > 0){
 	 						if((returnArr[r]-Math.ceil(amount/prizeArr[r])) <= _low){
 	 							_low -= (returnArr[r]-Math.ceil(amount/prizeArr[r]));
 	 							returnArr[r] = Math.ceil(amount/prizeArr[r]);
 	 						}else{
 	 							returnArr[r] -= _low;
 	 							_low = 0;
 	 						}
 	 					}

 	 			}
 				for(var r=0;r<returnArr.length;r++){
 	 				
 	 					if(returnArr[r]-Math.ceil(amount/prizeArr[r]) < 0){
 							returnArr[r] = Math.ceil(amount/prizeArr[r]);
 	 					}
 	 		
 	 			}
 			}
	     	return returnArr;
		}

function binCommet(arrbin,pr){
	var radioVal = $('.xuanz').val(),countMoney = parseInt($('.srmn').val());
	var ka = [];
	var spArr = [];
	for(var l =0; l < arrbin.length; l++)
	{
		spArr.push(arrbin[l].csm);
	}
	alert(spArr);
	spArr.sort(function(a,b){return a-b});
	if(pr > 0){
		arrbin.sort(function(a,b){return a.csm-b.csm});
		if(radioVal=='p'){
			ka = prizeOptimize(countMoney,spArr);
		}else if(radioVal=='r'){
			ka = benOptimize(countMoney,spArr);
		}else if(radioVal=='l'){
			ka = coolOptimize(countMoney,spArr);
		}
		yh_showHTML(arrbin,ka);
	}else{
		for(var j=0;j<spArr.length;j++){
	     	ka[ka.length] = 1;
		 }
		yh_showHTML(arrbin,ka);
	}
}

function yh_showHTML(arrbinObj,ka){
	arrbinObj.sort(function(a,b){return a.csm-b.csm});
	newArrbin = arrbinObj;
	newKa = ka;
	var tr="";
	var max = [];
	var zhushu = 0;
	var URL = location.href;
	URL = URL.substring(URL.lastIndexOf('/')+1,URL.length);
	if(URL=='prizereview.jsp'){
		for(var b=0;b<arrbinObj.length;b++){
			arrbinObj[b].z = ka[b];
			arrbinObj[b].m = parseFloat(arrbinObj[b].csm * ka[b]).toFixed(2);
			max.push(arrbinObj[b].m);
			var pstr = sumPrice(arrbinObj[b].ArrSp,arrbinObj[b].ArrStrNum);
			zhushu+=arrbinObj[b].z;
			tr+="<tr arl='"+b+"'><td>"+(b+1)+"</td><td>"+pstr+"</td><td>"+arrbinObj[b].ArrSp.split(",").length+"串1</td><td><a href='javascript:zzz_Jian("+b+")' class='zs_jian' /><input class='cm_in' type='text' onkeyup='txtOnChange("+b+",this)' value='"+arrbinObj[b].z+"' /><a href='javascript:zzz_Jia("+b+")' class='zs_jia' /></td><td><font color='red' class='m_"+b+"'>"+arrbinObj[b].m+"</font></td></tr>";
		}
		max.sort(function(a,b){return b-a});
		$('.kzJJ').text(max[0]);
		$('.countKzjj').text(zhushu*2);
		$(".yh_tab > tbody").html(tr);
	}
}
function zuMax(arr){
	var zu = 0;
	var zumax=[];
	for(var i =0;i<arr.length;i++)
	{
		zu+=arr[i].z;
		zumax.push(arr[i].m);
	}
	zumax.sort(function(a,b){return b-a});
	return zu+","+zumax[0];
}
function zzz_Jian(suy){
	if(newArrbin[suy].z>0){ 
		newKa[suy] -= 1;
		yh_showHTML(newArrbin,newKa);
	}else{
		alert("您调节的奖金不能小于0");
	}
}
function zzz_Jia(suy){
	newKa[suy] += 1;
	yh_showHTML(newArrbin,newKa);
}
function txtOnChange(suy,_this){
	var val = parseInt(_this.value);
	if(isNaN(val)){
		val = _this.value = 1;
	}else if(val<0){
		val = _this.value=0;
	}else if(val>1000000){
		val = _this.value=1000000;
	}
	newKa[suy] = val;
	newArrbin[suy].z = val;
	newArrbin[suy].m = parseFloat(newArrbin[suy].csm * newKa[suy]).toFixed(2);
	var zm = zuMax(newArrbin).split(",");
	$(".m_"+suy).text(newArrbin[suy].m);
	$('.countKzjj').text(zm[0]*2);
	$('.kzJJ').text(zm[1]);
}
function sumPrice(arrsp,arrnum){
	var spnum = '',count=1;
	arrsp = arrsp.split(",");
	arrnum = arrnum.split(",");
	for(var m=0;m<arrsp.length;m++){
		var nv = '';
		if(arrnum[m].indexOf("-") != -1){
			nv = arrnum[m].replace("-",":");
		}else{
			nv = ar[arrnum[m]];
		}
		spnum+=nv+"(<font color='red'>"+arrsp[m]+"</font>)"+"×"
		count*=arrsp[m];
	}
	spnum+="2="+parseFloat(count*2).toFixed(2);
	
	return spnum;
}
function yh_MainLoad(msr,ctype,price){
	var numberPush = [];bsTemp = 0 , combin=[] ,newCArry=[];
	var type = ctype.split(",");
	for(var j=0;j<type.length;j++){
		yh_Main(msr,parseInt(type[j]));
	}
	 for(var u=0;u<NumSpArray.length;u++){
		numberPush.push({"c":NumSpArray[u].length,"ret":doExchange(NumSpArray[u])});
	}
	doCombin(numberPush,price);
}

function TXT_Price(){
	var val = $('.srmn').val();
	if(isNaN(val)){
		alert("请正确输入计划购买金额！");
		return;
	}else if(parseInt(val) % 2 != 0){
		alert("输入金额必须是2的倍数!");
		return;
	}else if(parseInt(val) < agrs.countprice){
		alert("计划购买金额至少需要"+agrs.countprice+"元！");
		return;
	}else if(parseInt(val)>1000000){
		alert("输入计划购买金额最大支持100万元！");
		return;
	}
	$('.countKzjj').text(val);
	yh_MainLoad(agrs.tempStr,agrs.mcn,val);
}
function TXTOnkeyval(){
	for(var i=0;i<newArrbin.length;i++){
		newArrbin[i].z=0;
		newKa[i]=0;	
	}
	yh_showHTML(newArrbin,newKa);
}
function TXTwriteNumber(){
	if(agrs.nikeName=='--'){
		alert("请登录后再提交投注！");
		return;
	}
	var strbin = '',sparr='',againstid='',strka = newKa.toString();
	for(var i=0;i<newArrbin.length;i++)
	{
		strbin+=newArrbin[i].ArrStrNum+"//";
		sparr+=newArrbin[i].ArrSp+"//";
		againstid+=newArrbin[i].ArrXh+"//";
	}
	strbin=strbin.substring(0,strbin.length-2);
	sparr=sparr.substring(0,sparr.length-2);
	againstid=againstid.substring(0,againstid.length-2);
	create_class.seaDetails('blk2','s','您好！投注中....','success','');
	if(agrs.gameCode=='511'){
		strbin = strbin.replace(/[R]/g,'');
	}
	$.getJSON("../data/yhCommit.jsp?r="+Math.random(),{'ArrStrNum':strbin,'Arrz':strka,'ArrSp':sparr,'ArrXh':againstid,'FMCN':fmc,'gamecode':agrs.gameCode},function(rv){
		
			if(rv.result=='0000'){
				K.S += rv.serialno;
				K.status = 'success';
				create_class.seaDetails('blk2','s','您好！您的方案已提交成功！',K.status,K.S);
			}else{
				if(rv.result=='非法登录或登录超时!'){
					 setting.login();
					 create_class.seaDetails('blk2','h');
				}else{
					K.status = 'error';
					create_class.seaDetails('blk2','s','您好！'+rv.result+'',K.status,K.L);
				}
			}
				
	});
}
$('.yhradio').click(function(){
	$('.yhradio').attr('checked',false).removeClass('xuanz');
	$(this).attr('checked',true).addClass('xuanz');
});
