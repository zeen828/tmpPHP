var timeout=null;//保存右侧顶部和投注图片的定时显示的值
function hover(tr){
	$(tr).addClass("hoverbg");
}
function out(tr){ 
	$(tr).removeClass("hoverbg");
}
function spOnchange(){//改变赔率公司时，赔率的改变
	var spValue = $("#selectSpValue").val();
	$.ajax({
		   type: "POST",
		   url: "/football!returnJson.shtml",
		   data: "spType="+spValue+"&date="+$("#searchback").val(),
		   success: function(msg){
		    var data=eval("("+msg+")");
		    $(data).each(function(ids,item){
		    	$("#"+item.teanNo).html(item.value);
		    });
		   } 
	});
}


function spOnchangeOne(){//改变赔率公司时，赔率的改变
	var spValue = $("#selectSpValueOne").val();
	$.ajax({
		   type: "POST",
		   url: "/football!returnJson.shtml",
		   data: "spType="+spValue,
		   success: function(msg){
		    var data=eval("("+msg+")");
		    $(data).each(function(ids,item){
		    	$("#"+item.teanNo).html();
		    	$("#"+item.teanNo).html(item.value);
		    });
		   }
	});
}
function rangqiuMarch_onclick(){
	//获取让球赛事的结果
	var rangqiuMarch = document.getElementById("rangqiuMarch").value;
	g_rangqiuHiddenArray.length = 0;
	if(rangqiuMarch == "全部赛事"){
		$("tr[id^='tr']").show();
		g_rangqiuHiddenArray.length = 0;
		g_rangqiu = false;
		document.getElementById("hiddenFootballMarch").innerHTML = 0;
	}else if(rangqiuMarch == "让球赛事"){
		var i = 0;
		var xianshi_hide = 0;
		$("tr[id^='tr']").each(function(){
				var rangqiuDiv = $(this).find("td:gt(4)"); 
				var rangqiuDivId = rangqiuDiv.attr("id");
				var rangqiu = rangqiuDiv.find("div").html();
				if(parseInt(rangqiu)==0){
					xianshi_hide++;
					$(this).hide();
				}else{
					g_rangqiuHiddenArray[i] = rangqiuDivId;
					g_rangqiu = true;
					i++;
					$(this).show();
				}
		});
		document.getElementById("hiddenFootballMarch").innerHTML = xianshi_hide;
	}else if(rangqiuMarch == "非让球赛事"){
		var i = 0;
		var xianshi_hide = 0;
		$("tr[id^='tr']").each(function(){
				var rangqiuDiv = $(this).find("td:gt(4)"); 
				var rangqiuDivId = rangqiuDiv.attr("id");
				var rangqiu = rangqiuDiv.find("div").html();
				if(parseInt(rangqiu)!=0){
					xianshi_hide++;
					$(this).hide();
				}else{
					g_rangqiuHiddenArray[i] = rangqiuDivId;
					g_rangqiu = true;
					i++;
					$(this).show();
				}
		});
		document.getElementById("hiddenFootballMarch").innerHTML = xianshi_hide;
	}
}

function marchSelect_onmouseover(){
	if($("#marchSelect").get(0).style.display=="none"){
		$("#marchSelect").show();
	}else{$("#marchSelect").hide();}
}

function marchSelect_close(){
	$("#marchSelect").hide();
}
function marchSelect_quanxuan(){//赛事全选
	$("#zz").find("ul").find("li").find("input").attr("checked",true);
}
function marchSelect_fanxuan(){//赛事反选
	$("#zz").find("ul").find("li").each(function(){
		if($(this).find("input").attr("checked")){
			$(this).find("input").attr("checked",false);
		}
		else{
			$(this).find("input").attr("checked",true);
		}
	});
}

function marchSelect_queding(){//赛事确定操作
	var le=0;//赛事场数
	var res="";
	$("#marchSelect").hide();
	$("#zz").find("ul").find("li").each(function(i){
		if($(this).find("input").attr("checked")){
			res+=$.trim($(this).find("label").text())+",";
		}
	});
	$("#matchbody").find("tr[id^='tr']").each(function(i){
		var a=$(this).find("td").eq(1).find("span").attr("cn");
		if(res.indexOf(a)>-1){
			$(this).show();
		}
		else{
			le++;
			$(this).hide();
		}
	});
	$("#hiddenFootballMarch").text(le);
}
/** ****match** */
function named(flag){
	$(".named").each(function(){
		this.innerHTML=$(this).attr(flag);
	});
}
function showStop(show){
	$(".stop").toggle();
}
function showHide(){
	$(".show").find("td:eq(0)").find(":checkbox").attr("checked",true);
	FootballHidden.hideMatch();
}
function randomColor(leangueName) {	
	leangueName=encodeURI(leangueName);
	var color=getCookie(leangueName,false);
	if(color){
		return color;
	}
	var arrHex = ["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"];
	var strHex = "#";
	var index;
	for(var i = 0; i < 6; i++) {
		index = Math.round(Math.random() * 15);
		strHex += arrHex[index];
	}
	setCookie(leangueName,strHex,9999,false);
	return strHex;
}
function selectLeague(name){
	if(name=="0"){
		$(".show").show();
	}
	$(".show").each(function(){
		if($(this).find("td[cn="+name+"]").length>0){
			$(this).show();
		}else{
			$(this).hide();
		}
	});
}
/*-s wlong 赛事的显示隐藏 2011-7-27*/
var FootballHidden={
	hiddenCount : 0,//隐藏赛事的场次数
	toggleKey : function(key,obj){//胜平负、总进球、半全场显示隐藏
//			var xianshi_hide = 0;
			matchbody.find("tr[key="+key+"]").each(function(){
//			var rangqiuDiv = $(this).find("td:gt(4)"); 
//			var id=this.id.substring(2);
			if($(obj).html().indexOf("隐藏")!=-1){
				$(this).addClass("stop");
			}else{
				$(this).removeClass("stop");
			}
//			if(g_rangqiu){//让球和非让球赛事显示
//				for(var i=0 ; i<g_rangqiuHiddenArray.length;i++){
//					if(id!=g_rangqiuHiddenArray[i].substring(2)){
//						continue;
//					}else{
//						if(document.getElementById(this.id).style.display==""||document.getElementById(this.id).style.display =="block"||document.getElementById(this.id).style.display=="table-row"){
//							$(this).hide();
//						}
//						else{
//							if(document.getElementById(this.id).style.display=="none"){
//								$(this).show();
//								$(this).attr("style","");
//							}
//						}
//					}
//				}
//			}else{
//				if(document.getElementById(this.id).style.display==""||document.getElementById(this.id).style.display =="block"||document.getElementById(this.id).style.display=="table-row"){
//					$(this).hide();
//					FootballHidden.hiddenCount++;
//				}
//				else{
//					if(document.getElementById(this.id).style.display=="none"){
//						if(!$(this).find("input").eq(0).attr("checked")){
//							$(this).hide();
//						}
//						else{
//							$(this).show();
//							
//							if($("#id").val()=='rfgg'||$("#id").val()=='rfdg'){
//								$(this).attr("style","");
//							}
//							FootballHidden.hiddenCount--;
//						}
//					}
//				}
//			}
		});
		$("#hiddenFootballMarch").html($(".stop").not(".jz").length);
		obj=$(obj);
		if(obj.html().indexOf("隐藏")!=-1){
			obj.html('点击显示&nbsp;<img src="/etc/images/zk.gif"/>');
		}else{
			obj.html('点击隐藏&nbsp;<img src="/etc/images/zc.gif"/>');
		}
	},
	toggleKeyRf : function(key,obj){//比分的显示隐藏
//		var trObf = matchbody.find("tr[key="+key+"]").get(0);
//		var trFirst = document.getElementById(trObf.id).style.display;
		matchbody.find("tr[key=toggleKeyTempKey_"+key+"]").each(function(i){//投注sp值得显示隐藏
			if(document.getElementById(this.id).style.display ==""||document.getElementById(this.id).style.display =="block"||document.getElementById(this.id).style.display =="table-row"){
				$(this).hide();
				$(this).attr("style","display:none");
			}
			else{
				if(document.getElementById(this.id).style.display =="none"){
					if($(this).find("table").find("table").find("td").eq(1).find("span").text().replace(" ","")!=""){
						$(this).show();
					}
					else{
						$("#"+this.id).remove();
					}
				}
				else{
					$(this).hide();
				}
			}
		});
		matchbody.find("tr[key="+key+"]").each(function(i){//赛事的显示隐藏
			if(document.getElementById(this.id).style.display==""||document.getElementById(this.id).style.display=="block"||document.getElementById(this.id).style.display=="table-row"){
				$(this).hide();
				$(this).attr("style","display:none");
				FootballHidden.hiddenCount++;
			}
			else{
				if(document.getElementById(this.id).style.display=="none"){
					$(this).show();
					$(this).attr("style","");
					FootballHidden.hiddenCount--;
				}
			}
		});
		$("#hiddenFootballMarch").html(FootballHidden.hiddenCount);
		obj=$(obj);
		if(obj.html().indexOf("隐藏")!=-1){
			obj.html('点击显示&nbsp;<img src="/etc/images/zk.gif"/>');
		}else{
			obj.html('点击隐藏&nbsp;<img src="/etc/images/zc.gif"/>');
		}
	},
	hideMatch:function(obj){//赛事复选框按钮
		if($(obj).attr("checked")){
			$(obj).parent().parent().show();
		}
		else{
			$(obj).parent().parent().hide();
			var maid=$(obj).parent().parent().next().attr("id");
			if(typeof(maid)!="undefined"){
				if(maid.split("_")[0]=="toggleKeyTemp"){
					$(obj).parent().parent().next().hide();
				}
			}
			if($("#id").val().indexOf('rf')!=-1)
				$(obj).parent().parent().find("td:last").find("img").attr("src","/etc/images/dg-01_61_56.gif");
			FootballHidden.hiddenCount++;
		}
		$("#hiddenFootballMarch").text(FootballHidden.hiddenCount);
	},
	showFootballMarch:function (){//点击显示
		$("[id^='chk_matchNo']").each(function(){
			if(!$(this).attr("checked")){//复选框没有选中
				$(this).attr("checked","true");
				FootballHidden.hiddenCount--;
			}
		});
		$("tr[id^='tr']").show();
		$("tr[id^='tr']").attr("style","");
		matchbody.find("tr[key^='toggleKeyTempKey_']").each(function(){
			if($(this).style==""||$(this).style=="display:block"){
				$(this).hide();
			}
		});
		$("tr[id^='tr']").each(function(){
			if($(this).find("td:last").find("img").attr("src")=="/etc/images/dg-01_61_59.gif")
				$(this).find("td:last").find("img").attr("src","/etc/images/dg-01_61_56.gif");
		});
		$("span[id^='toggle']").each(function(){
			if($(this).text().replace(/\s/g, "")=="点击显示"){
				$(this).html('点击隐藏&nbsp;<img src="/etc/images/zc.gif"/>');
			}
		});
		g_rangqiuHiddenArray.length = 0;
		g_rangqiu = false;
		FootballHidden.hiddenCount=0;
		document.getElementById("hiddenFootballMarch").innerHTML = 0;
	}
};
/*-e wlong 赛事的显示隐藏  2011-7-27*/

//展开选项和隐藏选项
function toggleKeyTemp(gameId,index){
	var idStr = "toggleKeyTemp_"+gameId;
//	var playtypesp=$("#id").val();//单关、过关
//	var numone="toggleKeyTempImage_"+gameId;
	var spvlue="<tr id='toggleKeyTemp_"+gameId+"' class='show match_tr"+index%2+"' style='' >"
	+"<td class='table_x_bk' align='center' colspan='10'><table width='964' cellspacing='2' cellpadding='0' bgcolor='#CCCCCC'><tbody><tr><td width='960' bgcolor='#FFFFFF' colspan='13'>"
	+"<table id='sp"+gameId+"' width='100%' cellspacing='1' cellpadding='0' border='0' bgcolor='#FFFFFF'><tbody>";
	var spvl="</tbody></table></td></tr></tbody></table>";
	if($("#"+idStr).html()==""||$("#"+idStr).html()==null){//赛事下面没有sp tabale
		$.post("/football!respBf.shtml",{gameId:gameId}, function(msg){
				$("#tr"+gameId).after(spvlue+msg+spvl);
			}
		);
	}
	else{
		if($("#"+idStr).html()!=""||$("#"+idStr).html()!=null){//赛事下面有 sp table
				if(document.getElementById(idStr).style.display==""||document.getElementById(idStr).style.display=="undefined"){
					$("#"+idStr).hide();
				}
				else{
					if(document.getElementById(idStr).style.display!=""&&document.getElementById(idStr).style.display=="none"){
						$("#"+idStr).show();
					}
					else{
						$("#"+idStr).hide();
					}
				}
		}
		else{
			$("#"+idStr).attr("style","");
		}
	}
	var obj = $("#toggleKeyTempImage_"+gameId);
	if(obj.attr("src")=="/etc/images/dg-01_61_56.gif"){
		obj.attr("src","/etc/images/dg-01_61_59.gif");
	}else{
		obj.attr("src","/etc/images/dg-01_61_56.gif");
	}
	//处理截止赛事不能投注
	if($("#tr"+gameId).hasClass("jz")){
	  $("#tr"+gameId).next().find("td").each(function(){
		  this.onclick="";  //取消点击事件
		  $(this).find("input").attr("disabled","false");
	  });
	}
	var result=$("#tr"+gameId).attr("result"); //这场比赛的赛果
	$("#tr"+gameId).next().find("span[c="+result+"]").addClass("sshcxs");
}

function chOpt2(obj){
	initOpt($(obj));
	$("#changshu").html(" "+getMatchSize()+" ");
	calcMoney();
}

//比分球队的算法
function chOptRg(obj){
	initOptRg($(obj));
	$("#changshu").html(" "+getMatchSize()+" ");
	calcMoney();
}

function bao(obj){
	if(obj.checked){
		var len;
		if(!isSfc)
		  len=$(obj).parent().parent().find(".hand1").length;
		else
		  len=$(obj).parent().parent().parent().find(".hand1").length;
		if(getMatchSize()+1>maxMatchLen &&len==0){
			obj.checked=false;
			alert("最多选择"+maxMatchLen+"场比赛进行投注!");
			return;
		}
	}
	var tr;
	if(isSfc){
		tr = $(obj).parent().parent();
		tr.find("td.hand"+(obj.checked?"":"1")).each(function(){
			initOptRg($(this));
		});
	}else{
		tr=$(obj).parents("tr");
		tr.find(".hand"+(obj.checked?"":"1")).each(function(){
			initOpt($(this));
		});	
	}
	$("#changshu").html(" "+getMatchSize()+" ");
	calcMoney();
}

function calcMoney(){
	/* 过关方式 */
	if(!isDg){
		initPass();		
		for(var index in danNO){
			var ch=itembody.find("#i_chk_"+index);
			if(ch.length==0){
				delete danNO[index];
			}else{
				ch.parent().parent().find(":checkbox:last").attr("checked",true);
			}
		}
		if(passDiv.find(":checked").length>0){
			money(false);
		}else{
			betCount=0;
			money(betCount);
		}
		var len=itembody.find(":checked[name=dan]").length;
		if(len>0){
			passDiv.find(":checkbox").each(function(){
				if(parseInt(this.value.split("-")[0],10)<=len){
					this.checked=false;
					this.disabled=true;
					delete ggWay[this.value];
				}else{
					this.disabled=false;
				}
			});
		}
		sd();
	//单关
	}else{
		//如果是单关，就直接算值
		if(lType=='sf'){
			betCount=oneCalc('1-1');money(betCount);
			 $("#matchCount").html(itembody.find(".xuan_12").length);
		}
		else if(lType=='rf'){
			betCount=oneCalc('1-1');money(betCount);
			 $("#matchCount").html(itembody.find(".xuan_2").length);
		}else if(lType=='sfc'){
			betCount=oneCalc('1-1');money(betCount);
			 $("#matchCount").html(itembody.find(".xuan_3").length);
		}
		
		else{
		betCount=oneCalc('1-1');money(betCount);
		 $("#matchCount").html(itembody.find(".xuan_1").length);
		}
	}
}

/* 得到总投注场次数 */
function getMatchSize(){
	return itembody.find(".hand2").length;
}


//足球比分 选项区设置
function initOptRg(jqObj){
	//球队编号
	var index=jqObj.attr("id");
	var tr = $("#tr"+index);
	var index1=tr.find("td").eq(0).find("input:hidden").eq(0).val().replace(/\D/gi,"");
	//再tr下寻找label的标签，因为只有一个，所有就去值，球队编号
	var item=tr.find("label").text();
	//在tr下寻找host开始的id，是球队主队名称
	var hostName=tr.find("#host"+index).text();
	//在tr下寻找visit开始的id，是球队客队名称
	var visitName=tr.find("#visit"+index).text();
	//在tr下寻找rf开始的id，是球队让分
//	var rf=tr.find("#rf"+index).text();
	
	//寻找复选框的本标签
	var check=jqObj.find(":checkbox")[0];
	
	
		if(jqObj.hasClass("hand")){
		//把matchid存入到marchIds中，也就是index值
		if(!matchIds[index]||matchIds[index]==""){
			if(getMatchSize()+1>maxMatchLen ){
				check.checked=false;
				alert("最多选择"+maxMatchLen+"场比赛进行投注!");
				return;
			}
		}
		//更换复选框td的class，也就是换下颜色
		jqObj.removeClass("hand").addClass("hand1");
		//更新为选中
		check.checked=true;
		//取得span中的值
		var sp=parseFloat(jqObj.find("span:eq(0)").text(),10);
		if(!spArr[index]){
			spArr[index]=[];
		}
		//把值存到spArr中
		spArr[index].push(sp);
		spArr[index].sort(asc);
	}else{
		//如果已经被选中，就更换为没有选中的样式，更新为没有选中
		jqObj.removeClass("hand1").addClass("hand");
		check.checked=false;
	}
		
	var idStr = "toggleKeyTemp_"+index;
	var trObj = $("#"+idStr);
		
	//寻找为包的多选框
	var chk;
		chk=trObj.find(".hand1 > :checked");
	var checkedLen=chk.length;
	//如果选中的最大值等于多选框的个数，就把包更新为选中
	if(checkedLen==0){
		delete itemArr[index1];
		delete matchIds[index];//marchId的值集合
		delete optArr[index];  //选中的最大值集合  
		delete danNO[index];
		delete spArr[index];   //sp值的集合
	}else{
		if(!itemArr[index1]||itemArr[index1]==''||itempart[3]!=index){
			itempart[1]=(bgcolor[++g_idx%2]); 
			itempart[3]=itempart[5]=index; //球队号码，就是marchId
			itempart[7]=item;     			//球队编号      
			itempart[9]=(hostName); //客队
			itempart[10] = "</span></span></td>";
			itempart[12] = "<td align=\"center\"class=\"table_x_bk\">";
			itempart[13]=(visitName); //主球队
			//是否是单关
			if(!isDg){
				itempart[17]="'"+index+"'"; //球队号码，就是marchId
			}
		}
		itempart[15]=getItemOptRf(trObj);		
		itemArr[index1]=itempart.join("");
		optArr[index]=checkedLen;
//		var spValueArr=[];
		var optValue=[];
		spArr[index]=[];
		chk.each(function(){
			var sp=$(this).parent().find("span").eq(0).text();
			optValue.push(this.value);
			spArr[index].push(sp);
		});
		matchIds[index]=optValue.join(",");
		spArr[index].sort(asc);
	}
	//确定有几个tr值
	var t=[];
	var k=[];
	for(var i in itemArr){
		if(i!=undefined){
			k.push(i);
			t.push(itemArr[i]);
		}
	
	}
	for(var i=0,l=k.length;i<l;i++){
		for(var j=i,p=k.length;j<p;j++){
			var temp;
			if(parseFloat(k[i])<parseFloat(k[j])){
				temp=k[j];
				k[j]=k[i];
				k[i]=temp;
				temp=t[j];
				t[j]=t[i];
				t[i]=temp;	
			}	
		}
	}
	itembody.html(t.reverse().join(''));
	var trlen=7-itembody.find("tr").length;	
	//加几个空的tr值
	for(var i=0;i<trlen;i++){
		itembody.append('<tr style="background:'+bgcolor[i%2]+'">'+p_str+'</tr>');
	}
	itembody.find("tr").each(function(idx){
		if(idx%2==0){
			$(this).css("background","#f9f9f9");
		}else{
			$(this).css("background","#f2f2f2");
		}
	});
}


/*选项区设值*/
function initOpt(jqObj){
	//tr对象
	var tr=jqObj.parent();
	//球队编号，也就是matchid
	var index=jqObj.attr("id");
//	var gameid=jqObj.attr("gameid");
	var index1=tr.find("td").eq(0).find("input:hidden").eq(0).val().replace(/\D/gi,"");
	//再tr下寻找label的标签，因为只有一个，所有就去值，球队编号
	var item=tr.find("label").text();
	if(item==""){
		item=tr.prev().find("label").text();
	}
	//在tr下寻找host开始的id，是球队主队名称
	var hostName=tr.find("#visit"+index).text();
	if(hostName==""){
		hostName=tr.next().find("#visit"+index).text();
	}
	//在tr下寻找visit开始的id，是球队客队名称
	var visitName=tr.find("#host"+index).text();
	if(visitName==""){
		visitName=tr.prev().find("#host"+index).text();
	}
	//在tr下寻找rf开始的id，是球队让分
	var rf=tr.find("#rf"+index).text();
	if(rf==""){
		rf=tr.prev().find("#rf"+index).text();
	}
	
	
	//寻找复选框的本标签
	var check=jqObj.find(":checkbox")[0];
	
	//如果有hand的class,就执行下列代码
	if(jqObj.hasClass("hand")){
		//把matchid存入到marchIds中，也就是index值
		if(!matchIds[index]||matchIds[index]==""){
			if(getMatchSize()+1>maxMatchLen ){
				check.checked=false;
				alert("最多选择"+maxMatchLen+"场比赛进行投注!");
				return;
			}
		}
		//更换复选框td的class，也就是换下颜色
		jqObj.removeClass("hand").addClass("hand1");
		//更新为选中
		check.checked=true;
		//取得span中的值
		var sp;
		//if(lType=='sf'){//因为没有用图片了 ，所以把下标全部用0来读到数据
			 sp =parseFloat(jqObj.find("span:eq(0)").text(),10);
		if(!spArr[index]){
			spArr[index]=[];
		}
		//把值存到spArr中
		spArr[index].push(sp);
		spArr[index].sort(asc);
	}else{
		//如果已经被选中，就更换为没有选中的样式，更新为没有选中
		jqObj.removeClass("hand1").addClass("hand");
		check.checked=false;
	}
	
	
	//寻找为包的多选框
	var bao=jqObj.parent().find(":checkbox[name=bao]")[0]||jqObj.parent().prev().find(":checkbox[name=bao]")[0];
	var chk;
	if(isSfc){
		chk=matchbody.find("tr[id=tr"+jqObj.attr("id")+"]").find(".hand1 > :checked");
	}else{
		chk=jqObj.parent().find(".hand1 > :checked");
	}
	var checkedLen=chk.length;
	//如果选中的最大值等于多选框的个数，就把包更新为选中
	bao.checked=(checkedLen==maxOption);
	
	
	
	//如果没有选中其中的任何一项，就删除数组值
	if(checkedLen==0){
		delete itemArr[index1];
		delete matchIds[index];//marchId的值集合
		delete optArr[index];  //选中的最大值集合  
		delete danNO[index];
		delete spArr[index];   //sp值的集合
	}else{
		if(!itemArr[index1]||itemArr[index1]==''||itempart[3]!=index){
			itempart[1]=(bgcolor[++g_idx%2]); 
			itempart[3]=itempart[5]=index; //球队号码，就是marchId
			itempart[7]=item;     			//球队编号      
			itempart[9]=(visitName); //客队
			if(lType!='sf'&&lType!="dt"){
				itempart[10] = "</span></span></td>";
				itempart[12] = "<td align=\"center\"class=\"table_x_bk\">";
			}else{
				var rangqiu = (rf);
				if(parseInt(rangqiu) == 0){
					itempart[11] = '<div style="color: gray; font-weight: bold">'+rangqiu+'</div>';
				}else if(parseInt(rangqiu) < 0){
					itempart[11] = '<div style="color: green; font-weight: bold">'+rangqiu+'</div>'; //让球
				}else if(parseInt(rangqiu) > 0){
					itempart[11] = '<div style="color: red; font-weight: bold">'+rangqiu+'</div>'; //让球
				}
			}
			itempart[13]=(hostName); //主球队
			//是否是单关
			if(!isDg){
				itempart[17]="'"+index+"'"; //球队号码，就是marchId
			}
		}
		itempart[15]=getItemOpt(jqObj);	
		itemArr[index1]=itempart.join("");
		optArr[index]=checkedLen;
		var optValue=[];
//		var spValueArr=[];
		spArr[index]=[];
		chk.each(function(){
			var sp=$(this).next().text();
			optValue.push(this.value);
			spArr[index].push(sp);
		});
		matchIds[index]=optValue.join(",");
		spArr[index].sort(asc);
	}
	//确定有几个tr值
	var t=[];
	var k=[];
	for(var i in itemArr){
		if(i!=undefined){
			k.push(i);
			t.push(itemArr[i]);
		}
	
	}
	for(var i=0,l=k.length;i<l;i++){
		for(var j=i,p=k.length;j<p;j++){
			var temp;
			if(parseFloat(k[i])<parseFloat(k[j])){
				temp=k[j];
				k[j]=k[i];
				k[i]=temp;
				temp=t[j];
				t[j]=t[i];
				t[i]=temp;	
			}	
		}
	}
	itembody.html(t.reverse().join(''));
	
	var trlen=7-itembody.find("tr").length;	
	//加几个空的tr值
	for(var i=0;i<trlen;i++){
		itembody.append('<tr style="background:'+bgcolor[i%2]+'">'+p_str+'</tr>');
	}
	itembody.find("tr").each(function(idx){
		if(idx%2==0){
			$(this).css("background","#f9f9f9");
		}else{
			$(this).css("background","#f2f2f2");
		}
	});
	
}


function initPass(){
	var len=getMatchSize();
	if(len>1){/* 至少2场 */
		var flag=document.getElementById("passType0").checked;
		if(flag){ //自由过关
			var t,ul,li;
			if(passDiv.find("#uz").length==0){
				ul=$('<ul id="uz"></ul>');
				passDiv.append(ul);
			}else{
				ul=passDiv.find("#uz");
			}
			var i=2;		
			for(;i<=len&&i<=8&&i<=maxPass+1;i++){
				t=i+"-"+1;
				if(passDiv.find("#p"+t).length==0){	
				  li=$('<li><input value="'+t+'"name="passway"id="p'+t+'"type="checkbox"onclick="passWayC(this,\''+t+'\')"/><label for="p'+t+'" class="hand2">'+i+'串1</label></li>');
				  ul.append(li);
				}else{
					continue;
				}
			}
			if($("#p"+i+"-1").length!=0){
				$("#p"+i+"-1").parent().remove();
				delete ggWay[i+"-1"];
			}
		}else{
			var t,ul,li,j=0;
			for(;j<=len-3&&j<passArr.length&&j<maxPass-1;j++){
				if(passDiv.find("#u"+j).length==0){
					ul=$('<ul id="u'+j+'"></ul>');
					passDiv.append(ul);
				}else{
					continue;
				}
				var passStr=passArr[j].split(",");			
				for(var i=0;i<passStr.length;i++){
					t=(j+3)+'-'+passStr[i];
					if(ul.find("#p"+t).length==0){
						li=$('<li><input value="'+t+'"name="passway"id="p'+t+'"type="checkbox"onclick="passWayC(this,\''+t+'\')"/><label for="p'+t+'" class="hand2">'+(j+3)+'串'+passStr[i]+'</label></li>');
						ul.append(li);
					}
				}
			}
			for(;j<passArr.length;j++){
				ul=passDiv.find("#u"+j);
				if(ul.length>0){
					ul.find(":checked").each(function(){
						delete ggWay[this.value];
					});
					ul.remove();
				}
			}
		}
		var len=itembody.find(":checked[name=dan]").length;
		if(len>0){
			passDiv.find(":checkbox").each(function(){
				if(parseInt(this.value.split("-")[0],10)<=len){
					this.checked=false;
					this.disabled=true;
					delete ggWay[this.value];
				}else{
					this.disabled=false;
				}
			});
		}else{
			passDiv.find(":disabled").each(function(){
				this.disabled=false;
			});
		}
	}else{
		passDiv.empty();
		ggWay=[];
	}
}
function danC(obj,no){
	if(obj.checked){
		danNO[no]=no;
	}else{
		delete danNO[no];
	}
	if(!isDg){
		var len=itembody.find(":checked[name=dan]").length;
		if(len>0){
			passDiv.find(":checkbox").each(function(){
				if(parseInt(this.value.split("-")[0],10)<=len){
					this.checked=false;
					this.disabled=true;
					delete ggWay[this.value];
				}else{
					this.disabled=false;
				}
			});
		}else{
			passDiv.find(":disabled").each(function(){
				this.disabled=false;
			});
		}
		betCount=allCalc();
		money(betCount);
		sd();
	}else{
		betCount=oneCalc('1-1');
		money(betCount);
	}
}
function passWayC(obj,value){
	var count=0;
	for(var i in ggWay){
		ggWay[i]&&count++;
	}
	//-s wlong 倍数为空，赋值为1
	if($("#multipleJq").val()==""){
		$("#multipleJq").val(1);
		}
	//-s wlong
	if(obj.checked){
		if(count>4){
			obj.checked=false;
			alert("组合过关选择的过关方式不能超过5个");
			return ;
		}
	}
	if(obj.checked){
		ggWay[value]=value;
		betCount+=oneCalc(value);
	}else{
		delete ggWay[value];
		betCount-=oneCalc(value);
	}
	money(betCount);
}
function getItemOpt(jqObj){
	var opt=[];
	var tr;
	if(isSfc){
		var id=jqObj.parent().attr("id");
		tr=matchbody.find("tr[id="+id+"]");
	}else{
		tr=jqObj.parent();
	}
	tr.find(".hand1").each(function(){
		var check=$(this).find(":checked");
		if(check.length>0){
			opt.push('<li><input type="checkbox" checked value="'+check.val()+'"onclick="cancelOpt(this)"name="'+check.attr("name")+'"/><span>'+check.attr("c")+'</span></li>');
		}
	});
	return opt.join('');
}

function  getItemOptRf(tr){
	var opt=[];
	tr.find(".hand1").each(function(){
		var check=$(this).find(":checked");
		if(check.length>0){
			opt.push('<li><input type="checkbox" checked value="'+check.val()+'"onclick="cancelOpt(this)"name="'+check.attr("name")+'"/><span width="100">'+check.attr("c")+'</span></li>');
		}
	});
	return opt.join('');
}

function cancelOpt(obj){/* 取消一个选项 */
	matchbody.find(":checked[name="+obj.name+"][value="+obj.value+"]").parent().click();
}
function cancelMatch(obj){/* //取消一对阵 */
	var index=obj.id.substring(6);
	delete itemArr[index];
	if(lType=='rf')
		matchbody.find("tr[id=tr"+index+"]").next().find(".hand1").click();
	else
	    matchbody.find("tr[id=tr"+index+"]").find(".hand1").click();
}

function cancelAll(){/* //取消全部 */
	itembody.find("label").each(function(){
		index=$(this).attr("for").substring(6);
		delete itemArr[index];
		matchbody.find("tr[id=tr"+index+"]").find(".hand1").click();
	});
    betCountJq.text(0);
    moneyJq.text(0);
}

function cancelAllRf(){
	itembody.find("label").each(function(){
		index=$(this).attr("for").substring(6);
		delete itemArr[index];
		matchbody.find("tr[id=toggleKeyTemp_"+index+"]").find(".hand1").click();
	});
    betCountJq.text(0);
    moneyJq.text(0);
}



var betCount=0,g_idx=0,maxMatchLen=15,maxOption=3,maxPass=7, 
//passArr=['1','1,3,4','1,4,5,6,11','1,5,6,10,16,20,26','1,6,7,15,20,22,35,42,50,57','1,7,8,21,35,120','1,8,9,28,56,70,247'],
itempart=['<tr style="background:','','"><td height="24"align="center"class="table_x_bk"><input type="checkbox"onclick="cancelMatch(this)" checked id="i_chk_','','"/><label class="hand2"for="i_chk_','','">','','</label></td><td align="center"class="table_x_bk"><span class="sizi_1"><span>','','</span></span></td><td align="center"class="table_x_bk"><strong class="sizi_2">','','</strong></td><td align="center"class="table_x_bk">','','</td><td valign="middle"align="center"class="table_x_bk"><div class="xuan_1"><ul>','','</ul></div></td><s:if test="in.indexOf("dt")!=-1"><td align="center"class="table_x_bk"><input type="checkbox"name="dan"onclick="danC(this,','',')"/></td></s:if></tr>'],
passArr=['3,4','4,5,6,11','5,6,10,16,20,26','6,7,15,20,22,35,42,50,57','7,8,21,35,120','8,9,28,56,70,247'],lbs='<div class="lb_box"><form name="loginFormBox"id="loginFormBox"method="post"action="/user.shtml"><div class="lb_con"><div><label for="">用户名：</label><input name="userName"value=""type="text"id="userName1"/></div><div><label for="">密　码：</label><input name="password"type="password"/></div><div><label for="validCodeBox">验证码：</label><input value=""name="validCode"id="validCodeBox"class="inp1"type="text"/><img id="imgCodeBox"src="http://passport.ecp888.com/validatecode.shtml"style="cursor: pointer;"onclick="refreshimg(this);"border="0"/></div><div class="lb_sbm"><button type="submit">登录</button><a href="http://tools.ecp888.com/user/forgetpwd.shtml"title=""class="blue"target="_blank">忘记密码</a><a href="http://passport.ecp888.com/user/reg.shtml"title=""class="red"target="_blank">免费注册</a></div></div></form></div>',
p_str='<td height="24"align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td>',
zg='<div id="zg_tab"style="display:none;"><table class="nou_tab1main nou_tab1mt"cellspacing="0"><tr class="nou_tablmt1"><td colspan="2"align="center"><strong class="sizi_z"></strong></td></tr><tr class="nou_tablmt1"><td width="55%"align="right">方案金额：</td><td align="left"><strong id="s_money"></strong>元</td></tr><tr><td align="right">方案注数：</td><td align="left"><strong id="s_betCount"></strong>注</td></tr><tr><td align="right">倍　　数：</td><td align="left"><strong id="s_mul"></strong>倍</td></tr><tr><td align="right">过关方式：</td><td align="left"id="s_passway"style="color:green"></td></tr><tr><td colspan="2"style="height:8px;"></td></tr><tr><td colspan="2"><input type="button"value="确定"class="nou_tab1input1" onclick="ordersele()"/><input type="button"value="取消"class="nou_tab1input2" onclick="closetipsWindown()"/><br/>&nbsp;</td></tr></table></div>',
hm='',lid={sf:46,rf:47,sfc:48,dxf:49},

of='<form action="/footballorder.shtml"method="post"name="orderForm" id="orderForm"><input type="hidden" name="project.ppcount"/><input type="hidden" name="project.prevMoney"/><input type="hidden" name="project.subscribecount"/><input type="hidden"name="detail.matchids"/><input type="hidden"name="project.passway"/><input type="hidden"name="project.isDg"/><input type="hidden"name="fromurl"/><input type="hidden"name="id"/><input type="hidden"name="project.projecttype"/><input type="hidden"name="project.lotteryid"/><input type="hidden"name="project.playtype"/><input type="hidden"name="project.passtype"/><input type="hidden"name="project.totalamount"/><input type="hidden"name="project.totalcount"/><input type="hidden"name="project.minimumcount"/><input type="hidden"name="project.projectbets"/><input type="hidden"name="project.promul"/><input type="hidden"name="project.percent"/><input type="hidden"name="project.openstatus"/><input type="hidden"name="detail.content"/><input type="hidden"name="detail.projectinfo"/><input type="hidden"name="detail.followuser"/><input type="hidden"name="detail.dan"/><input type="hidden"name="detail.dancount"/><input type="hidden"name="detail.buysp"/></form>';
cDiv='<div id="hmdiv" style="display:none"><div class="nou_tab1main"id="cDiv"><div class="nou_tablm1">你确定认购<strong></strong>元吗？</div><div><input type="button"class="nou_tab1input1"value="确认"><input type="button"class="nou_tab1input2"value="取消"onclick="closetipsWindown();"></div></div></div>';
var multipleJq,moneyJq,betCountJq,orderForm=false;
var isDg=false,isSfc=false,validReg=false;
var Reg={
		contentValidReg:{46:/^(\d+:([12],?){1,2}\/?)+$/,38:/^(\d+:([vh]((1\-5)|(6\-10)|(11\-15)|(16\-20)|(21\-25)|(26)),?){1,12}\/?)+$/},
		passArrReg:/^(1\-1)|(2\-1)|(3\-1)|(3\-3)|(3\-4)|(4\-5)|(4\-6)|(4\-11)|(5\-16)|(5\-20)|(5\-26)|(6\-35)|(6\-22)|(6\-20)|(6\-15)|(5\-10)|(5\-6)|(6\-7)|(6\-6)|(5\-5)|(4\-4)|(4\-1)|(5\-1)|(6\-1)|(6\-42)|(6\-50)|(6\-57)|(7\-8)|(7\-21)|(7\-35)|(7\-120)|(8\-247)|(8\-70)|(8\-56)|(8\-28)|(8\-9)|(8\-8)|(7\-7)|(7\-1)|(8\-1)$/
};

function money(wager) {
	betCount = wager || allCalc();
    var multiple = parseInt(multipleJq.val(), 10);
    var money = betCount * 2 * multiple;
    betCountJq.text(betCount);
    moneyJq.text(money);
    gusuan();
}

function gusuan(){
	var mul=ZQ.muliptile;//倍数
	var minprize=0,maxprize=0;
	var minP=$("#minprize"),maxP=$("#maxprize");
	if(mul==0){
		minP.text(minprize);
		maxP.text(maxprize);
		return;
	}
	var items=parseInt($('.the_selected').text());	
	
	if(isDg){ //是否是单关
		if(items>0){
			var maxSp=0,minSp=1000;
			for(var sp in spArr){
					if(parseFloat(spArr[sp][0])<parseFloat(minSp)){
					minSp=spArr[sp][0];
				}
				maxSp +=parseFloat(spArr[sp][spArr[sp].length-1]);//wulong 转化成float
			}
			if(lType=='rf'){
				minprize=(mul*minSp).toFixed(2)*2;
				maxprize=(mul*maxSp).toFixed(2)*2;
			}else{
				minprize=(mul*minSp).toFixed(2);
				maxprize=(mul*maxSp).toFixed(2);
			}
		}
		minP.text(minprize);
		maxP.text(maxprize);
	}else{
	
		if(items>1){
			
			var tempMinArr=[];
			var minPassCount=new Array(0,0,0,0,0,0,0,0,0);  //用于普通过关计算最小
			var min=1000;
			for(var passWay in ggWay){
				var passType = ptHash.get(ggWay[passWay]);
				var minPass = passType.passMatchs[0];
				min=min<minPass?min:minPass;
			}
			
			var cc=0;//最小奖金出现的次数
			for(var passWay in ggWay){
				var isdc=passWay.split("-")[1]!=1;
				var passType = ptHash.get(ggWay[passWay]);
				var minPass = passType.passMatchs[0];
				minPassCount[minPass]++;
				var arr=gusuangg(ggWay[passWay],min);
				tempMinArr.push(arr[0]*mul);
				maxprize+=arr[1]*mul;
				if(isdc){
					cc+=arr[2];
				}
			}
			tempMinArr.sort(asc);
			if(cc!=0){
				$("#minprize").text(''+tempMinArr[0]*cc);
			}else{
				$("#minprize").text((tempMinArr[0]*minPassCount[min]));
			}
			$("#maxprize").text(maxprize);
		}else{
			$("#minprize").text(minprize);
			$("#maxprize").text(maxprize);
		}
		ZQ.biggestPrize = maxprize / ZQ.muliptile;
		//数据小数点后两位去掉
		var minindex=$("#minprize").text().indexOf(".");
		var maxindex=$("#maxprize").text().indexOf(".");

		if(minindex!=-1)
		   minP.text($("#minprize").text().substring(0,minindex+3));
		if(maxindex!=-1)
		   maxP.text($("#maxprize").text().substring(0,maxindex+3));
	}
}
var ptHash=new Hash();ptHash.set('1',{key:'1',units:1,matchCount:1,passMatchs:[1],text:'单关',value:1});ptHash.set('2-1',{key:'2-1',units:1,matchCount:2,passMatchs:[2],text:'2x1',value:2});ptHash.set('3-1',{key:'3-1',units:1,matchCount:3,passMatchs:[3],text:'3x1',value:4});ptHash.set('3-3',{key:'3-3',units:3,matchCount:3,passMatchs:[2],text:'3x3',value:8});ptHash.set('3-4',{key:'3-4',units:4,matchCount:3,passMatchs:[2,3],text:'3x4',value:16});ptHash.set('4-1',{key:'4-1',units:1,matchCount:4,passMatchs:[4],text:'4x1',value:32});ptHash.set('4-4',{key:'4-4',units:4,matchCount:4,passMatchs:[3],text:'4x4',value:64});ptHash.set('4-5',{key:'4-5',units:5,matchCount:4,passMatchs:[3,4],text:'4x5',value:128});ptHash.set('4-6',{key:'4-6',units:6,matchCount:4,passMatchs:[2],text:'4x6',value:256});ptHash.set('4-11',{key:'4-11',units:11,matchCount:4,passMatchs:[2,3,4],text:'4x11',value:512});ptHash.set('5-1',{key:'5-1',units:1,matchCount:5,passMatchs:[5],text:'5x1',value:1024});ptHash.set('5-5',{key:'5-5',units:5,matchCount:5,passMatchs:[4],text:'5x5',value:2048});ptHash.set('5-6',{key:'5-6',units:6,matchCount:5,passMatchs:[4,5],text:'5x6',value:4096});ptHash.set('5-10',{key:'5-10',units:10,matchCount:5,passMatchs:[2],text:'5x10',value:8192});ptHash.set('5-16',{key:'5-16',units:16,matchCount:5,passMatchs:[3,4,5],text:'5x16',value:16384});ptHash.set('5-20',{key:'5-20',units:20,matchCount:5,passMatchs:[2,3],text:'5x20',value:32768});ptHash.set('5-26',{key:'5-26',units:26,matchCount:5,passMatchs:[2,3,4,5],text:'5x26',value:65536});ptHash.set('6-1',{key:'6-1',units:1,matchCount:6,passMatchs:[6],text:'6x1',value:131072});ptHash.set('6-6',{key:'6-6',units:6,matchCount:6,passMatchs:[5],text:'6x6',value:262144});ptHash.set('6-7',{key:'6-7',units:7,matchCount:6,passMatchs:[5,6],text:'6x7',value:524288});ptHash.set('6-15',{key:'6-15',units:15,matchCount:6,passMatchs:[2],text:'6x15',value:1048576});ptHash.set('6-20',{key:'6-20',units:20,matchCount:6,passMatchs:[3],text:'6x20',value:2097152});ptHash.set('6-22',{key:'6-22',units:22,matchCount:6,passMatchs:[4,5,6],text:'6x22',value:4194304});ptHash.set('6-35',{key:'6-35',units:35,matchCount:6,passMatchs:[2,3],text:'6x35',value:8388608});ptHash.set('6-42',{key:'6-42',units:42,matchCount:6,passMatchs:[3,4,5,6],text:'6x42',value:16777216});ptHash.set('6-50',{key:'6-50',units:50,matchCount:6,passMatchs:[2,3,4],text:'6x50',value:33554432});ptHash.set('6-57',{key:'6-57',units:57,matchCount:6,passMatchs:[2,3,4,5,6],text:'6x57',value:67108864});ptHash.set('7-1',{key:'7-1',units:1,matchCount:7,passMatchs:[7],text:'7x1',value:134217728});ptHash.set('7-7',{key:'7-7',units:7,matchCount:7,passMatchs:[6],text:'7x7',value:268435456});ptHash.set('7-8',{key:'7-8',units:8,matchCount:7,passMatchs:[6,7],text:'7x8',value:536870912});ptHash.set('7-21',{key:'7-21',units:21,matchCount:7,passMatchs:[5],text:'7x21',value:1073741824});ptHash.set('7-35',{key:'7-35',units:35,matchCount:7,passMatchs:[4],text:'7x35',value:-2147483648});ptHash.set('7-120',{key:'7-120',units:120,matchCount:7,passMatchs:[2,3,4,5,6,7],text:'7x120',value:1});ptHash.set('8-1',{key:'8-1',units:1,matchCount:8,passMatchs:[8],text:'8x1',value:2});ptHash.set('8-8',{key:'8-8',units:8,matchCount:8,passMatchs:[7],text:'8x8',value:4});ptHash.set('8-9',{key:'8-9',units:9,matchCount:8,passMatchs:[7,8],text:'8x9',value:8});ptHash.set('8-28',{key:'8-28',units:28,matchCount:8,passMatchs:[6],text:'8x28',value:16});ptHash.set('8-56',{key:'8-56',units:56,matchCount:8,passMatchs:[5],text:'8x56',value:32});ptHash.set('8-70',{key:'8-70',units:70,matchCount:8,passMatchs:[4],text:'8x70',value:64});ptHash.set('8-247',{key:'8-247',units:247,matchCount:8,passMatchs:[2,3,4,5,6,7,8],text:'8x247',value:128});
function gusuangg(ggWay,minPassAll) {
	var passType = ptHash.get(ggWay);
	var minPass = passType.passMatchs[0];
	/*是不是串1的*/
	var mp = parseInt(ggWay.split("-")[1])==1; 
	
	/*取出所有的奖金数组*/
	var minArr = [];
	var maxArr = [];
	var danMinArr = [];
	var danMaxArr = [];
	var minAward;
	var maxAward;
	var mintimes=0;//最小奖金重复次数
//	var tempAward = 0.0;

	if(mp){
		for(var y = 0 ; y < spArr.length;y++){
			var tempArr = spArr[y];
			if(tempArr){
				var danNo = ZQ.spzValue.split('//');
				var	danM =  danNo[y].split(',');
				if(danM[2] == '1'){
					danMinArr.push(tempArr[0]);
					danMaxArr.push(tempArr[tempArr.length - 1]);
				}else{
					minArr.push(tempArr[0]);
					maxArr.push(tempArr[tempArr.length - 1]);
					/************************************alert(maxArr);***************************************/
				}
			}
		}
	}else{
		for(var y = 0 ; y < spArr.length;y++){
			var tempArr = spArr[y];
			if(tempArr){
				minArr.push(tempArr[0]);
				maxArr.push(tempArr[tempArr.length - 1]);
			}
		}
	}
	
	if (minArr.length != maxArr.length) {
		return [0,0];
	}
	minArr.sort(asc);
	maxArr.sort(desc);
	if (isDg) {
		minAward = minArr[0];
		maxAward = 0;
		for (var i = 0; i < minArr.length; i++) {
			maxAward += maxArr[i];
		}
	}else if(mp){
		var pass = minPass;
		var danSize = danMinArr.length;
		var undanSize = minArr.length;
		danMinArr.sort(asc);
		/*模糊定胆*/
		var danMinHit=danSize;
		
		minAward = 1;
		for ( var i = 0; i < danMinHit; i++) {
			minAward *= danMinArr[i];
		}
		var min_arr = [];
		for ( var i = danMinHit; i < danSize; i++) {
			min_arr.push(danMinArr[i]);
		}
		min_arr = min_arr.concat(minArr);
		min_arr.sort(asc);
		var len = pass - danMinHit;
		for(var i=0;i<len;i++){
			minAward *= min_arr[i];
		}
		minAward *= 2;
		maxAward = 0;
		var countMaxFn = function(dan){
			C3(danSize, dan, function(comb1, n1, m1) {
				var award = 1;
				var pos = 0;
				for ( var k = 0; k < n1; k++) {
					if (comb1[k] == true) {
						award *= danMaxArr[k];
						pos++;
						if (pos == m1)
							break;
					}
				}
				C3(undanSize, pass-m1, function(comb2, n2, m2) {
					var award2 = award;
					var pos2 = 0;
					for ( var k2 = 0; k2 < n2; k2++) {
						if (comb2[k2] == true) {
							award2 *= maxArr[k2];
							pos2++;
							if (pos2 == m2)
								break;
						}
					}
					award2 *= 2;
					maxAward += award2;
				});
			});
		};
		for(var dan=danMinHit;dan <= danSize;dan++){
			countMaxFn(dan);
		}
	} else {
		minAward = 1;
		for (var i = 0; i < minPass; i++) {
			minAward *= minArr[i];
		}
		minAward *= 2;
		maxAward = 0;  //最大奖金
		var chuan=parseInt(ggWay.split("-")[0]);
		var maxTempArr;
		var flag=false;
	
		C3(maxArr.length, chuan, function(comb1, n, m) {
			for(var i=0;i<minPassAll&minPassAll==minPass;i++){
				if(!comb1[comb1.length-i-1]){
					flag=false;
					break;
				}else{
					flag=true;
				}
			}
			if(flag){
				mintimes++;
			}
			maxTempArr=[];
			for(var j=0;j<comb1.length;j++){   //临时的赔率最大,串小于场数组合场次的SP存入数组
					if(comb1[j]){
						maxTempArr.push(maxArr[j]);
					}
			}
			for(var i=0,l=passType.passMatchs.length;i<l;i++){
				if(passType.passMatchs[i]==chuan){
					var award = 1;
					var pos = 0;
					for ( var k = 0; k <maxArr.length; k++) {
						if (comb1[k] == true) {
							award *= maxArr[k];
							pos++;
							if (pos == m)
								break;
						}
					}
					award *= 2;
					maxAward += award;
				}else{//小于串的情况继续拆
						C3(chuan, passType.passMatchs[i], function(comb2, n, m) {
							var award = 1;
							var pos = 0;
							for ( var k = 0; k < n; k++) {
								if (comb2[k] == true) {
									award *= maxTempArr[k];
									pos++;
									if (pos == m)
										break;
								}
							}
							award *= 2;
							maxAward += award;
						});
				 }
			}
		});
	}
	/*算出来的最大最小奖金开始进行计算*/
	return [minAward,maxAward,mintimes];
}
/*奖金估算明细页面*/
function prizegs(){
	//alert("胆："+getDan());
//	if(getDan()!=''){
//		return ;
//	}
	if(parseFloat($("#maxprize").text(),10)>0 && parseFloat($("#minprize").text(),10)>0){
		var spArrgs=[];
		var contentArrgs=[];
		var content;
		var sp;
		$(".hand1").each(function(){
		   if(spArrgs["m"+this.id]==undefined){
		     spArrgs["m"+this.id]=[];
		     contentArrgs["m"+this.id]=[];
		   } 
		    spArrgs["m"+this.id].push($.trim($(this).find("p").text())||$.trim($(this).find("span").text()));
		    contentArrgs["m"+this.id].push($(this).find("input").val());
		});
		var spArr1=[];
		for(var id in spArrgs){
			spArr1.push(id.substring(1)+":"+spArrgs[id]);
		}
		sp=spArr1.join("/");
		var ccArr1=[];
		for(var id in contentArrgs){
			ccArr1.push(id.substring(1)+":"+contentArrgs[id]);
		}
		content=ccArr1.join("/");
		var param=["detail.content="+content];
		param.push("project.passway="+getPassWay());
		param.push("project.ischedan="+(isDg?"1":"0"));
		param.push("detail.dan="+getDan());
		param.push("detail.buysp="+sp);
		param.push("project.lotteryid="+lid[lType]);
		param.push("project.promul="+ multipleJq.val());
		param.push("project.totalamount="+moneyJq.text());
		if(getDan()!=''){
			window.open('/'+$("#ball").val()+'/'+lType+(isDg?'dg':'gg')+'/prizeDetail.shtml?'+param.join("&"),'prizeDetail','');
		}else{
			window.open('/'+$("#ball").val()+'/'+lType+(isDg?'dg':'gg')+'/prize.shtml?'+param.join("&"),'prize','');
		}
	}
	 if($("#multipleJq").val()==''){
			alert("投注的倍数不能为空!");
		}
		  else if($("#multipleJq").val()==0){
			alert("投注的倍数不能0!");
		}
}
function oneCalc(ggWay){
    /*
	 * var minabs = parseInt(this.selectsJq.eq(0).val(), 10);var maxabs =
	 * parseInt(this.selectsJq.eq(1).val(), 10);
	 */
    var wagertype = "1";
    var sa = [];
    var sb = [];
    for (var k in optArr) {
        if (danNO[k]) {
            sb.push(optArr[k]);
        } else {
            sa.push(optArr[k]);
        }
    }
    var zs = 0;
    var minabs=maxabs=sb.length;
    zs = parseInt(myCalc(ggWay, wagertype, sa, sb, minabs, maxabs), 10);
    return zs;
}
function allCalc(){
	/*
	 * var minabs = parseInt(this.selectsJq.eq(0).val(), 10); var maxabs =
	 * parseInt(this.selectsJq.eq(1).val(), 10);
	 */
    var wagertype = "1";
    var wager = 0;
    var sa = [];
    var sb = [];
    for (var k in optArr) {
        if (danNO[k]) {
            sb.push(optArr[k]);
        } else {
            sa.push(optArr[k]);
        }
    }
    var minabs=maxabs=sb.length;
    for (var k1 in ggWay) {
        wager += parseInt(myCalc(ggWay[k1], wagertype, sa, sb, minabs, maxabs), 10);
    }
    return wager;
}

var project={oneAmount:0,projecttype:0,ppcount:0,lotteryid:36,isDg:1,playtype:0,passtype:1,passway:'',totalamount:0,totalcount:1,subscribecount:1,minimumcount:0,projectbets:0,promul:1,percent:0,openstatus:4,detail:{content:'',projectinfo:'',followuser:'',dan:'',dancount:'',matchids:''}};
function validForm(){
	if(!orderForm||!validReg){
		return false;
	}
	if(isNaN(orderForm["project.lotteryid"].value)){
		alert("彩种id应该是数字!");
		return false;
	}
	if(isNaN(orderForm["project.totalamount"].value)){
		alert("方案金额应该是数字");
		return false;
	}
	if(isNaN(orderForm["project.projectbets"].value)){
		alert("方案注数应该是数字");
		return false;
	}
	if(isNaN(orderForm["project.promul"].value)){
		alert("方案倍数应该是数字");
		return false;
	}
	if(parseInt(orderForm["project.promul"].value,10)>10000 ){
		alert("方案倍数不能超过10000倍");
		return false;
	}
	if(isNaN(orderForm["detail.dancount"].value)){
		alert("方案胆个数应该是数字");
		return false;
	}
	if(!validReg.test(orderForm["detail.content"].value)){
		alert("方案内容格式验证失败");
		return false;
	}
	return true;
}
function initZgData(){
	project.projecttype=0;
	project.lotteryid=lid[lType];
	project.passway=getPassWay(false,0);
	project.totalamount=moneyJq.text();
	project.projectbets=betCountJq.text();
	project.promul=multipleJq.val();
	project.isDg=(isDg?1:0);
	project.totalcount=project.subscribecount=1;
	project.percent=project.minimumcount=0;
	project.openstatus=4;
	project.detail.content=getContent();
	project.detail.dan=getDan();
	project.detail.danCount=project.detail.dan==""?0:project.detail.dan.split(",").length;
	project.detail.matchids=getMatchIds();
	project.prevMoney = getMaxPr(); 
}
function getMaxPr()
{
	 var p = $("#maxprize").text().replace(/\s/g,'');
	 if(p=='') return 0;
	 return p;
}
function initFilterData(){
	project.projecttype=0;
	project.lotteryid=lid[lType];
	project.passway=getPassWay(false,0);
	project.totalamount=moneyJq.text();
	project.projectbets=betCountJq.text();
	project.promul=multipleJq.val();
	project.isDg=(isDg?1:0);
	project.totalcount=project.subscribecount=1;
	project.percent=project.minimumcount=0;
	project.openstatus=4;
	project.detail.content=getContent();
	project.detail.dan=getDan();
	project.detail.danCount=project.detail.dan==""?0:project.detail.dan.split(",").length;
	project.detail.matchids=getMatchIds();
}


function initHmData(){
	initZgData();
	project.projecttype=1;
	project.totalcount=parseInt(project.totalamount);
	project.subscribecount=project.totalamount*0.05<1?1:Math.ceil(project.totalamount*0.05);
	project.minimumcount=0;
	project.oneAmount=(parseInt(project.totalamount,10)/project.totalcount);
	var matchitem =[];
	var flag1 = true;
	var flag2 = true;
	var flag3 = true;
	var flag4 = false;
	var number1 = 0;
	var number2 = 0;
	var va = '';
	itembody.find("tr").each(function(idx){
		if($(this).find(".hand2").length==0)return false;
		matchitem.push('<tr'+(idx%2==1?' class="nou_telbetop_list"':'')+'>');
		matchitem.push('<td>'+$(this).find(".hand2").text()+'</td>');
		//alert("text=="+$(this).find(".hand2").text());
		var hand2Val = $(this).find(".hand2").text();
		$("#matchbody").find("label").each(function(){
			var gleagueName = $(this).html();
			if(hand2Val == gleagueName){
				var ys=$(this).parent().next().attr("style");//获取到赛事名称的颜色
				matchitem.push('<td style="'+ys+'"><font class="sizi_3 named">'+$(this).parent().next().find("span").eq(0).html()+'</font></td>');
			}
		});
		
		if(lType!='sf'){
			matchitem.push('<td>'+'<font color="#1F3A87">'+$(this).find("td:eq(1)").text()+'</font>'+'&nbsp;VS&nbsp;'+'<font color="#1F3A87">'+$(this).find("td:eq(2)").text()+'</font>'+'</td>');
		}else{
			matchitem.push('<td>'+'<font color="#1F3A87">'+$(this).find("td:eq(1)").text()+'</font>'+'&nbsp;VS&nbsp;'+'<font color="#1F3A87">'+$(this).find("td:eq(3)").text()+'</font>'+'</td>');
		}
		matchitem.push('<td class="border-bottom:1px solid #DDDDDD">'+$("#trF"+$(this).find(":checked:eq(0)").attr("id").replace(/\D/g,"")).find("td:eq(2)").text()+'</td>');
		if(lType=='sf'){
			if($(this).find(".sizi_2").text()>0){
				matchitem.push('<td style="color:red;font-weight:bold">'+$(this).find(".sizi_2").text()+'</td>');
			}
			else if($(this).find(".sizi_2").text()<0){
				matchitem.push('<td style="color:green;font-weight:bold">'+$(this).find(".sizi_2").text()+'</td>');
			}
			else{
				matchitem.push('<td style="color:gray;font-weight:bold">'+$(this).find(".sizi_2").text()+'</td>');
			}
		}
		var optArrEx=[]; 
		if(lType!='sf'){//不是让球胜平负的
			if(lType=='rf'){
				$(this).find("td:eq(3)").find("li > span").each(function(){
					if(optArrEx.length%5==0){
						if(optArrEx.length==0){
							optArrEx.push(this.innerHTML);	
						}else{
							optArrEx.push('<br/>'+this.innerHTML);	
						}
					}else{
						optArrEx.push(this.innerHTML);
					}
				});
			} 
			else if(lType=='dxf'){
				$(this).find("td:eq(3)").find("li > span").each(function(){
					if(optArrEx.length%3==0){
						if(optArrEx.length==0){
							optArrEx.push(this.innerHTML);	
						}else{
							optArrEx.push('<br/>'+this.innerHTML);	
						}
					}else{
						optArrEx.push(this.innerHTML);
					}
				});
			}
			else{
				$(this).find("td:eq(3)").find("li > span").each(function(){
							optArrEx.push(this.innerHTML);	
				});
			}
		}else {//让球胜平负
			$(this).find("td:eq(4)").find("li > span").each(function(){
				if(optArrEx.length%3==0){
					if(optArrEx.length==0){
						optArrEx.push(this.innerHTML);	
					}else{
						optArrEx.push('<br/>'+this.innerHTML);	
					}
				}else{
					optArrEx.push(this.innerHTML);
				}
			});
		}
		if(lType=='rf'){
			matchitem.push('<td><font color="#1F3A87">'+optArrEx.join(",")+'</font></td>');
		}
		else{
			matchitem.push('<td style="line-height:150%"><font color="#1F3A87">'+optArrEx.join(",")+'</font></td>');
		}
		
		matchitem.push('<td>'+($(this).find(":checked[name=dan]").length==1?'胆':'')+'</td>');
		if(idx==0){
			matchitem.push('<td rowspan="'+itembody.find(".hand2").length+'">'+(isDg?'单关':getPassWay('<br/>',5).replace(/-/g,'串'))+'</td>');
		}
		matchitem.push('</tr>');
	});
	$("#matchitem").html(matchitem.join(''));
	$("#m_i").html('总金额<span>￥'+moneyJq.text()+'</span>元(【普通过关】，<span>'+betCountJq.text()+'</span>注，<span>'+multipleJq.val()+'</span>倍)');
	$("#b_f").val(parseInt(project.totalamount,10));
	$("#b_mf").text(project.oneAmount.toFixed(2));
	$("#b_b").attr("checked",false);
	$("#b_bf").val("").attr("disabled",true);
	$("#b_bl").val("").attr("disabled",true);
	$("#bb_bl").val("").attr("disabled",true);
	$("#b_bj").text("￥0.00元(0.00%)");
	$("#b_tc").val("5");
	$("#openStatus1").attr("checked",true);
	$("#b_ms").val("");
	$("#b_fu").val("").attr("disabled",true).prev().attr("checked",false);
	$("#b_rf").val("").attr("disabled",false);
	$("#b_rf").val(project.subscribecount);
	$("#b_rj").text("￥0.00");
	$("#b_rjb").text("0.00%");
	$("#b_proportion").attr("checked",false);
	$("#bb_proportion").attr("checked",false);
	$("#bb_b").attr("checked",true);
	$("#b_rj").text("￥"+(parseInt(project.subscribecount,10)*project.oneAmount).toFixed(2));
	$("#b_rjb").text("元("+(parseInt(project.subscribecount,0)/project.totalcount*100).toFixed(2)+"%)"); 
	var tempE= $("#b_f").data("events");
	if(!tempE){
		$("#b_f").bind("keyup",function(){
			this.value=this.value.replace(/\D/g,"");
			if(this.value==""||this.value==0)
				return;
			project.totalcount=parseInt(this.value,10);
			project.oneAmount=(parseInt(moneyJq.text(),10)/project.totalcount);
			$("#b_mf").text(project.oneAmount.toFixed(2));
			$("#b_rj").text("￥"+(parseInt(project.subscribecount,10)*project.oneAmount).toFixed(2));
			$("#b_rjb").text("("+(parseInt(project.subscribecount,0)/project.totalcount*100).toFixed(2)+"%"+")"); 
		}).bind("blur",function(){
			if(project.totalamount%project.totalcount!=0){
				alert("每份金额必须为整数！");
				$("#b_f").select().focus();
				return false;
			}
		});
		$("#b_b").bind("click",function(){
			if(flag1 == true){
				$("#b_b").attr("checked",true);
				$("#b_proportion").attr("checked",false);
				$("#b_bl").val("").attr("disabled",true);
				$("#b_blj").text("");
				flag2 = true;
				flag1 = false;
			}else{
				$("#b_b").attr("checked",false);
				flag1 = true;
			}
			
			if(this.checked){
				$("#b_bf").attr("disabled",false);
				project.minimumcount=project.totalcount*0.1<1?1:Math.ceil(project.totalcount*0.1);
				$("#b_bf").val(project.minimumcount);
				$("#b_bj").text("￥"+(parseInt(project.minimumcount,0)*parseInt(project.oneAmount)).toFixed(2)+"元("+(parseInt(project.minimumcount,0)/project.totalcount*100).toFixed(2)+"%)");
			}else{
				$("#yzbd").hide();
				$("#b_bf").val("").attr("disabled",true);
				$("#b_bj").text("");
				project.minimumcount=0;
			}
		});
		
		$("#bb_b").bind("click",function(){
			if(flag4 == true){
				$("#bb_b").attr("checked",true);
				$("#bb_proportion").attr("checked",false);
				$("#bb_bl").val("").attr("disabled",true);
				$("#bb_blj").text("");
				flag4 = false;
				flag3 = true;
			}else{
				//$("#bb_b").attr("checked",false);
				flag4 = true;
			}
			
			if(this.checked){
				$("#b_rf").val("").attr("disabled",false);
				$("#b_rf").val(project.totalamount*0.05<1?1:Math.ceil(project.totalamount*0.05));
				$("#b_rj").text("￥"+(parseInt($("#b_rf").val(),10)*project.oneAmount).toFixed(2));
				$("#b_rjb").text("元("+(parseInt($("#b_rf").val(),0)/project.totalcount*100).toFixed(2)+"%)");
				project.subscribecount = this.value;
			}else{
				$("#b_rf").val("").attr("disabled",true);
				$("#b_rjb").text("");
				$("#b_rj").text("");
				project.subscribecount = 0;
			}
		});
		
				
		$("#b_proportion").bind("click",function (){
			if(flag2 == true){
				$("#b_proportion").attr("checked",true);
				$("#b_b").attr("checked",false);
				$("#b_bf").val("").attr("disabled",true);
				$("#b_bj").text("");
				flag1 = true;
				flag2 = false;
			}else{
				$("#b_proportion").attr("checked",false);
				flag2 = true;
			}
			if(this.checked){
				$("#b_bl").attr("disabled",false);
//				var count = project.totalcount * 10 / 100;
//				var number = 100 / project.totalcount;
//				$("#b_bl").val(parseFloat(number).toFixed(2));
//				$("#b_blj").text(" ￥"+(parseInt(project.totalcount*parseFloat($("#b_bl").val())/100)*parseInt(project.oneAmount)).toFixed(2)+"元("+parseInt(project.totalcount*parseFloat($("#b_bl").val())/100)+"份)");
			}else{
				$("#yzbd").hide();
				$("#b_bl").val("").attr("disabled",true);
				$("#b_blj").text("");
			}
			project.minimumcount=0;
		});
		
		$("#bb_proportion").bind("click",function (){
			if(flag3 == true){
				$("#bb_proportion").attr("checked",true);
				$("#bb_b").attr("checked",false);
				$("#b_rf").val("").attr("disabled",true);
				$("#b_rj").text("");
				$("#b_rjb").text("");
				flag3 = false;
				flag4 = true;
			}else{
				//$("#bb_proportion").attr("checked",false);
				flag3 = true;
			}
			if(this.checked){
				$("#bb_bl").attr("disabled",false);
				//var count = project.totalcount * 10 / 100;
				//var count = project.totalcount * 10 / 100 < 1 ? 100 / project.totalcount : parseInt(project.minimumcount,0)/project.totalcount*100;
//				var number = 100 / project.totalcount;
				//$("#bb_bl").val(parseFloat(number).toFixed(2));
				//$("#bb_blj").text(" ￥"+(parseInt(project.totalcount*parseFloat($("#bb_bl").val())/100)*parseInt(project.oneAmount)).toFixed(2)+"元("+parseInt(project.totalcount*parseFloat($("#bb_bl").val())/100)+"份)");
				//project.subscribecount = parseInt(project.totalcount*parseFloat($("#bb_bl").val()/100));
			}else{
				$("#bb_bl").val("").attr("disabled",true);
				$("#bb_blj").text("");
			}
			project.subscribecount = 0;
		});
		$("#b_bl").bind("keyup",function(){
//				var str = this.value;
//				var reg = /(\d+\.\d{1,2})|(\d+)/g;
//  				var result =  str.match(reg);
//  				this.value = result;
			this.value=this.value.replace(/[^\d|\.]/g,"");
			if(this.value=="")
				return;
			if((project.totalcount / 100 * parseFloat(this.value,0)) > project.totalcount){
				alert("保底份数不能大于总份数");
				//$("#b_bl").focus();
				return;
			}
			$("#b_blj").text(" ￥"+((project.totalcount*parseInt(this.value,0)/100)*parseInt(project.oneAmount))+"元("+(project.totalcount*parseInt($("#b_bl").val())/100)+"份)");
			project.minimumcount=0;
		});
		
		$("#b_bl").bind("blur",function(){
			if(this.value=="")
				return;

  			var re = /^[0-9]*[1-9][0-9]*$/ ;
			//var result = re.test(parseInt(project.totalcount*parseInt($("#b_bl").val())/100));   // 返回true或false
			
			if(project.totalcount / 100 * parseFloat(this.value,0) < 1){
				alert("保底份数必须为整数，系统将为您默认最佳数值");
				//$("#b_bl").focus();
				var numStr = '1.0';
				if(numStr.length > 1){
					numStr = numStr.substring(0,1);
					this.value = parseFloat(100 / project.totalcount * numStr).toFixed(2);
				}
				$("#b_blj").text(" ￥"+((project.totalcount*parseInt(this.value,0)/100)*parseInt(project.oneAmount)).toFixed(2)+"元("+(project.totalcount*parseInt($("#b_bl").val())/100).toFixed(0)+"份)");
				return false;
			}else{
				var varr;
				if(this.value > 100)
					this.value = 100;
				if(!re.test(project.totalcount*parseInt($("#b_bl").val())/100)){
					if(number1==0){
					alert("保底份数必须为整数，系统将为您默认最佳数值");
					var numStr = project.totalcount / 100 * parseFloat(this.value,0).toFixed(2)+'';
					varr = numStr.split(".");
					this.value = parseFloat(100 / project.totalcount * varr[0]).toFixed(2);
					va = this.value;
					$("#b_blj").text(" ￥"+parseInt(varr[0])*parseInt(project.oneAmount)+"元("+(project.totalcount*parseFloat($("#b_bl").val())/100).toFixed(0)+"份)");
				}
				else{
					if(this.value != va){
						alert("保底份数必须为整数，系统将为您默认最佳数值");
						var numStr = project.totalcount / 100 * parseFloat(this.value,0)+'';
						varr = numStr.split(".");
						this.value = parseFloat(100 / project.totalcount * varr[0]).toFixed(2);
						va = this.value;
						$("#b_blj").text(" ￥"+parseInt(varr[0])*parseInt(project.oneAmount)+"元("+(project.totalcount*parseFloat($("#b_bl").val())/100).toFixed(0)+"份)");
					}
				}
				number1++;
				}
			}
			project.minimumcount = (project.totalcount*parseFloat($("#b_bl").val())/100).toFixed(0);
		});
//			if((project.minimumcount==0||project.minimumcount/project.totalcount*100<5)){
//				$("#yzbd").html("保底份数不能少于5%!");
//				$("#yzbd").show();
//				$("#b_bf").focus();
//				return false;
//			}
		
		$("#bb_bl").bind("keyup",function(){
//				var str = this.value;
//				var reg = /(\d+\.\d{1,2})|(\d+)/g;
//  				var result =  str.match(reg);
//  				this.value = result;
		//	this.value=this.value.replace(/\D/g,"");
		this.value=this.value.replace(/[^\d|\.]/g,"");
			if(this.value=="")
				return;
			if((project.totalcount / 100 * parseFloat(this.value,0)) > project.totalcount){
				alert("认购份数不能超过总份数");
				//$("#b_bl").focus();
				return false;
			}
			$("#bb_blj").text(" ￥"+((project.totalcount*parseInt(this.value,0)/100)*parseInt(project.oneAmount))+"元("+(project.totalcount*parseInt($("#bb_bl").val())/100)+"份)");
			project.subscribecount = project.totalcount*parseInt($("#bb_bl").val())/100;
		});
		
		$("#bb_bl").bind("blur",function(){
			if(this.value=="")
				return;
  			var re = /^[0-9]*[1-9][0-9]*$/ ;
//			var result = re.test(parseInt(project.totalcount*parseInt($("#bb_bl").val())/100));   // 返回true或false
			if(project.totalcount / 100 * parseFloat(this.value,0) < 1){
				alert("认购份数必须为整数，系统将为您默认最佳数值");
				//$("#b_bl").focus();
				var numStr = '1.0';
				if(numStr.length > 1){
					numStr = numStr.substring(0,1);
					this.value = parseFloat(100 / project.totalcount * numStr).toFixed(2);
				}
				$("#bb_blj").text(" ￥"+((project.totalcount*parseFloat(this.value,0)/100)*parseInt(project.oneAmount)).toFixed(2)+"元("+(project.totalcount*parseFloat($("#bb_bl").val())/100).toFixed(0)+"份)");
				return false;
			}else{
				var str;
				if(this.value > 100)
					this.value = 100;
				if(!re.test(project.totalcount*parseInt($("#bb_bl").val())/100)){
					if(number2==0){
					alert("认购份数必须为整数，系统将为您默认最佳数值");
					var numStr = project.totalcount / 100 * parseFloat(this.value,0)+'';
					str = numStr.split(".");
					this.value = parseFloat(100 / project.totalcount * str[0]).toFixed(2);
					va = this.value;
					$("#bb_blj").text(" ￥"+(parseInt(str[0])*parseInt(project.oneAmount))+"元("+(project.totalcount*parseFloat($("#bb_bl").val())/100).toFixed(0)+"份)");
				}
				else{
					if(this.value != va){
						alert("认购份数必须为整数，系统将为您默认最佳数值");
						var numStr = project.totalcount / 100 * parseFloat(this.value,0)+'';
						str = numStr.split(".");
						this.value = parseFloat(100 / project.totalcount * str[0]).toFixed(2);
						va = this.value;
						$("#bb_blj").text(" ￥"+(parseInt(str[0])*parseInt(project.oneAmount))+"元("+(project.totalcount*parseFloat($("#bb_bl").val())/100).toFixed(0)+"份)");
					}
				}
				number2++;
				}
			}
			project.subscribecount = (project.totalcount*parseFloat($("#bb_bl").val())/100).toFixed(0);
		});
			
		$("#b_bf").bind("keyup",function(){
			this.value=this.value.replace(/\D/g,"");
			if(this.value=="")
				return;
			if(parseInt(this.value,0)>project.totalcount){
				alert("保底份数不能大于总份数");
				$("#b_bf").focus();
				return false;
			}
			
			$("#b_bj").text("￥"+(parseInt(this.value,0)*parseInt(project.oneAmount))+"元("+(parseInt(this.value,0)/project.totalcount*100).toFixed(2)+"%)");
			project.minimumcount=this.value;
		});
		$("#b_bf").blur(function(){
			if((project.minimumcount==0||project.minimumcount/project.totalcount*100<5)){
				$("#yzbd").html("保底份数不能少于5%!");
				$("#yzbd").show();
				$("#b_bf").focus();
				return false;
			}else{
				$("#yzbd").hide();
			}
		});
		
		$("#b_rf").bind("keyup",function(){
			this.value=this.value.replace(/\D/g,"");
			if(this.value=="")
				return;
			if(parseInt(this.value)>parseInt(project.totalcount)){
				alert("认购份数不能超过总份数");
				$("#b_rf").select().focus();
				return;
			}
			project.subscribecount=this.value;
 
			$("#b_rj").text(" ￥"+(parseInt(this.value,10)*project.oneAmount).toFixed(2));
			$("#b_rjb").text("元("+(parseInt(this.value,0)/project.totalcount*100).toFixed(2)+"%)");
 
		});
		$("#uNameEx").text(LoginStatus.getUserName());
		$("#uAmountEx1").text("￥"+LoginStatus.getUserAmount());
		$(".nou_input2").unbind().bind("click",function(){
			if(checkHmData()&&initForm()&&checkForm()){//合买
				if(cDiv){
					$(cDiv).appendTo("body");
					cDiv=null;
				}
				tipsWindown('来自彩票直通车的消息！','id:hmdiv',233,130,true,'',true,'');
				$("#windown-content").find(".nou_tab1input1").bind("click",function(){
					closetipsWindown();
					project.openstatus=$(".nou_radiohack").find(":checked").val();
					project.percent=$("#b_tc").val();
					checkHmData()&&initForm()&&checkForm()&&submit();
				});
 
				if($("#b_rj").text() != ''){
					$("#windown-content").find("strong").text($("#b_rj").text());
				}else{
					$("#windown-content").find("strong").text("￥"+(parseInt(project.totalcount*parseFloat($("#bb_bl").val())/100)*parseInt(project.oneAmount)).toFixed(2));
				}
 
				//$("#cDiv").dialog({resizable:false,title:'来自彩票直通车的消息！',width:233,modal:true}).find("strong").text($("#b_rj").text());
			}
		});
		//绑定提成选择
		$("#b_tc").change(function(){
			 if(this.value>Math.floor(project.subscribecount*100/project.totalcount)){
				 alert("提成比例不能高于自己认购的比例!");
				 $("#b_tc").val(Math.floor(project.subscribecount*100/project.totalcount));
			 }
		});
		$("#yps").bind("keyup",function(){
			this.value=this.value.replace(/\D/g,"");
			if(this.value==""||this.value==0)
				return;
			var maxpp;
			var tc=parseInt($("#b_tc").val());
			if(tc==0){
			    maxpp=project.subscribecount;
			}else{
				maxpp=parseInt(project.subscribecount)-Math.ceil(project.totalcount*tc/100<1?1:project.totalcount*tc/100);
			}		
			if(this.value>maxpp){
				alert("预抛售份数不符合要求!");
				$("input[name=project.ppflag]").val(1);	//赋值form预抛售标识-1为预抛售，0-为默认
				$("input[name=project.ppcount]").val(maxpp);	//赋值form预抛售份数
				$("#yps").val(maxpp);	//赋值预抛售输入框	
				project.ppcount= maxpp;
			}else if(maxpp==0){
				$("input[name=project.ppflag]").val(0);	//赋值form预抛售标识-1为预抛售，0-为默认
				$("input[name=project.ppcount]").val(0);	//赋值form预抛售份数
				$("#yps").val("");	//赋值预抛售输入框
				project.ppcount= 0;
			}else {
				$("input[name=project.ppflag]").val(1);	//赋值form预抛售标识-1为预抛售，0-为默认
				$("input[name=project.ppcount]").val(parseInt(this.value,10));	//赋值form预抛售份数
				$("#yps").val(parseInt(this.value,10));	//赋值预抛售输入框	
				project.ppcount= 0;
			}			
		});
	}
}
function submit(){
	$(orderForm).ajaxSubmit({
		success:function(data){
		  resultForm(data);
	    },
		error:function(data){
		  resultForm(data.m||data.responseText||data.response);
	},clearForm: true,timeout:3000,dataType:'json'});
}

function salesubmit(){
	$(orderForm).ajaxSubmit({
		success:function(data){
		  resultsaleForm(data);
	    },
		error:function(data){
		  resultsaleForm(data.m||data.responseText||data.response);
	},clearForm: true,timeout:3000,dataType:'json'});
}

function checkFileterDate(){
	if(project.totalcount==0){
		alert("总份数必须大于0");
		closetipsWindown();
		$("#b_f").focus();
		return false;
	}
	
	return true;
}

function checkHmData(){
	if(parseInt(project.minimumcount)+parseInt(project.subscribecount)>project.totalcount){
		alert("认购份数加保底份数不能大于总份数");
		return false;
	}
	if(project.totalcount==0){
		alert("总份数必须大于0");
		$("#b_f").focus();
		return false;
	}
	if(project.subscribecount==0){
		alert("认购份数不能等于0");
		$("#b_rf").focus();
		return false;
	}
	if(project.subscribecount>project.totalcount){
		alert("认购份数不能超过总份数");
		$("#b_rf").focus();
		return;
	}
	if($("#b_b").attr("checked") && (project.minimumcount==0||project.minimumcount/project.totalcount*100<5)){
		alert("保底份数不能少于5%");
		$("#b_rf").focus();
		return false;
	}
	if($("#b_proportion").attr("checked") && (project.minimumcount==0||project.minimumcount/project.totalcount*100<5)){
		alert("保底份数不能少于5%");
		$("#b_bl").focus();
		return false;
	}
	 if($("#b_tc").val()>Math.floor(project.subscribecount*100/project.totalcount)){
		 alert("提成比例不能高于自己认购的比例!");
		 $("#b_tc").val(Math.floor(project.subscribecount*100/project.totalcount));
		 return false;
	 }
	project.detail.projectinfo=$("#b_ms").val();
	if(getBytesLength(project.detail.projectinfo)>300){
		alert("方案描述最多300个字符");
		$("#b_ms").focus();
		return false;
	}
	project.detail.followuser=$("#b_fu").val();
	if(getBytesLength(project.detail.followuser)>250){
		alert("指定跟单人最多250个字符");
		$("#b_fu").focus();
		return false;
	}
	return true;
}
function initForm(){
	if(!orderForm){
		return false;
	}
	orderForm["fromurl"].value=location.href.split("?")[0];
	orderForm["id"].value=id;
	orderForm["project.projecttype"].value=project.projecttype;
	orderForm["project.lotteryid"].value=project.lotteryid;
	orderForm["project.playtype"].value=project.playtype;
	orderForm["project.passtype"].value=project.passtype;
	orderForm["project.passway"].value=project.passway;
	orderForm["project.totalamount"].value=project.totalamount;
	orderForm["project.totalcount"].value=project.totalcount;
	orderForm["project.percent"].value=project.percent;
	orderForm["project.openstatus"].value=project.openstatus;
	orderForm["project.projectbets"].value=project.projectbets;
	orderForm["project.minimumcount"].value=project.minimumcount;
	orderForm["project.promul"].value=project.promul;
	orderForm["project.isDg"].value=project.isDg;
	orderForm["project.subscribecount"].value=project.subscribecount;
	orderForm["detail.content"].value=project.detail.content;
	orderForm["detail.dan"].value=project.detail.dan;
	orderForm["detail.dancount"].value=0;
	orderForm["detail.matchids"].value=project.detail.matchids;
	orderForm["detail.followuser"].value=project.detail.followuser;
	orderForm["detail.buysp"].value=getSp();
	orderForm["detail.projectinfo"].value=project.detail.projectinfo;
	orderForm["project.prevMoney"].value=project.prevMoney;
	orderForm["project.ppcount"].value=project.ppcount;
	return true;
}
function followUser(obj){
	$(obj).next().attr("disabled",!obj.checked);
}
/**
 * 预抛售
 * @param obj
 */
function szyps(obj){
	$(obj).next().attr("disabled",!obj.checked);
	var maxpp;
	if(obj.checked){
		if(project.subscribecount!=0){
			var tc=parseInt($("#b_tc").val());
			if(tc==0){
			    maxpp=project.subscribecount;
			}else{
				maxpp=parseInt(project.subscribecount)-Math.ceil(project.totalcount*tc/100<1?1:project.totalcount*tc/100);
			}
			if(maxpp>0){
				$("input[name=project.ppcount]").val(parseInt(maxpp));	//赋值form预抛售份数
				$("#yps").val(maxpp);	//赋值预抛售输入框
			}else {
				$("input[name=project.ppcount]").val(0);	//赋值form预抛售份数
				$("#yps").val("");	//赋值预抛售输入框
			}			
		}
	}else{
		$("input[name=project.ppcount]").val(0);	//赋值form预抛售份数
		$("#yps").val("");	//赋值预抛售输入框
	}
}
function before(buyType){
	if(LoginStatus.isLogin()){
		var id="sfdg";
		if(id.indexOf("gg")>-1){
			if(""==$(".xxk4").html()){
				alert("请选择投注内容!");
				return false;
			}
			if(moneyJq.text()==0||isNaN(parseInt(moneyJq.text(),0))){
				alert("请选择过关方式!");
				return false;
			}
		}
		if(id.indexOf("dg")>-1){
			if(moneyJq.text()==0||isNaN(parseInt(moneyJq.text(),0))){
				alert("请选择投注内容!");
				return false;
			}
		}
		if(buyType == "selfBuy"){
			if(parseFloat($("#uAmount").text().replace(/￥(.+)元/,"$1"),10)<parseInt(moneyJq.text(),0)){
				alert("余额不足!");
				return false;
			}
		}
		if(!isDg){
			if(itembody.find(".hand2").length<2){
				alert("至少选择两场对阵");
				return false;
			}
		}
		if(multipleJq.val()==0||multipleJq.val()==""){
			if(multipleJq.val()==0){
		    return !!alert("倍数不能为0！");
			}
			 if(multipleJq.val()==""){
			     return !!alert("倍数不能为空！");
			}
		}
		if(multipleJq.val()>10000){
			alert("倍数不能超过10000倍！");
			return false;
		}
		//添加订单表单
		if(!orderForm){
			orderForm=$(of);
			$("body").append(orderForm);
			orderForm=orderForm[0];
			of=null;
		}
		return true;
	}else{
		LoginStatus.showLogin();
		return false;
	}
}

function checkForm(){
//先注入掉,以后必须还原
	if(!/^[01]$/.test(orderForm["project.projecttype"].value)){
		alert("方案合买自购参数有误!");
		return false;
	}
	if(orderForm["project.lotteryid"].value<46||orderForm["project.lotteryid"].value>49){
		alert("彩种ID参数有误!");
		return false;
	}
	if(orderForm["project.passtype"].value!='1'){
		alert("过关类型参数有误!");
		return false;
	}
	var passWay=orderForm["project.passway"].value;
	if(!passWay||passWay==""){
		alert("过关方式参数有误!");
		return false;
	}
	passWay=passWay.split(",");
	for(var i=0;i<passWay.length;i++){
		if(!Reg.passArrReg.test(passWay[i])){
			alert("过关方式参数有误,不能有"+passWay[i]);
			return false;
		}
	}
	var ta=parseInt(orderForm["project.totalamount"].value,10);
	if(ta<2){
		alert("投注金额不能少于2元");
		return false;
	}
	var tc=orderForm["project.totalcount"].value;
	if(tc<1||tc!=parseInt(tc,10)){
		alert("总份数不能不于1份且必须是整数");
		return false;
	}
	tc=parseInt(orderForm["project.totalcount"].value,10);
	var tmp=ta/tc;
	if(tmp<1){
		alert("每份金额不能小于1元");
		return false;
	}
	if(ta%tc!=0){
		alert("每份金额必须为整数！");
		return false;
	}
	var promul=orderForm["project.promul"].value;
	if(promul<1||promul>100000||promul!=parseInt(promul,10)){
		alert("方案倍数必须是小于100000的正整数!");
		return false;
	}
	var rg=parseInt(orderForm["project.subscribecount"].value,10);
	if(rg>tc){
		alert("认购份数不能大于总份数");
		return false;
	}
	if(rg*1.0/tc<0.05){
		alert("方案认购不能少于5%");
		return false;
	}
	var reg=Reg.contentValidReg[orderForm["project.lotteryid"].value];
	if(!reg){
		reg=Reg.contentValidReg["36"];
	}
	var content=orderForm["detail.content"].value;
	var matchIds=orderForm["detail.matchids"].value;
	matchIds=matchIds.split(",");
	content=content.split(/[:\/]/);
	var j=0;
	for(var i=0,l=content.length;i<l;i++){
		if(i%2==0){			
			if(content[i]!=matchIds[j++]){
				alert("投注内容与所选完事不符合");
				return false;
			}
		}
	}
	return true;
}

function saleresultForms (msg){
	if(msg&&msg.m){
		msg=msg.m;
		/*msg=msg.replace(/null/g,"").split(";");*/
		if(msg=="A"){
			alert("用户余额不足!");
		}else if(msg=="B"){
			alert("出错了,请与客服联系!");
		}else{
			msg=msg.split("_");
			if(msg.length==2){
				if(lType=='rf'){
					cancelAllRf();}
				else{
					cancelAll();}
				location.href="/footlotterypartner/"+msg[0]+"/detail.shtml";
//				location.href="/jczq/fa-"+msg[0]+"/";
			}else{
				alert(msg);
			}
		}
	}else if (typeof msg == 'string'){
		if(msg.indexOf("登录")!=-1){
			alert("登录失效,请重新登录!!");
			return; 
		}else if(msg.indexOf("完善")!=-1){
//			alert("请先完善个人资料!!");
			LoginStatus.userinfoPopValidation();
			return;
		}
	}
}

function resultForm(msg){
	if(msg&&msg.m){
		msg=msg.m;
		/*msg=msg.replace(/null/g,"").split(";");*/
		if(msg=="A"){
			alert("用户余额不足!");
		}else if(msg=="B"){
			alert("出错了,请与客服联系!");
		}else{
			msg=msg.split("_");
			if(msg.length==2){
				if(lType=='rf')
					cancelAllRf();
				else
					cancelAll();
				if(project.projecttype=='0'){
					tipsWindown('来自彩票直通车的消息！','id:successdivz',233,130,true,'',true,'');
					$("#windown-content").find("#pNo").text(msg[1]);
					$("#windown-content").find(".nou_tab1input3:eq(0)").unbind("click").bind("click",function(){
						location.href="/footlotterypartner/"+msg[0]+"/detail.shtml";
//						location.href="/jczq/fa-"+msg[0]+"/";
					});
				}else{
					tipsWindown('来自彩票直通车的消息！','id:successdivh',233,130,true,'',true,'');
					$("#windown-content").find("#pNo").text(msg[1]);
					$("#windown-content").find(".nou_tab1input3:eq(0)").unbind("click").bind("click",function(){
						location.href="/footlotterypartner/"+msg[0]+"/detail.shtml";
//						location.href="/jczq/fa-"+msg[0]+"/";
					});
				}
			}else{
				alert(msg);
			}
		}
	}else if (typeof msg == 'string'){
		if(msg.indexOf("登录")!=-1){
			alert("登录失效,请重新登录!!");
			return;
		}else if(msg.indexOf("完善")!=-1){
//			alert("请先完善个人资料!!");
			LoginStatus.userinfoPopValidation();
			return;
		}
	}
}
function resultsaleForm(msg){
	if(msg&&msg.m){
		msg=msg.m;
		/*msg=msg.replace(/null/g,"").split(";");*/
		if(msg=="A"){
			alert("用户余额不足!");
		}else if(msg=="B"){
			alert("出错了,请与客服联系!");
		}else{
			msg=msg.split("_");
			if(msg.length==2){
				if(lType=='rf')
					cancelAllRf();
				else
					cancelAll();
					tipsWindown('来自彩票直通车的消息！','id:successdivzsale',233,130,true,'',true,'');
					$("#windown-content").find("#pNo").text(msg[1]);
					$("#windown-content").find(".nou_tab1input3:eq(0)").unbind("click").bind("click",function(){
						location.href="/footlotterypartner/"+msg[0]+"/detail.shtml";
//						location.href="/jczq/fa-"+msg[0]+"/";
					});
			}else{
				alert(msg);
			}
		}
	}else if (typeof msg == 'string'){
		if(msg.indexOf("登录")!=-1){
			alert("登录失效,请重新登录!!");
			return;
		}else if(msg.indexOf("完善")!=-1){
//			alert("请先完善个人资料!!");
			LoginStatus.userinfoPopValidation();
			return;
		}
	}
}
	//过滤的一些功能
   function FilterClass(){
	    //过滤检查
		this.before = function(){
			return before("filterBuy");
		};
		//初式化数据
		this.initData = function(){
			project.projecttype=0;
			project.lotteryid=lid[lType];
			project.passway=getPassWay(false,0);
			project.totalamount=moneyJq.text();
			project.projectbets=betCountJq.text();
			project.promul=multipleJq.val();
			project.isDg=(isDg?1:0);
			project.totalcount=project.subscribecount=1;
			project.percent=project.minimumcount=0;
			project.openstatus=4;
			project.detail.content=getContent();
			project.detail.dan=getDan();
			project.detail.danCount=project.detail.dan==""?0:project.detail.dan.split(",").length;
			project.detail.matchids=getMatchIds();
		};
		//初始化表单
		this.initForm = function(){
			initForm();
		};
		//检验form是否符合过滤条件
		this.checkForm = function(){
			checkForm();
		};
		this.submit = function(){
			$("form[name='orderForm']").submit();
		};
	}
function reProject(msg){
	msg=msg.replace(/null/g,"").split(";");
	project.projecttype=msg[0];
	project.passtype=msg[1];
	project.passway=msg[2];
	project.promul=msg[6];
	project.detail.content=msg[7];
	project.detail.dan=msg[8];
	project.detail.dancount=msg[9];
	var contents=project.detail.content.split(/[:\/]/);
	for(var i=0;i<leng;i+=2){
		var opt=contents[i+1].split(",");
		matchbody.find("td[id="+contents[i]+"]").each(function(){
			var obj=$(this);
			for(var ii=0,leng=opt.length;ii<leng;ii++){
				if(obj.find("input[value="+opt[ii]+"]").length>0){
					obj.click();
				}
			}
		});
	}
	multipleJq.val(project.promul);
	var passWay=project.passway.split(",");
	for(var i=0,l=passWay.length;i<l;i++){
		passDiv.find("#p"+passWay[i]).click();
	}
	if(project.detail.dan!=""){
		var dans=project.detail.dan.split(",");
		for(var i =0,l=dans.length;i<l;i++){
			itembody.find("#i_chk_"+dans[i]).parent().parent().find("input[name=dan]").click();
		}
	}
	if(project.projecttype==1){
		if(before()){
			toggle();
			initHmData();
		}
		project.minimumcount=msg[3];
		project.openstatus=msg[4];
		project.percent=msg[5];
		project.totalcount=parseInt(msg[10],10);
		project.subscribecount=parseInt(msg[11],10);
		project.detail.followuser=msg[12];
		project.detail.projectinfo=msg[13];
		$("#b_f").val(project.totalcount).keyup();
		if(project.minimumcount>0){
			$("#b_b").attr("checked",true);
			$("#b_bf").attr("disabled",false).val(project.minimumcount);
		}
		$("#b_ms").val(project.detail.projectinfo);
		if(project.detail.followuser!=""){
			$("#b_fu").prev().click().end().val(project.detail.followuser);				
		}
		$("#b_tc").val(parseInt(project.percent,10)+"").keyup();
		$(".nou_radiohack").find("#openStatus"+project.openstatus).attr("checked",true);
		$("#b_rf").val(project.subscribecount).keyup();
	}
	alert(msg[msg.length-1]);
}


$(function(){
	//绑定预售复式发起方案按钮
	$("#saleprojectButton").click(function(){
		//添加订单表单
		if(before()&&LoginStatus.loginValidation()){
			var projectno=$("#saleprojectno").val();
			var url="/footballorder!saleupdate.shtml?issingle=1&issale=1&saleprojectno="+projectno;
			initZgData();
			initForm();
			if($("#issale").val()==1){
				$("#orderForm").attr("action",url);
			}
			checkForm()&&salecheck()&&salesubmit();
		}
	});
	//页面的id值
	id='sfgd';
	var lTyperf=id.substring(0,id.length-2);
	if(lTyperf=='rf'){
	$("#pictures1").find("img").attr("src","/etc/images/dg-01_61_59.gif");
	}
	//ajax方式设置
	$.ajaxSetup({
		async: false,
		global: false,
		type: "POST"
    });
	if(lTyperf=='dt'){//单关配页面 wulong 2012-05-29
		$("#dgmulitp").attr("checked","checked");
		$("#dgmoney").attr("checked",false);
		$("#tzmoney").attr("disabled","disabled");
		$("#tishi").hide();
		$("#tishizh").hide();
		$("#spsj").hide();
	}
	//彩票选项
	matchbody=$("#matchbody");
	//彩票已选选项
	itembody=$("#itembody");
	//如果页面有已截止的的赛事   就灰掉投注选项 add wulong 2011-8-31
	if(id=="rfdg"||id=="rfgg"){
			var ids=matchbody.find(".stop").attr("id");
			if(typeof(ids)!="undefined"){
				var id_s=ids.replace(/\D/gi,"");
				$("td[id="+id_s+"]").each(function(){
					$(this).attr("onclick","");
				});
				matchbody.find(".stop").each(function(){
					$(this).find(":input").attr("disabled","disabled");
				});
			}
	}
	if(id!="rfdg"&&id!="rfgg"){
		matchbody.find(".stop").each(function(){
			var id=$(this).attr("id");
			id=id.replace("tr","");
			$(this).find("td[id="+id+"]").attr("onclick","");
			$(this).find(":input").attr("disabled","disabled");
		});
	}
	//过关方式
	passDiv=$(".xxk4");
	
	if(id=='undefined'){
		id=$("#ids").val();
	}
	//那个竞彩页面
	var ball=$("#ball").val();
	//判断那个足球竟彩页面和单关形式
	if(!isNaN(id)){
		for(var aa in lid){
			if(lid[aa]==id){
				lType=aa;
				break;
			}
		}		
	}else{
		lType=id.substring(0,id.length-2);	
		//alert("lType="+lType);
		isDg=(id.substring(id.length-2)=="dg");
	}
	//设定多选框的个数
	if(lType=='sf'){
		maxOption=3;	maxPass=7;
		validReg=/^(\d+:([vh]((1\-5)|(6\-10)|(11\-15)|(16\-20)|(21\-25)|(26)),?){1,12}\/?)+$/;
		itempart[14]=itempart[14].replace("xuan_1","xuan_12");
	}else if(lType=='rf'){
		isSfc = true;
		maxOption=12;	maxPass=3;
		validReg=/^(\d+:([12],?){1,2}\/?)+$/;
		itempart[14]=itempart[14].replace("xuan_1","xuan_2");
		p_str='<td height="24"align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td>';
	}else if(lType=='sfc'){
		maxOption=8;	maxPass=5;
		validReg=/^(\d+:([12],?){1,2}\/?)+$/;
		itempart[14]=itempart[14].replace("xuan_1","xuan_3");
		p_str='<td height="24"align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td>';
	}else if(lType=='dxf'){
		maxOption=9;	maxPass=3;
		validReg=/^(\d+:([12],?){1,2}\/?)+$/;
		p_str='<td height="24"align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td>';
	}
	
	//如果是单关
	if(isDg){
		project.playtype=1;
		ggWay['1-1']='1-1';
		itempart[16]='</ul></div>';
		itempart[18]='</td></tr>';
		p_str='<td height="24"align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td><td align="center"class="table_x_bk">&nbsp;</td>';
	}else{//如果不是过关
		project.playtype=2;
	}
	
	//倍数
	multipleJq=$("#multipleJq");
	//输入倍数后，就计算总金额
	multipleJq.bind("keyup",function(){
		this.value=this.value.replace(/\D/,'');
		if(this.value>10000){
			this.value=10000;
		}
		if(this.value!=0||this.value!=''){
			money(betCount);
		}
	 });
	//总金额
	moneyJq=$("#moneyJq");
	//总注数
	betCountJq=$("#betCount");
	
	var leagueNames=[];
//	$('#loginForm').ajaxForm({beforeSubmit:  submitLoginForm, success:submitLoginFinish });
	$(".sizi_3").each(function(){
		var name=$(this).attr("cn");
		if($(this).parent().css("background")==""||$(this).parent().attr("style")==""){
			$(this).parent().css("background",randomColor(name));
		}
		leagueNames[name]='<option value="'+name+'">'+name+'</option>';
	});	
	for(var name in leagueNames){
		$("#league").append(leagueNames[name]);
	}
	
	//过关，单关，合买按钮事件
	$("#radio_gg").click(function(){location.href='/'+ball+'/'+lType+'gg.shtml';});
	$("#radio_dg").click(function(){location.href='/'+ball+'/'+lType+'dg.shtml';});
	$("#radio_ds").click(function(){location.href='/footballsingle/'+lType+'gg.shtml';});   //单式
	$("#radio_hm").click(function(){location.href='/footlotterypartner/'+lid[lType]+'/index.shtml';});
	$("#subnav"+lType).addClass("subnav_c");
	//发起自购
	/**
	 * wyong edit 2012-05-28
	 * 此处逻辑应该是， 1。发起方案时，验证发起人是否已经完善信息。否，弹窗显示，处理后，进入认购环节	
	 * 					2。已经完善，进入下面的认购环节。
	 * */
	
	//认购方法独立，完善后再调用，或者认购时调用
	function rengou_afterlogin(){
		if(before("selfBuy")){
			//发起自购，打开对话框
			var zg_tab=$("#zg_tab");
			if(zg_tab.length==0){
				zg_tab=$(zg);
				$("body").append(zg_tab);
				zg=null;
			}
			$("#s_money").text(moneyJq.text());
			$("#s_betCount").text(betCountJq.text());
			$("#s_mul").text(multipleJq.val());			
			$("#s_passway").html(isDg?'单关':getPassWay('<br/>',3).replace(/-/g,'串'));
			zg_tab.find(".sizi_z").text("您正在发起竞彩足球"+$.trim($(".subnav_c").text())+"自购方案");
			tipsWindown('来自彩票直通车的消息！','id:zg_tab',333,171,true,'',true,'');
		}
	}

	
	//弹窗之后需要完善资料才能发单
	$(".botoom_an").find("input:eq(0)").bind("click",function(){
		   if(LoginStatus.isLogin()){
				var ustatus = getCookie("U_I_STATUS");
				//stauts=1表示用户帐户有钱，但是资料不完善，需要填写
				if(ustatus=="1"){
				   $.getJSON(LoginStatus.loginURL+"/user/user-info-validate/ecp3/check.shtml?cookieForm=?"+"&t="+ new Date().getTime(),
					{userid:LoginStatus.getUserId()},
					function(responseText) {
					if ("0" == responseText.status) {
						 rengou_afterlogin();
					}else if ("-1" == responseText.status){
						 rengou_afterlogin();
					}else{
						$.nyroModalManual({
							width:360,
							height:205,
							minWidth:200,
							minHeight:100,
							content:LoginStatus.userinfoPopContent(responseText)
							});
							return false;
						}			    					
					});
			   }else{
				    rengou_afterlogin();
			   }
		   }else{
			   LoginStatus.showLogin();
		   }
		    // LoginStatus.loginValidation();
			
			
	}).next().bind("click",function(){
		  if(LoginStatus.isLogin()){
			  var ustatus = getCookie("U_I_STATUS");
				//stauts=1表示用户帐户有钱，但是资料不完善，需要填写
			  if(ustatus=="1"){
				$.getJSON(LoginStatus.loginURL+"/user/user-info-validate/ecp3/check.shtml?cookieForm=?"+"&t="+ new Date().getTime(),
						{userid:LoginStatus.getUserId()},
						function(responseText) {
						if ("0" == responseText.status) {
					        rengou_hemai();
						}else if ("-1" == responseText.status){
					      	rengou_hemai();
						}else{
							$.nyroModalManual({
								width:360,
								height:205,
								minWidth:200,
								minHeight:100,
								content:LoginStatus.userinfoPopContent(responseText)
								});
								return false;
							}			    					
						});
				}else{
					rengou_hemai();
				}
		}else{
			LoginStatus.showLogin();
		}
	});
	if(lType=='sf' && !isDg){
		$("#filterButton").bind("click",function(){
			 if(getMatchSize()<2){
				 alert("至少选择两场以上的比赛进行过滤投注!");
				 return;
			 } 
			if(getMatchSize()>10){
				alert("您好,过滤只支持10场比赛过滤!");
				return;
			}
			 var a = filter.rq.htmlCss.init();
			 if(!a) return ;
			 $("#issueNoId").attr("value",$("#issueNo").val());
			 $("#oldfilterType").val($("input:[name=passway][checked]").val());
			 $("#matchids").val(getMatchIds());
			 $("#lid").val($("#id").val());
			 $("#dan").val(getDan());
			 if($("input:[name=passway][checked]").size()==0){
				 $("#oldfilterType").val("");
			 }
			$("#issueNoId").attr("value",$("#issueNo").val());
			$("#filtermatchbody").attr("value",getContent()); 
			$("#passtype").val($("#xhDiv").find("input:[name=pass][checked]").val());
			$("#lotteryId").val("89");	
			$("#passtype").val($("#xhDiv").find("input:[name=pass][checked]").val());
			$("#lotteryId").val("89");	
			$("#multiForm").get(0).submit();
		});
	}
	matchbody.find(":checked[c]").each(function(){this.checked=false;});
	$("input:[name=passType]").click(function(){
		$("#minprize").text(0);
		$("#maxprize").text(0);
		$("#betCount").text(0);
		$("#moneyJq").text(0);
		betCount =0;
		passDiv.empty();
		ggWay=[];
		initPass();
	});
	$(".hand2").click(function(){
		$(this).prev().attr("checked",true);
		$("#minprize").text(0);
		$("#maxprize").text(0);
		$("#betCount").text(0);
		$("#moneyJq").text(0);
		betCount =0;
		passDiv.empty();
		ggWay=[];
		initPass();
	});
	setInterval(cpdjs,1000);
		//赛事回查相关
		$("#searchback").change(function(){
			var type=isDg?"dg":"gg";
			var url="/football/"+lType+type+".shtml?date="+$("#searchback").val();
			window.location.href=url;
		});
		$("#matchbody").find("tr").each(function(){
			var result=$(this).attr("result"); 
			$(this).find("span[c="+result+"]").addClass("sshcxs");
			
		});
		$("#zjcs").text($(".jz").length);
		$("#zjck").click(function(){
			if($("#zjck").attr("checked")){
				$(".jz").each(function(){
					$(this).removeClass("stop");
				});
			}else{
				$(".jz").each(function(){
					$(this).addClass("stop");
				});
			}
		});
		//鼠标移动更换背景颜色 
		$(".hm_table tr").mouseover(function(){$(this).addClass("demo_tab_new_bg2");}).mouseout(function(){$(this).removeClass("demo_tab_new_bg2");}); 	
		$(".hm_table tr:even").addClass("demo_tab_new_bg1");
		
		$(".dc_left table tr").mouseover(function(){$(this).addClass("s12");}).mouseout(function(){$(this).removeClass("s12");}); 
		$(".dc_left table tr:even").addClass("s11");
		
		
		$(".dc_le table tr:even").addClass("s13");
		
		$(".sf_table tr:even").addClass("th_bg");
		$(".touz_table tr:even").addClass("s13");
		
		$(".select_hide").hover(function(){
			$(".select_hide").children(".zfb_1").hide();
			$(".select_hide").children(".hide5").show();
			},function(){
			$(".select_hide").children(".zfb_1").show();
			$(".select_hide").children(".hide5").hide();
		});
		
		$(".m1").hover(function(){
			$(".m1").children(".m2").show();
			},function(){
			$(".m1").children(".m2").hide();
		});
		
		$(".m3").hover(function(){
			$(".m3").children(".mm").show();
			},function(){
			$(".m3").children(".mm").hide();
		});
		
		$(".m4").hover(function(){
			$(".m4").children(".mmm").show();
			},function(){
			$(".m4").children(".mmm").hide();
		});
		
		$(".m5").hover(function(){
			$(".m5").children(".p1").show();
			},function(){
			$(".m5").children(".p1").hide();
		});
		$(".m6").hover(function(){
			$(".m6").children(".p2").show();
			},function(){
			$(".m6").children(".p2").hide();
		});
		$(".m7").hover(function(){
			$(".m7").children(".p3").show();
			},function(){
			$(".m7").children(".p3").hide();
		});
		$(".m8").hover(function(){
			$(".m8").children(".p4").show();
			},function(){
			$(".m8").children(".p4").hide();
		});
		
		$(".public_list_l").hover(function(){
			$(this).children(".btn_gc").css("background","url(../images/hb_06.gif) no-repeat");
			$(this).children(".hide6").show();
		},function(){
			$(this).children(".btn_gc").css("background","none");
			$(this).children(".hide6").hide();
		});
		
		//竞彩推荐用
		var xx=$("#tzxx").val();
		if(/^(\d{4}\_[310]{1,3}\|?)+$/.test(xx)){
			var xxArr=xx.split("|");
			for(var i=0,len=xxArr.length;i<len;i++){
				var onexx=xxArr[i];
				var onexxArr=onexx.split("_")[1].split("");
				var allxx=$("tr[matchno='"+onexx.split("_")[0]+"']").find(".hand");
				for(var j=0,leng=onexxArr.length;j<leng;j++){
					if(onexxArr[j]=="3")
						allxx.eq(0).click()
					else if(onexxArr[j]=="1")
						allxx.eq(1).click()
					else if(onexxArr[j]=="0")
						allxx.eq(2).click()		
			    }
			}
			var passWay=$("#passWay").val();
			$("#p"+passWay.replace("_","-")).click();
			document.documentElement.scrollTop=document.body.clientHeight-300;
		}
		
		
//		$(".h_title span").each(function(e){
//		$(this).click(function(){
//			$(this).addClass("f5fafb").siblings("span").removeClass("f5fafb");
//			$(".h_tab .hide").eq(e).show().siblings(".hide").hide();
//		});
//		});
//		$(".h_title span:first").click();
//		$(".pr").hover(function(){
//			$(this).children(".hide1").show();
//		},function(){
//			$(this).children(".hide1").hide();
//		});
//		$(".regsiter2 li").each(function(e) {
//        $(this).click(function(){
//			$(this).removeClass("j2").addClass("j1").siblings("li").removeClass("j1").addClass("j2");
//			$(".content .hide").eq(e).show().siblings(".hide").hide();
//			});
//   		 });//each重复调用函数
//		$(".regsiter2 li:first").click();
});
function cpdjs(){
	if (typeof Stime != "undefined"){
		var d = new Date(Stime);
		var week = d.getDay();
		var hour = d.getHours();
		var minute = d.getMinutes();
		var second=d.getSeconds();
		var hour1=0;
		var minute1=0;
		var second1=0;
		var flag=false;
		if(week>=2&&week<=5){
			if(hour<9||(hour==23&&minute>=45)){
				flag=true;
				if(hour>22){
					  hour1=9+24-hour-1;
					  minute1=59-minute;
					  second1=59-second;
				}else{
						hour1=9-hour-1;
						minute1=59-minute;
						second1=59-second;
				}
			}
		}else if(week==6){
			if(hour<9){
				flag=true;
				hour1=9-hour-1;
				minute1=59-minute;
				second1=59-second;
			}
		}else if(week==1){
			if((hour>0&&hour<9)||(hour==23&&minute>=45)||(hour==0&&minute>=45)){
				flag=true;
				if(hour>22){
					  hour1=9+24-hour-1;
					  minute1=59-minute;
					  second1=59-second;
				}else{
						hour1=9-hour-1;
						minute1=59-minute;
						second1=59-second;
			    }
			}
		}else if(week==0){
			if((hour>0&&hour<9)||(hour==0&&minute>=45)){
				flag=true;
				hour1=9-hour-1;
				minute1=59-minute;
				second1=59-second;
			}
		}
		if(flag){
			if(minute1<10)
				minute1="0"+minute1;
			if(second1<10)
				second1="0"+second1;
			if($("#djs").length==0)
				$("#ysxg").append("<font class='cpdjst'>现已进入预售状态,离出票还剩:</font><span id='djs' class='cpdjs'></span>");
			if(parseFloat(hour1)==0&&parseFloat(minute1)==0&&parseFloat(second1)==0){
				$(".cpdjst").remove();
				$(".cpdjs").remove();
			}
			$("#djs").html(hour1+"时"+minute1+"分"+second1+"秒");
		}
	} 

}
function sd(){   //设胆禁用启用
	var dan=itembody.find(":checked[name=dan]").length;
	var teamcount=itembody.find(":checkbox[name=dan]").length;
	if(teamcount==1||dan==maxPass||dan==teamcount-1){
		itembody.find(":checkbox[name=dan]").each(function(){
			if(!this.checked){
				this.disabled=true;
			}
		});
	}else{
		itembody.find(":checkbox[name=dan]").each(function(){
			if(this.disabled){
				this.disabled=false;
			}
		});
	}
}
//窗口关闭
function closetipsWindown(){
	$("#windownbg").remove();
	$("#windown-box").fadeOut("slow",function(){$(this).remove();});
}
//发起自购
function ordersele(){
	//吴龙 2012-07-06  sp变化层隐藏
	if(document.getElementById('pop') && document.getElementById('pop').style.display!='none'){
		closeSpb();
		$('#pop').html('');
	}
	
	$("#windownbg").remove();
	$("#windown-box").remove();
	initZgData();
	initForm()&&checkForm()&&submit();
}
//赛事的截止和开赛时间 wulong 2011-12-9
function timechange1(obj){
	var time=$("#times1").val();
	if(time==1){
		$("#matchbody").find("tr[id^='tr']").each(function(){
			$(this).find("td[id='twotime']").show();
			$(this).find("td[id='onetime']").hide();
		});
	}
	else{
		$("#matchbody").find("tr[id^='tr']").each(function(){
			$(this).find("td[id='twotime']").hide();
			$(this).find("td[id='onetime']").show();
		});
	}
}
function timechange2(obj){
	var time=$("#times2").val();
	if(time==1){
		$("#matchbody").find("tr[id^='tr']").each(function(){
			$(this).find("td[id='twotime']").show();
			$(this).find("td[id='onetime']").hide();
		});
	}
	else{
		$("#matchbody").find("tr[id^='tr']").each(function(){
			$(this).find("td[id='twotime']").hide();
			$(this).find("td[id='onetime']").show();
		});
	}
}
function salecheck(){
	var moneyJq = parseInt($("#moneyJq").html());
	var mina = parseFloat($("#mina").html());
		var maxa = parseFloat($("#maxa").html());
	if(!(moneyJq>=mina&&moneyJq<=maxa)){
		alert("您的方案金额不在指定的上传区间内");
		return false;
	}
	else{
		return true;
	}
}
function MM_showHideLayers() { //v9.0
	var i,v,obj,args=MM_showHideLayers.arguments;
	for (i=0; i<(args.length-2); i+=3) 
	with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
	if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
	obj.visibility=v; }
	}


/**
 * sp值变化显示层
 * @param {Object} event
 * @param {Object} gameid
 * @return {TypeName} 
 */
function showspb(event,gameid){
		if(gameid!=null&&typeof(gameid)!='undefined'&&gameid!=''){
			var url="/football/"+gameid+"/getSpBian.shtml";
			$.ajax({
				type: "POST",
				url: url,
				dataType:"text",
				cache:false,
				success: function(msg){
					$("#pop").html("").html(msg);
				},error:function(){}
			}); 
//			var scrollwidth=$("#pop").width();
//			var scrollheight=$("#pop").height();
			var px, py; 
//	         var bodyWidth  =getDocWidth(); 
//	         var screenHeight =window.screen.height;           //屏幕分辨率的高 
//	         var screenWidth =window.screen.width;            //屏幕分辨率的宽 
	        if(!event) { 
	            event = window.event; 
	        } 
	        if(document.all) { // is ie 
	            px = event.clientX; 
	            py = event.clientY; 
	            px += document.documentElement.scrollLeft; 
	            py += document.documentElement.scrollTop; 
	        } else { 
	            px = event.pageX; 
	            py = event.pageY; 
	        } 
	        $("#pop").attr("style","top:"+(py)+"px");
			$("#pop").show();
		}else{
			alert('参数错误！');
			return;
		}
}
function getDocWidth(){return(document.documentElement 
   &&document.documentElement.scrollWidth) 
   ||(document.body&&document.body.scrollWidth)||0;} 

function closeSpb(){
	$("#pop").hide();
}









/**
 * 得到字符串的字符长度（一个汉字占两个字符长）
 */
function getBytesLength(str) {
	return str.replace(/[^\x00-\xff]/g, 'xx').length;
}

/**
 * 根据字符长来截取字符串
 */
function subStringByBytes(val, maxBytesLen) {
	var len = maxBytesLen;
	var result = val.slice(0, len);
	while(getBytesLength(result) > maxBytesLen) {
		result = result.slice(0, --len);
	} 
	return result;
}
function Hash(){
	this.length = 0;
	this.items = new Array();
	for (var i = 0; i < arguments.length; i += 2) {
		if (typeof(arguments[i + 1]) != 'undefined') {
			this.items[arguments[i]] = arguments[i + 1];
			this.length++;
		}
	};
	this.removeItem = function(in_key){
		var tmp_previous;
		if (typeof(this.items[in_key]) != 'undefined') {
			this.length--;
			var tmp_previous = this.items[in_key];
			delete this.items[in_key];
		}	   
		return tmp_previous;
	};
	this.getItem = function(in_key) {
		return this.items[in_key];
	};
	this.setItem = function(in_key, in_value){
		var tmp_previous;
		if (typeof(in_value) != 'undefined') {
			if (typeof(this.items[in_key]) == 'undefined') {
				this.length++;
			}
			else {
				tmp_previous = this.items[in_key];
			}

			this.items[in_key] = in_value;
		}
		return tmp_previous;
	};
	this.hasItem = function(in_key){
		return typeof(this.items[in_key]) != 'undefined';
	};
	this.clear = function(){
		for (var i in this.items) {
			delete this.items[i];
		}
		this.length = 0;
	};	
	this.set=this.setItem;
	this.get=this.getItem;
	this.put=this.set;	
}
/**
 * 供数组排序用，降序
 * 
 * @param {Number}
 *            x
 * @param {Number}
 *            y
 */
function desc(x, y) {
	var a = parseFloat(x);
	var b = parseFloat(y);
	if (a >= b)
		return -1;
	if (a < b)
		return 1;
}

/**
 * 供数组排序用，升序
 * 
 * @param {Number}
 *            x
 * @param {Number}
 *            y
 */
function asc(x, y) {
	var a = parseFloat(x);
	var b = parseFloat(y);
	if (a > b)
		return 1;
	if (a <= b)
		return -1;
}
function roundPrize(prize){
	if(isNaN(prize)){
		return 0;
	}else{
		return parseFloat(new Number(prize).toFixed(2));
	}	
}
function C3(n, m, callbackFn) {
	if (m < 0 || m > n) {
		return;
	}
	var bs = [];
	for ( var i = 0; i < m; i++) {
		bs[i] = true;
	}
	if (n == m) {
		callbackFn(bs, n, m);
		return;
	}
	for ( var i = m; i < n; i++) {
		bs[i] = false;
	}
	if (m == 0) {
		callbackFn(bs, n, m);
		return;
	}
	var flag = true;
	var tempFlag = false;
	var pos = 0;
	var sum = 0;
	do {
		sum = 0;
		pos = 0;
		tempFlag = true;
		callbackFn(bs, n, m);

		for ( var i = 0; i < n - 1; i++) {
			if (bs[i] == true && bs[i + 1] == false) {
				bs[i] = false;
				bs[i + 1] = true;
				pos = i;
				break;
			}
		}

		for ( var i = 0; i < pos; i++) {
			if (bs[i] == true) {
				sum++;
			}
		}
		for ( var i = 0; i < pos; i++) {
			if (i < sum) {
				bs[i] = true;
			} else {
				bs[i] = false;
			}
		}

		for ( var i = n - m; i < n; i++) {
			if (bs[i] == false) {
				tempFlag = false;
				break;
			}
		}
		if (tempFlag == false) {
			flag = true;
		} else {
			flag = false;
		}
	} while (flag);
	callbackFn(bs, n, m);
}
/**
 * 计算器 过关方式,过关类型,非胆完事选项个数数组,胆选项个数数组,模糊定胆个数1,模糊定胆个数2
 */
function myCalc(PassType, WagerType, sa, sb, b0, b1) {
    if (sb.length == 0) return calc(PassType, WagerType, sa, sb);
    else {
        var wcount = 0;
        for (var k = b0; k <= b1; k++) {
            var bm = combinArray(sb, k);
            for (var j in bm) {
                wcount += calc(PassType, WagerType, sa, bm[j]);
            }
        }
        return wcount;
    }
}
function calc(PassType, WagerType, sa, sb) {
    var WagerCount = 0;
    var t_list = PassType.split("-");
    var pc = parseInt(t_list[0], 10);
    if (WagerType == 1) {
        var AbsCount = sb.length;
        var len = pc - AbsCount;
        if (len == 0 && AbsCount > 0) {
            var pm = new Array(pc);
            for (var P in sb) {
                var AbsVoteC = sb[P];
                for (var k = 0; k < pc; k++) {
                    if (pm[k] == 0 || pm[k] == null) {
                        pm[k] = AbsVoteC;
                        break;
                    }
                }
            }
            var pstr = pm.slice(0, pc).join(",");
            eval("WagerCount += calcuteWC(PassType," + pstr + ");");
        } else {
            var arr = new Array();
            for (var I in sa) {
              arr[arr.length] = I;
            }
            var w = combinArray(arr, len);
            for (var I in w) {
                var splitArr = w[I];
                var pm = new Array(pc);
                for (var k = 0; k < pc; k++) {
                    var d = splitArr[k];
                    pm[k] = splitArr[k] != null ? sa[d] : 0;
                }
                if (AbsCount > 0) {
                    for (var P in sb) {
                        var AbsVoteC = sb[P];
                        for (var k = 0; k < pc; k++) {
                            if (pm[k] == 0 || pm[k] == null) {
                                pm[k] = AbsVoteC;
                                break;
                            }
                        }
                    }
                }
                var pstr = pm.slice(0, pc).join(",");
                eval("WagerCount += calcuteWC(PassType," + pstr + ");");
            }
        }
    } else if (WagerType == 2) {
        var t_list = PassType.split("-");
        var len = parseInt(t_list[0], 10);
        var arr = new Array();
        for (var I in sa) {
            arr[arr.length] = I;
        }
        var w = subsectionArray(arr, len);
        for (var I in w) {
            var splitArr = w[I];
            var pm = new Array(pc);
            for (var k = 0; k < pc; k++) {
                var d = splitArr[k];
                pm[k] = splitArr[k] != null ? sa[d] : 0;
            }
            var pstr = pm.slice(0, pc).join(",");
            eval("WagerCount += calcuteWC(PassType," + pstr + ");");
        }
    }
    return WagerCount;
}
function combinArray(arr, len) {
    var Re = new Array();
    arr.sort(asc);
    if (arr.length < len || len < 1) {
        return Re;
    } else if (arr.length == len) {
        Re[0] = arr;
        return Re;
    }
    if (len == 1) {
        for (var I in arr) {
            Re[I] = new Array();
            Re[I][0] = arr[I];
        }
        return Re;
    }
    if (len > 1) {
        for (var I in arr) {
            var arr_b = new Array();
            for (var J in arr) {
                if (J > I) arr_b[arr_b.length] = arr[J];
            }
            var s = combinArray(arr_b, len - 1);
            if (s.length > 0) {
                for (var K in s) {
                    var p = s[K];
                    p[p.length] = arr[I];
                    p.sort(asc);
                    Re[Re.length] = p;
                }
            }
        }
    }
    return Re;
}
function subsectionArray(arr, len) {
    var Re = new Array();
    if (arr.length < len || len < 1) {
        return Re;
    } else if (arr.length == len) {
        Re[0] = arr;
        return Re;
    }
    if (len == 1) {
        for (var I in arr) {
            Re[I] = new Array();
            Re[I][0] = arr[I];
        }
        return Re;
    }
    if (len > 1) {
        var st = 0;
        var end = len - 1;
        var suitC = Math.ceil(arr.length / len);
        for (var I = 0; I < suitC; I++) {
            var a = new Array();
            var sid = I * len;
            var eid = (I + 1) * len - 1;
            if (sid < arr.length) {
                if (eid >= arr.length) {
                    eid = arr.length - 1;
                    sid = arr.length - len;
                }
                for (var J = sid; J <= eid; J++) {
                    a[a.length] = arr[J];
                }
                Re[Re.length] = a;
            }
        }
    }
    return Re;
}
function calcuteWC(passtype, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o) {
    var re = 0;
    a = a == null ? 0 : parseInt(a, 10);
    b = b == null ? 0 : parseInt(b, 10);
    c = c == null ? 0 : parseInt(c, 10);
    d = d == null ? 0 : parseInt(d, 10);
    e = e == null ? 0 : parseInt(e, 10);
    f = f == null ? 0 : parseInt(f, 10);
    g = g == null ? 0 : parseInt(g, 10);
    h = h == null ? 0 : parseInt(h, 10);
    i = i == null ? 0 : parseInt(i, 10);
    j = j == null ? 0 : parseInt(j, 10);
    k = k == null ? 0 : parseInt(k, 10);
    l = l == null ? 0 : parseInt(l, 10);
    m = m == null ? 0 : parseInt(m, 10);
    n = n == null ? 0 : parseInt(n, 10);
    o = o == null ? 0 : parseInt(o, 10);
    switch (passtype) {
    case "1-1":
        re = a;
        break;
    case "2-1":
        re = a * b;
        break;
    case "2-3":
        re = (a + 1) * (b + 1) - 1;
        break;
    case "3-1":
        re = a * b * c;
        break;
    case "3-3":
        re = a * b + a * c + b * c;
        break;
    case "3-4":
        re = a * b * c + a * b + a * c + b * c;
        break;
    case "3-7":
        re = (a + 1) * (b + 1) * (c + 1) - 1;
        break;
    case "4-1":
        re = a * b * c * d;
        break;
    case "4-4":
        re = a * b * c + a * b * d + a * c * d + b * c * d;
        break;
    case "4-5":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) - (a * (b + c + d + 1) + b * (c + d + 1) + (c + 1) * (d + 1));
        break;
    case "4-6":
        re = a * b + a * c + a * d + b * c + b * d + c * d;
        break;
    case "4-11":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) - (a + b + c + d + 1);
        break;
    case "4-15":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) - 1;
        break;
    case "5-1":
        re = a * b * c * d * e;
        break;
    case "5-5":
        re = a * b * c * d + a * b * c * e + a * b * d * e + a * c * d * e + b * c * d * e;
        break;
    case "5-6":
        re = a * b * c * d * e + a * b * c * d + a * b * c * e + a * b * d * e + a * c * d * e + b * c * d * e;
        break;
    case "5-10":
        re = a * b + a * c + a * d + a * e + b * c + b * d + b * e + c * d + c * e + d * e;
        break;
    case "5-16":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) - (a * (b + c + d + e + 1) + b * (c + d + e + 1) + c * (d + e + 1) + (d + 1) * (e + 1));
        break;
    case "5-20":
        re = a * b * c + a * b * d + a * b * e + a * c * d + a * c * e + a * d * e + b * c * d + b * c * e + b * d * e + c * d * e + a * b + a * c + a * d + a * e + b * c + b * d + b * e + c * d + c * e + d * e;
        break;
    case "5-26":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) - (a + b + c + d + e + 1);
        break;
    case "5-31":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) - 1;
        break;
    case "6-1":
        re = a * b * c * d * e * f;
        break;
    case "6-6":
        re = a * b * c * d * e + a * b * c * d * f + a * b * c * e * f + a * b * d * e * f + a * c * d * e * f + b * c * d * e * f;
        break;
    case "6-7":
        re = a * b * c * d * e * f + a * b * c * d * e + a * b * c * d * f + a * b * c * e * f + a * b * d * e * f + a * c * d * e * f + b * c * d * e * f;
        break;
    case "6-15":
        re = a * b + a * c + a * d + a * e + a * f + b * c + b * d + b * e + b * f + c * d + c * e + c * f + d * e + d * f + e * f;
        break;
    case "6-20":
        re = a * b * c + a * b * d + a * b * e + a * b * f + a * c * d + a * c * e + a * c * f + a * d * e + a * d * f + a * e * f + b * c * d + b * c * e + b * c * f + b * d * e + b * d * f + b * e * f + c * d * e + c * d * f + c * e * f + d * e * f;
        break;
    case "6-22":
        re = a * b * c * d * e * f + a * b * c * d * e + a * b * c * d * f + a * b * c * e * f + a * b * d * e * f + a * c * d * e * f + b * c * d * e * f + a * b * c * d + a * b * c * e + a * b * c * f + a * b * d * e + a * b * d * f + a * b * e * f + a * c * d * e + a * c * d * f + a * c * e * f + a * d * e * f + b * c * d * e + b * c * d * f + b * c * e * f + b * d * e * f + c * d * e * f;
        break;
    case "6-35":
        re = a * b * c + a * b * d + a * b * e + a * b * f + a * c * d + a * c * e + a * c * f + a * d * e + a * d * f + a * e * f + b * c * d + b * c * e + b * c * f + b * d * e + b * d * f + b * e * f + c * d * e + c * d * f + c * e * f + d * e * f + a * b + a * c + a * d + a * e + a * f + b * c + b * d + b * e + b * f + c * d + c * e + c * f + d * e + d * f + e * f;
        break;
    case "6-42":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) * (f + 1) - (a * (b + c + d + e + f + 1) + b * (c + d + e + f + 1) + c * (d + e + f + 1) + d * (e + f + 1) + (e + 1) * (f + 1));
        break;
    case "6-50":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) * (f + 1) - (a + b + c + d + e + f + 1) - (a * b * c * d * e + a * b * c * d * f + a * b * c * e * f + a * b * d * e * f + a * c * d * e * f + b * c * d * e * f + a * b * c * d * e * f);
        break;
    case "6-57":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) * (f + 1) - (a + b + c + d + e + f + 1);
        break;
    case "6-63":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) * (f + 1) - 1;
        break;
    case "7-1":
        re = a * b * c * d * e * f * g;
        break;
    case "7-7":
        re = a * b * c * d * e * f + a * b * c * d * e * g + a * b * c * d * f * g + a * b * c * e * f * g + a * b * d * e * f * g + a * c * d * e * f * g + b * c * d * e * f * g;
        break;
    case "7-8":
        re = a * b * c * d * e * f * g + a * b * c * d * e * f + a * b * c * d * e * g + a * b * c * d * f * g + a * b * c * e * f * g + a * b * d * e * f * g + a * c * d * e * f * g + b * c * d * e * f * g;
        break;
    case "7-21":
        re = a * b * c * d * e + a * b * c * d * f + a * b * c * d * g + a * b * c * e * f + a * b * c * e * g + a * b * c * f * g + a * b * d * e * f + a * b * d * e * g + a * b * d * f * g + a * b * e * f * g + a * c * d * e * f + a * c * d * e * g + a * c * d * f * g + a * c * e * f * g + a * d * e * f * g + b * c * d * e * f + b * c * d * e * g + b * c * d * f * g + b * c * e * f * g + b * d * e * f * g + c * d * e * f * g;
        break;
    case "7-35":
        re = a * b * c * d + a * b * c * e + a * b * c * f + a * b * c * g + a * b * d * e + a * b * d * f + a * b * d * g + a * b * e * f + a * b * e * g + a * b * f * g + a * c * d * e + a * c * d * f + a * c * d * g + a * c * e * f + a * c * e * g + a * c * f * g + a * d * e * f + a * d * e * g + a * d * f * g + a * e * f * g + b * c * d * e + b * c * d * f + b * c * d * g + b * c * e * f + b * c * e * g + b * c * f * g + b * d * e * f + b * d * e * g + b * d * f * g + b * e * f * g + c * d * e * f + c * d * e * g + c * d * f * g + c * e * f * g + d * e * f * g;
        break;
    case "7-120":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) * (f + 1) * (g + 1) - (a + b + c + d + e + f + g + 1);
        break;
    case "8-1":
        re = a * b * c * d * e * f * g * h;
        break;
    case "8-8":
        re = a * b * c * d * e * f * g + a * b * c * d * e * f * h + a * b * c * d * e * g * h + a * b * c * d * f * g * h + a * b * c * e * f * g * h + a * b * d * e * f * g * h + a * c * d * e * f * g * h + b * c * d * e * f * g * h;
        break;
    case "8-9":
        re = a * b * c * d * e * f * g * h + a * b * c * d * e * f * g + a * b * c * d * e * f * h + a * b * c * d * e * g * h + a * b * c * d * f * g * h + a * b * c * e * f * g * h + a * b * d * e * f * g * h + a * c * d * e * f * g * h + b * c * d * e * f * g * h;
        break;
    case "8-28":
        re = a * b * c * d * e * f + a * b * c * d * e * g + a * b * c * d * e * h + a * b * c * d * f * g + a * b * c * d * f * h + a * b * c * d * g * h + a * b * c * e * f * g + a * b * c * e * f * h + a * b * c * e * g * h + a * b * c * f * g * h + a * b * d * e * f * g + a * b * d * e * f * h + a * b * d * e * g * h + a * b * d * f * g * h + a * b * e * f * g * h + a * c * d * e * f * g + a * c * d * e * f * h + a * c * d * e * g * h + a * c * d * f * g * h + a * c * e * f * g * h + a * d * e * f * g * h + b * c * d * e * f * g + b * c * d * e * f * h + b * c * d * e * g * h + b * c * d * f * g * h + b * c * e * f * g * h + b * d * e * f * g * h + c * d * e * f * g * h;
        break;
    case "8-56":
        re = a * b * c * d * e + a * b * c * d * f + a * b * c * d * g + a * b * c * d * h + a * b * c * e * f + a * b * c * e * g + a * b * c * e * h + a * b * c * f * g + a * b * c * f * h + a * b * c * g * h + a * b * d * e * f + a * b * d * e * g + a * b * d * e * h + a * b * d * f * g + a * b * d * f * h + a * b * d * g * h + a * b * e * f * g + a * b * e * f * h + a * b * e * g * h + a * b * f * g * h + a * c * d * e * f + a * c * d * e * g + a * c * d * e * h + a * c * d * f * g + a * c * d * f * h + a * c * d * g * h + a * c * e * f * g + a * c * e * f * h + a * c * e * g * h + a * c * f * g * h + a * d * e * f * g + a * d * e * f * h + a * d * e * g * h + a * d * f * g * h + a * e * f * g * h + b * c * d * e * f + b * c * d * e * g + b * c * d * e * h + b * c * d * f * g + b * c * d * f * h + b * c * d * g * h + b * c * e * f * g + b * c * e * f * h + b * c * e * g * h + b * c * f * g * h + b * d * e * f * g + b * d * e * f * h + b * d * e * g * h + b * d * f * g * h + b * e * f * g * h + c * d * e * f * g + c * d * e * f * h + c * d * e * g * h + c * d * f * g * h + c * e * f * g * h + d * e * f * g * h;
        break;
    case "8-70":
        re = a * b * c * d + a * b * c * e + a * b * c * f + a * b * c * g + a * b * c * h + a * b * d * e + a * b * d * f + a * b * d * g + a * b * d * h + a * b * e * f + a * b * e * g + a * b * e * h + a * b * f * g + a * b * f * h + a * b * g * h + a * c * d * e + a * c * d * f + a * c * d * g + a * c * d * h + a * c * e * f + a * c * e * g + a * c * e * h + a * c * f * g + a * c * f * h + a * c * g * h + a * d * e * f + a * d * e * g + a * d * e * h + a * d * f * g + a * d * f * h + a * d * g * h + a * e * f * g + a * e * f * h + a * e * g * h + a * f * g * h + b * c * d * e + b * c * d * f + b * c * d * g + b * c * d * h + b * c * e * f + b * c * e * g + b * c * e * h + b * c * f * g + b * c * f * h + b * c * g * h + b * d * e * f + b * d * e * g + b * d * e * h + b * d * f * g + b * d * f * h + b * d * g * h + b * e * f * g + b * e * f * h + b * e * g * h + b * f * g * h + c * d * e * f + c * d * e * g + c * d * e * h + c * d * f * g + c * d * f * h + c * d * g * h + c * e * f * g + c * e * f * h + c * e * g * h + c * f * g * h + d * e * f * g + d * e * f * h + d * e * g * h + d * f * g * h + e * f * g * h;
        break;
    case "8-247":
        re = (a + 1) * (b + 1) * (c + 1) * (d + 1) * (e + 1) * (f + 1) * (g + 1) * (h + 1) - (a + b + c + d + e + f + g + h + 1);
        break;
    case "9-1":
        re = a * b * c * d * e * f * g * h * i;
        break;
    case "10-1":
        re = a * b * c * d * e * f * g * h * i * j;
        break;
    case "11-1":
        re = a * b * c * d * e * f * g * h * i * j * k;
        break;
    case "12-1":
        re = a * b * c * d * e * f * g * h * i * j * k * l;
        break;
    case "13-1":
        re = a * b * c * d * e * f * g * h * i * j * k * l * m;
        break;
    case "14-1":
        re = a * b * c * d * e * f * g * h * i * j * k * l * m * n;
        break;
    case "15-1":
        re = a * b * c * d * e * f * g * h * i * j * k * l * m * n * o;
        break;
    default:
        break;
    }
    return re;
}
function getPassWay(b,c){
	var g=[],i=0;
	for(var gg in ggWay ){
		if(b){
			if(i%c==0&&i!=0){
				gg=b+gg;
			}
			i++;
		}
		g.push(gg);
	}
	g.sort(function(a,b){
		a=a.split("-");
		b=b.split("-");
		if(a[0]==b[0]){
			return a[1]-b[1];
		}else{
			return a[0]-b[0];
		}
	});
	return g.join(',');
}
function getContent(){
	var d=[];
	for(var no in matchIds){
		d.push(no+":"+matchIds[no]);
	}
	return (d.join("/"));
}
function getMatchIds(){
	var d=[];
	for(var no in matchIds){
		d.push(no);
	}
	return d.join(",");
}
function getDan(){
	var d=[];
	for(var no in danNO){
		d.push(no);
	}
	return d.join(",");
}
function getSp(){
	var sp=[];
	for(var no in spArr){
		sp.push(spArr[no].join(","));
	}
	return sp.join("/");
}
var id,lType,mulpe=1,matchbody,itembody,passbody,itemArr=[],g_rangqiu = false; g_rangqiuHiddenArray = [],optArr=[],danNO=[],ggWay='',matchIds=[],spArr='',bgcolor=["#f9f9f9","#f2f2f2"];

/*******************************hun he************************************/
var newCArry=[] , NumSpArray=[] , combin=[] ,bsTemp = 0 ,newArrbin = [],newKa=[],OverArry = [];

function reconBonus(arr,type,mcnType,danmaArr,mcn){
	OverArry = [];
	var bonus = 0;
	startRecon(arr,type,mcnType,danmaArr,mcn);
	/*var dyArr = [];
	for(var s=0;s<arr.length;s++)
	{
		dyArr.push(arr[s][arr[s].length-1]);
	}
	startRecon(dyArr,type,mcnType,danmaArr,mcn);
	*/
	for(var i=0;i<OverArry.length;i++){
		var oneBonAr = OverArry[i].substring(0,OverArry[i].length-1).split('-');
		var bus = 1;
		for(var s=0;s<oneBonAr.length;s++)
		{
			var bons = oneBonAr[s].split(':');
			bus *= parseFloat(bons[2]);
		}
		bonus += bus * 2;
	}
	return parseFloat(bonus).toFixed(2);
}
function dgRecon(arr,mcn,danmaArr){
	var newdgAr= [];
	var toArrNewObj = [];
	for(var m=0;m<arr.length;m++)
	{
		toArrNewObj.push(arr[m]);
		if(toArrNewObj[m].length>1){
			try{
				toArrNewObj[m] = toArrNewObj[m].join(',').replace(/[,]/g,'=');
			}catch(e){
				//exception e , this toArrNewObj[m] length is 1 
			}
		}
	}
	myfind(new Array(),toArrNewObj,mcn);
	for(var i=0;i<newCArry.length;i++)
	{
		if(newCArry[i].indexOf('=')!=-1){
			var toArr= newCArry[i].split(',');
			var lstoAr = [];
			for(var s=0;s<toArr.length;s++){
				lstoAr.push(toArr[s].split('='));
			}
			var newchangeAr = doExchange(lstoAr);
			for(var j=0;j<newchangeAr.length;j++){
				if(danmaArr.length>0){
					var dcFlat = true;
					for(var g=0;g<danmaArr.length;g++){
						if(newchangeAr[j].indexOf(danmaArr[g])==-1){
							dcFlat=false;
							break;
						}
					}
					if(dcFlat){
						newdgAr.push(newchangeAr[j]);
					}
				}else{
					newdgAr.push(newchangeAr[j]);
				}
				//newdgAr.push(newchangeAr[j]);
			}
		}else{
			newdgAr.push(newCArry[i]);
		}
	}
	return newdgAr;
}
function startRecon(arr,type,mcnType,danmaArr,mcn){

	var types = type.split(',');
	newCArry = [];
	var oneAr;
	if(mcnType==1){
		oneAr = dgRecon(arr,mcn,danmaArr);
	}
	for(var k=0;k<types.length;k++){
		if(mcnType==1){
			for(var i=0;i<oneAr.length;i++)
			{  
				var twoAr = oneAr[i].substring(0,oneAr[i].length-1).split('~');
				newCArry=[];
				myfind(new Array(),twoAr,types[k]);
				for(var s=0;s<newCArry.length;s++){
					var threeAr = newCArry[s].split(',');
					if(newCArry[s].indexOf('/')!=-1){
						var thrnewAr = [];
						for(var d=0;d<threeAr.length;d++){
							thrnewAr.push(threeAr[d].split('/'));
						}
						var fourAr = doExchange(thrnewAr);
						for(var l=0;l<fourAr.length;l++){
							OverArry.push(fourAr[l]);
						}
					}else{
						OverArry.push(newCArry[s].replace(/[,]/g,''));
					}
				}
				
			}
		}else{
			var fiveAr=[];
			for(var y=0;y<arr.length;y++){
				var lsstr = '';
				try{
					var arryAr = arr[y].split(',');
					for(var g=0;g<arryAr.length;g++){
						lsstr+=arryAr[g];
					}
				}catch(e){
					for(var g=0;g<arr[y].length;g++){
						lsstr+=arr[y][g];
					}
				}
				lsstr = lsstr.replace(/[/]/g,'~');
				fiveAr.push(lsstr.substring(0,lsstr.length-1));
			}
			
			myfind(new Array(),fiveAr,types[k]);
			var cabArr = newCArry;
			for(var e=0;e<cabArr.length;e++){
				var dyArr = cabArr[e].split(',');

					var newsiteArr = [];
					for(var r=0;r<dyArr.length;r++){
						newsiteArr.push(dyArr[r].split('~'));
					}
					var nstArr = doExchange(newsiteArr);
					for(var w=0;w<nstArr.length;w++){
						if(danmaArr.length>0){
							var flagDan = true;
							for(var u=0;u<danmaArr.length;u++){
								if(nstArr[w].indexOf(danmaArr[u])==-1){
									flagDan=false;
									break;
								}
							}
							if(flagDan){
								OverArry.push(nstArr[w]);
							}
						}else{
							OverArry.push(nstArr[w]);
						}
					}
			}
		}
	}
}
function doExchange(doubleArrays){ 
	var len=doubleArrays.length; 
	if(len>=2){ 
		var len1=doubleArrays[0].length; 
		var len2=doubleArrays[1].length; 
		var newlen=len1*len2; 
		var temp=new Array(newlen); 
		var index=0; 
		for(var i=0;i<len1;i++){
			for(var j=0;j<len2;j++){
				temp[index]=doubleArrays[0][i]+doubleArrays[1][j];
				index++;
			}
		}
		var newArray=new Array(len-1);
		for(var i=2;i<len;i++){
			newArray[i-1]=doubleArrays[i];
		}
		newArray[0]=temp;
		return doExchange(newArray);
	}
	else{
		return doubleArrays[0];
	}
}
	
	
function myfind(has, other, n) {
	if (n == 0) {
		newCArry.push(has.join(","));
		return;
	}
	if (other.length < n) {
		return;
	}
	var one = other.shift();
	var newhas = has.concat();
	var newother = other.concat();
	has.push(one);
	myfind(has, other, n-1);
	myfind(newhas, newother, n);
	return has;
}

function yh_Main(msr,ctype){
	if(ctype > msr.length){
		return;
	}
	NumSpArray=[];
	myfind(new Array(),msr.split(","),ctype);
	for(var p=0;p<newCArry.length;p++){
		var ar = newCArry[p].split(",");
		var tempArrone=[];
		for(var j=0;j<ar.length;j++){
			var arj = ar[j].split("|");
			var arjk = [];
			if(arj.length>1){
				for(var k=0;k<arj.length;k++){
					arjk.push(arj[k]);
				}
				tempArrone.push(arjk);
			}else{
				tempArrone.push(arj[0].split("$_"));
			}
		}
		NumSpArray.push(tempArrone);
	}
}
	
function doCombin(arr,pr){
	var bs = pr / 2;
	var retOne=arr;
	var comAry=[];
	for(var b=0;b<retOne.length;b++){
		var ret = retOne[b].ret;
		for(var l=0;l<ret.length;l++){
			var retFlat = true;
			if(dan_GG.length>0){
				for(var j=0;j<dan_GG.length;j++){
					if(ret[l].indexOf(dan_GG[j])==-1){
						retFlat = false;
					}
				}
			}
			if(retFlat){
				var rt = ret[l].substring(0,ret[l].length-1);
				rt = rt.split("~");
				var ArrStrNum = "" ,ArrSp="",ArrXh="";var m=1,lotname="",dantuo="";
				for(var v=0;v<rt.length;v++){
					var rtv = rt[v].split(":");
					lotname=rtv[0];
					dantuo=rtv[4];
					ArrStrNum += rtv[1]+",";
					ArrSp     += rtv[2]+",";
					ArrXh	  += rtv[3]+",";
					m = m * parseFloat(rtv[2]);
				}
				ArrSp = ArrSp.substring(0,ArrSp.length-1);
				ArrStrNum = ArrStrNum.substring(0,ArrStrNum.length-1);
				ArrXh = ArrXh.substring(0,ArrXh.length-1);
				m = parseFloat(m * 2).toFixed(2);
				comAry.push({"ArrSp":ArrSp,"ArrStrNum":ArrStrNum,"m":m,"s":l,"z":1,"csm":m,"ArrXh":ArrXh,"lotname":lotname,"dantuo":dantuo});
			}
		
		}
	}
	binCommet(comAry,pr/2-comAry.length);
}

function binCommet(arrbin,pr){
	var radioVal = $('.xuanz').val(),countMoney = parseInt($('.srmn').val());
	var ka = [];
	var hhspArr= [];
	for(var l =0; l < arrbin.length; l++)
	{
		hhspArr.push(arrbin[l].csm);
	}
	hhspArr.sort(function(a,b){return a-b});
	if(pr > 0){
		arrbin.sort(function(a,b){return a.csm-b.csm});
		if(radioVal=='p'){
			ka = prizeOptimize(countMoney,spArr);
		}else if(radioVal=='r'){
			ka = benOptimize(countMoney,spArr);
		}else if(radioVal=='l'){
			ka = coolOptimize(countMoney,spArr);
		}
		yh_showHTML(arrbin,ka);
	}else{
		for(var j=0;j<hhspArr.length;j++){
	     	ka[ka.length] = 1;
		 }
		yh_showHTML(arrbin,ka);
	}
}

function yh_showHTML(arrbinObj,ka){
	arrbinObj.sort(function(a,b){return a.csm-b.csm});
	newArrbin = arrbinObj;
	newKa = ka;
	var tr="";
	var max = [];
	var zhushu = 0;
}

function zuMax(arr){
	var zu = 0;
	var zumax=[];
	for(var i =0;i<arr.length;i++)
	{
		zu+=arr[i].z;
		zumax.push(arr[i].m);
	}
	zumax.sort(function(a,b){return b-a});
	return zu+","+zumax[0];
}
var dan_GG = [];
function yh_MainLoad(msr,ctype,price){
	var numberPush = [];bsTemp = 0 , combin=[] ,newCArry=[],dan_GG = [];
	var type = ctype.split(",");
	for(var j=0;j<type.length;j++){
		yh_Main(msr,parseInt(type[j]));
	}
	if(NumSpArray[0]){
		for(var u=0;u<NumSpArray.length;u++){
			numberPush.push({"c":NumSpArray[u].length,"ret":doExchange(NumSpArray[u])});
		}
		for(var d=0;d<NumSpArray[0].length;d++)
		{
			var nspa = NumSpArray[0][d][0].substring(0,NumSpArray[0][d][0].length-1);
			var newpsa = nspa.split(":");
			if(newpsa[4]=='1'){
				dan_GG.push(newpsa[3]);
			}
		}
	}
	doCombin(numberPush,price);
}

function lanqiu_ys(arr,v){
	var sfar = arr['505'],rfsfar=arr['506'],sfcar=arr['507'],dxfar=arr['508'];

	var ysArr=[],sfArr=[],rfsfArr=[],sfcArr=[],dxfArr=[];
	if(v==1){
		if(sfar){
			if(sfar['1'])sfArr.push({'gn':'505','brouns':sfar['1'],'val':'1'});
		}
		if(rfsfar){
			if(rfsfar['1D'])rfsfArr.push({'gn':'506','brouns':rfsfar['1D'],'val':'1D'});
		}
		if(sfcar){
			for(var sfc in sfcar){
				if(parseInt(sfc)>=51 && parseInt(sfc)<=56){
					sfcArr.push({'gn':'507','brouns':sfcar[sfc],'val':sfc});
				}
			}
			if(sfcArr.length>0)sfcArr.sort(function(a,b){return a.brouns - b.brouns});
		}
		if(dxfar){
			for(var dxf in dxfar){
				if(dxfar[dxf])dxfArr.push({'gn':'508','brouns':dxfar[dxf],'val':dxf});
			}
			if(dxfArr.length>0)dxfArr.sort(function(a,b){return a.brouns - b.brouns});
		}
	}else if(v==0){
		if(sfar){
			if(sfar['0'])sfArr.push({'gn':'505','brouns':sfar['0'],'val':'0'});
		}
		if(rfsfar){
			if(rfsfar['0D'])rfsfArr.push({'gn':'506','brouns':rfsfar['0D'],'val':'0D'});
		}
		if(sfcar){
			for(var sfc in sfcar){
				if(parseInt(sfc)>=01 && parseInt(sfc)<=06){
					sfcArr.push({'gn':'507','brouns':sfcar[sfc],'val':sfc});
				}
			}
			if(sfcArr.length>0)sfcArr.sort(function(a,b){return a.brouns - b.brouns});
		}
		if(dxfar){
			for(var dxf in dxfar){
				if(dxfar[dxf])dxfArr.push({'gn':'508','brouns':dxfar[dxf],'val':dxf});
			}
		}
	}
	
	if(sfArr.length>0) ysArr.push(sfArr[sfArr.length-1]);
	if(rfsfArr.length>0) ysArr.push(rfsfArr[rfsfArr.length-1]);
	if(sfcArr.length>0) ysArr.push(sfcArr[sfcArr.length-1]);
	if(dxfArr.length>0) ysArr.push(dxfArr[dxfArr.length-1]);
	
	return ysArr;
}
function lq_ys_main(arr){
	var homeWin = lanqiu_ys(arr,1);
	var draw = lanqiu_ys(arr,0);
	var MxMiMo = [];
	if(homeWin.length>=1)MxMiMo.push({'bz':homeWin,'cm':forCalculated(homeWin)});
	if(draw.length>=1)MxMiMo.push({'bz':draw,'cm':forCalculated(draw)});
	MxMiMo.sort(function(a,b){return a.cm - b.cm});
	var maxObj = MxMiMo[MxMiMo.length-1].bz;
	var minObj = MxMiMo[0].bz;
	return {'max':maxObj,'min':minObj};
}
function yusuanMain(arr,rq){
		if(rq>0)rq='+'+rq;
			var sobj = yusuan(arr,3,rq);
			var pobj = yusuan(arr,1,rq);
			var fobj = yusuan(arr,0,rq);
			var MxMiMo = [];
			if(sobj.length>=1)MxMiMo.push({'bz':sobj,'cm':forCalculated(sobj)});
			if(pobj.length>=1)MxMiMo.push({'bz':pobj,'cm':forCalculated(pobj)});
			if(fobj.length>=1)MxMiMo.push({'bz':fobj,'cm':forCalculated(fobj)});
			MxMiMo.sort(function(a,b){return a.cm - b.cm});
			var maxObj=0;
			//alert("---"+MxMiMo.length);
			if(MxMiMo.length>=1){
			    maxObj = MxMiMo[MxMiMo.length-1].bz;
			}else{
				maxobj=100;
				minObj=50;
			}
			var minObj =0;
			if(MxMiMo[0]!=null){
			    minObj = MxMiMo[0].bz;
			}else{
				maxobj=100;
				minObj=50;
			}
			return {'max':maxObj,'min':minObj};
			
}
function bdyusuanMain(arr,rq){
		if(rq>0)rq='+'+rq;
			var sobj = bdyusuan(arr,3,rq);
			var pobj = bdyusuan(arr,1,rq);
			var fobj = bdyusuan(arr,0,rq);
			var MxMiMo = [];
			if(sobj.length>=1)MxMiMo.push({'bz':sobj,'cm':forCalculated(sobj)});
			if(pobj.length>=1)MxMiMo.push({'bz':pobj,'cm':forCalculated(pobj)});
			if(fobj.length>=1)MxMiMo.push({'bz':fobj,'cm':forCalculated(fobj)});
			MxMiMo.sort(function(a,b){return a.cm - b.cm});
			var maxObj = MxMiMo[MxMiMo.length-1].bz;
			var minObj = MxMiMo[0].bz;
			return {'max':maxObj,'min':minObj};
}
		function forCalculated(obj){
			var occasion=1;
			for(var i=0;i<obj.length;i++)
			{
				occasion*=obj[i].brouns;
			}
			//alert("jieguo--"+occasion);
			return occasion;
		}
		function yusuan(arr,v,rq){
			var bf = arr['502'],jqar = arr['503'],rqar = arr['511'],bqar = arr['504'],spfar = arr['501'];
			var ysNewArr = [],bfArr=[],spfArr=[],rqspfArr=[],bqcArr=[],jqsArr=[];
			if(v==3){
				if(spfar){
					if(spfar['3'])spfArr.push({'gn':'501','brouns':spfar['3'],'val':'3'});
				}
				if(bf){
					for(var b_f in bf)
					{
						var bo =b_f.split("#");
						if(bo[0]>bo[1])
						bfArr.push({'gn':'502','brouns':bf[b_f],'val':b_f});
					}
					if(bfArr.length>0)bfArr.sort(function(a,b){return a.brouns - b.brouns});
				}
				if(rqar){
					if(bfArr.length>0){
						var bojb = bfArr[bfArr.length-1].val;
						var oj = bojb.split("#");
						var zj = oj[0] , kj = oj[1];
						if(zj - kj > 1 && rq.indexOf('-')!=-1){
							if(rqar['3R'])rqspfArr.push({'gn':'511','brouns':rqar['3R'],'val':'3R'});
						}else if(zj - kj == 1 && rq.indexOf('-')!=-1){
							if(rqar['1R'])rqspfArr.push({'gn':'511','brouns':rqar['1R'],'val':'1R'});
						}
					}else{
						if(rq.indexOf('-')!=-1){
							for(var r_q in rqar){
								if(r_q=='3R' || r_q == '1R')
								if(rqar[r_q])rqspfArr.push({'gn':'511','brouns':rqar[r_q],'val':r_q});
							}
						}else if(rq.indexOf('+')!=-1)
						{
							if(rqar['3R'])rqspfArr.push({'gn':'511','brouns':rqar['3R'],'val':'3R'});
						}
						if(rqspfArr.length>0)rqspfArr.sort(function(a,b){return a.brouns - b.brouns});
					}
				}
				if(jqar){
					for(var j_q in jqar)
					{
						if(j_q != '0')
						jqsArr.push({'gn':'503','brouns':jqar[j_q],'val':j_q});
					}
					if(jqsArr.length>0)jqsArr.sort(function(a,b){return a.brouns - b.brouns});
				}
				
				if(bqar){
					for(var b_q in bqar)
					{
						var bqb = b_q.split('_');
						if(bqb[1] == 3)
						bqcArr.push({'gn':'504','brouns':bqar[b_q],'val':b_q});
					}
					if(bqcArr.length>0)bqcArr.sort(function(a,b){return a.brouns - b.brouns});
				}
			}else if(v==1){
				if(spfar){
					if(spfar['1'])spfArr.push({'gn':'501','brouns':spfar['1'],'val':'1'});
				}
				if(bf){
					for(var b_f in bf)
					{
						var bo = b_f.split("#");
						if(bo[0]==bo[1])
						bfArr.push({'gn':'502','brouns':bf[b_f],'val':b_f});
					}
					if(bfArr.length>0)bfArr.sort(function(a,b){return a.brouns - b.brouns});
				}
				if(rqar){
					if(rqar['0R'] && rq.indexOf('-')!=-1)rqspfArr.push({'gn':'511','brouns':rqar['0R'],'val':'0R'});
					else if(rqar['0R'] && rq.indexOf('+')!=-1)rqspfArr.push({'gn':'511','brouns':rqar['3R'],'val':'3R'});
				}
				if(jqar){
					for(var j_q in jqar)
					{
						if(j_q==0)
						jqsArr.push({'gn':'503','brouns':jqar[j_q],'val':j_q});
					}
					if(jqsArr.length>0)jqsArr.sort(function(a,b){return a.brouns - b.brouns});
				}
				
				if(bqar){
					for(var b_q in bqar)
					{
						var bqb = b_q.split('_');
						if(bqb[1] == 1)
						bqcArr.push({'gn':'504','brouns':bqar[b_q],'val':b_q});
					}
					if(bqcArr.length>0)bqcArr.sort(function(a,b){return a.brouns - b.brouns});
				}
			}else if(v==0){
				if(spfar){
					if(spfar['0'])spfArr.push({'gn':'501','brouns':spfar['0'],'val':'0'});
				}
				if(bf){
					for(var b_f in bf)
					{
						var bo = b_f.split("#");
						if(bo[0]<bo[1])
						bfArr.push({'gn':'502','brouns':bf[b_f],'val':b_f});
					}
					if(bfArr.length>0)bfArr.sort(function(a,b){return a.brouns - b.brouns});
				}
				if(rqar){
					if(bfArr.length>0){
						var bojb = bfArr[bfArr.length-1].val;
						var oj = bojb.split("#");
						var zj = oj[0] , kj = oj[1];
						if(kj - zj > 1 && rq.indexOf('-')!=-1){
							if(rqar['0R'])rqspfArr.push({'gn':'511','brouns':rqar['0R'],'val':'0R'});
						}else if(kj-zj==1 && rq.indexOf('+')!=-1){
							if(rqar['1R'])rqspfArr.push({'gn':'511','brouns':rqar['1R'],'val':'1R'});
						}
					}else{
						if(rq.indexOf('-')!=-1){
							if(rqar['0R'])rqspfArr.push({'gn':'511','brouns':rqar['0R'],'val':'0R'});		
						}else if(rq.indexOf('+')!=-1){
							for(var r_q in rqar){
								if(r_q=='1R' || r_q == '0R')
								rqspfArr.push({'gn':'511','brouns':rqar[r_q],'val':r_q});
							}
						}
						if(rqspfArr.length>0)rqspfArr.sort(function(a,b){return a.brouns - b.brouns});
					}
				}
				if(jqar){
					for(var j_q in jqar)
					{
						if(j_q==0)
						jqsArr.push({'gn':'503','brouns':jqar[j_q],'val':j_q});
					}
					if(jqsArr.length>0)jqsArr.sort(function(a,b){return a.brouns - b.brouns});
				}
				
				if(bqar){
					for(var b_q in bqar)
					{
						var bqb = b_q.split('_');
						if(bqb[1] == 1)
						bqcArr.push({'gn':'504','brouns':bqar[b_q],'val':b_q});
					}
					if(bqcArr.length>0)bqcArr.sort(function(a,b){return a.brouns - b.brouns});
				}
			}
			
			if(bfArr.length>0) ysNewArr.push(bfArr[bfArr.length-1]);
			if(spfArr.length>0) ysNewArr.push(spfArr[spfArr.length-1]);
			if(rqspfArr.length>0) ysNewArr.push(rqspfArr[rqspfArr.length-1]);
			if(bqcArr.length>0) ysNewArr.push(bqcArr[bqcArr.length-1]);
			if(jqsArr.length>0) ysNewArr.push(jqsArr[jqsArr.length-1]);
			
			return ysNewArr;
		}
		
		
		function bdyusuan(arr,v,rq){
			var lotG,game;
			for(var gameAr in arr){
				game = gameAr;
				lotG = arr[gameAr];
			}
			var ysNewArr = [],brounsArr = [];
			if(lotG){
				for(var l_t in lotG){
					brounsArr.push({'gn':game,'brouns':lotG[l_t],'val':l_t});
				}
				if(brounsArr.length>0)brounsArr.sort(function(a,b){return a.brouns - b.brouns});
			}
			
			if(brounsArr.length>0) ysNewArr.push(brounsArr[brounsArr.length-1]);
			return ysNewArr;
		}