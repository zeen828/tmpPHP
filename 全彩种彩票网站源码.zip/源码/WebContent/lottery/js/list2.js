KO.t_bg='';
KO.tr_c='th_even';
KO.gameCode="1000";
KO.Pages="1";
KO.Every=myEveryPage;
KO.countEvery="2";
KO.S = url+'/letoula/hmdt/hm_center.jsp';
KO.SL = url+'/letoula/jclq/project_list.jsp?gameid='+KO.gameCode;
var McN_Map={
	'1':'1串1','2':'2串1',
	'3':'3串1','4':'3串3','5':'3串4',
	'6':'4串1','7':'4串4','8':'4串5','9':'4串6','10':'4串11',
	'11':'5串1','12':'5串5','13':'5串6','14':'5串10','15':'5串16','16':'5串20','17':'5串26',
	'18':'6串1','19':'6串6','20':'6串7','21':'6串15','22':'6串20','23':'6串22','24':'6串35','25':'6串42','26':'6串50','27':'6串57',
	'28':'7串1','29':'7串7','30':'7串8','31':'7串21','32':'7串35','33':'7串120','34':'7串127',
	'35':'8串1','36':'8串8','37':'8串9','38':'8串28','39':'8串56','40':'8串70','41':'8串247','42':'8串255'
},DC_McN_Map={
	'1':'1串1','2':'2串1',
	'3':'2串3','4':'3串1','5':'3串4',
	'6':'3串7','7':'4串1','8':'4串5','9':'4串11','10':'4串15',
	'11':'5串1','12':'5串6','13':'5串16','14':'5串26','15':'5串31','16':'6串1','17':'6串7',
	'18':'6串22','19':'6串42','20':'6串57','21':'6串63','22':'7串1','23':'8串1','24':'9串1','25':'10串1','26':'11串1','27':'12串1',
	'28':'13串1','29':'14串1','30':'15串1'
},Game_Map={
	'1':'单式','2':'复式'
};

function mouse_over(_this){
	KO.t_bg=$(_this).find('td').css("backgroundColor");
	$(_this).find('td').css("backgroundColor",'#f5f5f5');
	
}
function mouse_out(_this){
	$(_this).find('td').css("backgroundColor", "white");
}
function mltOnkeyUp(){
		
		var _this=arguments[0],
			val=parseInt(_this.value);
			
		var fs=parseInt(_this.getAttribute('f_S'));
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || val <= 0 || val>fs){
			
		   _this.value=1;
		   if(val>fs){
		   		_this.value=fs;
		   }
		}
}

function Chipped_in_submit(_this,Trading,gameid){
	var copies=$(_this).parent().siblings().find('.inputBg').val(); 
	if(isNaN(copies)){
		create_class.seaDetails('blk2','s','您好!请输入正确的数字!','error',KO.S);
		return;
	}
	if(confirm("确定要购买吗？")){
		$.getJSON(url+"/letoula/data/Chipped_in_submit.jsp?r="+Math.random(),{'gameid':gameid,'Trading':Trading,'copies':copies},function(result){
			if(result.result=='0000'){
				create_class.seaDetails('blk2','s','您好！您参与合买成功！','success',KO.S);
			}else{
				if(result.result=='S050'){
					jQuery.alertWindow("温馨提示:","您的余额不足!");
					console.log("st");
				}else{
					setting.loginDialog();
				}
			}
		})
	}
	
}
function over_t(l){
		
		rl = l == 'l' ? KO.SL : KO.S;
		create_class.seaDetails('blk2','h','','success',rl);
		
	}
function details_submit(as){
	
	var parmas=as.getAttribute('sb').split(','); 
	KO.$('userName').value  =	 parmas[0];
	KO.$('muliptile').value =	 parmas[1];
	KO.$('Copis').value     =    parmas[2];
	KO.$('copisPrice').value=    parmas[3];//单价
	KO.$('bdCopies').value  =    parmas[4];//份数
	KO.$('progress').value  =	 parmas[5];
	KO.$('tzway').value     =	 parmas[6];
	KO.$('moneyFw').value   =    parmas[7];
	KO.$('csm').value   	=    parmas[8];
	KO.$('starTime').value  =    parmas[9];
	KO.$('endTime').value   =    parmas[10];
	KO.$('id').value   		=    parmas[11];
	KO.$('Trading').value   =    parmas[12];
	KO.$('sycopies').value  =    parmas[13];
	KO.$('rgCopis').value   =    parmas[14];
	KO.$('isopen').value   =     parmas[15];
	KO.$('listform').submit();
}
function paging(ey,pages){
		var e_y_a='';
		pages = parseInt(pages);
		var countY = Math.ceil(ey);
		var next=pages >= ey ? ey : pages+1;
		var fist=pages <= 1 ? "1" : pages-1;
		var startY=0,endY=ey > 5 ? 8 : ey;
		if(pages>=5){
			startY = pages - 5; 
			endY   = ey - pages + 5 > ey ? ey :  pages + 5;
		}
		
		e_y_a+="<font>共有"+KO.countEvery+"条记录，共有"+Math.ceil(ey)+"页</font><a href='javascript:void(0)' onclick=showData('1','"+KO.Every+"') class='h_l'>◀</a><a href='javascript:void(0)' onclick=showData('"+fist+"','"+KO.Every+"') title='上一页' class='pre'>◀◀</a>";
		var cls='';
		for(var e=startY;e<endY;e++){
			if(e<ey){
				if(e==(pages-1)) cls='an_x_z';
				else cls='';
				e_y_a+='<a style="padding:0 10px;" href="javascript:void(0)" class="'+cls+'" onclick=showData("'+(e+1)+'","'+KO.Every+'")>'+(e+1)+'</a>';
			}else{
				break;
			}
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showData('"+next+"','"+KO.Every+"') class='next'>▶▶</a><a href='javascript:void(0)' onclick=showData('"+countY+"','"+KO.Every+"') class='h_l'>▶</a>";
		//e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		//"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='gray'>共"+countY+"页,"+(ey*parseInt(t_s))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}


function ValidataPage(ey,_this){

		var pg=parseInt(_this.value),
		reg=/^(0|[1-9][0-9]*)$/g;
		if(pg > ey) {
			_this.value=ey;
		}
		
		if(!reg.test(_this.value) || pg <= 0){
		   _this.value=1;
		}
		
}

function loadPageData(field,desc){
	
	var ps=$("#govalue").val();
	showData(ps,KO.Every,'"+field+"','"+desc+"');
}

function showData(pages,every,field,desc){
	//alert(111);
	//alert(pages+"---"+every+"---"+field+"---"+desc)
	$('.loding').show();
	if(undefined == pages){
		pages=1;
	}
	if(undefined == every){
		every=4;
	}
	KO.Pages=pages;
	KO.Every=every;
	KO.gameCode = $('.xunzhong').attr('code');
	KO.gameCode = KO.gameCode ? KO.gameCode : "1000";
	var status = $('#dstatus').val();
	var progress = $('#progress').val();
	var countMoney = $('#countMoeny').val();
	var selGame = $('#selGame').val();
	var username = $('.sartext').val();
	if($('.sartext').val()=='查找合买人' || $('.sartext').val()==''){
		username='';
	}
	//alert(222);
	$.getJSON(url+"/letoula/data/list_data.jsp?r="+Math.random(),{'gameid':selGame,'status':status,'progress':progress,'countMoney':countMoney,'usernickname':username,'pages':KO.Pages,'every':KO.Every},function(items){
		//alert(333);
		var tr='';
		$('#hmtbody,.f_an_page').empty();
		var it=items.items;
		KO.countEvery=parseInt(items.recod);
		var ey=parseInt(items.recod)/parseInt(KO.Every);
		ey = ey < 1 ? 1 : ey;
		paging(ey,pages,field,desc);
	
		it = create_class.Sort_field(it,field,desc);
		//alert(444)
		 $(it).each(function(i,v){
		 		var baodi=v.copisPrice*v.bdCopies;
		 		
		 		
		 		KO.tr_c = i % 2 == 0 ? 'th_top' : 'th_even';
		 		
		 		var sy_copies=v.countCopis-v.rgCopis,
		 			progress=Math.ceil(v.rgCopis/v.countCopis*100),
		 			bdr = Math.ceil(v.bdCopies/v.countCopis*100);
		 		var xh=i+parseInt(pages);
		 		xh = (parseInt(pages)*parseInt(every))-(it.length-i)+1;
		 		xh = it.length<=20 ? (i+1) : xh;
		 		progress = progress + '%';
		 		var tzway='';
		 		var way=v.way.split(',');
		 		
		 		if(v.gameType == '301' || v.gameType == '302' || v.gameType == '303' || v.gameType == '304' || v.gameType == '305'){
		 			
		 			for(var s=0;s<way.length;s++){
		 				tzway+=DC_McN_Map[way[s]]+'/';
		 			}
		 			
		 		}else if(v.gameType == '501' || v.gameType == '502' || v.gameType == '503' || v.gameType == '504' || v.gameType == '505' || v.gameType == '506' || v.gameType == '507' || v.gameType == '508'){
		 			for(var s=0;s<way.length;s++){
		 				tzway+=McN_Map[way[s]]+'/';
		 			}
		 		}else if(v.gameType == '102' || v.gameType == '103' || v.gameType == '106' || v.gameType == '107'){
		 			tzway+=Game_Map[way[s]]+'/';
		 		}
		 		
		 		
		 		tzway=tzway.substring(0,tzway.lastIndexOf('/'));
		 		
		 		var record_ZJ = create_class.Record_zhanJ(v.igl);
		 		var ye = parseInt(v.countCopis)-parseInt(v.rgCopis);
		 		var disabled = '' , flagM = "<input type='button' class='btn_S' onclick=Chipped_in_submit(this,'"+v.Trading+"','"+v.gameType+"') value='认 购' />";
		 		if(ye==0){
		 			disabled = "disabled='disabled'";
		 			flagM= "--";
		 		}
		 		var decoration = v.decoration.length > 8 ? v.decoration.substring(0,8)+"..." : v.decoration;
		 		//alert(decoration)
		 		tr+="<tr class='"+KO.tr_c+"' onmouseover='mouse_over(this)' onmouseout='mouse_out(this)'><td>"+xh+"</td><td title='"+v.decoration+"'><a href='../hmdt/hmx.jsp?id="+v.Trading+"' target='_blank'>"+decoration+"</a></td><td><a href='javascript:void(0)'>"+v.userName+"</a></td>"+
	 		    "<td>"+record_ZJ+"</td><td>"+lotName[v.gameType]+"</td><td>"+v.countCopis+"元</td><td>"+v.csm+"%</td><td>"+v.copisPrice+"元</td>"+
	 		    "<td>"+progress+"</td><td><input type='text' class='inputBg' value='剩"+ye+"' onfocus=create_class.onblurAndonkeyUp(this,'剩"+ye+"','onfocus') onblur=create_class.onblurAndonkeyUp(this,'剩"+ye+"','onblur') f_S='"+sy_copies+"' "+disabled+" onkeyup='mltOnkeyUp(this)' />份</td>"+
	 		    "<td>"+flagM+"</td>"+
	 		    "<td><a href='"+url+"/hema/"+v.Trading+"' target='_blank'>详情</a></td></tr>";
		 		
		 })
		 $(tr).appendTo("#hmtbody");
		 $('.loding').hide();
	});
}

$(function(){
	$('.page a').click(function(){
		//alert("111");
		$(this).siblings().removeClass();
		$(this).addClass('an_x_z');
		KO.Every=$(this).text();
		//alert("---"+KO.Every);
		if(KO.Every==null || KO.Every==''){
			KO.Every=myEveryPage;
		}
		showData(KO.Pages,KO.Every,'rgCopis','asc');
	});
	$('.p_x').click(function(){
		
		$('.des_time').removeClass().addClass('asc_pub');
		$(this).find('span').removeClass('asc_pub').addClass('des_time');
	});
	$('.gcc a').click(function(){
		$(".gcc a").removeClass();
		$(this).addClass('xunzhong');
		showData(KO.Pages,KO.Every,'rgCopis','asc');
	});
	showData(KO.Pages,KO.Every,'rgCopis','asc');

	window.onscroll=function(){
		var num_scroll_top = 0;
          if(document.body.scrollTop){
              num_scroll_top=document.body.scrollTop;
            }
            else{
              num_scroll_top=document.documentElement.scrollTop;
            }    
          // $("#bd").css("top",num_scroll_top);
	}
})