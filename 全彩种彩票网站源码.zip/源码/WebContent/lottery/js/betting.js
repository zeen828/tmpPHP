
$('.tzfs span input').click(function(){
	
	var r_Id=$(this).attr('id');
	
	$(this).parents('div').find('span>input').attr('checked',false);
	$(this).attr('checked',true);
	$('.trrg,.trhm').hide();

	if(r_Id=='qerg'){
		
			$('.trrg').show();
			Y.eachPrice=parseInt(agrs.countCopies);
			$('#copies').val('1');
			Y.hmfaType='1'; 
			Y.flag=true;
	}else{
		
			$('.trhm').show();
			Y.hmfaType='2';
	}
	
	settingMethod.validation_Copies(document.getElementById('copies'));
});
$('.jecthide>input').click(function(){
	
	$('.jecthide').find('input').attr('checked',false).removeClass('opens');
	$(this).attr('checked',true).addClass('opens');
});

var Y=new Object();


Y.t_input='精品合买单';
Y.area='一起中大奖！！';
Y.txt='';
Y.$=function(ele) { return document.getElementById(ele); };
Y.countCopies=parseInt(agrs.countCopies);
Y.RCopies=1;
Y.eachPrice=Y.countCopies;
Y.gameCode=agrs.gameCode;
Y.ZQMcN=agrs.zqmcn;
Y.multiple=agrs.multiple;
Y.hmfaType=1;
Y.DzCountMoney=1;
Y.flag=true;
Y.isUpLoad='1';
Y.status = 'success';
Y.S = agrs.url+'/letoula/useraccount/serNoScheme_details.jsp?id=';
Y.L = agrs.url+'/letoula/error.jsp';

var settingMethod={

	
	't_inputOnfocus':function(_this){
		
		Y.txt = _this.id=='schmeTitle' ? Y.t_input : Y.area;
		
		_this.value = _this.value==Y.txt ? '' : _this.value;
			
	},
	't_inputOnblur':function(_this){
		
		Y.txt = _this.id=='schmeTitle' ? Y.t_input : Y.area;
		
		_this.value = _this.value=='' ? Y.txt : _this.value;
		
	},
	't_inputOnkeyUp':function(_this){
		
		_this.id=='schmeTitle' ? $('.schmeMany').text(_this.value.length) : $('.schmedsp').text(_this.value.length);
		
		if(_this.value.length >= 200){
			
			_this.value=_this.value.substring(0,199);
		}
	},
	'Copies_onkeyUp':function(_this){
		
		if(!Y.flag){
			
			$('#copies').val('1');
			settingMethod.validation_Copies($('#copies'));
			$('.flag').hide();
		}
	},
	'mltOnkeyUp':function(){
	
		var _this=arguments[0],
			val=parseInt(_this.value);
	
		if(val > 99999) {
			_this.value='99999';
		}
		
		if(isNaN(_this.value) || val <= 0 || _this.value.indexOf('.')!=-1){
		
		   _this.value=1;
		}
		
		Y.multiple=_this.value;
		
		Y.countCopies = Y.countCopies*parseInt(Y.multiple);
		Y.eachPrice = Y.countCopies;
		$('.up_countP').text("￥"+Y.countCopies);
		$("#copies").val(Y.countCopies);
		this.validation_Copies(document.getElementById('copies'));
	},
	'closeWindow':function(u){   
    	var local = Y.status == 'error' ? Y.L : Y.S;
    	window.location.href=local;
	},
	'validation_Copies':function(_this){
		var price='0.00';
		$('.flag').hide();
		if(_this.value==''){
			price=0;
			Y.flag=false;
		}else if(_this.value=='0'){
			
			_this.value='1';
			price=Y.countCopies+'.00';
			Y.flag=false;
		}
		else if(parseInt(_this.value) > Y.countCopies){
			_this.value=Y.countCopies;
			price='1.00';
			Y.flag=false;
		}
		else if(isNaN(_this.value) || _this.value.indexOf('.')!=-1){
			_this.value='1';
			price=Y.countCopies+'.00';
			Y.flag=false;
		}
		else if(Y.countCopies % parseInt(_this.value) != 0){
			Y.flag=false;
			$('.flag').show();
		}else{
			Y.flag=true;
		}
		if(price.substring(price.indexOf('.')+1,price.length)!='00'){
			$(_this).val('1');			
		}
		
		price=parseFloat(Y.countCopies/parseInt(_this.value)).toFixed(2);
		$('#a_copies').text('￥'+price);
		Y.RCopies=_this.value;
		Y.eachPrice=price;
		settingMethod.subscribe_Copies(Y.$('sbConpies'));
		settingMethod.validation_downside(Y.$('side'));
		
	},
	'validation_downside':function(_this){
		
		var sbbePrice='0.00';
		var flag=true;
		
		if(_this.value==''){
			sbbePrice=sbbePrice;
			flag=false;
		}
		else if(isNaN(_this.value) || _this.value.indexOf('.')!=-1){
			_this.value='1';
			sbbePrice=Y.eachPrice;
			flag=false;
		}
		else if(parseInt(_this.value)>Y.RCopies){
			_this.value=Y.RCopies;
			sbbePrice=Y.eachPrice;
			flag=true;
		}
		else if(_this.value=='0'){
			sbbePrice=sbbePrice;
			$('#side').attr({'disabled':true,'value':'0'});
			$('#downside').attr('checked',false);
		}
		if(flag){ sbbePrice=parseFloat(parseFloat(Y.eachPrice)*parseInt(_this.value)).toFixed(2); }
		$('.dse').text('￥'+sbbePrice);
	},
	'subscribe_Copies':function(_this){
		
		var sbbePrice='0.00';
		var flag=true;
		
		if(_this.value==''){
			sbbePrice=sbbePrice;
			flag=false;
		}
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 ||  _this.value=='0'){
			_this.value='1';
			sbbePrice=Y.eachPrice;
			flag=false;
		}
		if(parseInt(_this.value)>Y.RCopies){
			_this.value=Y.RCopies;
			sbbePrice=Y.eachPrice;
			flag=true;
		}
		if(flag){ sbbePrice=parseFloat(parseFloat(Y.eachPrice)*parseInt(_this.value)).toFixed(2); }
		$('.sbbePrice').text('￥'+sbbePrice);
	},
	'downside':function(){
		
		var sides=arguments[0];
		
		if(sides.checked) { 
			
			$('#side').attr({'disabled':false,'value':'1'}); 
			settingMethod.validation_downside(Y.$('side'));
		}
		else {
			
			$('#side').attr({'disabled':true,'value':'0'});
			settingMethod.validation_downside(Y.$('side'));
		}
	},
	'over_t':function(){
	
		create_class.seaDetails('blk2','h','','success',Y.S);
		
	},
	'submitBtn':function(t){
		
		if(!Y.flag) { alert("请完善您的购买形式!"); return; }
		var gameCode=Y.gameCode; 					//玩法类型
		var manner=Y.ZQMcN;     					//投注方式
		var title=$('#schmeTitle').val();  			//标题
		var description=$('#description').val(); 	//描述
		var isopen=$('.opens').val(); 			    //是否公开
		var openusers='all'; 						//面向全部网友
		var isUpload=Y.isUpLoad; 					//是否上传
		var payofftc=$('#comm').val();  			//提成比例
		var money=agrs.countCopies; 				//投注总金额
		var multiple=Y.multiple;  					//倍数
		var copies=$('#copies').val();				//总份数
		var copies1=$('#sbConpies').val();      	//认购份数
		var eachPrice=Y.eachPrice;					//每份单价
		var ensures=$('#side').val();				//保底份数
		var chipinNums=agrs.tzNumber.replace(/[" "]/g,"");		//投注号码
		var hmfaType=Y.hmfaType;  					//代购1,合买2
		var spValue=agrs.spzValue;   				//SP值
		var moneyFw=agrs.moneyFw;					//奖金范围
		var issue = agrs.issue;						//期号，竞彩没有期号unkonw
		
		if(t == 'chipin')
		{
			money     =  parseFloat(Y.countCopies).toFixed(2);
			copies    =  Y.countCopies;
			copies1   =  Y.countCopies;
			payofftc  =  '0';
			ensures    =  '0';
		}
		
		if(gameCode=='102' || gameCode=='103' || gameCode=='106' || gameCode=='107' ){
				
			if(t == 'chipin'){
					ensures = '1';
			}else if(t!='chipin' && ensures=='0'){
					ensures = '1';
			}
		}else if(gameCode=='511')
		{
			chipinNums = chipinNums.replace(/[R]/g,"");
		}else if(gameCode=='503'){
			chipinNums = chipinNums.replace(/[B]/g,"");
		}
		//parseInt(ensure)<=0 ? ensure=Y.countCopies : ensure=ensure;
		
		if(gameCode == '103' && chipinNums.indexOf('.txt')== -1){
		
		    	chipinNums = chipinNums.replace(/[*]/g,"9");
		}
		
			create_class.seaDetails('blk2','s','您好！投注中....','success',Y.S);
			$.getJSON("../data/request_betting.jsp?r="+Math.random(),
			{
			 'gameCode':gameCode,'issue':issue,'manner':manner,'title':title,'description':description,'isopen':isopen,'openusers':openusers,
			 'isUpload':isUpload,'payofftc':payofftc,'money':money,'multiple':multiple,'copies':copies,'copies1':copies1,
			 'eachPrice':eachPrice,'ensure':ensures,'chipinNums':chipinNums,'hmfaType':hmfaType,'spValue':spValue,'moneyFw':moneyFw
			},
			function(rquestText){
			
				if(rquestText.result=='0000'){
					Y.S += rquestText.serialno;
					Y.status = 'success';
					create_class.seaDetails('blk2','s','您好！您的方案已提交成功！',Y.status,Y.S);
				}else{
					if(rquestText.result=='非法登录或登录超时!'){
					 	setting.login();
					 	create_class.seaDetails('blk2','h');
					}else{
						Y.status = 'error';
						create_class.seaDetails('blk2','s','您好！'+rquestText.result+'',Y.status,Y.L);
					}
				}
					
			});
		
	}
}

$('.buyObj > p > input[type=radio]').click(function(){

	$(this).parents('div').find('p>input').attr('checked',false);
	
	$(this).attr('checked',true);
	
	if($(this).attr('id')=='allBuy'){
		
		$('#dpn').hide();

	}else{
	
		$('#dpn').show();
	}
})

$(function(){
	$.getJSON('../data/tary_single_user.jsp?r='+Math.random(),{'userNikeName':agrs.nikeName},function(JSON){
	
  				if(JSON.result == '0000'){
  					
  					$(JSON.items).each(function(i,v){
  						
  						Y.DzCountMoney+=parseFloat(v.price);
  							
  					})
  					$('.dzMoney').text('￥'+parseFloat(Y.DzCountMoney).toFixed(2)+'元');
  				}else{
  					
  					alert(JSON.result);
  				}
  		});
  		
  		settingMethod.validation_Copies(KO.$('copies'));
})
window.onscroll=function(){
		var num_scroll_top = 0;
          if(document.body.scrollTop){
              num_scroll_top=document.body.scrollTop;
            }
            else{
              num_scroll_top=document.documentElement.scrollTop;
            }    
          $("#bd").css("top",num_scroll_top);	
}