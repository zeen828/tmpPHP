

	$(".nav_menu").corner("5px");
