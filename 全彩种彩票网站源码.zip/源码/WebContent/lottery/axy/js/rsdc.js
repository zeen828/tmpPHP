﻿KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="100";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){

		var e_y_a='';
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var countY = Math.ceil(ey);
		if(countY > 1) KO.countEvery = 10;
		var startY=0,endY=countY-1 > 8 ? 7 : countY;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=showAuxiliary('1','"+KO.U.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'></a>";
		var cls='';

		for(var e=startY;e<endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showAuxiliary("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showAuxiliary('"+next+"','"+KO.U.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+countY+"','"+KO.U.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='#0f3f94'>共"+countY+"页,"+(ey*parseInt(KO.countEvery))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	var ps=$("#govalue").val();
	showAuxiliary(ps,KO.U.Every);
}
function selToTime(p,e){
	var issue = $("#issue_sel").val();
	showAuxiliary("1","10");
}

function showAuxiliary(p,e){
	
	$('.loding').show();
	var issue = $("#issue_sel").val();
	$.getJSON('../data/results_the_dclottery.jsp?r='+Math.random(),{'issue':issue},function(JSON){
		
		var items = JSON.items;
		var tr='';
		$('.ld_tbody,.f_an_page,#rc_t_ty,.ld_tbody,.xiang_x').empty();
		
		$(items).each(function(i,v){
			
			v.color = v.color == '-' ? '#004488' : v.color; 
			var con = '';
			if(parseFloat(v.rangqiushu) < 0){
  				con = '(<strong><font color="green">'+v.rangqiushu+'</font></strong>)';
  			}else if(parseFloat(v.rangqiushu) > 0){
  				con = '(<strong><font color="red">+'+v.rangqiushu+'</font></strong>)';
  			}else{
  				con = '';
  			}
			if(id=='0')
			{	
				
				tr += '<tr><td width="40">'+v.mathnum+'</td><td width="66" style="background:'+v.color+';color:#fff">'+v.matchName+'</td>'+
				  '<td width="100">'+create_class.axyformatTime(v.matchTime)+'</td><td class="text_r" width="100"><a>'+v.maindu+con+'</a></td><td width="30"><strong><font color="red">'+v.quanbifen+'</font></strong></td><td  width="100" class="text_l"><a>'+v.guestdu+'</a></td>'+
				  '<td width="15"></td><td width="50">'+v.rangqiu+'</td><td width="40"><strong><font color="red">'+v.rangqiusp+'</font></strong></td>'+
				  '<td width="15"></td><td width="50">'+v.zongjinqiu+'</td><td width="40"><strong><font color="red">'+v.zongjinqiusp+'</font></strong></td>'+
				  '<td width="15"></td><td width="50">'+v.shangxiapan+'</td><td width="40"><strong><font color="red">'+v.shangxiapansp+'</font></strong></td>'+
				  '<td width="15"></td><td width="50">'+v.bifen+'</td><td width="40"><strong><font color="red">'+v.bifensp+'</font></strong></td>'+
				  '<td width="15"></td><td width="50">'+v.banquanchang+'</td><td width="40"><strong><font color="red">'+v.banquanchangsp+'</font></strong></td></tr>';
				  
				  
			}else if(id == '1'){
			
			}else if(id == '2'){
				
			}else if(id == '3'){
				
			}else if(id == '4'){
				
			}
		})
		
		var cs = id == '0' ?  '.ld_tbody' : '.xiang_x'; 
		
		$(tr).appendTo(cs);
		
		$('.loding').hide();
	});
}


$(function(){
	showAuxiliary(KO.U.Pages,KO.U.Every);
	var lotIndex = id == 0 ? 0 : 1;
	$('.ld_table').eq(lotIndex).show();
	$('.rs_c_m > li').eq(id).addClass('c_m_xz');
})
function ftTime(time){
	var year=time.substr(0,4);
	var month=time.substr(4,2);
	var day=time.substr(6);
	return year+"-"+month+"-"+day;
}