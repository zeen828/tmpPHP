
$(function(){
	
	$.getJSON("../data/winsFlat.jsp?r="+Math.random(),{type:'0',smalltype:'501'},function(items){
	 	items=items.items;
	 	var t = items[items.length-1].stopTime.split(' ')[0].replace(/[-]/g,'');
	 	var ot = '';
	 	var dd = new Date();
	 	var LSTR_Year=t.substring(0,4); 
		var LSTR_Month=t.substring(4,6); 
		var LSTR_Date=t.substring(6,8); 

		/*for(var i=0;i<LSTR_Date;i++){
			var uom = new Date(LSTR_Year,LSTR_Month,LSTR_Date); 
			uom.setDate(uom.getDate()-i);//取得系统时间的前一天,重点在这里,负数是前几天,正数是后几天 
			var LINT_MM=uom.getMonth(); 
			var LSTR_MM=LINT_MM >= 10?LINT_MM:("0"+LINT_MM) 
			var LINT_DD=uom.getDate(); 
			var LSTR_DD=LINT_DD >= 10?LINT_DD:("0"+LINT_DD) ;
			
			//得到最终结果 
			uom = uom.getFullYear() + "-" + LSTR_MM + "-" + LSTR_DD;
			
			if(dd.getDate() == LINT_DD) {
				ot += '<option value="'+uom+'" selected="selected">'+uom+'</option>';
			}else{
				ot += '<option value="'+uom+'">'+uom+'</option>';
			} 
			
		}*/
		
		for(var i=0;i<=7;i++){
			var uom = new Date(); 
			uom.setDate(uom.getDate()-i);//取得系统时间的前一天,重点在这里,负数是前几天,正数是后几天 
			var LINT_MM=uom.getMonth()+1; 
			var LSTR_MM=LINT_MM >= 10?LINT_MM:("0"+LINT_MM) 
			var LINT_DD=uom.getDate(); 
			var LSTR_DD=LINT_DD >= 10?LINT_DD:("0"+LINT_DD) ;
			//得到最终结果 
			uom = uom.getFullYear() + "-" + LSTR_MM + "-" + LSTR_DD;
			if(dd.getDate() == LINT_DD) {
				ot += '<option value="'+uom+'" selected="selected">'+uom+'</option>';
			}else{
				ot += '<option value="'+uom+'">'+uom+'</option>';
			} 
			
		}
		$(ot).appendTo('.week');
		showEvt();
	});
	
});


		
			
function showEvt(){

var weekTime = $('.week').val();
weekTime = weekTime.replace(/[-]/g,"");
$.getJSON("../data/score.jsp?r="+Math.random(),{time:weekTime},function(items){
	 items=items.items;
	 var tr='';
	 var anysy = items[0].stopTime.substring(0,10);
	 var ms = ZQ.m;
	 $('.clearfix').empty();
	 for(var i=0;i<items.length;i++){
	 	
	 	var statusImg = '' , marketList = '' , caiguo = '<strong><font color="blue">'+items[i].caiguo+'</font></strong>' , trh = '' , ipt='checked';
	 			
	 			items[i].winrate501 = parseFloat(items[i].winrate501).toFixed(2);
	 			items[i].levelrate501 = parseFloat(items[i].levelrate501).toFixed(2);
	 			items[i].loserate501 = parseFloat(items[i].loserate501).toFixed(2);
	 			if(items[i].caiguo=='胜')
				{
					items[i].winrate501 = '<font class="speilv">'+parseFloat(items[i].winrate501).toFixed(2)+'</font>';
				}
				else if(items[i].caiguo=='平')
				{
					items[i].levelrate501 = '<font class="ppeilv">'+parseFloat(items[i].levelrate501).toFixed(2)+'</font>';
				}
				else if(items[i].caiguo=='负')
				{
					items[i].loserate501 = '<font class="fpeilv">'+parseFloat(items[i].loserate501).toFixed(2)+'</font>';
				}
				
	 	var tzSp = '<span width="9%" >'+items[i].winrate501+'</span>'+
      				'<span width="9%" class="weight">'+items[i].levelrate501+'</span>'+
      				'<span width="9%" >'+items[i].loserate501+'</span>';
     
      		if($("#"+items[i].gamename+"").attr)
      		marketList="<li><input type='checkbox' lg='"+items[i].gamename+"' class='m_k_t' checked='checked' onclick='config.clearfix_click(this)' id='"+items[i].gamename+"' /><font>"+items[i].gamename.substring(0,3)+"</font></li>";
  			
  			if($("#"+items[i].gamename+"").is('input')){
					marketList='';
			}
		
  			$(marketList).appendTo('.clearfix');
  			
 			if(ZQ.m != ms){
  				anysy = items[i].stopTime.substring(0,10);
  			}
  			if(items[i].currentStatus==' '){
  				items[i].currentStatus = '未';
  				items[i].banChang = '-';
  			}
  			else if(!isNaN(items[i].currentStatus.substring(0,2))){
  				statusImg = 'sta';
  				caiguo = '<strong><font color="blue">'+items[i].caiguo+'</font></strong>';
  			}else if(items[i].currentStatus=='完')
  			{
  				statusImg = 'gameover';
  				caiguo = '<strong><font color="red">'+items[i].caiguo+'</font></strong>';
  			}
  			else{
  			    statusImg = '';
  			}
  			
  			if($('.hiddenOver').attr('checked') &&  items[i].currentStatus=='完'){
  				trh = 'nn';
  			}
  			
  			if(ipt==false){
  				trh = 'nn';
  			}
  			
  				
				
  		items[i].stopselldate = config.Z_Date(items[i].stopselldate);
  		var	bf  = items[i].chuangChang!=' ' ? items[i].chuangChang : '-'; 
	 	tr+='<tr lg="'+items[i].gamename+'" class="'+trh+'"><td><input type="checkbox" class="gm"  checked="checked"/>'+items[i].gamenum+'</td>'+
	 	'<td style="background-color:'+items[i].color+';color:#fff" title='+items[i].gamename+'>'+items[i].gamename.substring(0,3)+'</td>'+
	 	'<td>'+items[i].stopselldate.substring(11, 13) + ":"+ items[i].stopselldate.substring(14, 16)+'</td><td class="'+statusImg+'">'+items[i].currentStatus+'</td>'+
	 	'<td class="r_t"><sup>'+items[i].hostTreamRankings+'</sup><a href="javascript:void(0)" class="blck"  title='+items[i].hostteam+'>'+items[i].hostteam+'</a></td>'+
	 	'<td><strong><font color="red">'+bf+'</font></strong></td>'+
	 	'<td class="l_t"><a href="javascript:void(0)" class="blck" title='+items[i].visitingteam+'>'+items[i].visitingteam+'</a><sup>'+items[i].guestTreamRankings+'</sup></td>'+
	 	'<td>'+items[i].concedenum+'</td><td><font color="red">'+items[i].banChang+'</font></td>'+
	 	'<td><a href="../axy/analysis.jsp?no='+no[items[i].gamenum.charAt(1)]+''+items[i].gamenum.substring(2,5)+'&issue='+anysy.replace(/[-]/g,"")+'" target="_blank">析</a><a href="#" target="_blank">亚</a><a href="#" target="_blank">欧</a></td>'+
	 	'<td>'+tzSp+'</td><td class="last_td">'+caiguo+'</td></tr>';
	 
	 }
	$('.bfcon').html(tr);
	
	
});
setTimeout("showEvt()",10000);
}
var config = {
	'showNode':function(){
		
		var parameters=this.showNode.arguments;
		
		$(parameters).each(function(i,v){
			
			$('.'+v).removeClass('nn').find('.gm').attr({'checked':true,'value':'on'});
			
		})
	
		
		$('.m_k_t').attr('checked',true);
		
		$('.yc').text($('.nn').length);
	},
	'showOppNode':function(){
		
		$('#bf_table > tbody > tr').addClass('nn');
		$('.m_k_t').attr('checked',false);
		$('.yc').text($('.nn').length);
	},
	'listDisplay':function(){
		
		$('#listDisplay').mouseover(function(){
			
			$('#listMenu').show();
			
		}).mouseout(function(){
			$('#listMenu').hide();
		});
	},
	'clearfix_click':function(m_this){
		
		var lg = m_this.id , t_rs = $('#bf_table > tbody > tr[lg="'+lg+'"]');
		
		m_this.checked ? t_rs.removeClass('nn') : t_rs.addClass('nn');
		
		$('.yc').text($('.nn').length);
	},
	'hiddenOver':function(_this){
		
		if(_this.checked){
			
			$('.gameover').parent('tr').addClass('nn');
		}else{
			
			$('.gameover').parent('tr').removeClass('nn');
		}
	},
	'Z_Date':function(d){
			var uom = new Date(d.substring(0,4),d.substring(5,7),d.substring(8,10),d.substring(11,13),d.substring(14,16),d.substring(17,19)); 
			uom.setMinutes(uom.getMinutes()+1);//取得系统时间的前一天,重点在这里,负数是前几天,正数是后几天 
			var LINT_MM=uom.getMonth(); 
			var LSTR_MM=LINT_MM >= 10?LINT_MM:("0"+LINT_MM) 
			var LINT_DD=uom.getDate(); 
			var LSTR_DD=LINT_DD >= 10?LINT_DD:("0"+LINT_DD) 
			var LINT_HH=uom.getHours();
			var LINT_HH=LINT_HH >= 10?LINT_HH:("0"+LINT_HH)
			var LINT_MM=uom.getMinutes();
			var LINT_MM=LINT_MM >= 10?LINT_MM:("0"+LINT_MM)
			var LINT_SS=uom.getSeconds();
			var LINT_SS=LINT_SS >= 10?LINT_SS:("0"+LINT_SS)  
			//得到最终结果 
			uom = uom.getFullYear() + "-" + LSTR_MM + "-" + LSTR_DD+" "+LINT_HH+":"+LINT_MM+":"+LINT_SS;
			
			return uom;
	}
},
no={'一':'1','二':'2','三':'3','四':'4','五':'5','六':'6','日':'7'};