﻿KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="100";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){

		var e_y_a='';
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var countY = Math.ceil(ey);
		if(countY > 1) KO.countEvery = 10;
		var startY=0,endY=countY-1 > 8 ? 7 : countY;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=showAuxiliary('1','"+KO.U.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'></a>";
		var cls='';

		for(var e=startY;e<endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showAuxiliary("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showAuxiliary('"+next+"','"+KO.U.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+countY+"','"+KO.U.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='#0f3f94'>共"+countY+"页,"+(ey*parseInt(KO.countEvery))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	var ps=$("#govalue").val();
	showAuxiliary(ps,KO.U.Every);
}
function selToTime(p,e){
	beginTime= create_class.formatTime(KO.$('startDate').value);
	showAuxiliary("1","10");
}

function showAuxiliary(p,e){
	
	$('.loding').show();
	KO.U.Pages = p;
	KO.U.Every = '100';
	if(beginTime=="null"){
		 beginTime = create_class.formatTime(KO.$('startDate').value);
	}

	//var beginTime = create_class.formatTime(KO.$('startDate').value);
	$.getJSON('../data/results_the_lottery.jsp?r='+Math.random(),{'starTime':beginTime,'pages':KO.U.Pages,'every':KO.U.Every},function(JSON){
		
		var items = JSON.items;
		var tr='';
		$('.ld_tbody,.f_an_page,#rc_t_ty,.ld_tbody,.xiang_x').empty();
		KO.countEvery=items.length;
		var ey=parseInt(JSON.record)/parseInt(KO.U.Every);
		ey = ey < 1 ? 1 : ey;
		paging1(ey,p);
		
		$(items).each(function(i,v){
			
			var vt=v.visitingteam,ht=v.hometeam;
 			
			var bqRe = v.bqcSingleRe.split('-');
			v.color = v.color == '-' ? '#004488' : v.color; 
			if(id=='0')
			{	
				
				tr += '<tr><td>'+v.leagueNumber+'</td><td style="background:'+v.color+';color:#fff">'+v.leagueName+'</td>'+
				  '<td>'+create_class.axyformatTime(v.stopTime)+'</td><td class="text_r"><a href="#">'+ht+'</a></td><td>'+v.giveBall+'</td><td class="text_l"><a href="#">'+vt+'</a></td>'+
				  '<td>('+v.hometeamSemiScore+')'+v.hometeamFullScore+'</td><td></td><td>'+v.spfSingleRe+'</td>'+
				  '<td><font color="red">'+v.spfSinglePr+'</font></td><td></td><td>'+v.zjqSingleRe+'</td><td><font color="red">'+v.zjqSinglePr+'</font></td>'+
				  '<td></td><td>'+v.bfSingleRe+'</td><td><font color="red">'+v.bfSinglePr+'</font></td><td></td>'+
				  '<td>'+v.bqcSingleRe+'</td><td><font color="red">'+v.bqcSinglePr+'</font></td></tr>';
				  
			}else if(id == '1'){
			
				tr += '<tr><td>'+v.leagueNumber+'</td><td><a class="league" href="#" style="background:'+v.color+';">'+v.leagueName+'</a></td>'+
				  '<td>'+create_class.axyformatTime(v.stopTime)+'</td><td class="text_r"><a href="#">'+ht+'</a></td><td>'+v.giveBall+'</td><td class="text_l"><a href="#">'+vt+'</a></td>'+
				  '<td>('+v.hometeamSemiScore+')'+v.hometeamFullScore+'</td><td>'+v.spfSingleRe+'</td><td></td>'+
				  '<td><font color="red">'+v.spfSinglePr+'</font></td><td></td></tr>';
				  
			}else if(id == '2'){
				tr += '<tr><td>'+v.leagueNumber+'</td><td><a class="league" href="#" style="background:'+v.color+';">'+v.leagueName+'</a></td>'+
				  '<td>'+create_class.axyformatTime(v.stopTime)+'</td><td class="text_r"><a href="#">'+ht+'</a></td><td>'+v.giveBall+'</td><td class="text_l"><a href="#">'+vt+'</a></td>'+
				  '<td>('+v.hometeamSemiScore+')'+v.hometeamFullScore+'</td><td>'+v.zjqSingleRe+'</td><td></td>'+
				  '<td><font color="red">'+v.zjqSinglePr+'</font></td><td></td></tr>';
			}else if(id == '3'){
				tr += '<tr><td>'+v.leagueNumber+'</td><td><a class="league" href="#" style="background:'+v.color+';">'+v.leagueName+'</a></td>'+
				  '<td>'+create_class.axyformatTime(v.stopTime)+'</td><td class="text_r"><a href="#">'+ht+'</a></td><td>'+v.giveBall+'</td><td class="text_l"><a href="#">'+vt+'</a></td>'+
				  '<td>('+v.hometeamSemiScore+')'+v.hometeamFullScore+'</td><td>'+v.bfSingleRe+'</td><td></td>'+
				  '<td><font color="red">'+v.bfSinglePr+'</font></td><td></td></tr>';
			}else if(id == '4'){
				tr += '<tr><td>'+v.leagueNumber+'</td><td><a class="league" href="#" style="background:'+v.color+';">'+v.leagueName+'</a></td>'+
				  '<td>'+create_class.axyformatTime(v.stopTime)+'</td><td class="text_r"><a href="#">'+ht+'</a></td><td>'+v.giveBall+'</td><td class="text_l"><a href="#">'+vt+'</a></td>'+
				  '<td>('+v.hometeamSemiScore+')'+v.hometeamFullScore+'</td><td>'+v.bqcSingleRe+'</td><td></td>'+
				  '<td><font color="red">'+v.bqcSinglePr+'</font></td><td></td></tr>';
			}
		})
		
		var cs = id == '0' ?  '.ld_tbody' : '.xiang_x'; 
		
		tr += "<tr><td colspan='21' class='rettxt'>注：\"奖金\"仅指比赛截止投注时的最终变化的单关赔率，仅供参考。 </td></tr>";
		
		$(tr).appendTo(cs);
		
		$('.loding').hide();
	});
}


$(function(){

	if(beginTime!="null"){
		$('#startDate').val(ftTime(beginTime));
	}
	showAuxiliary(KO.U.Pages,KO.U.Every);
	var lotIndex = id == 0 ? 0 : 1;
	$('.ld_table').eq(lotIndex).show();
	$('.rs_c_m > li').eq(id).addClass('c_m_xz');
})
function ftTime(time){
	var year=time.substr(0,4);
	var month=time.substr(4,2);
	var day=time.substr(6);
	return year+"-"+month+"-"+day;
}