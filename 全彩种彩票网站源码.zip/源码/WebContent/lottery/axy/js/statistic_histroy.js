﻿  		var pageSum="";
		var date="";
		var userNickName="all";
		var status="1";
  		function load(){
  			var dates = new Date();
  			for(var i=0;i<150;i++){
  				if(i==0){
  					dates.setDate(dates.getDate());
  				}else{
  					dates.setDate(dates.getDate()-1);
  				}
  				var year = dates.getUTCFullYear();
  				var month=dates.getMonth()+1;
  				var day= dates.getDate();
  				if(month<10){
  					month="0"+month;
  				}
  				if(day<10){
  					day="0"+day;
  				}
  				val=year+""+month+""+day;
  				
  				var option ="";
  				if(i==1)
  				{
  					option ="<option value="+val+" selected='selected'>"+year+'-'+month+'-'+day+"期</option>";
  				}else
  				{
  					option ="<option value="+val+">"+year+'-'+month+'-'+day+"期</option>";
  				}
  				$('#time').append(option);
  			}
  			date=$('#time').val();
  			ggtj_sum(date,userNickName,status);
  		}
  		var title_id="yjj";
  		function titleOnClick(_this){
  			if($(_this).attr('id')!=title_id){
  				var id="#"+title_id;
  				$(id).removeClass();
  				$(id).addClass('centre_div_ul02_a');
  				$(_this).removeClass();
  				$(_this).addClass('centre_div_ul02_text');
  				title_id=$(_this).attr('id');
  			}
  		}
  		var McN_Map={
			'1':'1串1',
			'2':'2串1',
			'3':'3串1',
			'4':'3串3',
			'5':'3串4',
			'6':'4串1',
			'7':'4串4',
			'8':'4串5',
			'9':'4串6',
			'10':'4串11',
			'11':'5串1',
			'12':'5串5',
			'13':'5串6',
			'14':'5串10',
			'15':'5串16',
			'16':'5串20',
			'17':'5串26',
			'18':'6串1',
			'19':'6串6',
			'20':'6串7',
			'21':'6串15',
			'22':'6串20',
			'23':'6串22',
			'24':'6串35',
			'25':'6串42',
			'26':'6串50',
			'27':'6串57',
			'28':'7串1',
			'29':'7串7',
			'30':'7串8',
			'31':'7串21',
			'32':'7串35',
			'33':'7串120',
			'34':'7串127',
			'35':'8串1',
			'36':'8串8',
			'37':'8串9',
			'38':'8串28',
			'39':'8串56',
			'40':'8串70',
			'41':'8串247',
			'42':'8串255'
			
		},
		DC_McN_Map={
			'1':'1串1','2':'2串1',
			'3':'2串3','4':'3串1','5':'3串4',
			'6':'3串7','7':'4串1','8':'4串5','9':'4串11','10':'4串15',
			'11':'5串1','12':'5串6','13':'5串16','14':'5串26','15':'5串31','16':'6串1','17':'6串7',
			'18':'6串22','19':'6串42','20':'6串57','21':'6串63','22':'7串1','23':'8串1','24':'9串1','25':'10串1','26':'11串1','27':'12串1',
			'28':'13串1','29':'14串1','30':'15串1'
		},
		lotteryType={
			'501':'竞彩胜平负','502':'竞彩比分','503':'竞彩总进球','504':'竞彩半全场','511':'竞彩让球胜平负','509':'竞足混投','510':'竞蓝混投','505':'竞彩胜负','506':'竞彩让分胜负','507':'竞彩胜分差','508':'竞彩大小分','102':'足彩胜负彩','103':'足彩任9','106':'足彩4场进球','107':'足彩6场半全','301':'单场胜平负','302':'单场上下单双','303':'单场总进球数','304':'单场比分','305':'单场半全场'
		};
		//过关统计总记录数
  		function ggtj_sum(date,userNickName,status){
  			userNickName=encodeURI(userNickName);
  			var urls = urll;
	  		$.ajax({
					url:urls+'/GuoguantjAction.do?action=ggtjSum&date='+date+'&userNickName='+userNickName+'&status='+status+'&r='+Math.random(),
					type:'POST',
					error:function(){alert('链接有误！！')},
					success:function(w_list){
						var sum=eval("("+w_list+")");
						var sum_items=sum.items;
						pageSum=Math.ceil(parseInt(sum_items[0].pageNum)/30);
						$('#text_sum').text("共"+pageSum+"页，"+sum_items[0].pageNum+"记录");
						changePage(now_page);
						ycj_tj(date,userNickName,status,now_page);
					}
			});
  		}
  		//获得记录
  		var it='';
  		function ycj_tj(date,userNickName,status,pageNum){
  			$('.contents').empty();
  			var urls = urll;
  			userNickName=userNickName;
  		
  			var _url=urls+'/GuoguantjAction.do?action=ggtj&date='+date+'&userNickName='+userNickName+'&status='+status+'&pageNum='+pageNum+'&r='+Math.random();
  			$.ajax({
					url:urls+'/GuoguantjAction.do?action=ggtj&date='+date+'&userNickName='+userNickName+'&status='+status+'&pageNum='+pageNum+'&r='+Math.random(),
					type:'POST',
					error:function(){alert('链接有误！！')},
					success:function(w_list){
						var list=eval("("+w_list+")");
						it=list.items;
						loadTab(it);
					}
			});
  		}
  		//已成交过关统计
  		function y_ggtj(_this){
			userNickName="all";
			status="1";
			now_page=1;
			ggtj_sum(date,userNickName,status);
			titleOnClick(_this);
  		}
  		//未成交过关统计
  		function w_ggtj(_this){
			userNickName="all";
			status="2";
			now_page=1;
			ggtj_sum(date,userNickName,status);
			titleOnClick(_this);
  		}
  		//我的过关
  		function my_ggtj(_this){
			userNickName="all";
			status="0";
			now_page=1;
			ggtj_sum(date,userNickName,status);
			titleOnClick(_this);
  		}
  		
  		//分页
  		function fenPage(startPage,endPage,nowPage){
  			$('#select_page').find('tr').empty();
  			for(var i=startPage;i<=endPage;i++){
  				var td="";
  				if(i==nowPage){
  					td="<td><a id="+i+" href='#' onClick='javascript:clickPage(this)' class='selPage'>"+i+"</a></td>";
  				}else{
  					td="<td><a id="+i+" href='#' onClick='javascript:clickPage(this)' class='w_selPage'>"+i+"</a></td>";
  				}
  				$('#select_page').find('tr').append(td);
  			}
  		}
  		//分页点击
  		var now_page="1";//第几页
  		var start_page="";//开始的页数
  		var end_page="";//最后页数
  		function clickPage(_this){
  			now_page=$(_this).attr('id');
  			changePage(now_page);
  			ycj_tj(date,userNickName,status,now_page);
  		}
  		function changePage(now_page){
  			if(pageSum<=9){
  				fenPage(1,pageSum,now_page);
  			}
  			else if(now_page<6){
  				fenPage(1,9,now_page);
  			}
  			else{
  				if((parseInt(now_page)+4)>=pageSum){
  					start_page=parseInt(pageSum)-8;
  					end_page=parseInt(pageSum);
  				}else{
  					start_page=parseInt(now_page)-4;
  					end_page=parseInt(now_page)+4;
  				}
  				fenPage(start_page,end_page,now_page);
  			}
  		}
  		//首页
  		function firstPage(){
  			now_page="1";
  			if(pageSum<=9){
  				fenPage(1,pageSum,now_page);
  			}else{
  				fenPage(1,9,now_page);
  			}
  			ycj_tj(date,userNickName,status,now_page);
  		}
  		//上一页
  		function backPage(){
  			if(now_page=="1"){
  				return;
  			}
  			now_page=parseInt(now_page)-1;
  			changePage(now_page);
  			ycj_tj(date,userNickName,status,now_page);
  		}
  		//下一页
  		function nextPage(){
  			if(now_page==pageSum){
  				return;
  			}
  			now_page=parseInt(now_page)+1;
  			changePage(now_page);
  			ycj_tj(date,userNickName,status,now_page);
  		}
  		//尾页
  		function endPage(){
  			now_page=pageSum;
  			if(pageSum<=9){
  				fenPage(1,pageSum,now_page);
  			}else{
  				var temp=now_page-8;
  				fenPage(temp,now_page,now_page);
  			}
  			ycj_tj(date,userNickName,status,now_page);
  		}
  		//GO
  		function goPage(){
  			var tempPage=$('#text_page').val();
  			if(tempPage>pageSum||tempPage<1){
  				return;
  			}else{
  				now_page=tempPage;
  			}
  			if(pageSum<=9){
  				fenPage(1,pageSum,now_page);
  			}else{
  				var temp=now_page-8;
  				fenPage(temp,now_page,now_page);
  			}
  			ycj_tj(date,userNickName,status,now_page);
  		}
  		//排序
  		function gg_sort(field,desc){
  			
  			loadTab(it);
  		}
  		//加载表头
  		function loadTabHeader(){
 				$('#content_tab').empty();
 				$('.loding').show();
				var tr="<tr height='24'>"+
	    		"<td align='center'>排序</td>"+
	    		"<td align='center'>发起人</td>"+
	    		"<td align='center'><a href='#' onClick='javascript:gg_sort('bet','asc')' class='paixu'>战绩</a></td>"+
	    		"<td align='center'>方案详情</td>"+
	    		"<td align='center'>投注类型</td>"+
	    		"<td align='center'>倍数</td>"+
	    		"<td align='center'><a href='#' class='paixu' onClick='javascript:gg_sort('otherInfo','asc')'>命中场次</a></td>"+
	    		"<td align='center'>过关方式</td>"+
	    		"<td align='center'>中奖信息</td>"+
	    		"<td align='center'><a href='#' onClick='javascript:gg_sort('bet','desc')' class='jj_paixu'>税前奖金</a></td>"+
	    		"<td align='center'>自动跟单</td>"+
	    		"</tr>";
	    		$('#content_tab').append(tr);			
  		}
  		//加载表格内容
  		function loadTab(it){
  						var style="";
						for(var i=0;i<it.length;i++){
							if(i%2==0){
								style='background:#F4F9FE';
							}else{
								style='background:#fff';
							}
							var betWays=it[i].betWay.split(",");
						
							var record_ZJ = create_class.Record_zhanJ(it[i].countPrice,it[i].uId);
						
							var betWay='';
							for(var j=0;j<betWays.length;j++){
								if(it[i].lotteryType=='102' || it[i].lotteryType=='103' || it[i].lotteryType=='106' || it[i].lotteryType=='107' ){
									betWay = betWays[j] == '1' ? '单式' : '复试';
								}else{
									if(j==betWays.length-1){ 
										
										if(it[i].lotteryType=='301' || it[i].lotteryType=='302' || it[i].lotteryType=='303' || it[i].lotteryType=='304' || it[i].lotteryType=='305')
										{
											betWay=betWay+DC_McN_Map[betWays[j]];
										}else{
											betWay=betWay+McN_Map[betWays[j]];
										}
										
									}else{
										
										if(it[i].lotteryType=='301' || it[i].lotteryType=='302' || it[i].lotteryType=='303' || it[i].lotteryType=='304' || it[i].lotteryType=='305')
										{
											betWay=betWay+DC_McN_Map[betWays[j]]+",";
										}else{
											betWay=betWay+McN_Map[betWays[j]]+",";
										}
										
										
									}
								}
							}
							var win = '' , mz = 0;
							
							/*var betNum = it[i].betNum.split("//");
							var onNum = it[i].onNum.split("/");
						
							$(betNum).each(function(s,v){
							
								var n = betNum[s].split(',')[1];
									n = n.split('/');
								
								$(n).each(function(m,t){
									
									if(n[m] == onNum[s].split(',')[1]){
									
										mz++;
									}
									
								});	
							});*/
							
							it[i].otherInfo!='' ? win = '<font color="red">'+it[i].otherInfo+'</font>' :  win = '未中奖';
							
							it[i].uName = it[i].manner == 1 ? it[i].uName.charAt(0)+'*****' : it[i].uName;
							tr="<tr style="+style+" height='28'>"+
    							"<td align='center'>"+(i+1)+"</td>"+
    							"<td align='left'><a href='javascript:void(0)'>"+it[i].uName+"</a></td>"+
    							"<td align='center' width='10%'>"+record_ZJ+"</td>"+
    							"<td align='center'><a href='../useraccount/serNoScheme_details.jsp?id="+it[i].transCode+"' target='_blank'>"+it[i].transCode+"</a></td>"+
    							"<td align='center'>"+lotteryType[it[i].lotteryType]+"</td>"+
    							"<td align='center'>"+it[i].betMultiples+"倍</td>"+
    							/*"<td align='center'>"+mz+"场</td>"+*/
    							"<td align='center'>"+betWay+"</td>"+
    							"<td align='center'>"+win+"</td>"+
    							"<td align='right'>"+it[i].zjye+"元</td>"+
    							"<td align='center'><a href='../useraccount/index.jsp?l=1&url=usertouzhu/anther_single.jsp&u="+it[i].uName+"' class='dz_gd' target='_blank'></a></td>"+
    						"</tr>";
    						$('.contents').append(tr);
						}	
						$('.loding').hide();
  		}
  		function selDate(){
  			date=$('#time').val();
  			ggtj_sum(date,userNickName,status);
  		}
  		
  		
  		
  		
 /***********战绩详情***********/
 
KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="10";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging(ey,pages,userid){
		var e_y_a='',t_s=ey == 1 ? KO.countEvery : KO.U.Every;
		var countY = Math.ceil(ey);
		var next=parseInt(pages) >= countY ? countY : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var startY=0,endY=ey > 8 ? 7 : ey;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=ShowBuyLotteryDate('1','"+KO.U.Every+"','"+userid+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+fist+"','"+KO.U.Every+"','"+userid+"') title='上一页' class='pre'></a>";
		var cls='';
		
		for(var e=startY;e<endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=ShowBuyLotteryDate("'+(e+1)+'","'+KO.U.Every+'","'+userid+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=ShowBuyLotteryDate('"+next+"','"+KO.U.Every+"','"+userid+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+countY+"','"+KO.U.Every+"','"+userid+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData('"+userid+"') value='GO'></span>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData(userid){
	
	var ps=$("#govalue").val();
	ShowBuyLotteryDate(ps,KO.U.Every,userid);
}


var G_setting = {
	'formatTime':function(str){return str.replace(/[-]/g,"")+"000000";},
	'loadDate':function(d,z){
		var month=(d.getMonth()+1) < 10 ? '0'+(d.getMonth()+1) : (d.getMonth()+1);
		var h=d.getDate() < 10 ? '0'+(d.getDate()) : (d.getDate());
		if(z == 's') h = "01";
		return d.getFullYear()+'-'+month+'-'+h;
	},
	'numberFixed':function(numStr){
		return parseFloat(numStr).toFixed(2);
	},
	'string2timeHS':function(s){return s.substring(0, 4) + "-" + s.substring(4, 6) + "-"+ s.substring(6, 8) + " " + s.substring(8, 10) + ":"+ s.substring(10, 12) + ":" + s.substring(12, 14);},
	'lotName':{'501':'胜平负','502':'总进球','503':'比分','504':'半全场','505':'胜负','506':'让分胜负','507':'胜负差','508':'大小分'},
	'status':{'0':'进行中','1':'已结束','2':'已取消'}
},NcN_Map={'1':'1串1','2':'2串1','3':'3串1','4':'3串3','5':'3串4','6':'4串1',
	'7':'4串4','8':'4串5','9':'4串6','10':'4串11','11':'5串1','12':'5串5','13':'5串6',
	'14':'5串10','15':'5串16','16':'5串20','17':'5串26','18':'6串1','19':'6串6','20':'6串7',
	'21':'6串15','22':'6串20','23':'6串22','24':'6串35','25':'6串42','26':'6串50','27':'6串57'
};
function ShowBuyLotteryDate(p,e,userid){

	$('.loding').show();
	var gameCode  = '501'; 
	var status    = KO.$('lotType').value;
	var beginTime = G_setting.formatTime(KO.$('startDate').value);
	var endTime   = KO.$('endDate').value.replace(/[-]/g,"");
	var c_j=parseInt(KO.$('endDate').value.substring(5,7))-parseInt(KO.$('startDate').value.substring(5,7));
	var t_c=parseInt(G_setting.loadDate(KO.U.d,'s').substring(5,7))-2;
	t_c = t_c < 10 ? '0'+t_c : t_c;
	etm =  KO.U.d.getFullYear()+""+t_c+"01000000";
	
	if(c_j > 3) {
		
		if(!confirm("您选择的时间段超过了3个月，超出的时间没有记录，是否继续")){
			
			return;
		}
	}
	
	KO.U.Pages = p;
	KO.U.Every = '15';
	
	$.getJSON('../../letoula/data/results_the_Zhanji.jsp?r='+Math.random(),{'userid':userid,'gameid':gameCode,'status':status,'beginTime':beginTime,'endTime':endTime,'pages':KO.U.Pages,'every':KO.U.Every},function(list){
		var tr = '';
		
		var items = list.items;
		if(items.length == 0) tr = '<tr><td colspan="10">没有找到相关的记录！</td></tr>';
		$('.hot_body,.f_an_page,#rc_t_ty').empty();
		KO.countEvery=items.length;
		var ey=parseInt(list.recod)/parseInt(KO.U.Every);
		ey = ey < 1 ? 1 : ey;
		paging(ey,p,userid);
		
		var x = 1;
		for(var s=0; s<items.length; s++)
		{
			
			var yl = G_setting.numberFixed(items[s].zjPrice - items[s].rgPrice);
			yl = yl < 0 ? 0 : yl; 
			if(yl == 0) continue;
			var hb = G_setting.numberFixed(yl / items[s].rgPrice);
				tr+='<tr><td>'+x+'</td><td>'+G_setting.string2timeHS(items[s].starTime)+'</td><td>'+lotteryType[items[s].gameid]+'</td>'+
				'<td>￥<font color="red">'+G_setting.numberFixed(items[s].rgPrice)+'</font></td><td>￥<font color="red">'+G_setting.numberFixed(items[s].zjPrice)+'</font></td>'+
				'<td>￥<font color="red">'+yl+'</font></td><td>'+hb+'倍</td><td><a href="../useraccount/scheme_details.jsp?trnNumber='+items[s].trnNumber+'&rgPrice='+items[s].rgPrice+'&id='+items[s].id+'&gameCode='+items[s].gameid+'" target="_blank" class="blue">详情</a></td><td>'+items[s].status+'</td>';
			x++;
		}

		$(tr).appendTo('.hot_body');
		$('.loding').hide();
	});
	
	
}
 