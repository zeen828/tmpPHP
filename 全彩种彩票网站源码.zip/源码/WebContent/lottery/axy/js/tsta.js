
KO.t_bg='';
KO.tr_c='th_even';
KO.Pages="1";
KO.Every="30";
KO.countEvery="30";
KO.S = url+'/letoula/jczq/project_list.jsp?gameid='+KO.gameCode;
KO.SL = url+'/letoula/jclq/project_list.jsp?gameid='+KO.gameCode;
KO.gameid = '501';

var McN_Map={
	'1':'1串1','2':'2串1',
	'3':'3串1','4':'3串3','5':'3串4',
	'6':'4串1','7':'4串4','8':'4串5','9':'4串6','10':'4串11',
	'11':'5串1','12':'5串5','13':'5串6','14':'5串10','15':'5串16','16':'5串20','17':'5串26',
	'18':'6串1','19':'6串6','20':'6串7','21':'6串15','22':'6串20','23':'6串22','24':'6串35','25':'6串42','26':'6串50','27':'6串57',
	'28':'7串1','29':'7串7','30':'7串8','31':'7串21','32':'7串35','33':'7串120','34':'7串127',
	'35':'8串1','36':'8串8','37':'8串9','38':'8串28','39':'8串56','40':'8串70','41':'8串247','42':'8串255'
},DC_McN_Map={
	'1':'1串1','2':'2串1',
	'3':'2串3','4':'3串1','5':'3串4',
	'6':'3串7','7':'4串1','8':'4串5','9':'4串11','10':'4串15',
	'11':'5串1','12':'5串6','13':'5串16','14':'5串26','15':'5串31','16':'6串1','17':'6串7',
	'18':'6串22','19':'6串42','20':'6串57','21':'6串63','22':'7串1','23':'8串1','24':'9串1','25':'10串1','26':'11串1','27':'12串1',
	'28':'13串1','29':'14串1','30':'15串1'
},Game_Map={
	'1':'单式','2':'复式'
},setting_open={
	'0':'公开','1':'保密'
},setting_status={
	'-3':'系统撤单','-2':'个人撤单','-1':'废票','0':'发起成功','1':'处理成功','2':'打印成功','3':'出票成功','4':'已搅奖','5':'已派奖'
},setting_manner={
	'1':'过关代购','2':'合买发起'
};

function mouse_over(_this){
	KO.t_bg=$(_this).find('td').css("backgroundColor");
	$(_this).find('td').css("backgroundColor",'white');
	
}
function mouse_out(_this){
	$(_this).find('td').css("backgroundColor",KO.t_bg);
}
function mltOnkeyUp(){
		
		var _this=arguments[0],
			val=parseInt(_this.value);
			
		var fs=parseInt(_this.getAttribute('f_S'));
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || val <= 0 || val>fs){
			
		   _this.value=1;
		   if(val>fs){
		   		
		   		_this.value=fs;
		   }
		}
}

function Chipped_in_submit(_this,Trading){
	
	var copies=$(_this).parent().siblings().find('.rec_text').val(); 
	
	$.getJSON("../data/Chipped_in_submit.jsp?r="+Math.random(),{'gameid':KO.gameCode,'Trading':Trading,'copies':copies},function(result){
		
		if(result.result=='0000'){
			create_class.seaDetails('blk2','s','您好！您参与合买成功！','success',KO.S);
			
		}else{
			create_class.seaDetails('blk2','s','您好！'+result.result+'','error',KO.S);
		}
	})
	
}
function over_t(l){
		
		rl = l == 'l' ? KO.SL : KO.S;
		create_class.seaDetails('blk2','h','','success',rl);
		
	}
function details_submit(as){
	
	var parmas=as.getAttribute('sb').split(',');
	KO.$('userName').value  =	 parmas[0];
	KO.$('muliptile').value =	 parmas[1];
	KO.$('Copis').value     =    parmas[2];
	KO.$('copisPrice').value=    parmas[3];
	KO.$('bdCopies').value  =    parmas[4];
	KO.$('progress').value  =	 parmas[5];
	KO.$('tzway').value     =	 parmas[6];
	KO.$('moneyFw').value   =    parmas[7];
	KO.$('csm').value   	=    parmas[8];
	KO.$('starTime').value  =    parmas[9];
	KO.$('endTime').value   =    parmas[10];
	KO.$('id').value   		=    parmas[11];
	KO.$('Trading').value   =    parmas[12];
	KO.$('sycopies').value  =    parmas[13];
	KO.$('rgCopis').value   =    parmas[14];
	KO.$('isopen').value   =     parmas[15];
	KO.$('listform').submit();
}
function paging(ey,pages){
		var e_y_a='';
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var countY = Math.ceil(ey);
		var startY=0,endY=countY-1 > 8 ? 7 : countY;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=showData('1','"+KO.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=showData('"+fist+"','"+KO.Every+"') title='上一页' class='pre'></a>";
		var cls='';

		for(var e=startY;e<endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showData("'+(e+1)+'","'+KO.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showData('"+next+"','"+KO.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=showData('"+countY+"','"+KO.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData() value='GO'></span><font color='#0f3f94'>共"+countY+"页,"+(ey*parseInt(KO.countEvery))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){

		var pg=parseInt(_this.value),
		reg=/^(0|[1-9][0-9]*)$/g;
		if(pg > ey) {
			_this.value=ey;
		}
		
		if(!reg.test(_this.value) || pg <= 0){
		   _this.value=1;
		}
		
}

function loadPageData(){
	
	var ps=$("#govalue").val();
	showData(ps,KO.Every);
}

function showData(pages,every){
	
	$('.loding').show();
	KO.Pages=pages;
	KO.Every=every;
	var date = $('#seltime').val();
	var usernikename = $('#insertUsername').val();
	if(usernikename == '输入用户名查询' || usernikename==''){
		usernikename = 'all';
	}
	usernikename = encodeURI(usernikename);
	var status = '5';
	$("#testCenterTab > tbody").empty();
	$.getJSON("../data/statdata.jsp?r="+Math.random(),{'date':date,'gameid':KO.gameid,'usernikename':usernikename,'status':status,'pages':KO.Pages,'every':KO.Every},function(items){
		var tr='';
		$('#rc_t_ty,.f_an_page').empty();
		var it=items.items;
		var ey=parseInt(items.recod)/parseInt(KO.Every);
		ey = ey < 1 ? 1 : ey;
		if(ey <= 1 && it.length<30){
			KO.countEvery = it.length;
		}else{
			KO.countEvery ="30";
		}
		paging(ey,pages);
		
		
		 $(it).each(function(i,v){
		 		
		 		var tzway='';
		var way=v.betway.split(',');
		var gameid = v.gameid;
		
				if(gameid == '301' || gameid == '302' || gameid == '303' || gameid == '304' || gameid == '305'){
		 			
		 			for(var s=0;s<way.length;s++){
		 				tzway+=DC_McN_Map[way[s]]+'/';
		 			}
		 			
		 			
		 		}else if(gameid == '501' || gameid == '502' || gameid == '503' || gameid == '504' || gameid == '505' || gameid == '506' || gameid == '507' || gameid == '508'){
		 			for(var s=0;s<way.length;s++){
		 				tzway+=McN_Map[way[s]]+'/';
		 			}
		 		}
		 		
		 		tzway=tzway.substring(0,tzway.lastIndexOf('/'));
		 		
		 		var trcolor = ((i+1) % 2) == 0 ? "#f9f9f9" : "#f2f2f2";
		 		v.status = setting_status[v.status];
		 		v.manner = setting_manner[v.manner];
		 		var isopen=v.isopen;
		 		var serino = '<a href="../useraccount/serNoScheme_details.jsp?id='+v.serino+'" class="dingzhi" target="_blank">'+v.serino+'</a>';
		 		if(isopen!=0){
		 			v.usernikename = v.usernikename.substring(0,2)+"***";
		 			serino = v.serino;
		 			v.bets = '--';
		 		}
		 		tr+="<tr style='background-color:"+trcolor+"'>"+
    				"<td>"+(i+1)+"</td><td><a href='#'>"+v.usernikename+"</a></td><td>"+serino+"</td>"+
    				"<td>"+v.manner+"</td>"+
    				"<td title="+tzway+">"+tzway+"</td><td>"+v.bets+"</td><td class='moneyred'>"+v.zjye+"</td>"+
    				"<td><a href='#'>"+v.status+"</a>    <a href='#' class='dingzhi'>定制</a></td></tr>";
    			
    				
		 });
		 
		 if(it.length == 0){
		 	tr = '<tr><td align="center" colspan="8">您好！没有查找到相关中奖纪录！</td></tr>';
		 }
		 $(tr).appendTo("#testCenterTab > tbody");
		 $('.loding').hide();
	});
}

$(function(){
			var dates = new Date();
  			for(var i=1;i<=7;i++){
  				if(i==0){
  					dates.setDate(dates.getDate());
  				}else{
  					dates.setDate(dates.getDate()-1);
  				}
  				var year = dates.getUTCFullYear();
  				var month=dates.getMonth()+1;
  				var day= dates.getDate();
  				if(month<10){
  					month="0"+month;
  				}
  				if(day<10){
  					day="0"+day;
  				}
  				val=year+""+month+""+day;
  				
  				var option ="";
  				if(i==0)
  				{
  					option ="<option value="+val+" selected='selected'>"+year+''+month+''+day+"</option>";
  				}else
  				{
  					option ="<option value="+val+">"+year+''+month+''+day+"</option>";
  				}
  				$('#seltime').append(option);
  			}
  			
	$('.ttc_menu li a').click(function(){
		$('.ttc_menu li a').removeClass('yesw');
		$(this).addClass('yesw');
		KO.gameid = $(this).attr('g');
		switch(KO.gameid){
			case '501': $('.lname').text('让球胜平负中奖查询');$('.zjdc_logo').removeClass().addClass('zjjczq_logo'); break;
			case '502': $('.lname').text('比分中奖查询');$('.zjdc_logo').removeClass().addClass('zjjczq_logo'); break;
			case '503': $('.lname').text('总进球数中奖查询');$('.zjdc_logo').removeClass().addClass('zjjczq_logo'); break;
			case '504': $('.lname').text('半全场中奖查询');$('.zjdc_logo').removeClass().addClass('zjjczq_logo'); break;
			case '505': $('.lname').text('胜负中奖查询'); $('.zjdc_logo').removeClass().addClass('zjjczq_logo');break;
			case '506': $('.lname').text('让分胜负中奖查询'); $('.zjdc_logo').removeClass().addClass('zjjczq_logo');break;
			case '507': $('.lname').text('胜负差中奖查询');$('.zjdc_logo').removeClass().addClass('zjjczq_logo'); break;
			case '508': $('.lname').text('大小分中奖查询');$('.zjdc_logo').removeClass().addClass('zjjczq_logo'); break;
			case '301': $('.lname').text('单场让球胜平负中奖查询');$('.zjjczq_logo').removeClass().addClass('zjdc_logo'); break;
			case '302': $('.lname').text('单场上下单双中奖查询'); $('.zjjczq_logo').removeClass().addClass('zjdc_logo');break;
			case '303': $('.lname').text('单场总进球数中奖查询');$('.zjjczq_logo').removeClass().addClass('zjdc_logo'); break;
			case '304': $('.lname').text('单场比分中奖查询');$('.zjjczq_logo').removeClass().addClass('zjdc_logo'); break;
			case '305': $('.lname').text('单场半全场中奖查询'); $('.zjjczq_logo').removeClass().addClass('zjdc_logo');break;
			case '102': $('.lname').text('足彩十四场中奖查询');$('.zjjczq_logo').removeClass().addClass('zjdc_logo'); break;
			case '103': $('.lname').text('足彩任选九中奖查询'); $('.zjjczq_logo').removeClass().addClass('zjdc_logo');break;
			case '106': $('.lname').text('足彩六场半全场中奖查询');$('.zjjczq_logo').removeClass().addClass('zjdc_logo'); break;
			case '107': $('.lname').text('足彩四场进球中奖查询');$('.zjjczq_logo').removeClass().addClass('zjdc_logo'); break;
		}
		showData("1","30")
	});
	$('.page a').click(function(){
		$(this).siblings().removeClass();
		$(this).addClass('an_x_z');
		KO.Every=$(this).text();
		showData(KO.Pages,KO.Every,'rgCopis','asc');
	})
	$('.p_x').click(function(){
		
		$('.des_time').removeClass().addClass('asc_pub');
		$(this).find('span').removeClass('asc_pub').addClass('des_time');
	})
	
	showData(KO.Pages,KO.Every);

	window.onscroll=function(){
		var num_scroll_top = 0;
          if(document.body.scrollTop){
              num_scroll_top=document.body.scrollTop;
            }
            else{
              num_scroll_top=document.documentElement.scrollTop;
            }    
          $("#bd").css("top",num_scroll_top);
	}
})