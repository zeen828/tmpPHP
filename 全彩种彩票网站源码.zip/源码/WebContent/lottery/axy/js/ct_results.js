function getResults(lots,issue){
	$.getJSON('../data/ct_results.jsp?r='+Math.random(),{'lot':lots,'issue':issue},function(JSON){
			var items = JSON.items;
			
			$('.xiang_x').empty();
			$('.ld_table').eq(1).show();
			$.each(items,function(i,v){
				var spValue=v.spValue.split(" ");
				var y_color='';
				var p_color='';
				var f_color='';
				if(v.result=='3'){
					y_color='red';
				}else if(v.result=='1'){
					p_color='red';
				}else{
					f_color='red';
				}
				var tr="<tr>"+
							"<td>"+v.againstId+"</td>"+
							"<td style='background:"+v.color+"'>"+v.matchName+"</td>"+
							"<td>"+v.homeTeam+"</td>"+
							"<td>"+formate(v.dsStopDate)+"</td>"+
							"<td>"+v.guestTeam+"</td>"+
							"<td>"+v.result+"</td>"+
							"<td style='color:"+y_color+"'>"+spValue[0]+"</td>"+
							"<td style='color:"+p_color+"'>"+spValue[1]+"</td>"+
							"<td style='color:"+f_color+"'>"+spValue[2]+"</td>"+
					   "</tr>";
				$('.ld_table').eq(1).append(tr);	   
			});
	});
}
//获取当前期号
function getNowIssue(lots){
	$.getJSON('../data/now_issue.jsp?r='+Math.random(),{'lot':lots},function(JSON){
		var items=JSON.items;
		loadIssue(items[0].issue);
		getResults(lot,items[0].issue);
	})
}
//期号加载
function loadIssue(issue){
	$('#issue').empty();
	for(var i=0;i<20;i++){
		var issues = parseInt(issue)-i;
		var option="<option value="+issues+">"+issues+"期&nbsp;&nbsp;&nbsp;</option>"
		$('#issue').append(option);
	}
}
//日期格式化
function formate(time){
	var year=time.substr(0,4);
	var month=time.substr(4,2);
	var day=time.substr(6,2);
	return year+"-"+month+"-"+day;
}
//期号选择
function changeSelet(_this){
	getResults(lot,$(_this).val());
}
//页面加载
$(function(){
	$('.rs_c_m > li').eq(0).addClass('c_m_xz');
	getNowIssue(lot);
})
//玩法选择
var _id=0;
function seletLot(lots,id){
	$('.rs_c_m > li').eq(_id).removeClass('c_m_xz');
	$('.rs_c_m > li').eq(id).addClass('c_m_xz');
	_id=id;
	lot=lots;
	getNowIssue(lot);
}


