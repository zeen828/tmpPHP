﻿

var hid="";
var aid="";
var hostName="";
var awayName="";
var ln="";
$(function(){
	
	var xmlAry = xmlDate.split('%');

	var data = eval("(" + xmlAry[3] + ")");
	var ha=xmlAry[4].split(",");
	hid=ha[0];
	aid=ha[1];
	ln=ha[2];
	$(data.items).each(function(i,v){
		$('.zd').text(v.hn);
		$('.kd').text(v.an);
		hostName=v.hn;
		awayName=v.an;
		$('#host').text(v.hn);
		$('#away').text(v.an);
		$('.m_tl').html("<font>"+v.hn+"(主)</font> VS <font>"+v.an+"</font>");
		$('.tl_tx').text(v.dt);
	})

	
	var odds   = createXml(xmlAry[0]);  //即时赔率
	var league = createXml(xmlAry[1]);	//联赛积分
	var analysis = createXml(xmlAry[2]); //赛事分析
	jz_data.da_odds(odds);
	jz_data.da_league(league);
	jz_data.da_analysis(analysis);
	addLeague(league);
	openDiv();
})

function formatTime(time){
	var times=parseInt(time.replace(/[-]/g,"").replace(" ", "").replace(/[:]/g,""));
	return times;
}

var jz_data = {
	'da_odds':function(odds){
		
		var company = $(odds).find('matchlist > match > company');
		var tr='',tro='';
		for(var i=0; i < company.length ; i++)
		{
			var tdc='',tdj='';
			var tdoc='',tdoj='';
			var odd = company[i].getElementsByTagName('odd');
			var companyName = company[i].getAttribute('cn');
			if(companyName!="钱德勒-伟德"&&companyName!="皇冠"&&companyName!="立博"&&companyName!="bet365"&&companyName!="澳门"){
				continue;
			}
			var anArr= new Array();
			var epArr= new Array();
			var anIndex=0;
    		var epIndex=0;
			for(var s=0; s<odd.length ; s++)
			{
    			var t = odd[s].getAttribute('t');
    			if(t == 'an'){
    				anArr[anIndex]= new Array(this.numberFixed(odd[s].getAttribute('o')),req[parseInt(odd[s].getAttribute('h'))],this.numberFixed(odd[s].getAttribute('u')),formatTime(odd[s].getAttribute('time')));
    				anIndex=anIndex+1;
    			}else if(t == 'ep'){
    				epArr[epIndex]=new Array(odd[s].getAttribute('o'),odd[s].getAttribute('h'),odd[s].getAttribute('u'),formatTime(odd[s].getAttribute('time')));
    				epIndex=epIndex+1;
    			}
    			
			}
			var tempTime=0;
			for(var j=0;j<anArr.length;j++){
				if(tempTime==0){
					tdc="<tr><td rowspan='2' class='s_blue work'>"+companyName+"</td><td>初</td><td>"+anArr[j][0]+"</td><td>"+anArr[j][1]+"</td>"+
    					"<td>"+anArr[j][2]+"</td></tr>";
					tdj="<tr><td class='h_red'>即</td><td class='s_blue'>"+anArr[j][0]+"</td><td class='s_blue'>"+anArr[j][1]+"</td><td class='s_blue'>"+anArr[j][2]+"</td></tr>";
    				
				}else{
					if(tempTime>parseInt(anArr[j][3])){
						tdc="<tr><td rowspan='2' class='s_blue work'>"+companyName+"</td><td>初</td><td>"+anArr[j][0]+"</td><td>"+anArr[j][1]+"</td>"+
    					"<td>"+anArr[j][2]+"</td></tr>";
					}
					if(tempTime<parseInt(anArr[j][3])){
						tdj="<tr><td class='h_red'>即</td><td class='s_blue'>"+anArr[j][0]+"</td><td class='s_blue'>"+anArr[j][1]+"</td><td class='s_blue'>"+anArr[j][2]+"</td></tr>";
					}
				}
				tempTime=parseInt(anArr[j][3]);
			}
			tr=tdc+tdj;
			$(tr).appendTo('.ods_tb:eq(0)');
			tempTime=0;
			for(var j=0;j<epArr.length;j++){
				if(tempTime==0){
					tdoc="<tr><td rowspan='2' class='s_blue work'>"+companyName+"</td><td>初</td><td>"+epArr[j][0]+"</td><td>"+epArr[j][1]+"</td>"+
    					"<td>"+epArr[j][2]+"</td></tr>";
					tdoj="<tr><td class='h_red'>即</td><td class='s_blue'>"+epArr[j][0]+"</td><td class='s_blue'>"+epArr[j][1]+"</td><td class='s_blue'>"+epArr[j][2]+"</td></tr>";
    				
				}else{
					if(tempTime>parseInt(epArr[j][3])){
						tdoc="<tr><td rowspan='2' class='s_blue work'>"+companyName+"</td><td>初</td><td>"+epArr[j][0]+"</td><td>"+epArr[j][1]+"</td>"+
    					"<td>"+epArr[j][2]+"</td></tr>";
					}
					if(tempTime<parseInt(epArr[j][3])){
						tdoj="<tr><td class='h_red'>即</td><td class='s_blue'>"+epArr[j][0]+"</td><td class='s_blue'>"+epArr[j][1]+"</td><td class='s_blue'>"+epArr[j][2]+"</td></tr>";
					}
				}
				tempTime=parseInt(epArr[j][3]);
				//alert(tempTime);
			}
			tro=tdoc+tdoj;
			$(tro).appendTo('.ods_tb:eq(1)');
		}
			//$(tr).appendTo('.ods_tb:eq(0)');
			//$(tro).appendTo('.ods_tb:eq(1)');
	},
	'numberFixed':function(numStr){
		return parseFloat(numStr).toFixed(2);
	},
		//联赛积分
	'da_league':function(league){
		var team = $(league).find('leaguetable>team')//.selectNodes('leaguetable/team');
		for(var i=0;i<team.length;i++){
			if(team[i].getAttribute('id')==hid){
				var tr="";
				var overall = team[i].getElementsByTagName('overall');
				var hostName=team[i].getAttribute('teamCn');
				var zsl=0;
				if(parseInt(overall[0].getAttribute('w'))!=0&&parseInt(overall[0].getAttribute('gp'))!=0){
					zsl=(parseInt(overall[0].getAttribute('w'))/parseInt(overall[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td>总</td>"+
    					"<td>"+overall[0].getAttribute('gp')+"</td>"+
    					"<td>"+overall[0].getAttribute('w')+"</td>"+
    					"<td>"+overall[0].getAttribute('d')+"</td>"+
    					"<td>"+overall[0].getAttribute('l')+"</td>"+
    					"<td>"+overall[0].getAttribute('gs')+"</td>"+
    					"<td>"+overall[0].getAttribute('ga')+"</td>"+
    					"<td>"+overall[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+overall[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+overall[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				$('#host').text("["+overall[0].getAttribute('rank')+"]"+hostName);
				var host= team[i].getElementsByTagName('host');
				zsl=0;
				if(parseInt(host[0].getAttribute('w'))!=0&&parseInt(host[0].getAttribute('gp'))!=0){
					zsl=(parseInt(host[0].getAttribute('w'))/parseInt(host[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td class='red'>主</td>"+
    					"<td>"+host[0].getAttribute('gp')+"</td>"+
    					"<td>"+host[0].getAttribute('w')+"</td>"+
    					"<td>"+host[0].getAttribute('d')+"</td>"+
    					"<td>"+host[0].getAttribute('l')+"</td>"+
    					"<td>"+host[0].getAttribute('gs')+"</td>"+
    					"<td>"+host[0].getAttribute('ga')+"</td>"+
    					"<td>"+host[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+host[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+host[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				var away= team[i].getElementsByTagName('away');
				zsl=0;
				if(parseInt(away[0].getAttribute('w'))!=0&&parseInt(away[0].getAttribute('gp'))!=0){
					zsl=(parseInt(away[0].getAttribute('w'))/parseInt(away[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td class='blue'>客</td>"+
    					"<td>"+away[0].getAttribute('gp')+"</td>"+
    					"<td>"+away[0].getAttribute('w')+"</td>"+
    					"<td>"+away[0].getAttribute('d')+"</td>"+
    					"<td>"+away[0].getAttribute('l')+"</td>"+
    					"<td>"+away[0].getAttribute('gs')+"</td>"+
    					"<td>"+away[0].getAttribute('ga')+"</td>"+
    					"<td>"+away[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+away[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+away[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				var round6= team[i].getElementsByTagName('round6');
				zsl=0;
				if(parseInt(round6[0].getAttribute('w'))!=0&&parseInt(round6[0].getAttribute('gp'))!=0){
					zsl=(parseInt(round6[0].getAttribute('w'))/parseInt(round6[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td>近6</td>"+
    					"<td>"+round6[0].getAttribute('gp')+"</td>"+
    					"<td>"+round6[0].getAttribute('w')+"</td>"+
    					"<td>"+round6[0].getAttribute('d')+"</td>"+
    					"<td>"+round6[0].getAttribute('l')+"</td>"+
    					"<td>"+round6[0].getAttribute('gs')+"</td>"+
    					"<td>"+round6[0].getAttribute('ga')+"</td>"+
    					"<td>"+round6[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+round6[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+round6[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				$(tr).appendTo('.h_by');
			}
			if(team[i].getAttribute('id')==aid){
				var tr="";
				var overall = team[i].getElementsByTagName('overall');
				var hostName=team[i].getAttribute('teamCn');
				var zsl=0;
				if(parseInt(overall[0].getAttribute('w'))!=0&&parseInt(overall[0].getAttribute('gp'))!=0){
					zsl=(parseInt(overall[0].getAttribute('w'))/parseInt(overall[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td>总</td>"+
    					"<td>"+overall[0].getAttribute('gp')+"</td>"+
    					"<td>"+overall[0].getAttribute('w')+"</td>"+
    					"<td>"+overall[0].getAttribute('d')+"</td>"+
    					"<td>"+overall[0].getAttribute('l')+"</td>"+
    					"<td>"+overall[0].getAttribute('gs')+"</td>"+
    					"<td>"+overall[0].getAttribute('ga')+"</td>"+
    					"<td>"+overall[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+overall[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+overall[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				$('#away').text("["+overall[0].getAttribute('rank')+"]"+awayName);
				var host= team[i].getElementsByTagName('host');
				zsl=0;
				if(parseInt(host[0].getAttribute('w'))!=0&&parseInt(host[0].getAttribute('gp'))!=0){
					zsl=(parseInt(host[0].getAttribute('w'))/parseInt(host[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td class='red'>主</td>"+
    					"<td>"+host[0].getAttribute('gp')+"</td>"+
    					"<td>"+host[0].getAttribute('w')+"</td>"+
    					"<td>"+host[0].getAttribute('d')+"</td>"+
    					"<td>"+host[0].getAttribute('l')+"</td>"+
    					"<td>"+host[0].getAttribute('gs')+"</td>"+
    					"<td>"+host[0].getAttribute('ga')+"</td>"+
    					"<td>"+host[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+host[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+host[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				var away= team[i].getElementsByTagName('away');
				zsl=0;
				if(parseInt(away[0].getAttribute('w'))!=0&&parseInt(away[0].getAttribute('gp'))!=0){
					zsl=(parseInt(away[0].getAttribute('w'))/parseInt(away[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td class='blue'>客</td>"+
    					"<td>"+away[0].getAttribute('gp')+"</td>"+
    					"<td>"+away[0].getAttribute('w')+"</td>"+
    					"<td>"+away[0].getAttribute('d')+"</td>"+
    					"<td>"+away[0].getAttribute('l')+"</td>"+
    					"<td>"+away[0].getAttribute('gs')+"</td>"+
    					"<td>"+away[0].getAttribute('ga')+"</td>"+
    					"<td>"+away[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+away[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+away[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				var round6= team[i].getElementsByTagName('round6');
				zsl=0;
				if(parseInt(round6[0].getAttribute('w'))!=0&&parseInt(round6[0].getAttribute('gp'))!=0){
					zsl=(parseInt(round6[0].getAttribute('w'))/parseInt(round6[0].getAttribute('gp'))*100).toFixed(1);
				}
				tr+="<tr><td>近6</td>"+
    					"<td>"+round6[0].getAttribute('gp')+"</td>"+
    					"<td>"+round6[0].getAttribute('w')+"</td>"+
    					"<td>"+round6[0].getAttribute('d')+"</td>"+
    					"<td>"+round6[0].getAttribute('l')+"</td>"+
    					"<td>"+round6[0].getAttribute('gs')+"</td>"+
    					"<td>"+round6[0].getAttribute('ga')+"</td>"+
    					"<td>"+round6[0].getAttribute('p')+"</td>"+
    					"<td class='red'>"+round6[0].getAttribute('points')+"</td>"+
    					"<td class='blue'>"+round6[0].getAttribute('rank')+"</td>"+
    					"<td class='red last_th'>"+zsl+"%</td>"+
    				"</tr>";
				$(tr).appendTo('.l_by');
			}
		}
	},
	'da_analysis':function(analysis){
		//两队交锋
		$('#hostName').text(hostName);
		$('#awayName').text(awayName);
		var vsList =$(analysis).find('analysis>vsList>match');//.selectNodes('analysis/vsList/match');
		var cs=0,s=0,p=0,f=0,sl=0,pl=0,dq=0,dql=0,dls=0,dl=0;
		for(var i=0;i<vsList.length;i++){
			var hn_sty='';
			var an_sty='';
			var ln=vsList[i].getAttribute('ln').split("|")[0];
			var koTime=vsList[i].getAttribute('koTime').substr(0,10);
			var hn=vsList[i].getAttribute('hn').split("|")[0];
			var an=vsList[i].getAttribute('an').split("|")[0];
			var oddsAsian="-";
			if(vsList[i].getAttribute('oddsAsian')!=""){
				var oddsAsian=req[vsList[i].getAttribute('oddsAsian')];
			}
			var hGoal=vsList[i].getAttribute('hGoal');
			var aGoal=vsList[i].getAttribute('aGoal');
			var hHalfGoal=vsList[i].getAttribute('hHalfGoal');
			var aHalfGoal=vsList[i].getAttribute('aHalfGoal');
			if(vsList[i].getAttribute('hid')==hid){
				hn_sty='color:#008000;';
			}else{
				an_sty='color:#008000;';
			}
			var res=parseInt(hGoal)-parseInt(aGoal);
			var sum=parseInt(hGoal)+parseInt(aGoal);
			var result="";
			var result_style="";
			var maxmin="";
			var maxmin_sty="";
			if(res>0){
				result="胜";
				result_style="color:red;";
				s=s+1;
			}else if(res==0){
				result="平";
				result_style="color:#008000;";
				p=p+1;
			}else{
				result="负";
				result_style="color:#0000FF;";
				f=f+1;
			}
			if(sum>=3){
				maxmin="大";
				maxmin_sty="color:red;";
				dq=dq+1;
			}else{
				maxmin="小";
				maxmin_sty="color:#0000FF;";
			}
			if(sum%2!=0){
				dls=dls+1;
			}
			cs=vsList.length;
			sl=(s/cs*100).toFixed(1);
			pl=(p/cs*100).toFixed(1);
			fl=(f/cs*100).toFixed(1);
			dql=(dq/cs*100).toFixed(1);
			dl=(dls/cs*100).toFixed(1);
			
			var tr="<tr height='25'>"+
    				"<td>"+ln+"</td>"+
    				"<td>"+koTime+"</td>"+
    				"<td style="+hn_sty+">"+hn+"</td>"+
    				"<td>"+oddsAsian+"</td>"+
    				"<td style="+an_sty+">"+an+"</td>"+
    				"<td style='color:red;'>"+hGoal+"-"+aGoal+"</td>"+
    				"<td>"+hHalfGoal+"-"+aHalfGoal+"</td>"+
    				"<td style="+result_style+">"+result+"</td>"+
    				"<td style="+maxmin_sty+">"+maxmin+"</td>"+
    				"</tr>";
    		$(tr).prependTo('.analysis');
		}
		graph('graph',sl,pl,fl);
		var end_tr="<tr height='24'>"+
				"<td colspan='9'>近<font color='red'>"+cs+"</font>场，胜"+s+"平"+p+"负"+f+"，胜率:<font color='red'>"+sl+"%</font>,大球率(>2.5):<font color='red'>"+dql+"%</font>,单率:<font color='red'>"+dl+"%</font><td>"+
				"</tr>";
			$(end_tr).appendTo('.analysis');	
		//主队近期战绩
		var hostList=$(analysis).find('analysis>hostList>match');
		var cs=0,s=0,p=0,f=0,sl=0,pl=0,dq=0,dql=0,dls=0,dl=0;
		for(var i=0;i<hostList.length;i++){
			var ln=hostList[i].getAttribute('ln').split('|')[0];
			var koTime=hostList[i].getAttribute('koTime').substr(0,10);
			var hn=hostList[i].getAttribute('hn');
			var oddsAsian="-";
			if(hostList[i].getAttribute('oddsAsian')!=''){
				oddsAsian=req[hostList[i].getAttribute('oddsAsian')];
			}
			var an=hostList[i].getAttribute('an');
			var haGoal=hostList[i].getAttribute('hGoal');
			var aGoal=hostList[i].getAttribute('aGoal');
			var hHalfGoal=hostList[i].getAttribute('hHalfGoal')+"-"+hostList[i].getAttribute('aHalfGoal');
			var result="";
			var result_sty="";
			var maxmin="";
			var maxmin_sty="";
			var hn_sty='';
			var an_sty='';
			var flag='';
			if(hostList[i].getAttribute('hid')==hid){
				hn_sty='color:#008000;';
				flag='float';
			}else{
				an_sty='color:#008000;';
			}
			if(flag=='float'&&parseInt(haGoal)-parseInt(aGoal)>0){
				result="胜";
				result_style="color:red;";
				s=s+1;
			}else if(flag=='float'&&parseInt(haGoal)-parseInt(aGoal)<0){
				result="负";
				result_style="color:#0000FF;";
				f=f+1;
			}else if(flag==''&&parseInt(haGoal)-parseInt(aGoal)>0){
				result="负";
				result_style="color:#0000FF;";
				f=f+1;
			}else if(flag==''&&parseInt(haGoal)-parseInt(aGoal)<0){
				result="胜";
				result_style="color:red;";
				s=s+1;
			}else{
				result="平";
				result_style="color:#008000;";
				p=p+1;
			}
			if(parseInt(haGoal)+parseInt(aGoal)>=3){
				maxmin="大";
				maxmin_sty="color:red;";
				dq=dq+1
			}else{
				maxmin="小";
				maxmin_sty="color:#0000FF;";
			}
			if((parseInt(haGoal)+parseInt(aGoal))%2!=0){
				dls=dls+1;
			}
			cs=hostList.length;
			sl=(s/cs*100).toFixed(1);
			pl=(p/cs*100).toFixed(1);
			fl=(f/cs*100).toFixed(1);
			dql=(dq/cs*100).toFixed(1);
			dl=(dls/cs*100).toFixed(1);
			var tr="<tr height='25'>"+
    				"<td>"+ln+"</td>"+
    				"<td>"+koTime+"</td>"+
    				"<td style="+hn_sty+">"+hn+"</td>"+
    				"<td>"+oddsAsian+"</td>"+
    				"<td style="+an_sty+">"+an+"</td>"+
    				"<td>"+haGoal+"-"+aGoal+"</td>"+
    				"<td>"+hHalfGoal+"</td>"+
    				"<td style="+result_style+">"+result+"</td>"+
    				"<td style="+maxmin_sty+">"+maxmin+"</td>"+
    				"</tr>";
    		$(tr).prependTo('.h_zj');
		}
		graph('z_graph',sl,pl,fl);
		var end_tr="<tr height='24'>"+
				"<td colspan='9'>近<font color='red'>"+cs+"</font>场，胜"+s+"平"+p+"负"+f+"，胜率:<font color='red'>"+sl+"%</font>,大球率(>2.5):<font color='red'>"+dql+"%</font>,单率:<font color='red'>"+dl+"%</font><td>"+
				"</tr>";
			$(end_tr).appendTo('.h_zj');	
		//客队近期战绩
		var visitList=$(analysis).find('analysis>visitList>match');
		var cs=0,s=0,p=0,f=0,sl=0,pl=0,dq=0,dql=0,dls=0,dl=0;
		for(var i=0;i<visitList.length;i++){
			var ln=visitList[i].getAttribute('ln').split('|')[0];
			var koTime=visitList[i].getAttribute('koTime').substr(0,10);
			var hn=visitList[i].getAttribute('hn');
			var oddsAsian="-";
			if(visitList[i].getAttribute('oddsAsian')!=''){
				oddsAsian=req[visitList[i].getAttribute('oddsAsian')];
			}
			var an=visitList[i].getAttribute('an');
			var haGoal=visitList[i].getAttribute('hGoal');
			var aGoal=visitList[i].getAttribute('aGoal');
			var hHalfGoal=visitList[i].getAttribute('hHalfGoal')+"-"+hostList[i].getAttribute('aHalfGoal');
			var result="";
			var result_sty="";
			var maxmin="";
			var maxmin_sty="";
			var hn_sty='';
			var an_sty='';
			if(visitList[i].getAttribute('hid')==aid){
				hn_sty='color:#008000;';
			}else{
				an_sty='color:#008000;';
			}
			if(parseInt(haGoal)-parseInt(aGoal)>0){
				result="胜";
				result_style="color:red;";
				s=s+1;
			}else if(parseInt(haGoal)-parseInt(aGoal)==0){
				result="平";
				result_style="color:#008000;";
				p=p+1;
			}else{
				result="负";
				result_style="color:#0000FF;";
				f=f+1;
			}
			if(parseInt(haGoal)+parseInt(aGoal)>=3){
				maxmin="大";
				maxmin_sty="color:red;";
				dq=dq+1;
			}else{
				maxmin="小";
				maxmin_sty="color:#0000FF;";
			}
			if((parseInt(haGoal)+parseInt(aGoal))%2!=0){
				dls=dls+1;
			}
			cs=visitList.length;
			sl=(s/cs*100).toFixed(1);
			pl=(p/cs*100).toFixed(1);
			fl=(f/cs*100).toFixed(1);
			dql=(dq/cs*100).toFixed(1);
			dl=(dls/cs*100).toFixed(1);
			var tr="<tr height='25'>"+
    				"<td>"+ln+"</td>"+
    				"<td>"+koTime+"</td>"+
    				"<td style="+hn_sty+">"+hn+"</td>"+
    				"<td>"+oddsAsian+"</td>"+
    				"<td style="+an_sty+">"+an+"</td>"+
    				"<td>"+haGoal+"-"+aGoal+"</td>"+
    				"<td>"+hHalfGoal+"</td>"+
    				"<td style="+result_style+">"+result+"</td>"+
    				"<td style="+maxmin_sty+">"+maxmin+"</td>"+
    				"</tr>";
    		$(tr).prependTo('.a_by');
		}
		graph('k_graph',sl,pl,fl);
		end_tr="<tr height='24'>"+
				"<td colspan='9'>近<font color='red'>"+cs+"</font>场，胜"+s+"平"+p+"负"+f+"，胜率:<font color='red'>"+sl+"%</font>,大球率(>2.5):<font color='red'>"+dql+"%</font>,单率:<font color='red'>"+dl+"%</font><td>"+
				"</tr>";
		$(end_tr).appendTo('.a_by');
	},
	'da_hostList':function(){
		
	}
	
},req = {
	'0':'平手','1':'平手/半球','2':'半球','3':'半球/一球','4':'一球','5':'一球/球半','6':'球半','7':'球半/两球','8':'两球',
	'9':'两球/两球半','10':'两球半','11':'两球半/三球','12':'三球','13':'三球/三球半','14':'三球半','15':'三球半/四球',
	'16':'四球','17':'四球/四球半','18':'四球半','19':'四球半/五球','20':'五球','21':'五球/五球半','-0':'平手','-1':'受平手/半球','-2':'受半球',
	'-3':'受半球/一球','-4':'受一球','-5':'受一球/球半','-6':'受球半','-7':'受球半/两球','-8':'受两球',
	'-9':'受两球/两球半','-10':'受两球半','-11':'受两球半/三球','-12':'受三球','-13':'受三球/三球半','-14':'受三球半','-15':'三球半/四球',
	'-16':'受四球','-17':'受四球/四球半','-18':'受四球半','-19':'受四球半/五球','-20':'受五球','-21':'受五球/五球半'
};


function createXml(str){ 

　　if(document.all){ 

　　		var xmlDom=new ActiveXObject("Microsoft.XMLDOM"); 
　　		xmlDom.loadXML(str);

　　		return xmlDom;

　　} 

　　else 

　　return new DOMParser().parseFromString(str, "text/xml"); 

} 
function closeDiv(){
	$('.all_league').hide();
}
function openDiv(){
	$('#leagueName').text(ln);
	allLeague();
}
//所有联赛积分
function allLeague(){
		var tr="";
		for(var i=0;i<arrLeague.length;i++){
				var wdl=arrLeague[i][9].split(",");
				var w=wdl[0];
				var d=wdl[1];
				var l=wdl[2];
				var sty="";
				if(arrLeague[i][11]==hid||arrLeague[i][11]==aid){
					sty="color:red;";
				}
				tr+="<tr height='25' >"+
    				"<td class='red'>"+arrLeague[i][0]+"</td>"+
    				"<td style="+sty+">"+arrLeague[i][1]+"</td>"+
    				"<td>"+arrLeague[i][2]+"</td>"+
    				"<td>"+arrLeague[i][3]+"</td>"+
    				"<td>"+arrLeague[i][4]+"</td>"+
    				"<td>"+arrLeague[i][5]+"</td>"+
    				"<td class='red'>"+arrLeague[i][6]+"</td>"+
    				"<td>"+arrLeague[i][7]+"</td>"+
    				"<td>"+arrLeague[i][8]+"</td>"+
    				"<td>"+
    					"胜<font color='red'>"+w+"</font>平<font color='green'>"+d+"</font>负<font color='blue'>"+l+"</font>"+
    				"</td>"+
    				"<td class='red last_td'>"+arrLeague[i][10]+"</td>"+
    				"</tr>";
		}
		$('.all_by').append(tr);
		$('.all_by').find('tr').bind("mouseover",function(){
			$(this).find('td').css("background","#ffff99");
		});
		$('.all_by').find('tr').bind("mouseout",function(){
			$(this).find('td').css("background","#fefaf8");
		})
}
var arrLeague =  new Array();
function addLeague(league){
	var team = $(league).find('leaguetable>team')//.selectNodes('leaguetable/team');
	for(var i=0;i<team.length;i++){
		var overall = team[i].getElementsByTagName('overall');
		var round6=team[i].getElementsByTagName('round6');
		var name=team[i].getAttribute('teamCn');
		var rank=overall[0].getAttribute('rank');
		var gp=overall[0].getAttribute('gp');
		var w=overall[0].getAttribute('w');
		var d=overall[0].getAttribute('d');
		var l=overall[0].getAttribute('l');
		var gs=overall[0].getAttribute('gs');
		var ga=overall[0].getAttribute('ga');
		var p=overall[0].getAttribute('p');
		var around6=round6[0].getAttribute('w')+","+round6[0].getAttribute('d')+","+round6[0].getAttribute('l');
		var points=overall[0].getAttribute('points');
		var id=team[i].getAttribute('id');
		arrLeague[i] = new Array(rank,name,gp,w,d,l,gs,ga,p,around6,points,id);
	}
	arrLeague.sort(sortfunction);
}
function sortfunction(x,y)
{
 return x[0] - y[0];//根据二维数组的第三列的第一个字母的ASCII码来降序排序
}
function descs(){
	arrLeague.sort(sortfunction);
	//arrLeague.reverse();
	//alert(arrLeague[0] + "\n" + arrLeague[1] + "\n" + arrLeague[2] + "\n"+ arrLeague[3] + "\n"+ arrLeague[4] + "\n")
}
//胜平负数据表
function graph(id,sl,pl,fl){
	var bg="FFFBF0";
	if(id=="graph"){
		bg="F2F2F2";
	}
	var data="<chart palette='4' caption='' decimals='0' "+
			"numberSuffix='%' showDivLineValues='1' baseFontSize='16' subCaption=''"+
			"enableSmartLabels='1' enableRotation='0' bgColor='"+bg+","+bg+","+bg+"' "+
			"bgAlpha='40,100' bgRatio='0,100' bgAngle='360'  startingAngle='70' >"+
            			"<set name='胜' value='"+sl+"' isSliced='1' color='E10E4F' />"+
            			"<set name='平' value='"+pl+"' color='07824F' />"+
            			"<set name='负' value='"+fl+"'  color='0815BA'/>"+
				"</chart>";
		   var chart = new FusionCharts("./Charts/Pie3D.swf", "ChartId", "440", "180", "0", "0");
		   chart.setDataXML(data);		   
		   chart.render(id);
}

//取初赔率
function dfsf(){
	sl=parseFloat(sl);
	pl=parseFloat(pl);
	fl=parseFloat(fl);
	var bg="FFFBF0";
	if(id=="graph"){
		bg="F2F2F2";
	}
	var myData = new Array(['胜(%)', sl], ['平(%)', pl], ['负(%)', fl]);
	var api = new jGCharts.Api();
			xdata=[[1],[1]]; 
			var opt = { 
				data : [[sl,60,52],[pl,70,60],[fl,80,40]],
				axis_labels: ["胜("+sl+"%)", "平("+pl+"%)", "负("+fl+"%)"], 
				colors : ['E10E4F','07824F','0815BA'],
				chbg_angle : '150',
				bg_trasparency : 0,
				bg : bg,
				lable_size : 50,
				size: "350x150",
				type : 'p3' 
			}; 
			jQuery('<img>').attr('src', api.make(opt)).appendTo("#"+id+"");
}


