﻿KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="100";
KO.U.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){
		var e_y_a='';
		pages = parseInt(pages);
		var countY = Math.ceil(ey);
		var next=pages >= ey ? ey : pages+1;
		var fist=pages <= 1 ? "1" : pages-1;
		var startY=0,endY=ey > 5 ? 8 : ey;
		if(pages>=5){
			startY = pages - 5; 
			endY   = ey - pages + 5 > ey ? ey :  pages + 5;
		}
		
		e_y_a+="<font color='#333333'>共有"+KO.U.countEvery+"条记录，共有"+Math.ceil(ey)+"页</font><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('1','"+KO.U.Every+"') class='h_l'>◀</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'>◀◀</a>";
		var cls='';
		for(var e=startY;e<endY;e++){
			if(e<ey){
				if(e==(pages-1)) cls='an_x_z';
				else cls='';
				e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=ShowBuyLotteryDate("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			}else{
				break;
			}
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=ShowBuyLotteryDate('"+next+"','"+KO.U.Every+"') class='next'>▶▶</a><a href='javascript:void(0)' onclick=ShowBuyLotteryDate('"+countY+"','"+KO.U.Every+"') class='h_l'>▶</a>";
		//e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		//"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='gray'>共"+countY+"页,"+(ey*parseInt(t_s))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page1');//左国斌f_an_page改为f_an_page1
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	var ps=$("#govalue").val();
	showAuxiliary(ps,KO.U.Every);
}
/*function selToTime(p,e){
	beginTime= create_class.formatTime(KO.$('startDate').value);
	showAuxiliary("1","10");
}*/
//
function selToTime1(p,e){
    beginTime= create_class.formatTime(KO.$('startDate').value);
	showAuxiliary("1","10");
	$('#gameid').val('footBall');
	//alert("zuqiu"+$('#gameid').val());
}
//
function selToTime2(p,e){
	beginTime= create_class.formatTime(KO.$('startDate').value);
	showAuxiliary("1","10");
	$('#gameid').val('basketBall');
	//alert("lanqiu"+$('#gameid').val());
}

function showAuxiliary(p,e){
	
	$('.loding').show();
	KO.U.Pages = p;
	KO.U.Every = '10';
	if(beginTime=="null"){
		 beginTime = create_class.formatTime(KO.$('startDate').value);
	}
	//左国斌添加条件查询篮球和足球分别按类型查询
	var gameid=$('#gameid').val();
	//alert("wo de id"+gameid);
	if(gameid=='null' || gameid==null || gameid==''){
		gameid='footBall';//赋初始值
	}
	$.getJSON(url+"/letoula/data/statdata.jsp?r="+Math.random(),{'date':beginTime,'gameid':gameid,'usernikename':'all','status':'1','pages':KO.U.Pages,'every':KO.U.Every},function(items){
		//var tr='';
		var li='';
		$('#rc_t_ty,.f_an_page1').empty();//左国斌f_an_page改为f_an_page1
		var it=items.items;
		var ey=parseInt(items.recod)/parseInt(KO.U.Every);
		ey = ey < 1 ? 1 : ey;
		if(ey <= 1 && it.length<30){
			KO.U.countEvery = it.length;
		}else{
			KO.U.countEvery ="30";
		}
		paging1(ey,p);
		$(it).each(function(i,v){
			var tzway='';
			var way=v.betway.split(',');
			var gameid = v.gameid;
			switch(gameid){
				case '501':
				case '502':
				case '503':
				case '504':
				case '505':
				case '506':
				case '507':
				case '508':
				case '509':
				case '510':
				case '511':
					for(var s=0;s<way.length;s++){
		 				tzway+=McN_Map[way[s]]+'/';
		 			}
		 		break;
		 		case '301':
		 		case '302':
		 		case '303':
		 		case '304':
		 		case '305':
		 			for(var s=0;s<way.length;s++){
		 				tzway+=DC_McN_Map[way[s]]+'/';
		 			}
		 		break;
		 		case '102':
		 		case '103':
		 		case '106':
		 		case '107':
		 			for(var s=0;s<way.length;s++){
		 				tzway = way[s] == '1' ? '单式' : '复试';
		 			}
		 		break;
			};
			tzway = tzway.substring(0,tzway.length-1);
			var trcolor = ((i+1) % 2) == 0 ? "#f9f9f9" : "#f2f2f2";
			v.status = setting_status[v.status];
		 	v.manner = setting_manner[v.manner];
		 	var isopen=v.isopen;
		 	var serino = '<a href="../useraccount/serNoScheme_details.jsp?id='+v.serino+'" class="dingzhi" target="_blank">'+v.serino+'</a>';
		 	var nke = v.usernikename;
		 	if(isopen!=0){
		 		nke = nke.substring(0,2)+"***";
		 		serino = v.serino;
		 		v.bets = '--';
		 	}
		 	var record_ZJ = create_class.Record_zhanJ(v.countPrice,v.userid);
			li+='<li><span style="float:left;width:50px;">'+nke+'</span><span style="float:left;width:73px; text-align:left;display:block;color:red;overflow: hidden;">￥'+v.zjye+'</span>'+'<span style="float:right">'+v.status+'</span></li>'
			
		});
        if(gameid=='footBall'){
			$('.tableborder03 tbody tr td ul').html(li);
			$('.loding').hide();
			$.domSpanBack($('.tableborder03 tbody tr td ul li'),'rowBg');//左国斌
		}
	     if(gameid=='basketBall'){
	    	 $('.tableborder04 tbody tr td ul').html(li);//左国斌
	    		$('.loding').hide();
	    		$.domSpanBack($('.tableborder04 tbody tr td ul li'),'rowBg');//左国斌
		}
	});
}


$(function(){

	if(beginTime!="null"){
		$('#startDate').val(ftTime(beginTime));
	}
	showAuxiliary(KO.U.Pages,KO.U.Every);
	var lotIndex = id == 0 ? 0 : 1;
	$('.ld_table').eq(lotIndex).show();
	$('.rs_c_m > li').eq(id).addClass('c_m_xz');
})
function ftTime(time){
	var year=time.substr(0,4);
	var month=time.substr(4,2);
	var day=time.substr(6);
	return year+"-"+month+"-"+day;
}