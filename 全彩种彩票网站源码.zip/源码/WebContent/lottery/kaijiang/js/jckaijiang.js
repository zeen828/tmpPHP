﻿KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="100";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){

		var e_y_a='';
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var countY = Math.ceil(ey);
		if(countY > 1) KO.countEvery = 10;
		var startY=0,endY=countY-1 > 8 ? 7 : countY;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=showAuxiliary('1','"+KO.U.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'></a>";
		var cls='';

		for(var e=startY;e<endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showAuxiliary("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showAuxiliary('"+next+"','"+KO.U.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+countY+"','"+KO.U.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='#0f3f94'>共"+countY+"页,"+(ey*parseInt(KO.countEvery))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	var ps=$("#govalue").val();
	showAuxiliary(ps,KO.U.Every);
}
function selToTime(p,e){
	beginTime= create_class.formatTime(KO.$('startDate').value);
	showAuxiliary("1","10");
}

function showAuxiliary(p,e){
	$('.loding').show();
	KO.U.Pages = p;
	KO.U.Every = '100';
	if(beginTime=="null"){
		 beginTime = create_class.formatTime(KO.$('startDate').value);
	}

	//var beginTime = create_class.formatTime(KO.$('startDate').value);
	$.getJSON(url+'/letoula/data/results_the_lottery.jsp?r='+Math.random(),{'starTime':beginTime,'pages':'0','every':'0'},function(JSON){
		var items = JSON.items;
		
		var tr = '';
		$(items).each(function(i,v){
			
			var vt=v.visitingteam,ht=v.hometeam;
 			
			var bqRe = v.bqcSingleRe.split('-');
			v.color = v.color == '-' ? '#f2f2f2' : v.color; 
			
			tr+='<tr align="center"><td>'+v.leagueNumber+'</td><td style="background:'+v.color+';" width="7%"><span class="namebox">'+v.leagueName+'</span></td><td>'+create_class.axyformatTimeTwo(v.stopTime)+'</td>'+
				'<td><a href="#" class="namebox link_blue" target="_blank">'+ht+'</a></td><td><a href="#" class="namebox link_blue" target="_blank">'+vt+'</a></td>'+
				'<td>'+v.visitingSemiScore+'</td><td class="border2">'+v.hometeamSemiScore+'</td><td><b class="font_red">'+v.spfSingleRe+'</b></td><td>'+v.spfSinglePr+'</td><td>'+v.giveBall+'</td>'+
				'<td><b class="font_red">'+v.rqSingleRe+'</b></td><td class="border2">'+v.rqSinglePr+'</td><td><b class="font_red">'+v.bfSingleRe+'</b></td><td class="border2">'+v.bfSinglePr+'</td>'+
				'<td><b class="font_red">'+v.zjqSingleRe+'</b></td><td class="border2">'+v.zjqSinglePr+'</td><td><b class="font_red">'+v.bqcSingleRe+'</b></td><td class="border2">'+v.bqcSinglePr+'</td></tr>';
			
		});
		
		$('.tableborder02 tbody').html(tr);
		$('.loding').hide();
		$.domSpanBack($('.tableborder02 tbody tr'),'rowBg');
	});
}


$(function(){

	if(beginTime!="null"){
		$('#startDate').val(ftTime(beginTime));
	}
	showAuxiliary(KO.U.Pages,KO.U.Every);
});

function ftTime(time){
	var year=time.substr(0,4);
	var month=time.substr(4,2);
	var day=time.substr(6);
	return year+"-"+month+"-"+day;
}