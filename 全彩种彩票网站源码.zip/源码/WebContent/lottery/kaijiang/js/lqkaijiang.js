﻿KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="100";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){

		var e_y_a='';
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var countY = Math.ceil(ey);
		if(countY > 1) KO.countEvery = 10;
		var startY=0,endY=countY-1 > 8 ? 7 : countY;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=showAuxiliary('1','"+KO.U.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'></a>";
		var cls='';

		for(var e=startY;e<endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showAuxiliary("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showAuxiliary('"+next+"','"+KO.U.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+countY+"','"+KO.U.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='#0f3f94'>共"+countY+"页,"+(ey*parseInt(KO.countEvery))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	var ps=$("#govalue").val();
	showAuxiliary(ps,KO.U.Every);
}
function selToTime(p,e){
	beginTime= create_class.formatTime(KO.$('startDate').value);
	showAuxiliary("1","10");
}
function formatstr(str){
	var dxresults = str.substring(0,str.length-1).split(",");
	var dxresults_opt = '' , dxresults_sel = '';
	for(var s =0;s<dxresults.length;s++){
		var vs = dxresults[s].replace(/[^\x00-\xff]/g,'');
		if(vs.indexOf('-') != -1 || vs.indexOf('+') != -1){
			dxresults_opt +='<option>'+vs+'</option>';
		}else{
			dxresults_opt ='<option>'+vs+'</option>'+dxresults_opt;
		}
	}
	dxresults_sel = '<select style="width:65px">'+dxresults_opt+'</select>';
	return dxresults_sel;
}
function showAuxiliary(p,e){
	$('.loding').show();
	KO.U.Pages = p;
	KO.U.Every = '100';
	if(beginTime=="null"){
		 beginTime = create_class.formatTime(KO.$('startDate').value);
	}

	//var beginTime = create_class.formatTime(KO.$('startDate').value);
	$.getJSON(url+'/letoula/data/results_the_Baklottery.jsp?r='+Math.random(),{'starTime':beginTime,'pages':'0','every':'0'},function(JSON){
		
		var items = JSON.items;
		
		var tr = '';
		$(items).each(function(i,v){
			
			var vt=v.visitingteam.substring(0,3),ht=v.hometeam.substring(0,3);
 			if(v.visitingteam.length < 3 ) vt = v.visitingteam.substring(0,1)+'&nbsp;&nbsp;&nbsp;&nbsp;'+v.visitingteam.substring(1,2);
 			if(v.hometeam.length < 3 ) 	ht =v.hometeam.substring(0,1)+'&nbsp;&nbsp;&nbsp;&nbsp;'+v.hometeam.substring(1,2);
 			
			v.color = v.color == '-' ? '#004488' : v.color; 
			var dxs = v.dxresults.substring(0,v.dxresults.length-1).split(",");
			dxs = dxs[dxs.length-1].replace(/[^\x00-\xff]/g,'');
			var rfs = v.rfsfguanresult.substring(0,v.rfsfguanresult.length-1).split(",") , rfresult = '';
			rfs = rfs[0].replace(/[^\x00-\xff]/g,'');
			var ys = parseFloat(dxs);
			var bifen = v.bifen.split(":");
			var bifensum = parseInt(bifen[0])+parseInt(bifen[1]);
			var dxf = bifensum > ys ? '大分' : '小分';
			if(rfs.indexOf('-') != -1){
				rfresult = (parseInt(bifen[1]) - parseInt(bifen[0])) <  parseFloat(rfs.replace('-','')) ? '让分主负' : '让分主胜';
			}else{
				rfresult = (parseInt(bifen[0]) - parseInt(bifen[1])) >  parseFloat(rfs.replace('+','')) ? '让分主负' : '让分主胜';
			}
			
			tr+='<tr align="center"><td>'+v.leagueNumber+'</td><td style="background:'+v.color+';color:#fff" width="7%"><span class="namebox">'+v.leagueName+'</span></td><td>'+create_class.axyformatTimeTwo(v.stopTime)+'</td>'+
				'<td><a href="#" class="namebox link_blue" target="_blank">'+vt+'</a></td><td><a href="#" class="namebox link_blue" target="_blank">'+ht+'</a></td>'+
				'<td>'+bifen[0]+'-'+bifen[1]+'</td><td>'+formatstr(v.rfsfguanresult)+'</td><td>'+rfresult+'</td><td>'+v.rfsfaward+'</td>'+
				'<td>'+formatstr(v.dxresults)+'</td><td>'+dxf+'</td><td>'+v.dxaward+'</td><td><b class="font_red">'+v.sfresults+'</b></td>'+
				'<td>'+v.sfaward+'</td><td><b class="font_red">'+v.sfcresults+'</b></td><td>'+v.sfcaward+'</td></tr>';
		});
		
		$('.tableborder02 tbody').html(tr);
		$('.loding').hide();
		$.domSpanBack($('.tableborder02 tbody tr'),'rowBg');
	});
}


$(function(){

	if(beginTime!="null"){
		$('#startDate').val(ftTime(beginTime));
	}
	showAuxiliary(KO.U.Pages,KO.U.Every);
});

function ftTime(time){
	var year=time.substr(0,4);
	var month=time.substr(4,2);
	var day=time.substr(6);
	return year+"-"+month+"-"+day;
}