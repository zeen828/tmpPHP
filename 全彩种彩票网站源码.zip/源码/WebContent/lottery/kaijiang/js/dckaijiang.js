﻿KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="100";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){

		var e_y_a='';
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var countY = Math.ceil(ey);
		if(countY > 1) KO.countEvery = 10;
		var startY=0,endY=countY-1 > 8 ? 7 : countY;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=showAuxiliary('1','"+KO.U.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'></a>";
		var cls='';

		for(var e=startY;e<endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showAuxiliary("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showAuxiliary('"+next+"','"+KO.U.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=showAuxiliary('"+countY+"','"+KO.U.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='#0f3f94'>共"+countY+"页,"+(ey*parseInt(KO.countEvery))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}

function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	var ps=$("#govalue").val();
	showAuxiliary(ps,KO.U.Every);
}
function selToTime(p,e){
	var issue = $("#issue_sel").val();
	showAuxiliary("1","10");
}

function showAuxiliary(p,e){
	
	$('.loding').show();
	var issue = $("#issue_sel").val();
	$.getJSON(url+'/letoula/data/results_the_dclottery.jsp?r='+Math.random(),{'issue':issue},function(JSON){
		var items = JSON.items;
		
		var tr = '';
		$(items).each(function(i,v){
			
			v.color = v.color == '-' ? '#004488' : v.color; 
			
			var con = '';
			if(parseFloat(v.rangqiushu) < 0){
  				con = '(<strong><font color="green">'+v.rangqiushu+'</font></strong>)';
  			}else if(parseFloat(v.rangqiushu) > 0){
  				con = '(<strong><font color="red">+'+v.rangqiushu+'</font></strong>)';
  			}else{
  				con = '';
  			}
			tr+='<tr align="center"><td>'+v.mathnum+'</td><td style="background-color:'+v.color+';color:#fff" width="7%"><span class="namebox">'+v.matchName+'</span></td><td>'+create_class.axyformatTimeTwo(v.matchTime)+'</td>'+
				'<td><a href="#" class="namebox link_blue" target="_blank">'+v.maindu+con+'</a></td><td><b class="font_red">'+v.quanbifen+'</b></td><td><a href="#" class="namebox link_blue" target="_blank">'+v.guestdu+'</a></td>'+
				'<td><b class="font_red">'+v.rangqiu+'</b></td><td class="border2">'+v.rangqiusp+'</td><td><b class="font_red">'+v.zongjinqiu+'</b></td><td class="border2">'+v.zongjinqiusp+'</td><td><b class="font_red">'+v.shangxiapan+'</b></td>'+
				'<td class="border2">'+v.shangxiapansp+'</td><td><b class="font_red">'+v.bifen+'</b></td><td class="border2">'+v.bifensp+'</td><td><b class="font_red">'+v.banquanchang+'</b></td>'+
				'<td>'+v.banquanchangsp+'</td></tr>';
			
		});
		
		$('.tableborder02 tbody').html(tr);
		$('.loding').hide();
		$.domSpanBack($('.tableborder02 tbody tr'),'rowBg');
	});
}


$(function(){
	showAuxiliary(KO.U.Pages,KO.U.Every);
})
function ftTime(time){
	var year=time.substr(0,4);
	var month=time.substr(4,2);
	var day=time.substr(6);
	return year+"-"+month+"-"+day;
}