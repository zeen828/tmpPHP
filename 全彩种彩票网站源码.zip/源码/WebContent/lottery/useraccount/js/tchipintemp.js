KO.Y={};
KO.Y.Trading=Trading;
KO.Y.Pages="1";
KO.Y.Every="30";
KO.countEvery="0";
var McN_Map={
	'1':'单关','2':'2串1',
	'3':'3串1','4':'3串3','5':'3串4',
	'6':'4串1','7':'4串4','8':'4串5','9':'4串6','10':'4串11',
	'11':'5串1','12':'5串5','13':'5串6','14':'5串10','15':'5串16','16':'5串20','17':'5串26',
	'18':'6串1','19':'6串6','20':'6串7','21':'6串15','22':'6串20','23':'6串22','24':'6串35','25':'6串42','26':'6串50','27':'6串57',
	'28':'7串1','29':'7串7','30':'7串8','31':'7串21','32':'7串35','33':'7串120','34':'7串127',
	'35':'8串1','36':'8串8','37':'8串9','38':'8串28','39':'8串56','40':'8串70','41':'8串247','42':'8串255'
},ChiPinStatus={
	'0':'已出票','1':'已出票','2':'已出票','3':'已派奖','4':'已派奖','5':'已派奖'
},ar = {'3':'胜','1':'平','0':'负'};  

function showUserData(t,p,e){
	KO.Y.Pages=p;
	KO.Y.Every=e;
	var My_Record='<tr><td>暂时没有您的认购信息 </td></tr>';
	$.getJSON("../data/results_the_tchipintemp.jsp?r="+Math.random(),{'serialno':t,'pages':KO.Y.Pages,'every':KO.Y.Every},function(items){
		var article = items.record; //总条数
		var c_pis=0,c_pic=0,gr='',trc='';  //购买总份数
		var List = items.items;
		$('.myList,.f_an_page').empty();
		KO.countEvery=items.record;
		var ey=parseInt(items.record)/parseInt(KO.Y.Every);
		ey = ey < 1 ? 1 : Math.ceil(ey);
		
		create_class.paging(ey,p);
		var tr='';
		//List.sort(function(a,b){return b.tempawardBets-a.tempawardBets});
		var zje=0 , zjje=0;
		for(var i=0;i<List.length;i++){
			
			var spvalue = List[i].spvalue.split("//");
			var spnum = mx(spvalue);
			zje+=parseFloat(List[i].bets);
			zjje+=parseFloat(List[i].tempawardBets);
			List[i].time = create_class.axyformatTime(List[i].time);
			tr+='<tr><td>'+(i+1)+'</td><td>'+List[i].time+'</td><td>'+spnum+'</td><td><b>￥<font color="red">'+List[i].bets+'</font></b></td><td>'+McN_Map[List[i].manner]+'</td><td>'+List[i].multiple+'倍</td><td><b>￥<font color="red">'+List[i].tempawardBets+'</font></b></td><td>'+ChiPinStatus[List[i].status]+'</td></tr>';
    		
		}
		$('.zje').text(zje.toFixed(2));
		$('.zjje').text(zjje.toFixed(2));
		$(tr).appendTo('.myList');
	});
	
}
function mx(arr){
	var str = '';
	for(var i=0;i<arr.length;i++){
		var arrst = arr[i].split(",");
		var m = arrst[1].split(":");
		str+=arrst[0]+">"+m[0]+"(<font color='red'>"+m[1]+"</font>)×";
	}
	str=str.substring(0,str.length-1);
	return str;
}
function mltOnkeyUp(){
		
		var _this=arguments[0],
			val=parseInt(_this.value),
			reg=/^(0|[1-9][0-9]*)$/g;
		var fs=parseInt($('.sy_c').text());
			
		if(!reg.test(_this.value) || val <= 0 || val>fs){
			
		   _this.value=1;
		   if(val>fs){
		   		
		   		_this.value=fs;
		   }
		}
		
		$('.countMoney').text('￥'+(parseInt(_this.value)*AG.copisPrice)+'.00');
}
$(function(){
	
	showUserData(KO.Y.Trading,KO.Y.Pages,KO.Y.Every);

});