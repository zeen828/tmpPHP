function check(){ 
//验证用户-------------------------
	 if(regform.loginName.value==""){ 
		alert("\请输入您的登录ID!");
		document.getElementById("loginName").select();
		document.getElementById("loginName").focus();
		return false;
	} 
	var varusername = regform.loginName.value.replace(/[^\x00-\xff]/g,"**");
	if(varusername.length<4 ||varusername.length>14){
		alert("\登录名称长度不能少于4或大于14个字符!");
		document.getElementById("loginName").select();
		document.getElementById("loginName").focus();
		return false;
	}
//验证密码--------------------------
	if( ! isPassword( document.getElementById("UserPassword").value ) ) {
		alert("\请重新输入密码,密码由至少6个英文字母或数字组成!");
		document.getElementById("UserPassword").select();
		document.getElementById("UserPassword").focus();
		return false;
	}
	if( ! isPassword( document.getElementById("confirmuserpwd").value ) ) {
		alert("\请输入确认密码,密码由至少6个英文字母或数字组成!");
		document.getElementById("confirmuserpwd").select();
		document.getElementById("confirmuserpwd").focus();
		return false;
	}
	if( document.getElementById("confirmuserpwd").value != document.getElementById("UserPassword").value ) {
		alert("\两次密码输入不一致!");
		document.getElementById("UserPassword").value="";
		document.getElementById("confirmuserpwd").value="";
		document.getElementById("UserPassword").focus();
		return false;
	} 
//验证帐户昵称------------------------------
	if(document.getElementById("UserNickName").value == ""){
		alert("帐户昵称不能为空!");
		document.getElementById("UserNickName").focus();
		return false;
	}	 
	
//验证email-----------------------------------
	 if( document.getElementById("email").value =="" ) {
		alert("\请输入Email!");		
		document.getElementById("email").focus();
		return false;
	}
	if(!isEmail(document.getElementById("email").value)){
		alert("EMail格式不符合要求"); 
		document.getElementById("email").select();
		document.getElementById("email").focus();
		return false;
	} 
 
}  
//密码
function isPassword(UserPassword){
	return /^[\w]{6,16}$/.test( UserPassword );
} 
//油箱
function isEmail(Email){
	
	return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/g.test(Email);
}    
/*点击填写下面的信息个人详细资料*/
 function showMoreRegInfo() {
  	if(document.getElementById('RegInfo').checked) {
       document.getElementById('MoreRegInfo').style.display = "block";
    } else {
      document.getElementById('MoreRegInfo').style.display = "none";
    }
 }
 /*点击填写下面的信息高级用户*/
 function showMoreRegInfoS() {
  	if(document.getElementById('RegInfos').checked) {
       document.getElementById('MoreRegInfos').style.display = "block";
    } else {
      document.getElementById('MoreRegInfos').style.display = "none";
    }
 }
 /*点击是否同意注册*/
 function changeRegister(){
	if(document.getElementById('radiobutton').checked){
		document.all.fin_reg.style.display="inline";
	}else{
		document.all.fin_reg.style.display="none";
	}
}

