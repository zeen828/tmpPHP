
//区域表单结束
$.getJSON("../../data/showUser.jsp?r="+Math.random(),function(items){
		var address=items.items[0].address.split(',');
		var sex=items.items[0].sex;
		var phone=items.items[0].phone;
		if(sex=="男"){
			$('#sex1').attr("checked",true);
		}
		if(sex=="女"){
			$('#sex2').attr("checked",true);
		}
		$("#phone").val(phone);
		if(address.length >= 2){
			$('#province').append("<option selected=selected>"+decodeURI(address[0])+"</option>");
			$('#city').append("<option selected=selected>"+decodeURI(address[1])+"</option>");
			$('#district').append("<option selected=selected>"+decodeURI(address[2])+"</option>");
		}
		
});
//用户信息保存
function userInfoSave(){
	var sex = $("input[name='sex'][type='radio']:checked").val();
	var address=$("#province > option:selected").text()+','+$('#city > option:selected').text()+','+$('#district > option:selected').text();
	var phone=$("#phone").val();
	if(sex==undefined){
		seaDetails('blk2','s','请选择性别！');
		return;
	}
	if(address==""){
		seaDetails('blk2','s','请选择地址！');
		return;
	}
	if(phone==""){
		seaDetails('blk2','s','请填写电话！');
		return;
	}
	address=encodeURI(address);
	
	$.getJSON("../../data/info.jsp?r="+Math.random(),{'sex':sex,'address':address,'phone':phone},function(items){
		if(items.items[0].str=="0000"){
			alert("保存成功！！！");
		}else{
			alert("保存失败！！！");
		}
	});
}

function seaDetails(nd,sh,txt){
		var off_top=document.documentElement.scrollTop;
		var off_left=document.documentElement.scrollLeft; 
        document.getElementById(nd).style.top=(off_top+50)+"px";
        document.getElementById(nd).style.left=(document.body.clientWidth-500)+"px";
        $('.errorMsg').text(txt);
		sh == 's' ? $('#bd,#'+nd+'').show() : $('#bd,#'+nd+'').hide();
}
