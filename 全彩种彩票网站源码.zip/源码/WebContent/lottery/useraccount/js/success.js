﻿//文本框获取焦点事件
 		function _onFocus(_this){
 			var id=$(_this).attr('id');
 			if(id=="email"){
	 			if($(_this).val()=='请输入您的常用邮箱'){
	 				$(_this).val('');
	 			}
 			}else if(id=="phone"){
 				if($(_this).val()=='请输入手机号码'){
	 				$(_this).val('');
	 			}
 			}else{
 				if($(_this).val()=='输入验证码'){
	 				$(_this).val('');
	 			}
 			}
 		}
 		//文本框失去焦点事件
 		function _onBlur(_this){
 			var id=$(_this).attr('id');
 			if(id=="email"){
 				if($(_this).val()==''){
 					$(_this).val('请输入您的常用邮箱');
 				}
 			}else if(id=="phone"){
 				if($(_this).val()==''){
	 				$(_this).val('请输入手机号码');
	 			}
 			}else{
 				if($(_this).val()==''){
	 				$(_this).val('输入验证码');
	 			}
 			}
 			
 		}
 		//验证邮箱
		function checkEmail(){
			var email=$('#email').val();
 			if(!isEmail($('#email').val())){
 				alert("邮箱格式不正确！！！");
			}else{
				$.getJSON("../../data/success.jsp?r="+Math.random(),{'uName':uName,'pwd':pwd,'email':email,'phoneCode':''},function(items){
					if(items.items[0].strs=="0000"){
						alert("验证邮件已发送到您的邮箱，请查收，领取体验金！！！");
					}else{
						alert("验证失败，请重新发送验证码！！！");
					}
				});
			}
		}
		function isEmail(Email){
			return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/g.test(Email);
		} 
		//手机验证
		var phoneCode='';
		var phones='';
		var n=300;
		function checkPhone(HTMLObjc){
			var phone=$('#phone').val();
			if(isNaN(phone)||phone.length<11||phone.length>11){
				alert("手机号码格式不正确！！！");
				return;
			}
			if(/^13\d{9}$/g.test(phone)||(/^15[0-35-9]\d{8}$/g.test(phone))|| (/^18[01-9]\d{8}$/g.test(phone))){
				var rnd="";
				for(var i=0;i<6;i++){
					rnd=rnd+Math.floor(Math.random()*10).toString();
				}
				var code ="欢迎您进入彩票中国网站，您的短信验证码为："+rnd+"。";
				code=encodeURI(code);
				$.getJSON("../../data/sendCode.jsp?r="+Math.random(),{'phone':phone,'code':code},function(items){
						if(items.strs=="0000"){
							phoneCode=items.code;
							phones=$('#phone').val();
						}else{
							alert(items.strs);
						}
				});
				$(HTMLObjc).attr('disabled',true);
				TimeLoad();
			}else{
				alert("手机号码格式不正确");
			}
		}
		
		function TimeLoad(){
			var HMO = $("#successPost");
			var l = n--;
			var tu = "";
			$(HMO).val("发送成功,还剩("+l+")秒");
			if(n==0){
				phoneCode = "";
				n = 300;
				$(HMO).val("验证码失效,重新发送验证码");
				$(HMO).attr('disabled',false);
				clearTimeout(tu);
				return;
			}
			tu = setTimeout('TimeLoad()',1000);
		}
		
		//手机验证
		function dPhone(){
			if($('#phoneCode').val()=="输入验证码"||$('#phoneCode').val()==""){
				alert("请输入验证码！！！");
				return;
			}else if(phoneCode!=$('#phoneCode').val()){
				alert("验证码有误！！！");
				return;
			}
			$.getJSON("../../data/success.jsp?r="+Math.random(),{'uName':uName,'pwd':pwd,'email':'','phone':phones},function(items){
					if(items.items[0].strs=="0000"){
						alert("验证成功！！！");
						location.href="http://www.jingcaile.com";
					}else{
						alert("验证失败，请重新发送验证码！！！");
					}
			});
		}
