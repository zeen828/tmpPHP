
//修改密码保护
function updatePwdProtect(){
	var _false=check();
	var pwd = $('#pwd').val();
	if(_false=="false"){
		return;
	}
	if(pwd==""){
		alert("请输入密码！！！");
	}
	qusition01 = encodeURI(qusition01);
	qusition02 = encodeURI(qusition02);
	answer01 = encodeURI(answer01);
	answer02 = encodeURI(answer02);
	$.getJSON("../../data/updatePwdProtect.jsp?r="+Math.random(),{pwd:pwd,qusition01:qusition01,qusition02:qusition02,answer01:answer01,answer02:answer02},function(items){
		if(items.items[0].strs=="0"){
			alert("密保修改成功！！！");
			location.reload();
		}else{
			alert("密保修改失败！！！");
		}
	});
}
var question={
	"0":"0",
	"1":"你的幸运数字是多少？",
	"2":"您什么时候第一次购彩？",
	"3":"您最喜欢的运动员全称？",
	"4":"您的宠物名字叫什么？"
}
//设置密保
function  setPwdProtect(_this){
	var _false=check();
	if(_false=="false"){
		return;
	}
	qusition01 = encodeURI(qusition01);
	qusition02 = encodeURI(qusition02);
	answer01 = encodeURI(answer01);
	answer02 = encodeURI(answer02);
	$.getJSON(url+"/letoula/data/pwdProtect.jsp?r="+Math.random(),{qusition01:qusition01,qusition02:qusition02,answer01:answer01,answer02:answer02},function(items){
		if(items.items[0].strs=="0"){
			alert("密保设置成功！！！");
			location.replace(location.href);
		}else{
			alert("密保设置失败！！！");
		}
	});
}
//验证问题、答案
var qusition01="";
var qusition02="";
var answer01="";
var answer02="";
function check(){
	qusition01=question[$('#qusition01').val()];
	qusition02=question[$('#qusition02').val()];
	answer01=$('#answer01').val();
	answer02=$('#answer02').val();
	if(qusition01=="0"||qusition02=="0"){
		alert("请选择问题！！！");
		return "false";
	}
	if(answer01==""||answer02==""){
		alert("请输入答案！！！");
		return "false";
	}
}
