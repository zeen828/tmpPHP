KO.U={};
KO.U.d=new Date();
KO.U.Pages="1";
KO.U.Every="10";
KO.countEvery="0";
KO.U.buyCountMoney=0.00;
KO.U.CountRgMoney=0.00;
KO.U.CountZjMoney=0.00;

function paging1(ey,pages){
		var e_y_a='';
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		var countY = Math.ceil(ey);
		var startY=0,endY=endY=ey-1 > 8 ? 7 : ey-1;
		if(pages>=8){
			startY = pages - 5; 
			endY   = parseInt(pages) + 2 >= countY ? countY-1 : parseInt(pages) + 2;
		}
		
		e_y_a+="<a href='javascript:void(0)' onclick=ShowCostumData('1','"+KO.U.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=ShowCostumData('"+fist+"','"+KO.U.Every+"') title='上一页' class='pre'></a>";
		var cls='';
		for(var e=startY;e<=endY;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
		
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=ShowCostumData("'+(e+1)+'","'+KO.U.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=ShowCostumData('"+next+"','"+KO.U.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=ShowCostumData('"+countY+"','"+KO.U.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+countY+",this)' id='govalue' value='1' />"+
		"<input type='button' class='btn' onclick=loadPageData1() value='GO'></span><font color='gray'>共"+countY+"页,"+(ey*parseInt(KO.countEvery))+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}


function ValidataPage(ey,_this){
		
		var pg=parseInt(_this.value);

		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData1(){
	
	var ps=$("#govalue").val();
	ShowCostumData(ps,KO.U.Every);
}

var setting = {
	'formatTime':function(str){return str.replace(/[-]/g,"")+"000000";},
	'loadDate':function(d,z){
		var month=(d.getMonth()+1) < 10 ? '0'+(d.getMonth()+1) : (d.getMonth()+1);
		var h=d.getDate() < 10 ? '0'+(d.getDate()+1) : (d.getDate()+1);
		if(z == 's') h = "01";
		return d.getFullYear()+'-'+month+'-'+h;
	},
	'string2timeHS':function(s){return s.substring(0, 4) + "-" + s.substring(4, 6) + "-"+ s.substring(6, 8) + " " + s.substring(8, 10) + ":"+ s.substring(10, 12) + ":" + s.substring(12, 14);},
	'lotName':{'501':'胜平负','502':'总进球','503':'比分','504':'半全场'},
	'status':{'0':'进行中','1':'已结束','2':'已取消'}
},NcN_Map={'1':'1串1','2':'2串1','3':'3串1','4':'3串3','5':'3串4','6':'4串1',
	'7':'4串4','8':'4串5','9':'4串6','10':'4串11','11':'5串1','12':'5串5','13':'5串6',
	'14':'5串10','15':'5串16','16':'5串20','17':'5串26','18':'6串1','19':'6串6','20':'6串7',
	'21':'6串15','22':'6串20','23':'6串22','24':'6串35','25':'6串42','26':'6串50','27':'6串57'
};
function CostumDate_del(gameCode,starNikeName,canyuNikeName){
	
	$.getJSON('../../data/tary_del_single.jsp?r='+Math.random(),{'gameCode':gameCode,'starNikeName':starNikeName,'canyuNikeName':canyuNikeName},function(requestText){
		
		if(requestText.result == 'success') {
			ShowCostumData(KO.U.Pages,KO.U.Every);
		}else{
			alert(requestText.result);
		}
	});
}
function ShowCostumData(p,e){
	
	
	$('.loding').show();
	var gameCode = KO.$('lotName').value;
	var status	 = KO.$('lotType').value;
	KO.U.Pages = p;
	KO.U.Every = e;
	
	$.getJSON('../../data/tary_select_single.jsp?r='+Math.random(),{'userNickName':nikeName,'gameCode':gameCode,'status':status,'pages':KO.U.Pages,'every':KO.U.Every},function(JSON){
		
		var items = JSON.items;
		
		var tr='';
		if(items.length == 0) tr = '<tr><td colspan="10">没有找到相关的记录！</td></tr>';
		$('.b_r_table > tbody,.f_an_page,#rc_t_ty').empty();
		KO.countEvery=items.length;
		var ey=parseInt(JSON.record)/parseInt(KO.U.Every);
		ey = ey < 1 ? 1 : ey;
		paging1(ey,p);
		
		$(items).each(function(i,v){
			
			tr += '<tr><td>'+setting.lotName[v.lotName]+'</td><td>'+v.startUserNickName+'</td><td><font color="red">'+parseInt(v.orderBets)+'元</font></td><td>'+setting.status[v.orderStatus]+'</td><td><a href="javascript:void(0)" onclick=CostumDate_del("'+v.lotName+'","'+v.startUserNickName+'","'+v.canYuUserNickName+'")>取消定制</a></td></tr>';
		})
		
		$(tr).appendTo('.my_tary');
		$('.loding').hide();
	});
}

 $(function(){
	$('.page a').click(function(){
		$(this).siblings().removeClass();
		$(this).addClass('an_x_z');
		KO.U.Every=$(this).text();
		ShowCostumData(KO.U.Pages,KO.U.Every);
	})
 })
 