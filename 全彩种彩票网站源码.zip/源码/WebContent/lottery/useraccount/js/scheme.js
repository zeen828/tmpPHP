
var issue = "" ;
function sort(item){
	
	for(var i=0;i<item.length-1;i++){
		
		for(var s=0;s<item.length-1-i;s++){
			
			if(item[s].charAt(0) > item[s+1].charAt(0)){
				
				var temp=item[s];
				item[s]=item[s+1];
				item[s+1]=temp;
			}
		}
	}
return item;
}

$.getJSON(url+'/letoula/data/buyLottery_details.jsp?r='+Math.random(),{'trnNumber':trnNumber},function(json){
	
	var items=json.items;
	$(items).each(function(i,v){
		
		var mcn=create_class.return_mcn(v.manner,v.lotName);
		$('.username').text(v.userid);
		switch(v.lotName){
			case '501':
			case '502':
			case '503':
			case '511':
			case '509':
			case '504':$('.zwf').text('竞彩足球');break;
			case '505':
			case '506':
			case '507':
			case '510':
			case '508':$('.zwf').text('竞彩篮球');break;
			case '301':
			case '302':
			case '303':
			case '304':
			case '305':$('.zwf').text('单场');break;
			case '102':
			case '103':
			case '106':
			case '107':$('.zwf').text('传统足彩');break;
		}
		$('.st_lot').html(lotName[v.lotName]);
		
		if(betNum.indexOf('.txt') <= -1){
			$('.t_head').append(table_head[v.lotName]);
		}else{
			if(v.lotName=='102' || v.lotName=='103' || v.lotName=='106' || v.lotName=='107'){
				$('.t_head').append(table_head[v.lotName]);
			}else if(v.lotName>=501 && v.lotName<=511){
				$('.t_head').append(table_head["uploadjc"]);
			}else{
				$('.t_head').append(table_head["upload"]);
			}
    		var u = betNum.substring(betNum.lastIndexOf("/")+1,betNum.length);
    		
    		$('.uploadDeatils').append("<tr><td colspan='2' align='center'><a class='uploadxq' href='uploadTxTShow.jsp?t="+u+"' target='_blank'>查看上传方案详情</a></td></tr>");
		}
		$('.st_startime').text(create_class.string2timeHS(v.starTime).split(" ")[0]);
		$('.st_startime_q').text(create_class.string2timeHS(v.starTime));
		$('.st_endTime').text(create_class.string2timeHS(v.endTime));
		$('.tzfs').html(mcn.split(',')[0]+'...<font color="red" title="'+mcn+'" style="cursor:pointer;">查看全部投注方式</font>');
		$('.fabh').text(v.serialno);
		$('.fazt').text(v.status);
		$('.bs').text(v.multiple);
		$('.bdfs').text(v.ensure);
		$('.my').text(''+parseInt(v.money));
		$('.uesrCount').text(v.userCount);
		$('.myrg').text(parseInt(rgPrice));
		$('.rgmy').text(parseInt(v.subscribe)*parseInt(v.price));
		$('.rgbl').text(parseFloat(parseInt(v.subscribe)/parseInt(v.copies)*100).toFixed(2)+'%');
		$('.rgzk').text(parseInt(v.subscribe)==parseInt(v.copies) ? '(满员)' : '(未满员)');
		$('.wtzk').text("("+v.status+")");
		$('.zjzk').text(isNaN(v.tempInfo) ? '(已中奖)' : '(未中奖)');
		$('.zjqk').text(isNaN(v.tempInfo) ? v.tempInfo : '(未中奖)');
		$('.shjj').text(isNaN(v.tempInfo)!=0 ? v.awardbets : '0.00');
		var item=sort(mcn.split(','));
		$('.minc').text(item[0].charAt(0));
		if(parseInt($('.mz').text()) >= parseInt(item[0].charAt(0)))
		{
			$('.zdc').text('√');
		}
		AG.numc = AG.numc.substring(0,AG.numc.length-1);
		//nowCai(v.issue,AG.numc);
	});
});


KO.Y={};
KO.Y.Trading=AG.Trading;
KO.Y.User=AG.User;
KO.Y.CP='份';
KO.Y.CR='元';
KO.Y.Pages="1";
KO.Y.Every="10";
KO.countEvery="0";
KO.S = AG.url+'/letoula/jczq/project_list.jsp?gameid='+AG.gameCode;

$('.d_h li').bind('click',function(){
	$(this).siblings().removeClass();
	$(this).removeClass().addClass('x_z');
	$('.list_table').hide().eq($(this).index()).show();

	if($(this).index()==1) showUserData(KO.Y.Trading,"1",KO.countEvery); 
	else showUserData(KO.Y.Trading,KO.Y.Pages,"10"); 
})

var table_head = {

	'501':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='108' colspan='3'><span>过关参考奖金</span><br/><span class='spf001'>胜</span>"+
  		  "<span class='spf001'>平</span><span class='spf001'>负</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'511':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='108' colspan='3'><span>过关参考奖金</span><br/><span class='spf001'>胜</span>"+
  		  "<span class='spf001'>平</span><span class='spf001'>负</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'502':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='80'><span>过关参考奖金</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'503':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='80'><span>过关参考奖金</span></td></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'509':"<tr class='headbg'><td>赛事编号</td><td width='172'>主队 VS 客队</td><td>比分</td><td>玩法</td><td width='250'>投注选项 [参考奖金指数]</td>"+
  		  "<td>彩果</td></tr>",	  
  		  
  	'504':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='80'><span>过关参考奖金</span></td></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'505':"<tr class='headbg'><td>赛事编号</td><td>客队</td><td>主队(让球值)</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='108' colspan='2'><span>过关参考奖金</span><br/><span class='spf001'>主负</span>"+
  		  "<span class='spf001'>主胜</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'506':"<tr class='headbg'><td>赛事编号</td><td>客队</td><td>主队(让球值)</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='108' colspan='2'><span>过关参考奖金</span><br/><span class='spf001'>主负</span>"+
  		  "<span class='spf001'>主胜</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'507':"<tr class='headbg'><td>赛事编号</td><td>客队</td><td>主队(让球值)</td><td width='150'>投注选项</td><td>胆拖</td>"+
  		  "<td width='80'><span>过关参考奖金</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'508':"<tr class='headbg'><td>赛事编号</td><td>客队</td><td>主队(让球值)</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='108' colspan='2'><span>过关参考奖金</span><br/><span class='spf001'>大分</span>"+
  		  "<span class='spf001'>小分</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'102':"<tr class='headbg'><td>场次</td><td>主队</td><td>客队</td><td width='74'>投注选项</td>"+
  		  "<td>彩果</td></tr>",
  		  
  	'103':"<tr class='headbg'><td>场次</td><td>主队</td><td>客队</td><td width='74'>投注选项</td>"+
  		  "<td>彩果</td></tr>",
  		  
  	'106':"<tr class='headbg'><td>场次</td><td>主队</td><td>客队</td><td width='74'>主场</td><td width='74'>客场</td>"+
  		  "<td>彩果(主/客)</td></tr>",
  		 
  	'107':"<tr class='headbg'><td>场次</td><td>主队</td><td>客队</td><td width='74'>半场</td><td width='74'>全场</td>"+
  		  "<td>彩果(半/全)</td></tr>",
  	
  	'301':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='108' colspan='3'><span>过关参考奖金</span><br/><span class='spf001'>胜</span>"+
  		  "<span class='spf001'>平</span><span class='spf001'>负</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'302':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='108' colspan='3'><span>过关参考奖金</span><br/><span class='spf001'>胜</span>"+
  		  "<span class='spf001'>平</span><span class='spf001'>负</span></td><td>比分</td><td>彩果</td></tr>",
  	
  	'303':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='80'><span>过关参考奖金</span></td></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'304':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='80'><span>过关参考奖金</span></td><td>比分</td><td>彩果</td></tr>",
  		  
  	'305':"<tr class='headbg'><td>赛事编号</td><td>主队(让球值)</td><td>客队</td><td width='74'>投注选项</td><td>胆拖</td>"+
  		  "<td width='80'><span>过关参考奖金</span></td></td><td>比分</td><td>彩果</td></tr>",
    'upload':"<tr class='headbg'><td width='100'>赛事编号</td><td>主队(让球值)</td><td>客队</td><td>投注选项</td><td>彩果</td><td>开奖SP值</td></tr>",
    'uploadjc':"<tr class='headbg'><td width='100'>赛事编号</td><td>主队(让球值)</td><td>客队</td><td>投注选项</td><td>比分</td><td>彩果</td></tr>",
    'uploadct':"<tr class='headbg'><td width='100'>赛事编号</td><td>主队(让球值)</td><td>客队</td><td>投注选项</td><td>彩果</td></tr>"
};
function Chipped_in_submit(_this,trading){
	
	var copies=$("#rg_c").val(); 

	$.getJSON("../data/Chipped_in_submit.jsp?r="+Math.random(),{'gameid':AG.gameCode,'Trading':trading,'copies':copies},function(su){
		
		if(su.result=='0000'){
		
			create_class.seaDetails('blk2','s','您好！您参与合买成功！','success',KO.S);
		}else{
			
			create_class.seaDetails('blk2','s','您好！'+su.result+'','error',KO.S);
		}
	})
	
}
function over_t(){
	
	create_class.seaDetails('blk2','h','','success',KO.S);
		
}
function paging(ey,pages){
		var e_y_a='';
		
		var next=parseInt(pages) >= ey ? ey : parseInt(pages)+1;
		var fist=parseInt(pages) <= 1 ? "1" : parseInt(pages)-1;
		
		e_y_a+="<a href='javascript:void(0)' onclick=showUserData('"+KO.Y.Trading+"','1','"+KO.Y.Every+"') class='h_l'>首页</a><a href='javascript:void(0)' onclick=showUserData('"+KO.Y.Trading+"','"+fist+"','"+KO.Y.Every+"') title='上一页' class='pre'></a>";
		var cls='';
		for(var e=0;e<ey;e++){
			
			if(e==(pages-1)) cls='an_x_z';
			else cls='';
			e_y_a+='<a href="javascript:void(0)" class="'+cls+'" onclick=showUserData("'+KO.Y.Trading+'","'+(e+1)+'","'+KO.Y.Every+'")>'+(e+1)+'</a>';
			
		}
		
		e_y_a+="<a href='javascript:void(0)' title='下一页' onclick=showUserData('"+KO.Y.Trading+"','"+next+"','"+KO.Y.Every+"') class='next'>下一页</a><a href='javascript:void(0)' onclick=showUserData('"+KO.Y.Trading+"','"+ey+"','"+KO.Y.Every+"') class='h_l'>尾页</a>";
		e_y_a+="<span class='sele_page'><input type='text' name='page' class='num' onkeyup='ValidataPage("+ey+",this)' id='govalue'  />"+
		"<input type='button' class='btn' onclick=loadPageData() value='GO'></span><font color='gray'>共"+Math.ceil(ey)+"页,"+KO.countEvery+"条记录</font>";
		
		$(e_y_a).appendTo('.f_an_page');
}
function ValidataPage(ey,_this){

		var pg=parseInt(_this.value);
		
		if(pg > ey) {
			_this.value=ey;
		}
		
		if(isNaN(_this.value) || _this.value.indexOf('.')!=-1 || pg <= 0){
		   _this.value=1;
		}
		
}
function loadPageData(){
	var ps=$("#govalue").val();
	showUserData(KO.Y.Trading,ps,KO.Y.Every);
}
function showUserData(t,p,e){
	KO.Y.Pages=p;
	KO.Y.Every=e;
	var Count_Record='';
	var My_Record='<tr><td>暂时没有您的认购信息 </td></tr>';
	$.getJSON("../data/list_user_data.jsp?r="+Math.random(),{'Trading':t,'pages':KO.Y.Pages,'every':KO.Y.Every},function(items){
		var article = items.record; //总条数
		var c_pis=0,c_pic=0,gr='',trc='';  //购买总份数
		var List = items.items;
		$('.countList,.myList,.f_an_page').empty();
		KO.countEvery=items.record;
		var ey=parseInt(items.record)/parseInt(KO.Y.Every);
		ey = ey < 1 ? 1 : Math.ceil(ey);
		
		paging(ey,p);
		My_Record='';
		for(var i=0;i<List.length;i++){
			
			
			gr = List[i].userName==AG.Lcd_user ? 'red' : 'gray';
			
			trc= (i+1) % 2==0 ? trc = 'tr2' : '';  
		 	
			Count_Record+="<tr class='"+trc+"'><td><a href='#'>"+List[i].userName+"</a></td>"+
    					  "<td><font class='"+gr+"'>"+List[i].copis+"</font></td>"+
    					  "<td><font class='"+gr+"'>"+List[i].price+"元</font></td>"+
    					  "<td><font class='"+gr+"'>"+create_class.string2timeHS(List[i].buyTime)+"</font></td>"+
    					  "<td class='"+gr+"'>-</td></tr>";
    		if(KO.Y.User==List[i].userName){
    			
    		   My_Record+="<tr><td><a href='#'>"+List[i].userName+"</a></td>"+
    					  "<td><font class='"+gr+"'>"+List[i].copis+"</font></td>"+
    					  "<td><font class='"+gr+"'>"+List[i].price+"元（"+parseFloat(parseInt(List[i].copis)/AG.count_pis*100).toFixed(2)+"%）</font></td>"+
    					  "<td><font class='"+gr+"'>"+create_class.string2timeHS(List[i].buyTime)+"</font></td>"+
    					  "<td class='"+gr+"'>-</td></tr>";
    		}
    		
		}
		
		$('.h_p').text(KO.countEvery);
		$(Count_Record).appendTo('.countList');
		$(My_Record).appendTo('.myList');
	});
	
}

function mltOnkeyUp(){
		
		var _this=arguments[0],
			val=parseInt(_this.value),
			reg=/^(0|[1-9][0-9]*)$/g;
		var fs=parseInt($('.sy_c').text());
			
		if(!reg.test(_this.value) || val <= 0 || val>fs){
			
		   _this.value=1;
		   if(val>fs){
		   		
		   		_this.value=fs;
		   }
		}
		
		$('.countMoney').text('￥'+(parseInt(_this.value)*AG.copisPrice)+'.00');
}


function nowCai(issue,numc){
	if(parseInt(AG.gameCode)<301 || parseInt(AG.gameCode)>305){
		clearTimeout(tt);
		return;
	}
	$.getJSON("../data/scoreDC.jsp?r="+Math.random(),{'issue':issue,'numc':numc},function(List){
		
		var items = List.items;
		var tr = "" , clsz = 'wu' , clsk = 'wu';
		for(var i = 0; i < items.length; i++){
			
			var odds = items[i].odds.split("|");
			if(items[i].quanchang == ""){
				items[i].quanchang = "--";
			}
			if(items[i].banchang == ""){
				items[i].banchang = "--";
			}
			
			
			if(items[i].spfcg != ""){
					
					var caiguo = items[i].spfcg , chinaCaiguo = "" , peilv = "" ,status = "";
						
						var qc = items[i].quanchang.split('-');
						if(parseInt(items[i].rangqiu) < 0){
							qc[0] = parseInt(qc[0]) + parseInt(items[i].rangqiu);
						}else{
							qc[1] = parseInt(qc[1]) - parseInt(items[i].rangqiu);
						}
						if(qc[0] == qc[1])
						{
							caiguo = '1';
						}else if(parseInt(qc[0]) > parseInt(qc[1])){
							caiguo = '3';
						}else if(parseInt(qc[0]) < parseInt(qc[1])){
							caiguo = '0';
						}
				switch(caiguo){
					case '3':
						chinaCaiguo = "胜"; 
						peilv = "<span><font class='speilv'>"+odds[0]+"</font></span><span class='weight'>"+odds[1]+"</span><span>"+odds[2]+"</span>";
						break;
					case '1':
						chinaCaiguo = "平"; 
						peilv = "<span>"+odds[0]+"</span><span class='weight'><font class='ppeilv'>"+odds[1]+"</font></span><span>"+odds[2]+"</span>";
						break;
					case '0':
						chinaCaiguo = "负"; 
						peilv = "<span>"+odds[0]+"</span><span class='weight'>"+odds[1]+"</span><span><font class='fpeilv'>"+odds[2]+"</font></span>";
						break;
					default:
						peilv = "<span>"+odds[0]+"</span><span class='weight'>"+odds[1]+"</span><span>"+odds[2]+"</span>";
						break;
				}
				
				if(isNaN(items[i].status)){
					items[i].spfcg = "<strong><font color='red'>"+chinaCaiguo+"</font></strong>";
					status = items[i].status;
				}else{
					items[i].spfcg = "<strong><font color='blue'>"+chinaCaiguo+"</font></strong>";
					status = items[i].status+"<img src='../images/in2.gif' />";
				}
				
			}
			
		
			var startime = items[i].startTime.substring(4,6)+"-"+items[i].startTime.substring(6,8)+" "+items[i].startTime.substring(8,10)+":"+items[i].startTime.substring(10,12);
			tr+="<tr><td>"+items[i].gamenum+"</td><td>"+items[i].gamename+"</td><td>"+startime+"</td><td>"+status+"</td><td align='right' class='"+clsz+"'>"+items[i].hostItem+"<font color='red'>("+items[i].rangqiu+")</font></td>"+
				"<td class='red'><strong>"+items[i].quanchang+"</strong></td><td align='left' class='"+clsk+"'>"+items[i].keItem+"</td><td class='red'><strong>"+items[i].banchang+"</strong></td><td>"+peilv+"</td><td>"+items[i].spfcg+"</td></tr>";
		}
		
		$('.hot_body').html(tr);
	});
	
	var tt = setTimeout("nowCai('"+issue+"','"+numc+"')",1000);
}
$(function(){
	
	showUserData(KO.Y.Trading,KO.Y.Pages,KO.Y.Every);

});