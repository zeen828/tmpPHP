
var uName_td="4-16个字符，可以使用汉字、数字、字母";
		var uName_msg01="对不起，用户名长度至少应该为4个字符！";
		var uName_msg02="对不起，用户名长度不能超过16个字符！";
		var pwd_msg01="您输入的密码不足6位，请重新输入！";
		var pwd_msg02="您输入的密码不能超过15位，请重新输入！";
		var pwd_msg03="您两次输入的密码不一致！";
		var pwd_msg04="6-15个字符，建议使用字母、数字组合，混合大小写";
		var nickName_msg01="对不起，账户昵称长度至少应该为2个字符！";
		var nickName_msg02="对不起，账户昵称长度不能超过20个字符！";
		var nickName_td="2-20个字符，可以使用汉字、数字、字母";
		var email_msg01="对不起，你输入的邮箱格式不正确";
		var email_msg02="请输入常用邮箱<font color='#FF0000'>(注:系统将把您的资料发到此邮箱,验证邮箱可货1元购彩金)</font>";
		var phone_msg01="对不起，你输入的手机号码格式不正确";
		var uName_false="false";
		var pwd_false="false";
		var ConfirmPwd="false";
		var nickName_false="false";
		var email_false="false";
		//检查用户名是否可用
		function checkUname(){
			var uName=$('#uName').val();
			var lens=0;;
			for(var i=0;i<uName.length;i++){
				if(uName.charCodeAt(i)>255){
					lens=lens+2;
				}else{
					lens=lens+1
				}
			}
			if(lens<4){
				$('#uName_msg').text(uName_msg01);
				$('#uName_td').html(uName_td);
				uName_false="false";
			}
			else if(lens>16){
				$('#uName_msg').text(uName_msg02);
				$('#uName_td').html(uName_td);
				uName_false="false";
			}else{
				uName=encodeURI(uName);
				$.getJSON("../../data/checkUserName.jsp?r="+Math.random(),{uName:uName,nickName:""},function(items){
					if(items.items[0].strs=="0"){
						$('#uName_td').html("<img src='../images/right.jpg' />");
						$('#uName_msg').text("");
						uName_false="true";
					}else{
						$('#uName_msg').text(items.items[0].strs);
						$('#uName_td').html(uName_td);
						uName_false="false";
					}
				});
			}
		}
		//检查密码是否可用
		function checkPwd(){
			var pwd=$('#pwd').val();
			if(pwd.length<6){
				$('#pwd_msg').text(pwd_msg01);
				$('#pwd_td').html(pwd_msg04);
				pwd_false="false";
			}
			else if(pwd.length>15){
				$('#pwd_msg').text(pwd_msg02);
				$('#pwd_td').html(pwd_msg04);
				pwd_false="false";
			}
			else{
				$('#pwd_msg').text("");
				$('#pwd_td').html("<img src='../images/right.jpg' />");
				pwd_false="true";
			}
		}
		//检查二次密码
		function checkConfirmPwd(){
			if($('#pwd').val()==""){
				$('#confirmPwd_td').html("请再次输入密码");
				ConfirmPwd="false";
				return;
			}
			if($('#pwd').val()==$('#confirmPwd').val()){
				$('#confirmPwd_msg').text("");
				$('#confirmPwd_td').html("<img src='../images/right.jpg' />");
				ConfirmPwd="true";
			}else{
				$('#confirmPwd_td').html("请再次输入密码");
				$('#confirmPwd_msg').text(pwd_msg03);
				ConfirmPwd="false";
			}
		}
		//检查账户昵称
		function checkNickName(){
			var nickName=$('#nickName').val();
			if(nickName.length<2){
				$('#nickName_msg').text(nickName_msg01);
				$('#nickName_td').html(nickName_td);
				nickName_false="false";
			}
			else if(nickName.length>20){
				$('#nickName_msg').text(nickName_msg02);
				$('#nickName_td').html(nickName_td);
				nickName_false="false";
			}else{
				nickName=encodeURI(nickName);
				$.getJSON("../../data/checkUserName.jsp?r="+Math.random(),{uName:"",nickName:nickName},function(items){
					if(items.items[0].strs=="0"){
						$('#nickName_td').html("<img src='../images/right.jpg' />");
						$('#nickName_msg').text("");
						nickName_false="true";
					}else{
						$('#nickName_msg').text(items.items[0].strs);
						$('#nickName_td').html(nickName_td);
						nickName_false="false";
					}
				});
			}
		}	
		//设置cookie
		function setCookie(){
			var rnd="";
			for(var i=0;i<6;i++){
				rnd=rnd+Math.floor(Math.random()*10).toString();
			}
			document.cookie="code="+rnd;
						var dsf=document.cookie
						alert(dsf);
		}

		function login(uName,pwd){
			var urls = url;
	  		$.ajax({
					url:urls+'/GuoguantjAction.do?action=login&uName='+uName+'&pwd='+pwd+'&r='+Math.random(),
					type:'POST',
					error:function(){alert('链接有误！！')},
					success:function(w_list){
						alert(w_list);
					}
			});
		}
		//用户注册
		function userRegister(){
			if(uName_false=="false"||pwd_false=="false"||ConfirmPwd=="false"){
					alert("请填写完整信息");
					return;
			}
			var uName=$('#uName').val();
			var pwd=$('#pwd').val();
			//uName=encodeURI(uName);
			$.getJSON("../../data/userRegistered.jsp?r="+Math.random(),{uName:uName,pwd:pwd},function(items){
					if(items.items[0].strs=="0"){
						var urls = url;
				  		$.ajax({
								url:urls+'/letoula/data/user_login.jsp?username='+encodeURIComponent(uName)+'&password='+pwd+'&code=no&validateCode=1314&r='+Math.random(),
								type:'POST',
								error:function(){alert('链接有误！！')},
								success:function(w_list){
									window.location.href="./success.jsp";
								}
						});
					}else{
						alert(items.items[0].strs);
					}
			});
		}
		//验证密码等级
function _onChage(_this){
	validateRules.pwdlevel($(_this).val());
}
var validateRules = {
	 pwdlevel:function(v){
	    var value = v;
		var strength = 0;
		$('#span1').removeClass();
		$('#span2').removeClass();
		$('#span3').removeClass();
		$('#span4').removeClass();
		$('#span5').removeClass();
		$('#span6').removeClass();
		if (value.length>=6)
		{
			//开始check
			var str = this.checkStrong(value);
			switch (str)
			{
				case 1:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade02");
					$('#span3').addClass("safe_grade02");
					$('#span4').addClass("safe_grade02");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("弱");
					grade="1;"
					break;
				case 2:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade02");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("中");
					grade="2";
					break;
				case 3:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade01");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("中");
					grade="3";
					break;	
				case 4:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade01");
					$('#span5').addClass("safe_grade01");
					$('#span6').addClass("safe_grade01");
					$('#span7').text("强");
					grade="4";
					break;
				default:
					break;
			}
		}else{
			$('#span1').addClass("safe_grade01");
			$('#span2').addClass("safe_grade02");
			$('#span3').addClass("safe_grade02");
			$('#span4').addClass("safe_grade02");
			$('#span5').addClass("safe_grade02");
			$('#span6').addClass("safe_grade02");
			$('#span7').text("弱");
		}
	 },
	 checkStrong:function(sPW){
		  var Modes=0;
		  for (var i=0;i<sPW.length;i++)
		  {
			  //测试每一个字符的类别并统计一共有多少种模式.
			  //测试某个字符是属于哪一类
			  var iN = sPW.charCodeAt(i)
			  var cm = (function(iN){
				  if (iN>=48 && iN <=57) //数字
				  return 1;
				  if (iN>=65 && iN <=90) //大写字母
				  return 2;
				  if (iN>=97 && iN <=122) //小写
				  return 4;
				  else
				  return 8; //特殊字符
			  })(iN);	
			  
			  Modes|=cm;
		  }
		  var bt =(function(num){
			   modes=0;
			   for (i=0;i<4;i++)
			   {
				  if (num & 1) modes++;
				  num>>>=1;
			   }
			   return modes;
			 })(Modes);
	  
		  return bt;
	 }
};