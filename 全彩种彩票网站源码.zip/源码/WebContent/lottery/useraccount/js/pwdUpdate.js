var grade="";
function _onChage(_this){
	validateRules.pwdlevel($(_this).val());
}
var validateRules = {
	 pwdlevel:function(v){
	    var value = v;
		var strength = 0;
		$('#span1').removeClass();
		$('#span2').removeClass();
		$('#span3').removeClass();
		$('#span4').removeClass();
		$('#span5').removeClass();
		$('#span6').removeClass();
		if (value.length>=6)
		{
			//开始check
			var str = this.checkStrong(value);
			switch (str)
			{
				case 1:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade02");
					$('#span3').addClass("safe_grade02");
					$('#span4').addClass("safe_grade02");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("弱");
					grade="1;"
					break;
				case 2:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade02");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("中");
					grade="2";
					break;
				case 3:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade01");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("中");
					grade="3";
					break;	
				case 4:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade01");
					$('#span5').addClass("safe_grade01");
					$('#span6').addClass("safe_grade01");
					$('#span7').text("强");
					grade="4";
					break;
				default:
					break;
			}
		}else{
			$('#span1').addClass("safe_grade01");
			$('#span2').addClass("safe_grade02");
			$('#span3').addClass("safe_grade02");
			$('#span4').addClass("safe_grade02");
			$('#span5').addClass("safe_grade02");
			$('#span6').addClass("safe_grade02");
			$('#span7').text("弱");
		}
	 },
	 checkStrong:function(sPW){
		  var Modes=0;
		  for (var i=0;i<sPW.length;i++)
		  {
			  //测试每一个字符的类别并统计一共有多少种模式.
			  //测试某个字符是属于哪一类
			  var iN = sPW.charCodeAt(i)
			  var cm = (function(iN){
				  if (iN>=48 && iN <=57) //数字
				  return 1;
				  if (iN>=65 && iN <=90) //大写字母
				  return 2;
				  if (iN>=97 && iN <=122) //小写
				  return 4;
				  else
				  return 8; //特殊字符
			  })(iN);	
			  
			  Modes|=cm;
		  }
		  var bt =(function(num){
			   modes=0;
			   for (i=0;i<4;i++)
			   {
				  if (num & 1) modes++;
				  num>>>=1;
			   }
			   return modes;
			 })(Modes);
	  
		  return bt;
	 }
};
function isPassword(UserPassword){
	return /^[\w]{6,16}$/.test( UserPassword );
} 
//检测密码
function updatePassword(){
   if( ! ( document.getElementById("oldPwd").value ) ) {
		alert("\请输入原密码!");
		document.getElementById("oldPwd").select();
		document.getElementById("oldPwd").focus();
		return false;
	}
	else if( ! isPassword( document.getElementById("newPwd").value ) ) {
		alert("\新密码至少由6个英文字母或数字组成!");
		document.getElementById("newPwd").select();
		document.getElementById("newPwd").focus();
		return false;
	}
	else if( ! ( document.getElementById("confirmPwd").value ) ) {
		alert("\请输入确认新密码!");
		document.getElementById("confirmPwd").select();
		return false;
	}
	else if( document.getElementById("confirmPwd").value != document.getElementById("newPwd").value ) {
		alert("\两次密码输入不一致!");
		document.getElementById("newPwd").value="";
		document.getElementById("confirmPwd").value="";
		document.getElementById("newPwd").focus();
		return false;
	}else{
		return true;
	}
}
//修改密码
function pwdUpdate(){
	if(!updatePassword()){
		return;
	}
	var newPwd= document.getElementById("newPwd").value;
	var oldPwd= document.getElementById("oldPwd").value;
	
	$.getJSON(url+"/letoula/data/pwdUpdate.jsp?r="+Math.random(),{newPwd:newPwd,oldPwd:oldPwd,safeGrade:grade},function(items){
		var item=items.items;
		alert(item[0].strs);
	});
}
