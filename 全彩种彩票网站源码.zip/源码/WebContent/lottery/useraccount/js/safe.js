﻿$.getJSON("../../data/showUser.jsp?r="+Math.random(),function(items){
		$('#span1').removeClass();
		$('#span2').removeClass();
		$('#span3').removeClass();
		$('#span4').removeClass();
		$('#span5').removeClass();
		$('#span6').removeClass();
	switch (parseInt(items.items[0].safeGrade)){
				case 1:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade02");
					$('#span3').addClass("safe_grade02");
					$('#span4').addClass("safe_grade02");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("弱");
					break;
				case 2:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade02");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("中");
					break;
				case 3:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade01");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("中");
					break;	
				case 4:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade01");
					$('#span3').addClass("safe_grade01");
					$('#span4').addClass("safe_grade01");
					$('#span5').addClass("safe_grade01");
					$('#span6').addClass("safe_grade01");
					$('#span7').text("强");
					break;
				default:
					$('#span1').addClass("safe_grade01");
					$('#span2').addClass("safe_grade02");
					$('#span3').addClass("safe_grade02");
					$('#span4').addClass("safe_grade02");
					$('#span5').addClass("safe_grade02");
					$('#span6').addClass("safe_grade02");
					$('#span7').text("弱");
					break;
	}
	if(items.items[0].pwdQuestion01==' '&&items.items[0].pwdQuestion01==''){
		$('#pwdProtect').html("<a href='#' style='color:#0F3F94;'>开通</a>");
	}else{
		$('#pwdProtect').html("<span style='color:#999999;'>已开通</span>");
	}
	$('#uName').text(items.items[0].nickName.substr(0,1)+"**");
	$('#idCard').text(items.items[0].idCard.substr(0,5)+"****"+items.items[0].idCard.substr(15));
	$('#cardNo').text(items.items[0].cardNo.substr(0,10)+"******");
	if(items.items[0].phoneNum==' '||items.items[0].phoneNum==""){
		$('#phoneNum').html("未验证<span style='font:12px Arail;color:#999999;'>(验证手机可获赠2元购彩资金)</span>");
		$('#phoneUpdate').html("<a href='#' style='color:#0F3F94;'>去验证</a>");
	}else{
		$('#phoneNum').text(items.items[0].phoneNum.substr(0,3)+"****"+items.items[0].phoneNum.substr(7));
		$('#phoneUpdate').html("<a href='#' style='color:#0F3F94;'>修改</a>");
	}
	if(items.items[0].email==' '||items.items[0].email==''){
		$('#email').html("未验证<span style='font:12px Arail;color:#999999;'>(验证手机可获赠1元购彩资金)</span>")
		$('#emailUpdate').html("<a href='#' style='color:#0F3F94;'>去验证</a>");
	}else{
		var index=items.items[0].email.indexOf("@");
		$('#email').text(items.items[0].email.substr(0,3)+"****"+items.items[0].email.substr(index))
		$('#emailUpdate').html("<a href='#' style='color:#0F3F94;'>修改</a>");
	}
	
});