function trim(obj) {
		obj.value = obj.value.replace(/(^\s*)|(\s*$)/g, "");
}
function bankBind(){
	var bank=$('#bank').val();
	var bankName=$('#bankName').val();
	var bankCard=$('#bankCard').val();
	//alert("bank---"+bank);
	//alert("bankName---"+trim(bankName));
	//alert("bankCard---"+trim(bankCard));
	if(bank=='0'){
		alert("请选择银行");
	 return false;	
	}
	if(bankName==null ||$.trim(bankName)==''){
		alert("请输入账户名");
	 return false;	
	}
	if(bankCard==null || $.trim(bankCard)==''){
		alert("请输入银行卡号");
	 return false;	
	}
	bank=encodeURI(bank);
	bankName=encodeURI(bankName);
	$.getJSON(url+"/letoula/data/bankBind.jsp?r="+Math.random(),{bank:bank,bankName:bankName,bankCard:bankCard},function(items){
		if(items.items[0].strs=="0000"){
			alert("绑定成功！！！");
			location.reload();
		}else{
			alert("绑定失败！！！");
		}
	});
}