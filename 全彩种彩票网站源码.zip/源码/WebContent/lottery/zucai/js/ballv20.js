
ZQ.betJson = {}; //总投注详情
ZQ.betArr = [];  //过滤详情为数组
ZQ.countBet=0; //投注金额
ZQ.notes=0; //注数
ZQ.muliptile=1; //倍数
ZQ.tzNumber=''; //投注号码
ZQ.spzValue = ''; //投注SP
ZQ.wasMuster='1';  //过关方式
ZQ.OptimizationStr = ''; //奖金优化串
ZQ.biggestPrize = 0;
ZQ.ClearanceType=0; //0单一彩种 , 1混合过关
ZQ.TenFourChang = {};
var today = ['日','一','二','三','四','五','六'];
ZQ.MarKetClearx={
	'r':[],
	's':[],
	'q':[]
}; //赛事筛选
function show_encounter(){
	
	$.getJSON(url+"/letoula/data/winsFlat_trade.jsp?r="+Math.random(),{'smalltype':javaAgras.gameid,'issue':javaAgras.issue},function($_return){
    	var it=$_return.items;
		var tr = '' , table = '<table class="entronTab zucaitable" cellspacing="0" cellpadding="0" id="table0" width="699">',day=0 , day_count = 0;
		var betodds = '',overbg = 'overbg';
		if(javaAgras.issue == javaAgras.currIssue){
			betodds='bet_odds' , overbg = '';
		}
		for(var i=0;i < it.length; i++)
		{
			var spvalue = it[i].spValue.replace(/[" "]/g,"|").split('|');
			if(spvalue[0] == 'null' || spvalue[0] == 'undefined' ||  spvalue[0]==''){
				spvalue = [' ',' ',' '];
			}
			ZQ.TenFourChang[it[i].againstId] = {'id':it[i].againstId,'ht':it[i].hostteam,'vt':it[i].guestdu,'lg':it[i].legaueName,'gamenum':it[i].mathNum,'stopselldate':'','rq':'','gall':'0','arrs':[],'arrnumber':["9"],'hbsg':'','bet':'','opn':''};
			var stoptime = it[i].stopselldate.substring(4,6) +'-'+ it[i].stopselldate.substring(6,8)+" "+it[i].stopselldate.substring(8,10)+':'+it[i].stopselldate.substring(10,12);
			
			if(javaAgras.issue >= javaAgras.currIssue){
				tr+='<tr class="alltrObj" lg="'+it[i].legaueName+'"  vt="'+it[i].guestdu+'"  rq="0" id="'+it[i].againstId+'" stopdate="'+it[i].stoptime+'" gamenum="'+it[i].mathNum+'" hostteam="'+it[i].hostteam+'" arrySerial="'+i+'">'+
					'<td align="center" width="20">'+it[i].mathNum+'</td>' + 
					'<td width="50"><span class="leglbl" style="background: ' + it[i].legaueColor + '">' + it[i].legaueName+'</span></td>' +
					'<td align="center" width="20">'+stoptime+'</td>' +
					'<td width="70"><span class="nm">' + it[i].hostteam + '</span><span class="st">' + it[i].b1 + '</span></td>' +
					'<td width="70"><span class="nm green">' + it[i].guestdu + '</span><span class="st">' + it[i].b2 + '</span></td>' +
					'<td align="center" class="dzSpTd" width="70"><div class="'+betodds+' zc_bet_odds">'+
					'<span  class="lqItem item_l '+overbg+'" data-sp="'+spvalue[0]+'" value="3" title="主队胜" data-s="t1" data-gamenum="103">' +
					// '<em class="kepai">'+it[i].b1+'</em>' +
					// '<em class="dcke zcke">'+it[i].hostteam+'</em>' +
					'<em class="dckename">'+spvalue[0]+'</em></span>'+
					'<span class="dczItem item_l '+overbg+'" data-sp="'+spvalue[1]+'" value="1" title="平局" data-s="t2" data-gamenum="103">'+spvalue[1]+'</span>'+
					'<span class="lqItem item_l '+overbg+'" data-sp="'+spvalue[2]+'" value="0" data-s="t3" title="客队胜" data-gamenum="103">' +
					// '<em class="zhupai">'+it[i].b2+'</em>' +
					// '<em class="dczhu zczhu">'+it[i].guestdu+'</em>' +
					'<em class="dczhuname">'+spvalue[2]+'</em></span>'+
					'</div></td>'+'<td width="20" text-align="center"><a href="#">析</a></td></div></td></tr>';
									
			}else{
				tr+='<tr class="alltrObj" lg="'+it[i].legaueName+'"  vt="'+it[i].guestdu+'"  rq="0" id="'+it[i].againstId+'" stopdate="'+it[i].stoptime+'" gamenum="'+it[i].mathNum+'" hostteam="'+it[i].hostteam+'" arrySerial="'+i+'">'+
					'<td align="center" width="33">'+it[i].mathNum+'</td><td width="65" style="">'+it[i].legaueName+'</td><td align="center" width="120">'+stoptime+'</td><td align="center" class="dzSpTd" width="500"><div class="'+betodds+' zc_bet_odds">'+
					'<span class="lqItem item_l '+overbg+'" data-sp="'+spvalue[0]+'" value="3" title="主队胜" data-s="t1" data-gamenum="103"><em class="kepai">'+it[i].b1+'</em><em class="dcke zcke">'+it[i].hostteam+'</em><em class="dckename">'+spvalue[0]+'</em></span>'+
					'<span class="dczItem item_l '+overbg+'" data-sp="'+spvalue[1]+'" value="1" title="平局" data-s="t2" data-gamenum="103">'+spvalue[1]+'</span>'+
					'<span class="lqItem item_l '+overbg+'" data-sp="'+spvalue[2]+'" value="0" data-s="t3" title="客队胜" data-gamenum="103"><em class="zhupai">'+it[i].b2+'</em><em class="dczhu zczhu">'+it[i].guestdu+'</em><em class="dczhuname">'+spvalue[2]+'</em></span>'+
					'</div></td><td align="center" width="50">'+it[i].bifen+'</td><td width="50" align="center" class="font_red font_bold">'+it[i].caiguo+'</td><td width="180"><div class="oupei"><span class="spf_rq">'+spvalue[0]+'</span><span class="spf_rq">'+spvalue[1]+'</span><span class="spf_rq">'+spvalue[2]+'</span></div></td></tr>';
			}
		}
		table += tr+"</table>";
		$('.encounterMain').html(table);
		if(it.length==0){
			$('.encounterMain').html('<div style="width:678px; height:100px; clear:both; text-align:center"><h1>温馨提示：</h1><br/>投注赛事暂未公布，去<a href="http://www.beikecai.com/jingcai2/0_0513">竞彩足球</a> 看看吧～</div>');
		}
		$.domHover($('.entronTab tbody tr'),'#fff8dc');
		$.domSpanBack($('.dzSpTd div span'),'zc_over');
		bet_config.spclick();
	});
	
};

var bet_config = {
	'spclick':function(){
		$('.bet_odds span').click(function(){
			var _class = $(this).attr('class');
			var HTMLOBJECT_TR = $(this).parents('tr');
			var id = HTMLOBJECT_TR.attr('id');
			if(_class.indexOf('yeswin')==-1)
			{
				$(this).addClass('yeswin');
				//$.Accession($(this),$('.sedan'));
			}else
			{
				$(this).removeClass('yeswin');
			}
			var betArr = $(HTMLOBJECT_TR).find('td:eq(5) > div > span.yeswin');
			var bet = [] , arrs = [] , arrnumber = [] , HybridStrings=[],suanJ = [],option=[];
			for(var k = 0; k < betArr.length;k++)
			{
				var gn = $(betArr).eq(k).attr('data-gamenum'),
					sp = $(betArr).eq(k).attr('data-sp'),
					s = $(betArr).eq(k).attr('data-s'),
					val = $(betArr).eq(k).attr('value');
				bet.push({'gn':gn,'sp':sp,'s':s,'val':val});
				arrs.push(sp);
				arrnumber.push(val);
				HybridStrings.push(gn+":"+val+":"+sp+":"+id+":");
				option.push(val+':'+sp+':'+HTMLOBJECT_TR.attr('gamenum')+'~');
			}
			var hbsg = HybridStrings.join('|');
			var opn = option.join('|');
			ZQ.betJson[id]={'id':id,'ht':HTMLOBJECT_TR.attr('hostteam'),'vt':HTMLOBJECT_TR.attr('vt'),'lg':HTMLOBJECT_TR.attr('lg'),'gamenum':HTMLOBJECT_TR.attr('gamenum'),'stopselldate':HTMLOBJECT_TR.attr('stopselldate'),'rq':HTMLOBJECT_TR.attr('rq'),'gall':'0','arrs':arrs,'arrnumber':arrnumber,'hbsg':hbsg,'bet':bet,'opn':opn};
			if(betArr.length<=0){
				delete ZQ.betJson[id];
			}
			bet_config.totalBouns();
		});
		
		$('.radio_ck').click(function(){
			bet_config.marKetClick();
			$.offsetScr('betbottom','BettingRegion');
			$.offsetTopTitle('encounterMain','marketTitle');
		});
	},
	'totalBouns':function(){
		var Yes_bet = ZQ.betJson;
		ZQ.betArr = [];
		var count = this.objectCount(Yes_bet);
		ZQ.betArr = create_class.intSort(ZQ.betArr);
		
		$('.the_selected').text(count);
		var betTr = '' , wfstr = '' ,wf = [] , maxCount = '0';
		for(var k=0;k<ZQ.betArr.length;k++)
		{
			var betObject = ZQ.betArr[k];
			var bettingNumber = betObject.bet;
			var _HMC = '';
			for(var l=0;l<bettingNumber.length;l++)
			{
				wf.push(bettingNumber[l].gn);
				var rq = bettingNumber[l].gn == '511' ? betObject.rq : '';
				_HMC+='<a href="#">'+rq+all_config[bettingNumber[l].gn][bettingNumber[l].val]+'</a>';	
			}
		
			betTr+='<tr><td class="btl9">'+betObject.gamenum+'</td><td>'+betObject.ht.substring(0,3)+'</td><td>'+betObject.vt.substring(0,3)+'</td><td class="btlxz">'+_HMC+'</td>'+
				'<td><s class="delbet" data-del="'+betObject.id+'" onclick="javascript:bet_config.delOption(this)" /></td></tr>';
			
		}
		wf=this.Arrdel(wf);
		$('.TZ_tab').html(betTr);
		if(wf.length>1)
		{
			//$('.gallbladder').attr('disabled',true);
			wfstr = '任选九场';
			ZQ.ClearanceType = 1;
			javaAgras.gameid = '509';
			wf.sort(function(a,b){return a-b});
			maxCount = all_config[wf[wf.length-1]].mcn;
			count = count > maxCount ? maxCount : count;
		}else if(wf.length==0){
			wfstr = '任选九场';
			ZQ.ClearanceType=1;
			javaAgras.gameid = '509';
		}else{
			wfstr = all_config[wf[0]].name;
			ZQ.ClearanceType=0;
			javaAgras.gameid = wf[0];
		}
		$('.wfwz').text(wfstr);
		if(count>=9){
			this.CountAward();
		}
	},
	'delOption':function(_this){
		var delType = $(_this).attr("data-del");
		if(delType=='all')
		{
			var fa = confirm("您确定要删除所有比赛吗？");
			if(fa==true){
				for(var bs in ZQ.betJson){
					delete ZQ.betJson[bs];
					$("#"+bs+" > td > div.bet_odds > span.yeswin").removeClass('yeswin');
				}
			}
		}else
		{
			delete ZQ.betJson[delType];
			$("#"+delType+" > td > div.bet_odds > span.yeswin").removeClass('yeswin');
		}
		bet_config.totalBouns();
		this.CountAward();
	},
	'glbdr':function(_this){
		var valid =_this.value;
		ZQ.betJson[valid].gall = _this.checked==true ? '1' : '0';
		this.gallOption('gl');
	},
	'gallOption':function(bsbox){
		var count = ZQ.betArr;
		if(ZQ.betArr.length <= 0)
		{
			$('.ipt input').attr('checked',false);
			return;
		}
		var optioncheck = $('.ipt > input:checked');
		var rcarr = [];
		for(var i=0;i<optioncheck.length;i++)
		{
			var rc = $(optioncheck).eq(i).parent('span').attr('id');
			rcarr.push(DC_TYPE_MAP[rc][0].charAt(0));
		}
		rcarr.sort(function(a,b){return a-b});
		var minRc = parseInt(rcarr[0]);
		if(minRc == ZQ.betArr.length)
		{
			$('.gallbladder').attr({'disabled':true,'checked':false});
		}else
		{
			if($('.gallbladder:checked').length == (minRc - 1)){
				$('.gallbladder:not(:checked)').attr('disabled',true);
			}else if($('.gallbladder:checked').length > (minRc - 1))
			{
				$('.gallbladder').attr({'disabled':false,'checked':false});
			}
		}
		if((bsbox=='rc' && optioncheck.length==0) || (bsbox=='gl' && $('.gallbladder:checked').length==0))
		{
			$('.gallbladder').attr({'disabled':false,'checked':false});
		}
		this.CountAward();
	},
	'CountAward':function(){
		var sa = new Array(); //不为胆码数组
		var sb = new Array(); //有胆数组
		var b0=0,b1=0,zhushu=0,maxprice = 0;
		var OverPortfolio = ZQ.betArr;
		var spValArr = [] , spvalue=[] , tznumber = [] , hy = [] , cn = [],newHY=[],sjarr = [],overarr=[],danmaArr=[],yhc=[] ,yhopn = [];
		ZQ.muliptile = parseInt($('#multipleTx').val());
		for(var k =0; k < OverPortfolio.length;k++)
		{
			spvalue.push(OverPortfolio[k].id+','+OverPortfolio[k].arrs.join('/')+','+OverPortfolio[k].gall);
			tznumber.push(OverPortfolio[k].id+','+OverPortfolio[k].arrnumber.join('/')+','+OverPortfolio[k].gall);
			yhopn.push(OverPortfolio[k].opn);
			var sr = OverPortfolio[k].hbsg.split("|");
			var newHbsg = [];
			var arr = {'103':{}};
			sjarr[k]={'103':[]};
			var yhstr = '';
			for(var s = 0;s < sr.length;s++){
				sr[s] = sr[s]+OverPortfolio[k].gall+"-";
				yhstr+=sr[s]+OverPortfolio[k].gall+"~|";
				newHbsg.push(sr[s]);
				var S_a = sr[s].replace(/[~]/g,"").replace(/[ ]/,"");
				var so = S_a.split(":");
				arr[so[0]][so[1]]=so[2]; //so[2]=501,so[0]=3,so[1]=3.20
				sjarr[k][so[0]].push(sr[s]);
			}
			yhc.push(yhstr.substring(0,yhstr.length-1));
			var sjls = [];
			for(var sl in sjarr[k])
			{
				if(sjarr[k][sl]!=''){
					var ksl = sjarr[k][sl].join("/");
					sjls.push(ksl+"~");
				}
			}
			hy.push(sjls);
			//if(ZQ.ClearanceType==1){
				var budGet = bdyusuanMain(arr,OverPortfolio[k].rq);
				var bdt = budGet['max'];
				var tsr = [];
				for(var y=0;y<bdt.length;y++){
					tsr.push(bdt[y].gn+":"+bdt[y].val+":"+bdt[y].brouns+":"+OverPortfolio[k].id+":"+OverPortfolio[k].gall+"-~");
				}
				newHY.push(tsr);
			//}
			if(OverPortfolio[k].gall == '1'){
				sb.push(OverPortfolio[k].bet.length);
				danmaArr.push(OverPortfolio[k].id);
				b0++;b1++;
			}else
			{
				sa.push(OverPortfolio[k].bet.length);
			}
			var vp = OverPortfolio[k].arrs.join(',');
			spValArr.push(vp.split(',').sort(asc));
		}
		ZQ.spzValue = spvalue.join('//');
		ZQ.tzNumber = tznumber.join('//');
		spArr = spValArr;
		if(OverPortfolio.length<9)
		{
			$('#minprize,#maxprize,#betMoney,#zhushu').text(0);
		}else{
			var tempstr = yhopn.join(',');
			ZQ.OptimizationStr = tempstr;
			OverArry=[];
			var psy = '9';
			var methods =0;
			startRecon(hy,psy,methods,danmaArr,'9');
			zhushu+=OverArry.length;
			ZQ.notes = zhushu;
			ZQ.countBet = zhushu * ZQ.muliptile * 2;
			$('#zhushu').text(ZQ.notes);
			$('#betMoney').text(ZQ.countBet);
		}
	},
	'maxCountPrice':function(nrb){
		var maxpc = 0;
		for(var i =0; i < nrb.length;i++)
		{
			maxpc += parseFloat(nrb[i].m);
		}
		return maxpc;
	},
	'objectCount':function(o){
		var count =0;
		for(var gs in o)
		{
			ZQ.betArr.push(ZQ.betJson[gs]);
			count++;
		}
		return count;
	},
	'Arrdel':function(Arr_) { 
		var a = {}, c = [], l = Arr_.length; 
		for (var i = 0; i < l; i++) { 
			var b = Arr_[i]; 
			var d = (typeof b) + b; 
			if (a[d] === undefined) { 
				c.push(b); 
				a[d] = 1; 
			} 
		} 
		return c;
	},
	'ArrdelObj':function(Arr_) {
		var finalArr = []; 
		for(var i=0;i<Arr_.length;i++){
			//document.write(Arr_[i].ArrSp+"----"+Arr_[i].ArrXh+"----"+Arr_[i].ArrStrNum+"<br/>");
			if(!create_class.containsAll(finalArr,'ArrSp',Arr_[i].ArrSp+"--"+Arr_[i].ArrStrNum+"--"+Arr_[i].ArrXh)){
				finalArr.push(Arr_[i]);
			}
		}
		return finalArr;
	},
	'mltOnkeyUp':function(){
		
		var _this=arguments[0],
			val=parseInt(_this.value);
			
		if(val > 500000) {
			_this.value='500000';
		}
		
		if(isNaN(_this.value) || val <= 0 || _this.value.indexOf('.')!=-1){
		
		   _this.value=1;
		}
		
		ZQ.muliptile=_this.value;
		
		this.CountAward();
	},
	'rise_reduce_control':function(v){
		if(v == 'r')
		{
			ZQ.muliptile += 1;
		}else
		{
			var m = ZQ.muliptile - 1;
			ZQ.muliptile = m < 1 ? 1 : m;
		}
		var countBet = ZQ.notes * ZQ.muliptile * 2;
		var mpz = (parseFloat(ZQ.biggestPrize) * parseFloat(ZQ.muliptile)).toFixed(2);
		$("#betMoney").text(countBet);
		$("#maxprize").text(mpz);
		$("#multipleTx").val(ZQ.muliptile);
		ZQ.countBet = countBet;
	},
	'seaDetails':function(nd,sh,txt){
		var off_top=document.documentElement.scrollTop;
		var off_left=document.documentElement.scrollLeft; 
        create_class.centertical(ZQ.$(nd));
        $('.eroorMsg').text(txt);
		sh == 's' ? $('#bd,#'+nd+'').show() : $('#bd,#'+nd+'').hide();
	},
	'countNum':function(s,v,v1){
		var count = 0;
		for(var l =0; l<s.length;l++){
			var sValue = s[l][v1];
			if(v1=='againstNum')
			{
				sValue = s[l][v1].substring(0,2);
				v = v.substring(0,2);
			}else if(v1=='gamenum')
			{
				var groupTime = parseInt(s[l].stopTime.substring(0,8));
				if(parseInt(s[l].stopTime.substring(8,14)) < 60000){
					groupTime = groupTime - 1;
				}
				groupTime = groupTime.toString();
				var gst =  groupTime.substring(0,4) +'/' +groupTime.substring(4,6) +'/'+ groupTime.substring(6,8);
				var days = today[new Date(gst).getDay()];
				sValue = days;
			}
			if(sValue==v)
			{
				count++;
			}
		}
		return count;
	},
	'todayClickHide':function(_this){
		var day = $(_this).attr('m');
		var ck = $('.radio_ck[m*="'+day+'"]').attr('checked');
		var bol = ck ? false : true;
		$('.radio_ck[m*="'+day+'"]').attr('checked',bol);
		this.marKetClick();
	},
	'marKetClick':function(){
		$('.entronTab tbody tr').show();
		var notcheck = $('.shaxlist ul li input:not(:checked)');
		var yc = 0;
		for(var i=0;i<notcheck.length;i++)
		{
			var id = $(notcheck).eq(i).attr('id');
			if(id.indexOf('rq')!=-1)
			{
				var rqm = $('.entronTab tbody tr[rq*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(rqm).hide();
				yc+=$(rqm).length;
			}else if(id.indexOf('lg')!=-1){
				var lqm = $('.entronTab tbody tr[lg*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(lqm).hide();
				yc+=$(lqm).length;
			}else
			{
				var gmm = $('.entronTab tbody tr[gamenum*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(gmm).hide();
				yc+=$(gmm).length;
			}
		}
		$('.redtxtc').text(yc);
	},
	'AllMarket':function(str){
		var sarr = str.split('_');
		if(sarr[1] == 'qx')
		{
			$('.'+sarr[0]+' > ul > li > input').attr('checked',true);
		}else if(sarr[1] == 'fx')
		{
			var zk = $('.'+sarr[0]+' > ul > li > input:not(:checked)');
			var jk = $('.'+sarr[0]+' > ul > li > input:checked');
			$(zk).attr('checked',true);
			$(jk).attr('checked',false);
			
		}else if(sarr[1] == 'qq')
		{
			$('.'+sarr[0]+' > ul > li > input').attr('checked',false);
		}
		this.marKetClick();
	},
	/*
	*投注提交
	*/
	'submitInformation':function(mx){
		
		ZQ.wasMuster = '1';
		var nb = ZQ.tzNumber.split('//');
		if(ZQ.betArr.length!=9){
			this.seaDetails('blk2','s','您好，任选九场只能选择9场比赛！');
				return;
		}else if(nb.length>9){
			ZQ.wasMuster = '2';
		}
		
		
		for(var y=0;y<nb.length;y++)
		{
			var nb_le = nb[y].split(',')[1].split('/');
			if(nb_le.length>1){
				ZQ.wasMuster = '2';
			}
		}
		
		
		
		$('.jzTime').val('');   								//截至时间
		$('.muliptile').val(ZQ.muliptile);							//倍数
		$('.tzNumber').val(ZQ.tzNumber); 							//投注号码
		$('.zhushu').val(ZQ.notes);										//注数
		$('.price').val(parseFloat(ZQ.countBet).toFixed(2));				//投注金额
		$('.ZQMcN').val(ZQ.wasMuster);										//McN
		$('.spzValue').val(ZQ.spzValue.replace(/[" "]/g,""));		//sp值
		$('.moneyFw').val('0-0');									//奖金范围
		$('.tempstr').val(ZQ.OptimizationStr);								//优化数据 
		$('.gameCode').val(javaAgras.gameid);						//玩法
		var mcnArray=ZQ.wasMuster.split(',');
		var rmrn=Game_Map[ZQ.wasMuster];
		$('.McN').val(rmrn);
		
		

		var d='$',cos='';
		for(var tf in ZQ.TenFourChang){
			var arr = ZQ.betJson[tf];
			if(ZQ.betJson[tf]){
				arr = ZQ.betJson[tf];
			}else{
				arr = ZQ.TenFourChang[tf];
			}
			var pl=arr.arrs.join('_');
			var spf=arr.arrnumber.join('/');
			cos+=arr.gamenum+','+arr.ht+','+arr.vt+','+arr.rq+','+spf+','+pl+','+arr.id+d;
		}
		cos=cos.substring(0,cos.lastIndexOf('$'));
		
		$('.inf').val(cos);
		var fromPanl = "";
		
		if(mx=='yh'){
			if(ZQ.muliptile!=1){
				alert("奖金优化只支持1倍优化");
				return;
			}
			fromPanl = "prizereview";
			var cc = ZQ.wasMuster.split(",");
			for(var d = 0 ; d<cc.length; d++)
			{
				if(DC_McN_Map[cc[d]].indexOf('串1')==-1){
					alert("奖金优化只支持串1过关！");
					return;
				}
			}
		}else if(mx='m'){
			fromPanl = "myform";
		}
		ZQ.$(fromPanl).submit();
	}
};
 
$(function(){
	var sy = all_config[javaAgras.gameid][javaAgras.type+javaAgras.gameid];
	$('.lottery_nav ul li').removeClass().eq(sy).addClass('lothot');
	show_encounter();
	$(".time_k_j p").click(function(){
			$(this).addClass('timeOk').siblings().removeClass();
			$('.timeEntron span').hide();
			if($(this).text() == '截止'){
				$('.jz').show();
			}else{
				$('.ks').show();
			}
	});
	$.divClientShow('buy_list','buylistcon','buylistcon_lik','listMain');
	$.McNShow('ddMatch','matchrc','matchzk','listMatch');
	$.offsetScr('betbottom','BettingRegion');
	$.offsetTopTitle('encounterMain','marketTitle');
});
