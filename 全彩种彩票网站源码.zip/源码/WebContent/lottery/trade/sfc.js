﻿
var chooseArray=['*','*','*','*','*','*','*','*','*','*','*','*','*','*'];  //存号
var sapce = {};
var count_C = 0;
sapce.manner = 1;
sapce.muliptile =1;
sapce.countMoney = 0.00;
sapce.zs = 0;
sapce.issue = 0000;
sapce.info = '';


function showDz() {

$.getJSON(""+contextPath+"/letoula/data/winsFlat_trade.jsp?r="+Math.random(),{smalltype:gameid},function($_return){
    var items=$_return.items;
	var tr = '';
	$('.stoptime').text(setting.axyformatTime(items[0].stoptime));
	var num_S = '<td><span class="sp_w45"><span class="sp_nxz" onclick="create_class.cursorX(this)">3</span></span></td><td><span class="sp_w45"><span class="sp_nxz" onclick="create_class.cursorX(this)">1</span></span></td><td><span class="sp_w45"><span class="sp_nxz" onclick="create_class.cursorX(this)">0</span></span></td>';
	
	for(var i=0;i<items.length;i++){
		
	
		var spvalue = items[i].spValue.replace(/[" "]/g,"|").split('|');
		if(spvalue[0] == 'null' || spvalue[0] == 'undefined' ||  spvalue[0]==''){
			spvalue = [' ',' ',' '];
		}
		var stoptime = items[i].stopselldate.substring(4,6) +'-'+ items[i].stopselldate.substring(6,8)+" "+items[i].stopselldate.substring(8,10)+':'+items[i].stopselldate.substring(10,12);
		tr+='<tr class="c'+i+'" mathNum="'+items[i].mathNum+'" vs="'+items[i].hostteam+' VS  '+items[i].guestdu+'"><td>'+items[i].mathNum+'</td><td style="background: rgb(51, 102, 153);color:#fff" width="70">'+items[i].legaueName+'</td><td width="80">'+stoptime+'</td><td width="190"><sup>'+items[i].b1+'</sup><a href="javascript:void(0)" title='+items[i].hostteam+'>'+items[i].hostteam+'</a> <a class="sp_vs"><font color="gray">VS</font></a> <a href="javascript:void(0)" title='+items[i].guestdu+'>'+items[i].guestdu+'</a><sup>'+items[i].b2+'</sup></td><!--<td><a href="#">析</a>  <a href="#" class="sp_vs">亚 </a> <a href="#">欧</a></td></td>--><td><span class="sp_w38">'+spvalue[0]+'</span><span class="sp_w38">'+spvalue[1]+'</span><span class="sp_w38">'+spvalue[2]+'</span></td>'+num_S+'</tr>';
	}
	
	sapce.issue = items[0].issue;
	
	$('.now_issue').text(items[0].issue);
	$('.dssc').attr('href',$('.dssc').attr('href')+'&issue='+sapce.issue);
	
	$(tr).appendTo('.conbody');
	
});


}

var create_class={
	'cursorX':function(_this){
		
		var clsname = _this.className;
		sapce.manner = 1;
		var rowc = $(_this).parents('tr').attr('class') , rowi = rowc.substring(1,rowc.length) , num = '';
		
		if(clsname == 'sp_nxz'){
			 $(_this).addClass('sp_xs') 
			 var nowRow = $(_this).parents('tr').find('.sp_xs');
		
			for(var i=0 ; i < nowRow.length ; i++){
			
				num += $(nowRow).eq(i).html() + ',';
			}
		
			chooseArray[rowi] = num.substring(0,num.length-1);
		}else{
			$(_this).removeClass('sp_xs');
			chooseArray[rowi] = "*";
		}
		
		
		$(chooseArray).each(function(i,s){
			if(s){
				if(s.length >= 2) {
					sapce.manner = 2;return;
				}
			}
		});
		this.choosefiler(chooseArray,_this);
	},
	'choosefiler':function(args,$_this){
		
		count_C = 0;
	
		var tzMsg = '' , tzNumber = '';sapce.info='';
		$('#comBody').empty();
		for(var s=0 ; s<args.length; s++){
			
			if(args[s]){
				
				if(args[s] != ''){
					count_C++;
				}
				if(gameid == '103' && count_C > 9){
					this.seaDetails('blk2','s',jsSrc[gameid].errorMsgM);
					this.cursorX($_this);
					return;
				}
				
				if(sapce.manner == 2) {
				 
						tzNumber+=chooseArray[s].replace(/[,]/g,'/')+"//";
					
				}else{
					tzNumber+=chooseArray[s] + '/';
				} 
				
				tzMsg += '<tr><td>'+(s+1)+'</td><td>'+$(".c"+s).attr('vs')+'</td><td class="ct_com">'+chooseArray[s]+'</td></tr>';
				sapce.info  += $(".c"+s).attr('mathNum') + '/' + $(".c"+s).attr('vs') + '/[' + chooseArray[s] + ']|';  		
			}
		}
		
		tzNumber = tzNumber.substring(0,tzNumber.length-sapce.manner);
		sapce.info = sapce.info.substring(0,sapce.info.length-1);
		
		$("#cs").html(count_C);
		if(count_C == jsSrc[gameid].cn){
			
			$(tzMsg).appendTo('#comBody');
			sapce.tzNumber = tzNumber;
		
			$.get(""+contextPath+"/letoula/data/calculate_money.jsp?r="+Math.random(),{mcn:sapce.manner,tzNumber:tzNumber,MaxNumber:sapce.muliptile,MaxSp:'maxsp',gameid:gameid},function(zd){
				
				sapce.countMoney=parseInt(zd)*2*sapce.muliptile;
				$("#zs").html(zd);
				$('.pc').text('￥'+parseFloat(sapce.countMoney).toFixed(2));
				sapce.zs = zd;
				
			});		
		}else{
		
			sapce.countMoney=0.00;
			$("#zs").html(0);
			$('.pc').text('￥0.00');
			sapce.zs = 0;
				
		}
	},
	'seaDetails':function(nd,sh,txt){
		var off_top=document.documentElement.scrollTop;
		var off_left=document.documentElement.scrollLeft; 
        ZQ.$(nd).style.top=(off_top+100)+"px";
        ZQ.$(nd).style.left=(document.body.clientWidth/2-250)+"px";
        $('.eroorMsg').text(txt);
		sh == 's' ? $('#bd,#'+nd+'').show() : $('#bd,#'+nd+'').hide();
	},
	'mltOnkeyUp':function(){
		
		var _this=arguments[0],
			val=parseInt(_this.value);
			
		if(val > 99999) {
			_this.value='99999';
		}
		
		if(isNaN(_this.value) || val <= 0 || _this.value.indexOf('.')!=-1){
		
		   _this.value=1;
		}
		
		sapce.muliptile=_this.value;
		
		sapce.countMoney=parseInt(sapce.zs)*2*sapce.muliptile;
		$("#zs").html(sapce.zs);
		$('.pc').text('￥'+parseFloat(sapce.countMoney).toFixed(2));
				
	},
	'loginCheck':function(url){
		
		var userName = ZQ.$('loginName').value;
		var password = ZQ.$('password').value;
		
		if(userName.length <= 0){
			
			this.seaDetails('blk2','s',betting_yz.lsn);
			return false;
		}else if(password.length <= 0)
		{
			this.seaDetails('blk2','s',betting_yz.lsp);
			return false;
		}else{
			$.get(url+'&r='+Math.random(),{'loginName':userName,'password':password,'code':'ny'},function(su){
				
				su = eval("("+su+")");
				if(su.errorMessage){
					create_class.seaDetails('blk2','s',su.errorMessage);
					return;
				}
				
				window.location.reload();
			})
		}
	},
	/*
	*投注提交
	*/
	'submitInformation':function(mx){
		
		var ct = 0;
		
		for(var s=0;s<chooseArray.length;s++){
			
			if(chooseArray[s] != '*'){
				ct++;
			}
		}
		if(ct < jsSrc[gameid].cn){
			this.seaDetails('blk2','s',jsSrc[gameid].errorMsg);
			return;
		}
	
		ZQ.$('muliptile').value=sapce.muliptile;						//倍数
		ZQ.$('tzNumber').value=sapce.tzNumber; 							//投注号码
		ZQ.$('zhushu').value=sapce.zs;									//注数
		ZQ.$('price').value=sapce.countMoney;							//投注金额
		ZQ.$('ZQMcN').value=sapce.manner;		    					//McN
		ZQ.$('issue').value=sapce.issue;								//期号
		ZQ.$('inf').value=sapce.info;
		mx == 'x' ? this.View_detail(cos) : ZQ.$('myform').submit();
	}
};

