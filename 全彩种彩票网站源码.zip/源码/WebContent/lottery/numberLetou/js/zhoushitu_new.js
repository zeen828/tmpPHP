function zhoushitucallback() {
	var xmlHttp = this.xmlHttp;
	if (xmlHttp.readyState == 4) {
		if (xmlHttp.status == 200) {
			var json = eval("(" + xmlHttp.responseText + ")");
			if (json.result != "0000") {
				if ("list_size_0" == json.result)
					return;
				return;
			}
			var tc = _$("zhoushitu00");
			tc.innerHTML = "";
			for (var i = 0;i < json.items.length; i++) {
				var lot = json.items[i].lot;
				if (_$("issue" + lot))
					_$("issue" + lot).innerHTML = json.items[i].issue;
				if (_$("issue" + lot))
					_$("timeId" + lot).innerHTML = json.items[i].stopTime;
				if (_$("issue" + lot))
					_$("stateId" + lot).innerHTML = json.items[i].state;
				var s = (i % 2) ? "<ul>" : "<ul class='leftOddColor'>";
				s += "<li style='width:34px'>{0}</li><li style='width:70px'>{1}</li><li style='width:70px'>{2}</li></ul>"
						.format(json.items[i].num, json.items[i].NickName,
								json.items[i].award);
				tc.innerHTML += s;
			}
			try {
				window.frames[0].window.init();
			} catch (e) {
			};
			var tc = _$("zhoushitu11");
			tc.innerHTML = "";
			for (var i = 0, j = 0;i < json.items.length; i++) {
				var st = json.items[i].stopTime.replace(/年/, "").replace(/月/,
						"").replace(/日/, "");
				if (st.substring(0, 8) != json.standTime)
					continue;
				var s = (j % 2) ? "<ul>" : "<ul class='leftOddColor'>";
				s += "<li style='width:60px;'>{0}</li><li style='width:60px'>{1}</li><li style='width:88px'>{2}</li></ul>"
						.format(json.items[i].lotName, json.items[i].issue,
								json.items[i].stopDay,
								json.items[i].onlyStopDay,
								json.items[i].mutlStopDay);
				tc.innerHTML += s;
				j++;
			}
		} else {
			window.alert("ajax返回错误!");
		}
	}
}