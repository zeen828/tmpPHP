$(document).ready(function(){
	(function zhongJiangxixun(){
		var ma = new MyAjax(kaiJiangxixunUrl);
		ma.sendPostRequest(null,function(){
			if(ma.xmlHttp.readyState == 4){
				if(ma.xmlHttp.status == 200){
					 document.getElementById("zhongJiangxixunContext").innerHTML=ma.xmlHttp.responseText;
					 // alert(ma.xmlHttp.responseText);
				}else{
					alert("ma.xmlHttp.status="+ma.xmlHttp.status);
				}
				//marque2(200,20,"icefable12","box1left2");//heroList滚动
			}else{
				//alert("ma.xmlHttp.readyState="+ma.xmlHttp.readyState);
			}
		});
	})(); 
});
