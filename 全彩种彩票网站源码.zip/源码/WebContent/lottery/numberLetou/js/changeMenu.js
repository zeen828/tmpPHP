var timeoutObj = null;
var menuDiv = (function() {
	var ary = [];
	for (var i = 0;i <= 7; i++)
		ary.push(_$("menuDown" + i));
	return ary;
}());
function changeMenuOver(num) {
	clearTimeout(timeoutObj);
	for (var i = 0;i < menuDiv.length; i++) {
		menuDiv[i].style.display = "none";
	}
	_$('menuDown' + num).style.display = 'block';
};
function changeMenuOut() {
	timeoutObj = setTimeout("hideMenu()", 1500);
};
function hideMenu() {
	for (var i = 0;i < menuDiv.length; i++) {
		menuDiv[i].style.display = "none";
	}
	_$('menuDown' + 0).style.display = 'block';
};
function menuAOver() {
	clearTimeout(timeoutObj);
};
function menuAOut() {
	timeoutObj = setTimeout("hideMenu()", 1500);
};
function changDivContext(xname, num, showNum, overClass, outClass) {
	for (var i = 0;i < num; i++) {
		if (i == showNum) {
			_$(xname + i + i).style.display = 'block';
			_$(xname + i).className = overClass;
			continue;
		}
		_$(xname + i + i).style.display = 'none';
		_$(xname + i).className = outClass;
	}
};
function changDivContext1(xname, num, showNum, overClass, outClass,displayid) {
	//alert(displayid);
	if(showNum!=0){
		try{
		_$(displayid).style.display = 'block';
		}catch(e){	
		}
	}else{
		try{
		_$(displayid).style.display = 'none';
		}catch(e){		
		}
	}
    if(showNum==2)
    {
    	_$('top1').style.display = 'none';
    	_$('top2').style.display = 'block';
    }
    else{
    	_$('top1').style.display = 'block';
    	_$('top2').style.display = 'none';
    }
	for (var i = 0;i < num; i++) {
		if (i == showNum) {
			_$(xname + i + i).style.display = 'block';
			_$(xname + i).className = overClass;
			continue;
		}
		_$(xname + i + i).style.display = 'none';
		_$(xname + i).className = outClass;
	}
};
function changDivContext2(xname, num, showNum) {
	try{
	for (var i = 0;i < num; i++) {
		if (i == showNum) {
			_$(xname + i).style.display = 'block';
			//_$(xname + i).className = overClass;
			continue;
		}
		_$(xname + i).style.display = 'none';
		//_$(xname + i).className = outClass;
	}
		}catch(e){
			
		}
};

function eleDisplay(id, str) {
	if (typeof str != "undefined") {
		_$(id).style.display = str;
		return;
	}
	if (_$(id).style.display == "none") {
		_$(id).style.display = "block";
	} else {
		_$(id).style.display = "none";
	}
};
function MyAjax() {
	this.xmlHttp = {};
};
MyAjax.prototype.createXMLHttpRequest = function() {
	if (window.XMLHttpRequest) {
		this.xmlHttp = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		this.xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
};
MyAjax.prototype.sendPostRequest = function(queryString, url, winnercallback) {
	this.createXMLHttpRequest();
	this.xmlHttp.open("POST", url, true);
	this.xmlHttp.onreadystatechange = winnercallback;
	this.xmlHttp.setRequestHeader("Content-Type",
			"application/x-www-form-urlencoded; charset=UTF-8");
	this.xmlHttp.send(queryString);
};