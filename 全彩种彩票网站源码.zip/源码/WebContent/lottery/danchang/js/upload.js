
function uploadStartMarket(){
	if('301|302|303|304|305'.indexOf(agrs.gameCode)!=-1)
	{
		$.getJSON("../../letoula/data/winsFlat_dc.jsp?r="+Math.random(),{'smalltype':agrs.gameCode,'type':'-1'},function(items){
		var it = items.items;
		var li = '' , ul = '<ul>',day=0 , day_count = 0;
		for(var i=0;i < it.length; i++)
		{
			
			var stoptime = it[i].stopTime.split(" ");
			var itNext = it[i+1] ? it[i+1] : it[i];
			var stoptimeNext = it[i+1] ? it[i+1].stopTime.split(" ") : it[i].stopTime.split(" ");
			var date = new Date(stoptime[0]);
			var dateNext = new Date(stoptimeNext[0]);
			var ServiceTime = new Date();
			ServiceTime.setTime(agrs.datemillis);
			var tt=parseInt(create_class.stringformat(ServiceTime));
			var at=parseInt(it[i].stopTime.replace(/[-A-Za-z\(\)\+@#:\s]/g,""));
			if(at < tt){
				continue;
			}
			day_count++;
	
			var trCls = "" , concedenumTd = "";
			if(parseInt(it[i].concedenum)>0){
				concedenumTd = "redTdColor";
			}else if(parseInt(it[i].concedenum)<0){
				concedenumTd = "greenTdColor";
			}

			var groupTime = parseInt(it[i].stopTime.substring(0,8));
			if(parseInt(it[i].stopTime.substring(8,14)) < 60000){
				groupTime = groupTime - 1;
			}
			groupTime = groupTime.toString();
			var gst =  groupTime.substring(0,4) +'/' +groupTime.substring(4,6) +'/'+ groupTime.substring(6,8);
			var days = today[new Date(gst).getDay()];
			var nextTime = parseInt(itNext.stopTime.substring(0,8));
			if(parseInt(itNext.stopTime.substring(8,14)) < 60000){
				nextTime = nextTime -1;
			}
			nextTime = nextTime.toString();
			var nextgst =  nextTime.substring(0,4) +'/' +nextTime.substring(4,6) +'/'+ nextTime.substring(6,8);
			var nextdays = today[new Date(nextgst).getDay()];
			
			it[i].voteSheng = setting.FixedFloatTwo(it[i].voteSheng);
			it[i].votePing = setting.FixedFloatTwo(it[i].votePing);
			it[i].voteFu = setting.FixedFloatTwo(it[i].voteFu);
			it[i].gamename = it[i].gamename.replace(/[0-9]|-/g,'')
			
			
			
			li+='<li class="WhiteBg" data-num="'+it[i].gamenum+'"><input type="checkbox" name="MatchOrd" class="MatchInput" data-num="'+it[i].gamenum+'"/><span class="numberSeriano">'+it[i].gamenum+'</span><a href="#">'+it[i].hostteam+' '+it[i].stopTime.substring(8, 10)+':'+it[i].stopTime.substring(10, 12)+' '+it[i].visitingteam+'</a>';
				
				
			if(groupTime!=nextTime){
				day++;
				it[i] = it[i-1] ? it[i-1] : it[i];
				var formatDate='<li class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+'  [10:00--次日10:00]</li>';
				ul+=formatDate+li+'</ul><ul>';
				li = ''; 
				day_count = 0;
			}
			
			if(i==it.length-1)
			{
				it[i] = it[i-1] ? it[i-1] : it[i];
				ul += '<li colspan="7" class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+'  [10:00--次日10:00]</li>'+li + "</ul>";
			}
		}
		$('#dcmarket').append(ul);
		marketNumClick();
	});
	}else if('501|511|502|503|504'.indexOf(agrs.gameCode)!=-1){
		$.getJSON("../../letoula/data/winsFlat.jsp?r="+Math.random(),{'smalltype':'501','type':'0'},function(items){
		var it = items.items;
		var li = '' , ul = '<ul>',day=0 , day_count = 0;
		for(var i=0;i < it.length; i++)
		{
			
			var spvalue = it[i].spvalue.split("|");
			var stoptime = it[i].stopTime.split(" ");
			var itNext = it[i+1] ? it[i+1] : it[i];
			var stoptimeNext = it[i+1] ? it[i+1].stopTime.split(" ") : it[i].stopTime.split(" ");
			var date = new Date(stoptime[0]);
			var dateNext = new Date(stoptimeNext[0]);
			var ServiceTime = new Date();
			ServiceTime.setTime(agrs.datemillis);
			var tt=parseInt(create_class.stringformat(ServiceTime));
			var at=parseInt(it[i].stopTime.replace(/[-A-Za-z\(\)\+@#:\s]/g,""));
			if(at < tt){
				continue;
			}
			day_count++;

			var trCls = "" , concedenumTd = "";
			if(parseInt(it[i].concedenum)>0){
				it[i].concedenum = "+"+it[i].concedenum;
				concedenumTd = "redTdColor";
			}else{
				concedenumTd = "greenTdColor";
			}
			if(i % 2 != 0)
			{
				trCls = "greyTr";
			}
			
			var newat = at.toString();
			var groupTime = parseInt(newat.toString().substring(0,8));
			if(parseInt(newat.substring(8,14)) < 60000){
				groupTime = groupTime - 1;
			}
			groupTime = groupTime.toString();
			var gst =  groupTime.substring(0,4) +'/' +groupTime.substring(4,6) +'/'+ groupTime.substring(6,8);
			var days = today[new Date(gst).getDay()];
			var newxt = itNext.stopTime.replace(/[-A-Za-z\(\)\+@#:\s]/g,"");
			var nextTime = parseInt(newxt.substring(0,8));
			if(parseInt(newxt.substring(8,14)) < 60000){
				nextTime = nextTime -1;
			}
			nextTime = nextTime.toString();
			var nextgst =  nextTime.substring(0,4) +'/' +nextTime.substring(4,6) +'/'+ nextTime.substring(6,8);
			var nextdays = today[new Date(nextgst).getDay()];
			
			li+='<li class="WhiteBg jdBg" data-num="'+it[i].gamenum+'"><input type="checkbox" name="MatchOrd" class="MatchInput" data-num="'+it[i].gamenum+'"/><span class="numberSeriano jcnso">'+it[i].gamenum+'</span><a href="#">'+it[i].hostteam+' '+it[i].stopTime.substring(8, 10)+':'+it[i].stopTime.substring(10, 12)+' '+it[i].visitingteam+'</a>';
				
				
			if(groupTime!=nextTime){
				day++;
				it[i] = it[i-1] ? it[i-1] : it[i];
				var formatDate='<li class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+'  [10:00--次日10:00]</li>';
				ul+=formatDate+li+'</ul><ul>';
				li = ''; 
				day_count = 0;
			}
			
			if(i==it.length-1)
			{
				it[i] = it[i-1] ? it[i-1] : it[i];
				ul += '<li colspan="7" class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+' </li>'+li + "</ul>";
			}
		}
		$('#dcmarket').append(ul);
		marketNumClick();
	});
	}
}

var marketNum = [];
function marketNumClick(){
	$('.MatchInput').click(function(){
		marketNum = [];
		var matchItem = $('.MatchInput:checked');
		for(var i=0;i<matchItem.length;i++){
			marketNum.push(matchItem.eq(i).attr("data-num"));
		}
		marketNum.sort(function(a,b){return a-b});
		$("#match").val(marketNum.join("|"));
	});
}

$(".SelectUploadStyle").click(function(){
	$(this).siblings("input:radio").attr("checked",false);
	$(".selectUd").val($(this).attr('sel-data'));
});
uploadStartMarket();