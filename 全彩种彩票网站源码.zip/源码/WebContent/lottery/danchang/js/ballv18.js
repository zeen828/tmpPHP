
ZQ.betJson = {}; //总投注详情
ZQ.betArr = [];  //过滤详情为数组
ZQ.countBet=0; //投注金额
ZQ.notes=0; //注数
ZQ.muliptile=1; //倍数
ZQ.tzNumber=''; //投注号码
ZQ.spzValue = ''; //投注SP
ZQ.wasMuster='';  //过关方式
ZQ.OptimizationStr = ''; //奖金优化串
ZQ.biggestPrize = 0;
ZQ.ClearanceType=0; //0单一彩种 , 1混合过关
ZQ.ViewHisMarketStatus = 0;
ZQ.MarKetClearx={
	'r':[],
	's':[],
	'q':[]
}; //赛事筛选

function show_encounter(){
	
	$.getJSON(url+"/letoula/data/winsFlat_dc.jsp?r="+Math.random(),{'smalltype':'301','type':javaAgras.issue},function(items){
		var it = items.items;
		var tr = '' , table = '<table class="entronTab" cellspacing="0" cellpadding="0" id="table0" width="998">',day=0 , day_count = 0,
		hisMarketCount=0,hisMarketView='';
		for(var i=0;i < it.length; i++)
		{
			
			var stoptime = it[i].stopTime.split(" ");
			var itNext = it[i+1] ? it[i+1] : it[i];
			var stoptimeNext = it[i+1] ? it[i+1].stopTime.split(" ") : it[i].stopTime.split(" ");
			var date = new Date(stoptime[0]);
			var dateNext = new Date(stoptimeNext[0]);
			var ServiceTime = new Date();
			ServiceTime.setTime(javaAgras.datemillis);
			var tt=parseInt(create_class.stringformat(ServiceTime));
			var at=parseInt(it[i].stopTime.replace(/[-A-Za-z\(\)\+@#:\s]/g,""));
			/*if(at < tt){
				continue;
			}*/
			day_count++;
	
			var trCls = "" , concedenumTd = "";
			if(parseInt(it[i].concedenum)>0){
				concedenumTd = "redTdColor";
			}else if(parseInt(it[i].concedenum)<0){
				concedenumTd = "greenTdColor";
			}
			if(i % 2 != 0)
			{
				trCls = "greyTr";
			}
			var groupTime = parseInt(it[i].stopTime.substring(0,8));
			if(parseInt(it[i].stopTime.substring(8,14)) < 60000){
				groupTime = groupTime - 1;
			}
			groupTime = groupTime.toString();
			var gst =  groupTime.substring(0,4) +'/' +groupTime.substring(4,6) +'/'+ groupTime.substring(6,8);
			var days = today[new Date(gst).getDay()];
			var nextTime = parseInt(itNext.stopTime.substring(0,8));
			if(parseInt(itNext.stopTime.substring(8,14)) < 60000){
				nextTime = nextTime -1;
			}
			nextTime = nextTime.toString();
			var nextgst =  nextTime.substring(0,4) +'/' +nextTime.substring(4,6) +'/'+ nextTime.substring(6,8);
			var nextdays = today[new Date(nextgst).getDay()];
			
			it[i].voteSheng = setting.FixedFloatTwo(it[i].voteSheng);
			it[i].votePing = setting.FixedFloatTwo(it[i].votePing);
			it[i].voteFu = setting.FixedFloatTwo(it[i].voteFu);
			
			if(!create_class.contains(ZQ.MarKetClearx.r,it[i].concedenum)){
				ZQ.MarKetClearx.r.push({'sat':it[i].concedenum,'dx':bet_config.countNum(it,it[i].concedenum,'concedenum'),'id':it[i].id});
			}
			if(!create_class.contains(ZQ.MarKetClearx.s,it[i].gamename)){
				ZQ.MarKetClearx.s.push({'sat':it[i].gamename,'dx':bet_config.countNum(it,it[i].gamename,'gamename'),'id':it[i].id});
			}
			if(!create_class.contains(ZQ.MarKetClearx.q,'星期'+days)){
				ZQ.MarKetClearx.q.push({'sat':'星期'+days,'dx':bet_config.countNum(it,days,'gamenum'),'id':it[i].id});
			}
			
			it[i].threeThree = setting.FixedFloatTwo(it[i].threeThree);
			it[i].threeOne = setting.FixedFloatTwo(it[i].threeOne);
			it[i].threeZero = setting.FixedFloatTwo(it[i].threeZero);
			it[i].oneThree = setting.FixedFloatTwo(it[i].oneThree);
			it[i].oneOne = setting.FixedFloatTwo(it[i].oneOne);
			it[i].oneZero = setting.FixedFloatTwo(it[i].oneZero);
			it[i].zeroThree = setting.FixedFloatTwo(it[i].zeroThree);
			it[i].zeroOne = setting.FixedFloatTwo(it[i].zeroOne);
			it[i].zeroZero = setting.FixedFloatTwo(it[i].zeroZero);
			it[i].gamename = it[i].gamename.replace(/[0-9]|-/g,'')
			var oupei = it[i].oupei.split('|');
			if(it[i].status!=0) hisMarketCount++;
			if(it[i].status==0 && ZQ.ViewHisMarketStatus==0){
				tr+='<tr class="'+trCls+'" lg="'+it[i].gamename+'"  vt="'+it[i].visitingteam+'"  rq="'+it[i].concedenum+'" id="'+it[i].id+'" stopdate="'+it[i].stopTime+'" gamenum="周'+days+it[i].gamenum+'" hostteam="'+it[i].hostteam+'" arrySerial="'+i+'"><td width="116" class="marketnum"><span class="leaugeNum">'+it[i].gamenum+'</span><span class="dcleaugeName" style="background-color:'+it[i].color+';color:#fff">'+it[i].gamename+'</span></td><td width="85" class="timeEntron">'+
					'<span  class="jz" title="截止时间：'+it[i].stopTime+'" >'+it[i].stopTime.substring(4, 6)+"-"+it[i].stopTime.substring(6, 8)+" "+it[i].stopTime.substring(8, 10) + ":"+ it[i].stopTime.substring(10, 12)+'</span>'+
					'</td>'+
					'<td width="251" class="tream"><em class="tmr_l">'+it[i].hostBiao+'</em><a href="#" class="tmr_l">'+it[i].hostteam.substring(0,5)+'</a><span class="tmr_z">VS</span><a href="#" class="tmr_r">'+it[i].visitingteam.substring(0,5)+'</a><em class="tmr_r">'+it[i].keBiao+'</em></td><td width="369"><div class="bet_odds">'+
						
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeThree+'" value="3_3" data-s="t0" data-gamenum="305">'+it[i].threeThree+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeOne+'" value="3_1" data-s="t1" data-gamenum="305">'+it[i].threeOne+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeZero+'" value="3_0" data-s="t2" data-gamenum="305">'+it[i].threeZero+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneThree+'" value="1_3" data-s="t3" data-gamenum="305">'+it[i].oneThree+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneOne+'" value="1_1" data-s="t4" data-gamenum="305">'+it[i].oneOne+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneZero+'" value="1_0" data-s="t5" data-gamenum="305">'+it[i].oneZero+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroThree+'" value="0_3" data-s="t6" data-gamenum="305">'+it[i].zeroThree+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroOne+'" value="0_1" data-s="t7" data-gamenum="305">'+it[i].zeroOne+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroZero+'" value="0_0" data-s="t8" data-gamenum="305">'+it[i].zeroZero+'</span>'+
						
					'</div></td><td width="59" class="xyo"><a href="../axy/nowouOdds.jsp?no='+it[i].gamenum+'&issue='+it[i].issue+'&type=bdspf" target="_blank">欧</a>/<a href="../axy/analysis.jsp?no='+it[i].gamenum+'&issue='+it[i].issue+'&type=bdspf" target="_blank">析</a></td>'+
					'<td width="118"><div class="oupei"><span>'+oupei[0]+'</span><span>'+oupei[1]+'</span><span>'+oupei[2]+'</span></div></td></tr>';
			}else if(ZQ.ViewHisMarketStatus==1){
				
				var CG0='',CG1='',CG2='',CG3='',CG4='',CG5='',CG6='',CG7='',CG8='';
				switch(it[i].banquanchang)
				{
					case '胜-胜':CG0='<b class="font_red">'+it[i].threeThree+'</b>';break;
					case '胜-平':CG1='<b class="font_red">'+it[i].threeOne+'</b>';break;
					case '胜-负':CG2='<b class="font_red">'+it[i].threeZero+'</b>';break;
					case '平-胜':CG3='<b class="font_red">'+it[i].oneThree+'</b>';break;
					case '平-平':CG4='<b class="font_red">'+it[i].oneOne+'</b>';break;
					case '平-负':CG5='<b class="font_red">'+it[i].oneZero+'</b>';break;
					case '负-胜':CG6='<b class="font_red">'+it[i].zeroThree+'</b>';break;
					case '负-平':CG7='<b class="font_red">'+it[i].zeroOne+'</b>';break;
					case '负-负':CG8='<b class="font_red">'+it[i].zeroZero+'</b>';break;
				}
				if(it[i].status==0){
					tr+='<tr class="'+trCls+'" lg="'+it[i].gamename+'"  vt="'+it[i].visitingteam+'"  rq="'+it[i].concedenum+'" id="'+it[i].id+'" stopdate="'+it[i].stopTime+'" gamenum="周'+days+it[i].gamenum+'" hostteam="'+it[i].hostteam+'" arrySerial="'+i+'"><td width="116" class="marketnum"><span class="leaugeNum">'+it[i].gamenum+'</span><span class="dcleaugeName" style="background-color:'+it[i].color+';color:#fff">'+it[i].gamename+'</span></td><td width="85" class="timeEntron">'+
					'<span  class="jz" title="截止时间：'+it[i].stopTime+'" >'+it[i].stopTime.substring(4, 6)+"-"+it[i].stopTime.substring(6, 8)+" "+it[i].stopTime.substring(8, 10) + ":"+ it[i].stopTime.substring(10, 12)+'</span>'+
					'</td>'+
					'<td width="251" class="tream"><em class="tmr_l">'+it[i].hostBiao+'</em><a href="#" class="tmr_l">'+it[i].hostteam.substring(0,5)+'</a><span class="tmr_z">VS</span><a href="#" class="tmr_r">'+it[i].visitingteam.substring(0,5)+'</a><em class="tmr_r">'+it[i].keBiao+'</em></td><td width="369"><div class="bet_odds">'+
						
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeThree+'" value="3_3" data-s="t0" data-gamenum="305">'+it[i].threeThree+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeOne+'" value="3_1" data-s="t1" data-gamenum="305">'+it[i].threeOne+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeZero+'" value="3_0" data-s="t2" data-gamenum="305">'+it[i].threeZero+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneThree+'" value="1_3" data-s="t3" data-gamenum="305">'+it[i].oneThree+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneOne+'" value="1_1" data-s="t4" data-gamenum="305">'+it[i].oneOne+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneZero+'" value="1_0" data-s="t5" data-gamenum="305">'+it[i].oneZero+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroThree+'" value="0_3" data-s="t6" data-gamenum="305">'+it[i].zeroThree+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroOne+'" value="0_1" data-s="t7" data-gamenum="305">'+it[i].zeroOne+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroZero+'" value="0_0" data-s="t8" data-gamenum="305">'+it[i].zeroZero+'</span>'+
						
					'</div></td><td width="50">'+it[i].quanbifen+'</td><td width="50"><b class="font_red">'+it[i].banquanchang+'</b></td><td width="59" class="xyo"><a href="../axy/nowouOdds.jsp?no='+it[i].gamenum+'&issue='+it[i].issue+'&type=bdspf" target="_blank">欧</a>/<a href="../axy/analysis.jsp?no='+it[i].gamenum+'&issue='+it[i].issue+'&type=bdspf" target="_blank">析</a></td>'+
					'<td width="118"><div class="oupei"><span>'+oupei[0]+'</span><span>'+oupei[1]+'</span><span>'+oupei[2]+'</span></div></td></tr>';
				}else{
				tr+='<tr class="'+trCls+'" lg="'+it[i].gamename+'"  vt="'+it[i].visitingteam+'"  rq="'+it[i].concedenum+'" id="'+it[i].id+'" stopdate="'+it[i].stopTime+'" gamenum="周'+days+it[i].gamenum+'" hostteam="'+it[i].hostteam+'" arrySerial="'+i+'"><td width="116" class="marketnum"><span class="leaugeNum">'+it[i].gamenum+'</span><span class="dcleaugeName" style="background-color:'+it[i].color+';color:#fff">'+it[i].gamename+'</span></td><td width="85" class="timeEntron">'+
					'<span  class="jz" title="截止时间：'+it[i].stopTime+'" >'+it[i].stopTime.substring(4, 6)+"-"+it[i].stopTime.substring(6, 8)+" "+it[i].stopTime.substring(8, 10) + ":"+ it[i].stopTime.substring(10, 12)+'</span>'+
					'</td>'+
					'<td width="251" class="tream"><em class="tmr_l">'+it[i].hostBiao+'</em><a href="#" class="tmr_l">'+it[i].hostteam.substring(0,5)+'</a><span class="tmr_z">VS</span><a href="#" class="tmr_r">'+it[i].visitingteam.substring(0,5)+'</a><em class="tmr_r">'+it[i].keBiao+'</em></td><td width="369"><div class="his_bet_odds">'+
						
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeThree+'" value="3_3" data-s="t0" data-gamenum="305">'+CG0+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeOne+'" value="3_1" data-s="t1" data-gamenum="305">'+CG1+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].threeZero+'" value="3_0" data-s="t2" data-gamenum="305">'+CG2+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneThree+'" value="1_3" data-s="t3" data-gamenum="305">'+CG3+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneOne+'" value="1_1" data-s="t4" data-gamenum="305">'+CG4+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].oneZero+'" value="1_0" data-s="t5" data-gamenum="305">'+CG5+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroThree+'" value="0_3" data-s="t6" data-gamenum="305">'+CG6+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroOne+'" value="0_1" data-s="t7" data-gamenum="305">'+CG7+'</span>'+
					'<span class="cut_odds_dcbq" data-sp="'+it[i].zeroZero+'" value="0_0" data-s="t8" data-gamenum="305">'+CG8+'</span>'+
						
					'</div></td><td width="50">'+it[i].quanbifen+'</td><td width="50"><b class="font_red">'+it[i].banquanchang+'</b></td><td width="59" class="xyo"><a href="../axy/nowouOdds.jsp?no='+it[i].gamenum+'&issue='+it[i].issue+'&type=bdspf" target="_blank">欧</a>/<a href="../axy/analysis.jsp?no='+it[i].gamenum+'&issue='+it[i].issue+'&type=bdspf" target="_blank">析</a></td>'+
					'<td width="118"><div class="oupei"><span>'+oupei[0]+'</span><span>'+oupei[1]+'</span><span>'+oupei[2]+'</span></div></td></tr>';
				}	
			}
			if(groupTime!=nextTime){
				day++;
				it[i] = it[i-1] ? it[i-1] : it[i];
				if(tr!=''){
					var formatDate='<tr class="bet_dateTr"><td colspan="9" class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+' <a href="javascript:void(0)" onclick="bet_config.todayClickHide(this)" m="周'+days+'">'+day_count+'场比赛可投注</a><s class="doul_arrow" /></td></tr>';
					table+=formatDate+tr+'</table><table class="entronTab" cellspacing="0" id="table'+day+'" cellpadding="0" width="998">';
				}
				tr = ''; 
				day_count = 0;
			}
			
			if(i==it.length-1)
			{
				it[i] = it[i-1] ? it[i-1] : it[i];
				if(tr!=''){
					table += '<tr class="bet_dateTr"><td colspan="9" class="todayTd">星期'+days+'  '+setting.eitFormattime(groupTime)+' <a href="javascript:void(0)" onclick="bet_config.todayClickHide(this)" m="周'+days+'">'+day_count+'场比赛可投注</a><s class="doul_arrow" /></td></tr>'+tr + "</table>";
				}
			}
		}
		bet_config.ClearFx();
		table = '<div class="endmacth"><input type="checkbox" id="showEndMacth" value="" /><label for="showEndMacth">显示已停售比赛['+hisMarketCount+'场]</label></div>' + table;
		$('.encounterMain').html(table);
		if(ZQ.ViewHisMarketStatus==1){
			$('#showEndMacth').attr('checked',true);
			$('.entronTab,#homeMain').css('width','1065px');
		}else{
			$('#showEndMacth').attr('checked',false);
			$('.entronTab,#homeMain').css('width','998px');
		}
		$.domHover($('.entronTab tbody tr'),'#fff8dc');
		$.domSpanBack($('.bet_odds span'),'over');
		bet_config.spclick();
	});
	
};

var bet_config = {
	'spclick':function(){
		$('.bet_odds span').click(function(){
			var _class = $(this).attr('class');
			var HTMLOBJECT_TR = $(this).parents('tr');
			var id = HTMLOBJECT_TR.attr('id');
			if(_class.indexOf('yeswin')==-1)
			{
				$(this).addClass('yeswin');
				$.Accession($(this),$('.sedan'));
			}else
			{
				$(this).removeClass('yeswin');
			}
			var betArr = $(HTMLOBJECT_TR).find('td:eq(3) > div > span.yeswin');
			var bet = [] , arrs = [] , arrnumber = [] , HybridStrings=[],suanJ = [],option=[];
			for(var k = 0; k < betArr.length;k++)
			{
				var gn = $(betArr).eq(k).attr('data-gamenum'),
					sp = $(betArr).eq(k).attr('data-sp'),
					s = $(betArr).eq(k).attr('data-s'),
					val = $(betArr).eq(k).attr('value');
				bet.push({'gn':gn,'sp':sp,'s':s,'val':val});
				arrs.push(sp);
				arrnumber.push(val);
				HybridStrings.push(gn+":"+val+":"+sp+":"+id+":");
				option.push(val+':'+sp+':'+HTMLOBJECT_TR.attr('gamenum')+'~');
			}
			var hbsg = HybridStrings.join('|');
			var opn = option.join('|');
			ZQ.betJson[id]={'id':id,'ht':HTMLOBJECT_TR.attr('hostteam'),'vt':HTMLOBJECT_TR.attr('vt'),'lg':HTMLOBJECT_TR.attr('lg'),'gamenum':HTMLOBJECT_TR.attr('gamenum'),'stopselldate':HTMLOBJECT_TR.attr('stopselldate'),'rq':HTMLOBJECT_TR.attr('rq'),'gall':'0','arrs':arrs,'arrnumber':arrnumber,'hbsg':hbsg,'bet':bet,'opn':opn};
			if(betArr.length<=0){
				delete ZQ.betJson[id];
			}
			bet_config.totalBouns();
		});
		
		$('.radio_ck').click(function(){
			bet_config.marKetClick();
			$.offsetScr('betbottom','BettingRegion');
			$.offsetTopTitle('encounterMain','marketTitle');
		});
		
		$('#showEndMacth').click(function(){
			var ck = $(this).attr('checked');
			ZQ.ViewHisMarketStatus = ck ? 1 : 0;
			if(ck){
				$('.Tab_title').hide(); $('.hisMarketTab').show();
			}else{
				$('.Tab_title').show(); $('.hisMarketTab').hide();
			}
			show_encounter();
		});
	},
	'totalBouns':function(){
		var Yes_bet = ZQ.betJson;
		ZQ.betArr = [];
		var count = this.objectCount(Yes_bet);
		ZQ.betArr = create_class.timeSort(ZQ.betArr);
		$('.the_selected').text(count);
		var betTr = '' , wfstr = '' ,wf = [] , maxCount = '0';
		for(var k=0;k<ZQ.betArr.length;k++)
		{
			var betObject = ZQ.betArr[k];
			var bettingNumber = betObject.bet;
			var _HMC = '';
			for(var l=0;l<bettingNumber.length;l++)
			{
				wf.push(bettingNumber[l].gn);
				var rq = bettingNumber[l].gn == '511' ? betObject.rq : '';
				_HMC+='<a href="#">'+rq+all_config[bettingNumber[l].gn][bettingNumber[l].val]+'</a>';	
			}
			
				betTr+='<tr><td class="btl9">'+betObject.gamenum+'</td><td>'+betObject.ht.substring(0,3)+'</td><td>'+betObject.vt.substring(0,3)+'</td><td class="btlxz">'+_HMC+'</td>'+
					'<td class="btl9"><input type="checkbox" onclick="bet_config.glbdr(this)" class="gallbladder" value="'+betObject.id+'"/></td><td><s class="delbet" data-del="'+betObject.id+'" onclick="javascript:bet_config.delOption(this)" /></td></tr>';
			
		}
		wf=this.Arrdel(wf);
		$('.TZ_tab').html(betTr);
		if(wf.length == 0){
			wfstr = '';
		}else{
			wfstr = all_config[wf[0]].name;
			ZQ.ClearanceType=0;
			javaAgras.gameid = wf[0];
			wf.sort(function(a,b){return a-b});
			maxCount = all_config[wf[wf.length-1]].mcn;
			count = count > maxCount ? maxCount : count;
		}
		
			$('.musterMain,.musterMain span.ipt').hide();
			$('.mstTx').show();
			$('.listMatch  ul  li,.listMatch  ul  li span').hide();
			if(count >= 1)
			{
				$('.mstTx').hide();
				$('.musterMain').show().find('span:lt('+(count)+')').show();
				$('.musterMain').find('span').not(':lt('+(count-1)+')').find('input').attr('checked',false);
				if(count>=2){
					$('.listMatch  ul  li:lt('+(count-1)+')').show().find('span').show();
					if(count >= 7){
						$('.mco').hide();
						if(count>=9) {
							count=count-8;
							$('.mco:lt('+(count)+')').show();
						}
					}
				}
			}
			this.gallOption();
		
		$('.wfwz').text(wfstr);
		
	},
	'delOption':function(_this){
		var delType = $(_this).attr("data-del");
		if(delType=='all')
		{
			var fa = confirm("您确定要删除所有比赛吗？");
			if(fa==true){
				for(var bs in ZQ.betJson){
					delete ZQ.betJson[bs];
					$("#"+bs+" > td > div.bet_odds > span.yeswin").removeClass('yeswin');
				}
			}
		}else
		{
			delete ZQ.betJson[delType];
			$("#"+delType+" > td > div.bet_odds > span.yeswin").removeClass('yeswin');
		}
		bet_config.totalBouns();
		this.CountAward();
	},
	'glbdr':function(_this){
		var valid =_this.value;
		ZQ.betJson[valid].gall = _this.checked==true ? '1' : '0';
		this.gallOption('gl');
	},
	'gallOption':function(bsbox){
		var count = ZQ.betArr;
		if(ZQ.betArr.length <= 0)
		{
			$('.ipt input').attr('checked',false);
			return;
		}
		var optioncheck = $('.ipt > input:checked');
		var rcarr = [];
		for(var i=0;i<optioncheck.length;i++)
		{
			var rc = $(optioncheck).eq(i).parent('span').attr('id');
			rcarr.push(DC_TYPE_MAP[rc][0].charAt(0));
		}
		rcarr.sort(function(a,b){return a-b});
		var minRc = parseInt(rcarr[0]);
		if(minRc == ZQ.betArr.length)
		{
			$('.gallbladder').attr({'disabled':true,'checked':false});
		}else
		{
			if($('.gallbladder:checked').length == (minRc - 1)){
				$('.gallbladder:not(:checked)').attr('disabled',true);
			}else if($('.gallbladder:checked').length > (minRc - 1))
			{
				$('.gallbladder').attr({'disabled':false,'checked':false});
			}
		}
		if((bsbox=='rc' && optioncheck.length==0) || (bsbox=='gl' && $('.gallbladder:checked').length==0))
		{
			$('.gallbladder').attr({'disabled':false,'checked':false});
		}
		this.CountAward();
	},
	'CountAward':function(){
		var sa = new Array(); //不为胆码数组
		var sb = new Array(); //有胆数组
		var b0=0,b1=0,zhushu=0,maxprice = 0;
		var OverPortfolio = ZQ.betArr;
		var spValArr = [] , spvalue=[] , tznumber = [] , hy = [] , cn = [],newHY=[],sjarr = [],overarr=[],danmaArr=[],yhc=[] ,yhopn = [];
		ZQ.muliptile = parseInt($('#multipleTx').val());
		for(var k =0; k < OverPortfolio.length;k++)
		{
			spvalue.push(OverPortfolio[k].id+','+OverPortfolio[k].arrs.join('/')+','+OverPortfolio[k].gall);
			tznumber.push(OverPortfolio[k].id+','+OverPortfolio[k].arrnumber.join('/')+','+OverPortfolio[k].gall);
			yhopn.push(OverPortfolio[k].opn);
			var sr = OverPortfolio[k].hbsg.split("|");
			var newHbsg = [];
			var arr = {'305':{}};
			sjarr[k]={'305':[]};
			var yhstr = '';
			for(var s = 0;s < sr.length;s++){
				sr[s] = sr[s]+OverPortfolio[k].gall+"-";
				yhstr+=sr[s]+OverPortfolio[k].gall+"~|";
				newHbsg.push(sr[s]);
				var S_a = sr[s].replace(/[~]/g,"").replace(/[ ]/,"");
				var so = S_a.split(":");
				arr[so[0]][so[1]]=so[2]; //so[2]=501,so[0]=3,so[1]=3.20
				sjarr[k][so[0]].push(sr[s]);
			}
			yhc.push(yhstr.substring(0,yhstr.length-1));
			var sjls = [];
			for(var sl in sjarr[k])
			{
				if(sjarr[k][sl]!=''){
					var ksl = sjarr[k][sl].join("/");
					sjls.push(ksl+"~");
				}
			}
			hy.push(sjls);
			//if(ZQ.ClearanceType==1){
				var budGet = bdyusuanMain(arr,OverPortfolio[k].rq);
				var bdt = budGet['max'];
				var tsr = [];
				for(var y=0;y<bdt.length;y++){
					tsr.push(bdt[y].gn+":"+bdt[y].val+":"+bdt[y].brouns+":"+OverPortfolio[k].id+":"+OverPortfolio[k].gall+"-~");
				}
				newHY.push(tsr);
			//}
			if(OverPortfolio[k].gall == '1'){
				sb.push(OverPortfolio[k].bet.length);
				danmaArr.push(OverPortfolio[k].id);
				b0++;b1++;
			}else
			{
				sa.push(OverPortfolio[k].bet.length);
			}
			var vp = OverPortfolio[k].arrs.join(',');
			spValArr.push(vp.split(',').sort(asc));
		}
		ZQ.spzValue = spvalue.join('//');
		ZQ.tzNumber = tznumber.join('//');
		spArr = spValArr;
		var chosenStyle = $(".ipt input:checked");
		if(chosenStyle.length<=0)
		{
			$('#minprize,#maxprize,#betMoney').text(0);
		}else{
			var tempstr = yhopn.join(',');
			ZQ.OptimizationStr = tempstr;
			
				if(ZQ.ClearanceType=='false'){
					var gte = [];
					$(chosenStyle).each(function(i,v){
						cn.push(v.value);
						var pt = $(v).next().text().replace("串","-");
						gte.push(pt);
						zhushu += parseInt(myCalc(pt,'1',sa,sb,b0,b1));
					});
					ggWay = gte;
					gusuan();
				}else{
					$(chosenStyle).each(function(i,v){
						OverArry=[];
						cn.push(v.value);
						var xzcg = $(v).next().text().split('串');
						if(xzcg[0]=='单关'){
							xzcg[0] = xzcg[1] = '1';
						}
						var passway = DC_TYPE_MAP['r'+xzcg[0]+'c'+xzcg[1]];
						var pwy = []; 
						for(var b = 0; b < passway.length;b++)
						{
							pwy.push(passway[b].split('_')[0]);
						}
						var psy = pwy.join(',');
						var methods =0;
						if(xzcg[1]>1)methods=1;
						else methods=0;
						
						startRecon(hy,psy,methods,danmaArr,xzcg[0]);
						zhushu+=OverArry.length;
						maxprice += parseFloat(reconBonus(newHY,psy,methods,danmaArr,xzcg[0]) * 0.65);
					});
					
						$("#maxprize").text(maxprice.toFixed(2) * ZQ.muliptile);
						ZQ.biggestPrize = maxprice.toFixed(2);
					}
				
			
			ZQ.wasMuster = cn.join(',');
			ZQ.notes = zhushu;
			ZQ.countBet = zhushu * ZQ.muliptile * 2;
			$('#betMoney').text(ZQ.countBet);
		}
	},
	'maxCountPrice':function(nrb){
		var maxpc = 0;
		for(var i =0; i < nrb.length;i++)
		{
			maxpc += parseFloat(nrb[i].m);
		}
		return maxpc;
	},
	'objectCount':function(o){
		var count =0;
		for(var gs in o)
		{
			ZQ.betArr.push(ZQ.betJson[gs]);
			count++;
		}
		return count;
	},
	'Arrdel':function(Arr_) { 
		var a = {}, c = [], l = Arr_.length; 
		for (var i = 0; i < l; i++) { 
			var b = Arr_[i]; 
			var d = (typeof b) + b; 
			if (a[d] === undefined) { 
				c.push(b); 
				a[d] = 1; 
			} 
		} 
		return c;
	},
	'ArrdelObj':function(Arr_) {
		var finalArr = []; 
		for(var i=0;i<Arr_.length;i++){
			//document.write(Arr_[i].ArrSp+"----"+Arr_[i].ArrXh+"----"+Arr_[i].ArrStrNum+"<br/>");
			if(!create_class.containsAll(finalArr,'ArrSp',Arr_[i].ArrSp+"--"+Arr_[i].ArrStrNum+"--"+Arr_[i].ArrXh)){
				finalArr.push(Arr_[i]);
			}
		}
		return finalArr;
	},
	'mltOnkeyUp':function(){
		
		var _this=arguments[0],
			val=parseInt(_this.value);
			
		if(val > 500000) {
			_this.value='500000';
		}
		
		if(isNaN(_this.value) || val <= 0 || _this.value.indexOf('.')!=-1){
		
		   _this.value=1;
		}
		
		ZQ.muliptile=_this.value;
		
		this.CountAward();
	},
	'rise_reduce_control':function(v){
		if(v == 'r')
		{
			ZQ.muliptile += 1;
		}else
		{
			var m = ZQ.muliptile - 1;
			ZQ.muliptile = m < 1 ? 1 : m;
		}
		var countBet = ZQ.notes * ZQ.muliptile * 2;
		var mpz = (parseFloat(ZQ.biggestPrize) * parseFloat(ZQ.muliptile)).toFixed(2);
		$("#betMoney").text(countBet);
		$("#maxprize").text(mpz);
		$("#multipleTx").val(ZQ.muliptile);
		ZQ.countBet = countBet;
	},
	'seaDetails':function(nd,sh,txt){
		var off_top=document.documentElement.scrollTop;
		var off_left=document.documentElement.scrollLeft; 
        create_class.centertical(ZQ.$(nd));
        $('.eroorMsg').text(txt);
		sh == 's' ? $('#bd,#'+nd+'').show() : $('#bd,#'+nd+'').hide();
	},
	'ClearFx':function(){
		for(var cx in ZQ.MarKetClearx)
		{
			var mA = ZQ.MarKetClearx[cx];
			var li = '';
			if(cx == 'r')
			{
				for(var i=0;i<mA.length;i++)
				{
					var d_n = '客让';
					if(mA[i].sat.indexOf('-')!=-1)
					{
						d_n = '主让';
					}else if(mA[i].sat==0){
						d_n = '非让';
					}
					if(mA[i].sat.indexOf('-')==-1){
						mA[i].sat = mA[i].sat;
					}
					li+='<li><input type="checkbox" class="radio_ck" c="'+mA[i].dx+'" id="rq_'+mA[i].sat+'" m="'+mA[i].sat+'" checked="true" />'+d_n+mA[i].sat.charAt(1)+'球['+mA[i].dx+'场]</li>';
				}
				$('.rqlist > ul').html(li);
			}else if(cx == 's')
			{
				for(var i=0;i<mA.length;i++)
				{
					li+='<li><input type="checkbox" class="radio_ck" c="'+mA[i].dx+'" id="lg'+mA[i].id+'" m="'+mA[i].sat+'" checked="true"/>'+mA[i].sat+'['+mA[i].dx+'场]</li>';
				}
				$('.sslist > ul').html(li);
			}else{
				for(var i=0;i<mA.length;i++)
				{
					li+='<li><input type="checkbox"  class="radio_ck" c="'+mA[i].dx+'" id="day'+mA[i].sat+'" m="周'+mA[i].sat.charAt(2)+'" checked="true"/>'+mA[i].sat+'['+mA[i].dx+'场]</li>';
				}
				$('.sjlist > ul').html(li);
			}
		}
	},
	'countNum':function(s,v,v1){
		var count = 0;
		for(var l =0; l<s.length;l++){
			var sValue = s[l][v1];
			if(v1=='againstNum')
			{
				sValue = s[l][v1].substring(0,2);
				v = v.substring(0,2);
			}else if(v1=='gamenum')
			{
				var groupTime = parseInt(s[l].stopTime.substring(0,8));
				if(parseInt(s[l].stopTime.substring(8,14)) < 60000){
					groupTime = groupTime - 1;
				}
				groupTime = groupTime.toString();
				var gst =  groupTime.substring(0,4) +'/' +groupTime.substring(4,6) +'/'+ groupTime.substring(6,8);
				var days = today[new Date(gst).getDay()];
				sValue = days;
			}
			if(sValue==v)
			{
				count++;
			}
		}
		return count;
	},
	'todayClickHide':function(_this){
		var day = $(_this).attr('m');
		var ck = $('.radio_ck[m*="'+day+'"]').attr('checked');
		var bol = ck ? false : true;
		$('.radio_ck[m*="'+day+'"]').attr('checked',bol);
		this.marKetClick();
	},
	'marKetClick':function(){
		$('.entronTab tbody tr').show();
		var notcheck = $('.shaxlist ul li input:not(:checked)');
		var yc = 0;
		for(var i=0;i<notcheck.length;i++)
		{
			var id = $(notcheck).eq(i).attr('id');
			if(id.indexOf('rq')!=-1)
			{
				var rqm = $('.entronTab tbody tr[rq*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(rqm).hide();
				yc+=$(rqm).length;
			}else if(id.indexOf('lg')!=-1){
				var lqm = $('.entronTab tbody tr[lg*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(lqm).hide();
				yc+=$(lqm).length;
			}else
			{
				var gmm = $('.entronTab tbody tr[gamenum*="'+$(notcheck).eq(i).attr("m")+'"]');
				$(gmm).hide();
				yc+=$(gmm).length;
			}
		}
		$('.redtxtc').text(yc);
	},
	'AllMarket':function(str){
		var sarr = str.split('_');
		if(sarr[1] == 'qx')
		{
			$('.'+sarr[0]+' > ul > li > input').attr('checked',true);
		}else if(sarr[1] == 'fx')
		{
			var zk = $('.'+sarr[0]+' > ul > li > input:not(:checked)');
			var jk = $('.'+sarr[0]+' > ul > li > input:checked');
			$(zk).attr('checked',true);
			$(jk).attr('checked',false);
			
		}else if(sarr[1] == 'qq')
		{
			$('.'+sarr[0]+' > ul > li > input').attr('checked',false);
		}
		this.marKetClick();
	},
	'marketHistroy':function(_this){
			javaAgras.issue = $(_this).val();
			if(javaAgras.issue < javaAgras.YIssue) ZQ.ViewHisMarketStatus=1;
			if(ZQ.ViewHisMarketStatus==1){
				$('.Tab_title').hide(); $('.hisMarketTab').show();
			}else{
				$('.Tab_title').show(); $('.hisMarketTab').hide();
			}
			show_encounter();
	},
	/*
	*投注提交
	*/
	'submitInformation':function(mx){
		

			if(ZQ.wasMuster.length<=0){
			
				this.seaDetails('blk2','s',betting_yz.s);
				return;
			}
		ZQ.tzNumber = ZQ.tzNumber.replace(/[_]/g,'-');
		$('.jzTime').val('');   								//截至时间
		$('.muliptile').val(ZQ.muliptile);							//倍数
		$('.tzNumber').val(ZQ.tzNumber); 							//投注号码
		$('.zhushu').val(ZQ.notes);										//注数
		$('.price').val(parseFloat(ZQ.countBet).toFixed(2));				//投注金额
		$('.ZQMcN').val(ZQ.wasMuster);										//McN
		$('.spzValue').val(ZQ.spzValue.replace(/[" "]/g,""));		//sp值
		$('.moneyFw').val('0-0');									//奖金范围
		$('.tempstr').val(ZQ.OptimizationStr);								//优化数据 
		$('.gameCode').val(javaAgras.gameid);						//玩法
		var mcnArray=ZQ.wasMuster.split(',');
		var rmrn='';
		for(var s=0;s<mcnArray.length;s++){
			rmrn+=DC_McN_Map[mcnArray[s]]+',';
		}
		rmrn=rmrn.substring(0,rmrn.lastIndexOf(','));
		
		$('.McN').val(rmrn);
		
		var d='$',cos='';
		for(var i=0;i<ZQ.betArr.length;i++){
			var arr = ZQ.betArr[i];
			var pl=arr.arrs.join('_');
			var spf=arr.arrnumber.join('/');
			cos+=arr.gamenum+','+arr.ht+','+arr.vt+','+arr.rq+','+spf+','+pl+','+arr.id+d;
		}
		cos=cos.substring(0,cos.lastIndexOf('$'));
		
		$('.inf').val(cos);
		var fromPanl = "";
		
		if(mx=='yh'){
			if(ZQ.muliptile!=1){
				alert("奖金优化只支持1倍优化");
				return;
			}
			fromPanl = "prizereview";
			var cc = ZQ.wasMuster.split(",");
			for(var d = 0 ; d<cc.length; d++)
			{
				if(DC_McN_Map[cc[d]].indexOf('串1')==-1){
					alert("奖金优化只支持串1过关！");
					return;
				}
			}
		}else if(mx='m'){
			fromPanl = "myform";
		}
		ZQ.$(fromPanl).submit();
	}
};
 
$(function(){
	var sy = all_config[javaAgras.gameid][javaAgras.type+javaAgras.gameid];
	$('.lottery_nav ul li').removeClass().eq(sy).addClass('lothot');
	show_encounter();
	$(".time_k_j p").click(function(){
			$(this).addClass('timeOk').siblings().removeClass();
			$('.timeEntron span').hide();
			if($(this).text() == '截止'){
				$('.jz').show();
			}else{
				$('.ks').show();
			}
	});
	$(".ipt > input").bind('click',function(){
		bet_config.gallOption('rc');
		bet_config.CountAward();
	});
	$.divClientShow('buy_list','buylistcon','buylistcon_lik','listMain');
	$.McNShow('ddMatch','matchrc','matchzk','listMatch');
	$.offsetScr('betbottom','BettingRegion');
	$.offsetTopTitle('encounterMain','marketTitle');
});