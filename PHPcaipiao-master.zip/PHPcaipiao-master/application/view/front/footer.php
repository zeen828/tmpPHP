<div class="clear"></div>
<footer>
    <h1>神马计划开奖网</h1>
    <p>开奖最快的专业彩票开奖网站</p>
    <p><script language="javascript" src=" http://count30.51yes.com/click.aspx?id=307538217&logo=9" charset="gb2312"></script> </p>
</footer>