<?php
return array(
    'host'=>'127.0.0.1',
    'dbuser'=>'root',
    'dbpwd'=>'root',
    'dbname'=>'cai',
    'charset'=>'utf8',
    'port'=>3306,
    'prefix'=>''
);