<?php
echo 123;
Echo 456;
ECHO 789;
EchO 10;
ecHo 11;
eCho 12;